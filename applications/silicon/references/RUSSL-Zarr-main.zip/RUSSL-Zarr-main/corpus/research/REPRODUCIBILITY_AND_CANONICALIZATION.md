# Reproducibility and Canonicalization Research Note

**Corpus:** 2.0.0. **Compatibility baseline:** existing RUSSL/1.0 identity domains. This note explains limits; it does not silently replace WP17 or invent a new cryptographic profile.

## Four different equalities

1. **Source byte equality:** exact accession bytes have the same ordinary SHA-256.
2. **Canonical source equality:** the identified UTF-8/NFC/LF source transformation yields equal bytes in its language domain.
3. **Structured identity equality:** the exact declared JSON serializer/domain emits equal bytes before hashing.
4. **Logical sample equivalence:** field samples/axes/types/metadata satisfy an explicitly selected comparison, which may survive changes in physical encoding.

A test of one equality does not prove another. Hash domains prevent confusion only if implementations use identical input bytes and versioned domain names. Archive checksum equality authenticates neither authorship nor approval.

## Python profile versus RFC 8785

The reference identity helper documents legacy compact sorted Python JSON. It should be named accordingly. [RFC 8785 JCS, June 2020](https://www.rfc-editor.org/rfc/rfc8785.html) (accessed 2026-10-09) additionally prescribes ECMAScript numeric serialization, UTF-16 property-key ordering, and preserved Unicode string content. Python codepoint key ordering and floating textual forms can differ. Simple no-whitespace/sorted-keys output is insufficient to claim JCS.

Examples motivating independent vectors: a floating value 1.0 can produce Python `1.0` versus JCS `1`; negative floating zero can differ; a supplementary-plane property key and a BMP key above the surrogate range can order differently. These are comparison examples, not a claim that every input path accepts all such values. Source NFC is a separate language normalization rule; applying it indiscriminately to JCS JSON strings changes their content.

Preserve RUSSL/1.0 identity behavior where compatibility is promised. If a JCS profile is adopted later, define a new versioned domain, accepted-number/string domain, cross-runtime vectors and identity migration map. Do not relabel old hashes as JCS.

## Reproduction obligations

Record exact serializer/runtime versions, accepted JSON domain, duplicate-key rejection, nonfinite rejection, resource limits, decimal/string treatment, Unicode handling, raw canonical bytes and raw domain prefix/NUL bytes. Run independent cross-runtime vectors covering key ordering, escapes, integer bounds, float magnitude and exponent notation. Reference-code regeneration of its own golden outputs is not independent verification.

For binary samples, declare endianness, dtype, shape/order, missing-sample rules and treatment of signed zero/NaN payloads. Preserve source blobs separately from normalized identities. Approximate numerical equality requires tolerances and scientific rationale; it cannot replace exact identity in integrity checks.
