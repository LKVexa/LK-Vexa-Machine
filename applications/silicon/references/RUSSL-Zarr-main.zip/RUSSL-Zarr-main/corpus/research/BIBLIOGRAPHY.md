# Research Bibliography and Source Dispositions

**Corpus:** 2.0.0. **External access date:** 2026-10-09. Machine-readable companion: `source_registry.json`. References support the scope stated here, not institutional approval or validation of P5×S³/8S.

| ID | Primary source and version | Role / limit |
|---|---|---|
| `EXT-BCP14-2119` | Bradner, [RFC 2119: requirement-level key words](https://www.rfc-editor.org/rfc/rfc2119.html), March 1997 | Terminology; no RUSSL standards status |
| `EXT-BCP14-8174` | Leiba, [RFC 8174: uppercase clarification](https://www.rfc-editor.org/rfc/rfc8174.html), May 2017 | Terminology clarification |
| `EXT-JCS` | Rundgren et al., [RFC 8785: JSON Canonicalization Scheme](https://www.rfc-editor.org/rfc/rfc8785.html), June 2020 | Comparison with corpus identity serialization; JCS conformance not claimed |
| `EXT-TIFF6` | Aldus, [TIFF Revision 6.0](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf), final 1992-06-03; original text hosted by ITU | TIFF boundary; not a generic codec/extension guarantee |
| `EXT-BIGTIFF` | LibTIFF, [BigTIFF Design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html), documentation 4.7.2 observed | Offset/directory extension; page mutable, design has no separately asserted numbered revision |
| `EXT-COG` | OGC, [Cloud Optimized GeoTIFF Standard 21-026](https://docs.ogc.org/is/21-026/21-026.html), 1.0, 2023-07-14 | Proposed class-specific adapter/hosting boundary; no executed certification |
| `EXT-NGFF` | OME, [OME-Zarr specification / NGFF](https://ngff.openmicroscopy.org/0.5/), 0.5 | Proposed adapter metadata/axis boundary |
| `EXT-ZARR3` | Zarr core developers, [Zarr core specification](https://zarr-specs.readthedocs.io/en/latest/v3/core/index.html), 3.1 observed | Zarr v3 representation; mutable URL, extension snapshots needed |
| `EXT-FAIR` | Wilkinson et al., [FAIR Guiding Principles](https://pmc.ncbi.nlm.nih.gov/articles/PMC4792175/), Scientific Data 3:160018 (2016), DOI 10.1038/sdata.2016.18 | Stewardship goals; not certification |
| `EXT-PROV` | W3C, [PROV-DM](https://www.w3.org/TR/2013/REC-prov-dm-20130430/), Recommendation 2013-04-30 | Proposed provenance crosswalk; no PROV serialization claim |
| `EXT-SSDF` | NIST, [SP 800-218: SSDF](https://csrc.nist.gov/pubs/sp/800/218/final), 1.1, February 2022 | Security-lifecycle policy input; no full implementation/endorsement |
| `EXT-IR` | NIST, [SP 800-61 Rev. 3](https://csrc.nist.gov/pubs/sp/800/61/r3/final), April 2025 | Incident-response policy input; no operating-effectiveness claim |

## Embedded and unavailable sources

The four original MSSL modules, master-law image, historical construction workflow and both lineage archives remain embedded; see `SOURCE_AUTHORITY.md` for verified hashes. The lineage implementation describes its own historical behavior; it is not executable authority over current RUSSL semantics.

The lab source `8S_Labs_3001_4000b.pdf`, pages 136–145, is unavailable. Parent RUSS 1.1 is a declared digest/lineage reference without independently accessible original bytes. Original authorship, MSSL internal-identity rules, source rights, empirical datasets and institutional attestations are not supplied. No bibliography entry fills those gaps.

## Citation policy

Cite exact version and URL, access date, embedded availability and claim scope. For mutable URLs, preserve a verified snapshot/commit before operational reliance; the registry records that this is pending. Distinguish an author's claim from a reproduced result. Standards references constrain an adapter; they do not independently establish that adapter's correctness. Do not reproduce full external standards or infer corpus redistribution rights from access to a cited page.

## Additional attachment audit references

The nineteen added sources and 159 decisions have a separate [primary reference index](ADDITIONAL_PRIMARY_REFERENCE_INDEX.md), with [source intake](ADDITIONAL_SOURCE_INTAKE.json) and a [research integration report](RESEARCH_INTEGRATION_REPORT.md). Identity/abstract checks, selected methods/results and complete uploaded-paper inspection are explicitly distinguished. Quantitative claims are retained only with their inspected configuration and evidence scope.
