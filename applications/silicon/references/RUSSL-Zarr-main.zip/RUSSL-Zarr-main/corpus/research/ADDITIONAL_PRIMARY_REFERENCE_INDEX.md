# Additional Primary Reference Index

Assessment date: 2026-10-09. This index joins 62 review-reference records by URL into 61 external reference locations. A reference can have different inspection scopes in the two reviews. It is not a list of 62 replicated experiments or fully inspected papers. The detailed registers preserve access limitations, authors, dates/versions where established, explicit unknowns and the precise claim decisions.

| Primary title and direct location | Version recorded | Inspection scopes | Review reference IDs |
|---|---|---|---|
| [1-bit LAMB: Communication Efficient Large-Scale Large-Batch Training with LAMB's Convergence Speed](https://arxiv.org/abs/2104.06069v2) | arXiv:2104.06069v2 (2021-10-06) | partial; complete_23_page_uploaded_text_and_selected_rendered_pages | LAMB in additional_math_claims.json; P-1BLAMB in additional_systems_claims.json |
| [3D-SHOT temporally focused holographic optogenetics](https://pmc.ncbi.nlm.nih.gov/articles/PMC5663714/) | not established | primary_paper_selected_methods_results | P-3DSHOT in additional_systems_claims.json |
| [A p-adic version of AdS/CFT](https://arxiv.org/abs/1705.00373) | arXiv:1705.00373v1 | abstract | ADS in additional_math_claims.json |
| [Acousto-Optic devices, RF drivers, Custom solutions — Catalog 2022](https://aaoptoelectronic.com/wp-content/uploads/2024/04/Plaquette-AA-OPTO-2022-1.pdf) | Catalog 2022 | partial | AO_CAT in additional_math_claims.json |
| [Analogy Making and Logical Inference on Images using Cellular Automata based Hyperdimensional Computing](https://ceur-ws.org/Vol-1583/CoCoNIPS_2015_paper_3.pdf) | not established | partial | CA in additional_math_claims.json |
| [AWQ: Activation-aware Weight Quantization for LLM Compression and Acceleration](https://arxiv.org/abs/2306.00978) | not established | primary_paper_identity_method_scope | P-AWQ in additional_systems_claims.json |
| [Band-Limited Angular Spectrum Method for Numerical Simulation of Free-Space Propagation in Far and Near Fields](https://opg.optica.org/oe/abstract.cfm?uri=oe-17-22-19662) | not established | partial | ASM in additional_math_claims.json |
| [BigTIFF Design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html) | BigTIFF format version 43; LibTIFF 4.7.2 documentation as displayed | official spec | BIGTIFF in additional_math_claims.json |
| [BitNet b1.58 2B4T Technical Report](https://arxiv.org/abs/2504.12285) | not established | primary_paper_identity_abstract | P-BITNET-2B in additional_systems_claims.json |
| [Comparative VSA experiments](https://arxiv.org/abs/2001.11797) | not established | primary_paper_selected_scope | P-VSA in additional_systems_claims.json |
| [Computations with p-adic numbers](https://arxiv.org/pdf/1701.06794) | arXiv:1701.06794v1 | partial | PADIC in additional_math_claims.json |
| [Computations with p-adic numbers](https://arxiv.org/abs/1701.06794) | not established | primary_paper_identity_and_precision_scope | P-CARUSO in additional_systems_claims.json |
| [Computer-generated double-phase holograms](https://opg.optica.org/ao/abstract.cfm?uri=ao-17-24-3874) | not established | abstract | DPM in additional_math_claims.json |
| [Continuous Optimization for p-Adic Models](https://arxiv.org/abs/2609.25501) | not established | primary_preprint_identity_abstract | P-PADIC-OPT in additional_systems_claims.json |
| [Deep-brain thermogenetic manipulation using photothermal nanotransducers](https://pmc.ncbi.nlm.nih.gov/articles/PMC9232843/) | not established | primary_paper_selected_methods_results | P-MINDS in additional_systems_claims.json |
| [DeepSpeed official 1-bit LAMB tutorial source](https://raw.githubusercontent.com/deepspeedai/DeepSpeed/master/docs/_tutorials/onebit-lamb.md) | not established | official_document_selected_sections | P-DEEPSPEED in additional_systems_claims.json |
| [Efficient Classical Simulation of Continuous Variable Quantum Information Processes](https://arxiv.org/abs/quant-ph/0109047) | arXiv:quant-ph/0109047v2 (2002-02-18) | abstract | GAUSS in additional_math_claims.json |
| [Explosive higher-order Kuramoto dynamics on simplicial complexes](https://arxiv.org/abs/1912.04405) | arXiv:1912.04405v3 (2020-05-18) | abstract | KURAMOTO in additional_math_claims.json |
| [Feedback Shift Registers, 2-Adic Span, and Combiners with Memory](https://www.math.ias.edu/~goresky/pdf/2adic.jour.pdf) | not established | partial | FCSR in additional_math_claims.json |
| [GEO GSE312903: Connectome-seq](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE312903) | not established | primary_author_dataset_record | P-CONNECTOME-DATA in additional_systems_claims.json |
| [GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers](https://arxiv.org/abs/2210.17323) | not established | primary_paper_identity_method_scope | P-GPTQ in additional_systems_claims.json |
| [Graphics Interchange Format Version 89a](https://www.w3.org/Graphics/GIF/spec-gif89a.txt) | 89a | official spec | GIF89A in additional_math_claims.json |
| [Holographic Reduced Representations](https://pages.ucsd.edu/~msereno/170/readings/06-Holographic.pdf) | not established | full text | HRR in additional_math_claims.json |
| [Intel VTune Hybrid CPU Analysis](https://www.intel.com/content/www/us/en/docs/vtune-profiler/user-guide/2026-0/hybrid-cpu-analysis.html) | not established | official_document_selected_sections | P-VTUNE in additional_systems_claims.json |
| [Known-plaintext attack on optical encryption based on double random phase keys](https://opg.optica.org/ol/abstract.cfm?uri=ol-31-8-1044) | not established | abstract | DRPE in additional_math_claims.json |
| [Lenovo IdeaPad Pro 5 16IMH9 PSREF](https://psref.lenovo.com/syspool/Sys/PDF/IdeaPad/IdeaPad_Pro_5_16IMH9/IdeaPad_Pro_5_16IMH9_Spec.pdf) | not established | official_specification_selected_pages | P-LENOVO-PRO in additional_systems_claims.json |
| [Lenovo IdeaPad Slim 5 16IRH10 PSREF](https://psref.lenovo.com/syspool/Sys/PDF/IdeaPad/IdeaPad_Slim_5_16IRH10/IdeaPad_Slim_5_16IRH10_Spec.pdf) | not established | official_specification_selected_pages | P-LENOVO-SLIM in additional_systems_claims.json |
| [Linux kernel Dynamic DMA mapping Guide](https://docs.kernel.org/core-api/dma-api-howto.html) | not established | official_document_selected_sections | P-DMA in additional_systems_claims.json |
| [Linux perf security documentation](https://docs.kernel.org/admin-guide/perf-security.html) | not established | official_document_selected_sections | P-PERF in additional_systems_claims.json |
| [Microsoft AVML README](https://raw.githubusercontent.com/microsoft/avml/main/README.md) | not established | official_source_selected_sections | P-AVML in additional_systems_claims.json |
| [MINFLUX nanoscopy at nanometer-scale resolution](https://www.nature.com/articles/s41592-019-0688-0) | not established | primary_paper_selected_results_figures | P-MINFLUX in additional_systems_claims.json |
| [Model-Based Real-Time Synthesis of Acousto-Optically Generated Laser-Beam Patterns and Tweezer Arrays](https://arxiv.org/html/2512.16774v1) | arXiv:2512.16774v1 (2025-12-18) | partial | AOD in additional_math_claims.json |
| [Nanos GPU accelerated computing tutorial](https://nanovms.com/dev/tutorials/gpu-accelerated-computing-nanos-unikernels) | not established | official_document_selected_sections | P-NANOS in additional_systems_claims.json |
| [Neuromorphic Visual Scene Understanding with Resonator Networks](https://arxiv.org/html/2208.12880v4) | arXiv:2208.12880v4 | primary_paper_selected_methods_results | P-RESONATOR in additional_systems_claims.json |
| [NVIDIA GPUDirect RDMA documentation](https://docs.nvidia.com/cuda/gpudirect-rdma/index.html) | not established | official_document_identity_selected_sections | P-CUDA-RDMA in additional_systems_claims.json |
| [OCP Microscaling Formats (MX) Specification v1.0](https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf) | v1.0 | primary_specification_selected_table | P-MX in additional_systems_claims.json |
| [OGC Cloud Optimized GeoTIFF Standard](https://docs.ogc.org/is/21-026/21-026.html) | 1.0; OGC document 21-026 | official spec | COG in additional_math_claims.json |
| [OME-TIFF specification](https://docs.openmicroscopy.org/ome-model/6.3.1/ome-tiff/specification.html) | OME Data Model and File Formats 6.3.1 documentation | official spec | OME in additional_math_claims.json |
| [OME-Zarr specification](https://ngff.openmicroscopy.org/0.5/) | Released metadata version 0.5; page history includes clarification revision 0.5.2 (2025-01-10) | official spec | NGFF in additional_math_claims.json |
| [Onset of non-Gaussian quantum physics in pulsed squeezing with mesoscopic fields](https://arxiv.org/html/2111.13799v1) | arXiv:2111.13799v1 | full text | QGIF in additional_math_claims.json |
| [Optical diffractive neural network-based orbital angular momentum mode fixed-base multiplication/division](https://doi.org/10.1364/OE.581948) | Journal version of record | partial | OAM in additional_math_claims.json |
| [Optical Full Adder Based on Integrated Diffractive Neural Network](https://pmc.ncbi.nlm.nih.gov/articles/PMC12195495/) | Journal version of record via PubMed Central | full text | ADDER in additional_math_claims.json |
| [p-adic Cellular Neural Networks: Applications to Image Processing](https://arxiv.org/abs/2210.14132) | arXiv:2210.14132v2 (2023-01-16) | abstract | CNN in additional_math_claims.json |
| [p-adic CFT is a holographic tensor network](https://arxiv.org/html/1902.01411v2) | arXiv:1902.01411v2 (2019-05-22) | partial | CFT in additional_math_claims.json |
| [p-Adic Diffusion and Random Walks on [0,1]](https://arxiv.org/abs/2608.02103) | arXiv:2608.02103v2 (2026-08-10) | abstract | MONNA in additional_math_claims.json |
| [PCI-SIG 2020 Update](https://pcisig.com/sites/default/files/files/PCI-SIG%202020%20Annual%20Press%20Conference_final.pdf) | 2020 annual press-conference presentation | full text | PCIE in additional_math_claims.json |
| [Plate1995 Holographic Reduced Representations](https://redwood.berkeley.edu/wp-content/uploads/2020/08/Plate-HRR-IEEE-TransNN.pdf) | not established | primary_host_retrieval_failed_mirror_garbled | P-PLATE in additional_systems_claims.json |
| [RFC-5: Coordinate Systems and Transformations](https://ngff.openmicroscopy.org/rfc/5/) | RFC-5 updated proposal; associated version 0.6.dev3; state S3 (Update implementations) | official spec | RFC5 in additional_math_claims.json |
| [SmoothQuant: Accurate and Efficient Post-Training Quantization for Large Language Models](https://proceedings.mlr.press/v202/xiao23c/xiao23c.pdf) | not established | primary_paper_selected_method_figure | P-SMOOTHQUANT in additional_systems_claims.json |
| [Sono-optogenetics](https://pmc.ncbi.nlm.nih.gov/articles/PMC6936518/) | not established | primary_paper_selected_methods_results | P-SONO in additional_systems_claims.json |
| [Sparse p-Adic Data Coding for Computationally Efficient and Effective Big Data Analytics](https://arxiv.org/abs/1604.06961) | arXiv:1604.06961v1 | abstract | SPARSE in additional_math_claims.json |
| [Synaptic MEMOIR preprint](https://pmc.ncbi.nlm.nih.gov/articles/PMC12703991/) | preprint v1 | primary_preprint_selected_methods_results | P-MEMOIR in additional_systems_claims.json |
| [Tensor networks, p-adic fields, and algebraic curves: arithmetic and the AdS3/CFT2 correspondence](https://arxiv.org/abs/1605.07639) | arXiv:1605.07639v2 (2017-07-03) | abstract | BT in additional_math_claims.json |
| [The Era of 1-bit LLMs: All Large Language Models are in1.58Bits](https://arxiv.org/abs/2402.17764) | not established | primary_paper_identity_method_scope | P-BITNET in additional_systems_claims.json |
| [TIFF Revision 6.0](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf) | Revision 6.0 | official spec | TIFF in additional_math_claims.json |
| [TIIF-Bench: How Does Your T2I Model Follow Your Instructions?](https://arxiv.org/abs/2506.02161) | arXiv:2506.02161v3 (2026-07-12) | abstract | TIIF in additional_math_claims.json |
| [Turing patterns in a p-adic FitzHugh-Nagumo system on the unit ball](https://arxiv.org/abs/2308.04364) | arXiv:2308.04364v3 (2023-11-21) | abstract | FHN in additional_math_claims.json |
| [Unikernel Linux (UKL)](https://arxiv.org/abs/2206.00789) | not established | primary_paper_identity_abstract | P-UKL in additional_systems_claims.json |
| [Unikraft: Fast, Specialized Unikernels the Easy Way](https://arxiv.org/abs/2104.12721) | not established | primary_paper_selected_sections | P-UNIKRAFT in additional_systems_claims.json |
| [vLLM Quantized KV Cache documentation](https://docs.vllm.ai/en/latest/features/quantization/quantized_kvcache/) | not established | official_document_selected_sections | P-VLLM in additional_systems_claims.json |
| [Wavelet analysis as a p-adic spectral analysis](https://arxiv.org/abs/math-ph/0012019) | arXiv:math-ph/0012019v3 (2001-02-23) | abstract | KOZYREV in additional_math_claims.json |

Use the [mathematical register](additional_math_claims.json), [systems register](additional_systems_claims.json), [central source registry](source_registry.json) and [integration report](RESEARCH_INTEGRATION_REPORT.md) together. External URLs may change; reviewed bytes are not deposited as archival snapshots. Only the nineteen uploaded sources and their extracts have full local byte/digest preservation. A primary citation cannot authenticate an export or validate a cross-domain architecture by itself.
