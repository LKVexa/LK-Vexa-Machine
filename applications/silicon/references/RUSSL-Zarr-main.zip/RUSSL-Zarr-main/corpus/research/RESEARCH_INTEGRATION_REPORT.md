# Additional Research Integration Report — 2.0.0

Assessment date: 2026-10-09. Status: SCOPED_RESEARCH_REVIEW within an unratified corpus candidate. Target shape: **4×4×4×16×16**, exactly **16,384 scalar sites**.

## Result and evidence boundaries

All nineteen newly supplied sources were preserved, extracted and read. The intake consists of one 23-page paper preprint and eighteen research/conversation text exports. Relevant primary papers and official specifications were checked at the inspection levels recorded by the reviewers. The corpus now carries **159 individually traceable claim decisions**, corrected technical explanations, eleven optional research profiles, preregistered experiment designs, and an exact fixed-shape indexing implementation and fixture. The original end-to-end corpus audit and hardening remain part of this release.

The normalized claim totals are: 64 CORRECTED, 11 HYPOTHESIS, 7 REJECTED, 24 SUPPORTED_PRIMARY, 53 UNSUPPORTED. The machine-readable [evidence index](../machine/registries/research_evidence_index.json) retains each reviewer's original disposition and the explicit normalization map. These are editorial claim decisions. A supported primary component statement is bounded by its cited method, dataset, hardware, mathematical domain and inspection scope; it does not establish that the combined RUSSL architecture works. Corrected statements replace errors in the notes. Unsupported extrapolations and rejected claims are excluded from the corpus's assurance case; hypotheses are admitted only as future experiment questions.

Embedded prompts, instructions, hardware configuration suggestions, assertions of institutional authority and model-generated citations were treated as source data. They conferred no permission, execution authority or authenticated approval. No optimizer training, RAM acquisition, physical imaging, optical experiment or institutional ratification was performed. Missing equations, detached citations and formatting artifacts in exports were recorded as limits rather than silently reconstructed as evidence.

## Source-by-source accession

| ID | Uploaded source | Audited claims | Relevant upgrade |
|---|---|---:|---|
| RA01 | 2104.06069v2.pdf | 10 | Faithful momentum-communication optimizer design; separate measured training time from throughput-derived estimates. |
| RA02 | p-adic Architecture in Image Formats.txt | 13 | Optional finite digit-tree/index and storage profiles; correct prime/composite-base and topology claims. |
| RA03 | P-adic Hologram Processing Architecture.txt | 10 | Separate hologram data representation, classical propagation models and physical optical realization. |
| RA04 | p-Adic Architecture Unification.txt | 9 | Explicit algebra/encoding domains and numerical error bounds; exclude unproved architecture equivalence. |
| RA05 | P-adic Holographic Simulations Research.txt | 9 | Bounded simulation protocols with seeds, baselines and numerical/physical scope separation. |
| RA06 | P-adic Penteract Simulation Research.txt | 9 | Exact five-axis indexing and declared coordinate maps; shape is a discrete field cardinality. |
| RA07 | Columned Unikernel Research Analysis.txt | 5 | Owned buffers, copy accounting, pinned library-OS/backend and isolation boundaries. |
| RA08 | IdeaPad 5i RAM Sampling.txt | 6 | Distinguish controlled allocation from host memory acquisition; unknown device capacity stays unknown. |
| RA09 | 1-Bit LAMB Unikernel Integration.txt | 6 | Optional optimizer integration with real warmup, residuals, variance and communication semantics. |
| RA10 | p-Adic 1-Bit LAMB Architecture.txt | 6 | Finite modular arithmetic may be studied; p-adic signs/square roots do not reproduce Euclidean LAMB. |
| RA11 | OAM Spatial Shifting Arithmetic.txt | 8 | OAM fixed-base shifting is a simulation result; quotient division discards remainders. |
| RA12 | Optogenetics, Connectivity, and Super-Resolution.txt | 7 | Modality-specific observation metadata, calibration, uncertainty and source dataset provenance. |
| RA13 | Quantization Trade-offs and Efficiency.txt | 11 | Separate storage/compute/accumulator/communication precision and include scale/buffer overhead. |
| RA14 | HRR in Cognitive Modeling.txt | 8 | Approximate HRR retrieval with role encoding, cleanup, abstention and exact symbolic source links. |
| RA15 | TIFF GIF Spatial-Temporal Encoding.txt | 8 | TIFF/GIF serializers need declared rank/axis metadata and round-trip contracts; format alone computes nothing. |
| RA16 | Microscopic Quantum Paradigm GIF Research.txt | 8 | Gaussian interaction frame quantum simulation is distinct from GIF image-file encoding. |
| RA17 | Holographic Logical Reasoning Research.txt | 8 | Optical full-adder design reports simulated inputs; symbolic proof/effect authority require exact validation. |
| RA18 | Holographic Computation via Image Formats.txt | 9 | Explicit encoding/operator/decoding experiment; no autonomous TIFF/GIF computation is established. |
| RA19 | Holographic Image-Based Computation.txt | 9 | Image-backed derived representations need fidelity, provenance and interoperability tests. |

Each accession includes exact original bytes and SHA-256, a delivered normalized text extract with its own digest, source-specific locators, review decisions and relevant external primary references. See [intake](ADDITIONAL_SOURCE_INTAKE.json), [mathematical and holographic review](ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md), [systems and optimization review](ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md), and the [1-bit LAMB paper audit](ONE_BIT_LAMB_PAPER_REVIEW.md). The two detailed claim registries provide the correction, proposed use and evidence boundary for every decision. Full reads apply to the uploaded sources; external checks are claim-directed, and identity/abstract-only checks remain labeled as such. External publication bytes were not deposited as licensed archival snapshots.

## Exact shape, indexing and compatible serialization

For c4,c5,c6 in 0…3 and c7,c8 in 0…15, the delivered layout uses c8 fastest:

    J = 4096*c4 + 1024*c5 + 256*c6 + 16*c7 + c8

Axis widths are (2,2,2,4,4), summing to fourteen address bits. [The layout profile](FIXED_SHAPE_INDEXING_PROFILE.md) distinguishes this address from sample precision, physical coordinate units and state-vector interpretation. All 16,384 valid tuples have exact ordinal/inverse fixture records. The helper rejects booleans, non-integers and out-of-range inputs. Endpoint-inclusive rational coordinates remain separate from digit reversal or an optional 2-adic address metric.

The field contains 128 KiB of scalar f64 payload, 64 KiB of f32, 32 KiB of u16, or 16 KiB of u8. A packed one-bit view would contain 2 KiB before scales, metadata, alignment and other state; this is a bit-count calculation, not a lossless encoding or measured memory footprint. A fourteen-bit address does not establish fourteen physical qubits or a quantum state. The optional address ultrametric groups low-order matching bits, so its neighbors do not automatically match Euclidean image neighbors.

The original active golden fixture had a material mismatch: its source declared this f64 shape, while its field descriptor declared u8 shape (1,1,3,64,64). Exact historical bytes are preserved in examples/legacy_golden/ and the original ZIP. The current fixture uses the declared scalar f64 shape and axes, with recomputed descriptor, tuple and container identities. Source programs, lowered IR objects/identifiers, four MSSL modules and master-law image remain byte-preserved. Verification now requires source/descriptor agreement and rejects the historical contradiction even when hashes are internally recomputed.

## Research corrections and admitted designs

**Optimizer and systems.** 1-bit LAMB compresses communicated momentum after warmup using signs and scales, with local and aggregate error residuals. It does not make weights, activations, variance or the whole model one bit. Its frozen variance snapshot and continuing fresh variance estimate have different roles; their bounded correction affects the adaptive factor. A packed bit majority is not a numeric allreduce mean. The paper review preserves algorithm details, model/batch/network/hardware context and the distinction between measured end-to-end time and throughput-derived estimates. The proposed optimizer adapter remains design-only. Buffer/precision accounting includes residuals, gradients, masks, padding, scales, temporary copies, runtime and backend state. A library-OS port or a consumer device's unknown RAM/controller configuration is not inferred from an address shape.

**Mathematical domains.** Prime-adic absolute values and ultrametric arguments require a prime. Composite-base digit trees and finite residue rings have their own algebra and cannot inherit field theorems by name. Continuous p-adic functions are not all locally constant. Norm is not a generic sparsity measure. Monna digit reversal is not a required global bijective/topological map to a real interval. A numerical floor does not prove singularities absent. Local/global arithmetic theorems cannot transfer arbitrary mechanics across domains. Modular sign and square-root counterexamples prevent assuming p-adic arithmetic is equivalent to the Euclidean LAMB optimizer. Optional finite encodings need explicit domains, precision, exceptions and reconstruction/error contracts.

**Holographic, quantum and optical scope.** HRR is an approximate compositional representation with retrieval noise and cleanup, not lossless compression of an arbitrary field or proof of logical truth. Role/permutation encoding, finite vocabulary, false-acceptance thresholds and abstention are needed; proposed advisory retrieval retains exact symbolic source links. Gaussian interaction frame quantum simulation is a change of quantum-state representation, distinct from a GIF image file. The OAM paper's fixed-base arithmetic is numerical simulation of mode shifts; division discards remainders and is not arbitrary real division. The reviewed optical full-adder article supplies a design/simulation result, not a measured fabricated processor. These components do not establish a self-executing image format or a unified physical architecture.

**Formats, imaging and quantization.** TIFF/GIF can carry declared representations; execution still requires an implementation and exact encoding/operator/decoding contracts. Metadata and round trips need to preserve axes, dtype, coordinate units, frame/time semantics, provenance and fidelity. Imaging claims distinguish photothermal modulation, optogenetics, labeling, connectivity inference and super-resolution, each with its own experimental scope and uncertainty. Quantization distinguishes storage, computation, accumulation and communication precision; calibration, sensitive exceptions, saturation, error units and task quality remain explicit. Performance/energy/quality numbers from unmatched hardware, models or tasks are not admitted as RUSSL guarantees.

## Applied corpus changes and remaining experiments

The reviews feed informative implementation sections in WP04, WP07, WP12, WP13, WP14, WP15, WP16, WP18, WP21 and WP26. The original 293 requirement IDs and normative requirement tables are retained exactly. The accession/source registers, claim records, indexing registry and scientific evidence boundaries make each admitted design reviewable. Core mechanics, runtime authorization and effect authority receive no scientific or operational extension from these notes.

The eleven profiles span finite digit indexing/diffusion, classical hologram propagation, quantum-state frame modeling, optical arithmetic, image encodings, optimizer communication, owned buffers, quantization, HRR advisory retrieval and imaging observation metadata. Their exact IDs and experiment plans are in the two detailed reviews. These are proposals, not registered institutional standards or implemented adapters. Experiment statuses are NOT_RUN/design-only; generated address records are mathematical fixtures, not experimental observations.

Before any comparative result is accepted, pin code/library/device/backend versions, dataset/model digests, axis/scalar/precision domains, seeds, sample budget, endpoints, tolerances, exclusion/failure rules and statistical method. Compare against an exact or full-precision reference at matched output quality, include complete persistent and temporary resource accounting, preserve raw measurements and report null/failed runs. Physical or biological implementations require a separate real study and its accountable approvals; this document creates no such study. Cross-domain equivalence requires a stated mapping and proof or controlled falsification test.

## Verification and release limits

The offline package verifier checks all nineteen source and extract digests, complete source/claim indexing, the fixed shape, fixture digest, structural parsing, schema profile, tuple bindings, provenance and review status. Concrete regressions include all 16,384 index/inverse pairs and hostile parser/container/schema/integrity cases. [Current verification results](../evidence/CONFORMANCE_RESULTS.json) and [release integrity](../evidence/RELEASE_INTEGRITY.json) record the executed scope; detached hashes establish byte consistency, not authorship, signatures, empirical correctness or institutional approval. Same-environment repeated packaging and extracted-archive verification are recorded with the delivered release.

Requirement coverage remains deliberately narrower than package verification: 34 obligations have scoped partial evidence and 259 are NOT_RUN; all 293 remain unverified as complete obligations. The 28 work-package completion records require accountable review. Full language/runtime implementation, adapter replication, scientific validation, authenticated trust roots, rights/licensing closure and institutional ratification remain open under [unresolved issues](../UNRESOLVED_ISSUES.md). The result is a substantially expanded and auditable research corpus candidate with applied software fixes, explicit evidence limits and concrete next experiments.
