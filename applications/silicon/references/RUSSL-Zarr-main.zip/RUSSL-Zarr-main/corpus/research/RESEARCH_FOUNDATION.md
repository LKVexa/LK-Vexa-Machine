# RUSSL Research Foundation

**Corpus:** 2.0.0; software compatibility RUSSL/1.0. **Status:** research framework and formalized source inputs. **Review date:** 2026-10-09.

## Research objects and custody

The supplied `master_coupled_mechanics.mssl`, `lab_stack.mssl`, `product_metrics.mssl`, `final_admission.mssl` and `research/source/master_law.png` are immutable source objects. Their independently recomputed file digests match the supplied baseline registry. The image digest is `12e144e83daf6b562c64b53f7a5f609524dbad9cd908953ca882031825911d86`, also declared inside the master module. File digests, source internal IDs and internal kappa fields are different evidence objects; matching an outer digest does not validate an unspecified internal construction.

The image was visually inspected as a mathematical source. It contains more mechanics than the master's reduced literal strings: coupling, phase evolution, field terms, sphere/embedding relations and geometric/classification quantities. The reduced MSSL does not constitute a complete executable implementation of the image. No source bytes are changed to reconcile them.

## Statement and evidence taxonomy

Use `DEFINITION`, `ASSUMPTION`, `HYPOTHESIS`, `DERIVATION`, `SIMULATION_RESULT`, `EMPIRICAL_RESULT` and `EXTERNAL_REPLICATION`. Each statement record contains ID, wording, scope/domain, source path/digest, dependencies, evidence type/grade, uncertainty, counterevidence, reviewer status and revision. Formal derivation requires explicit premises and proof; test success is not a proof for untested inputs.

| Grade | Evidence | Permitted interpretation |
|---|---|---|
| E0 | Assertion / undeveloped proposal | No verified behavior |
| E1 | Definition, explicit mathematical derivation or complete formal specification | Meaning under stated assumptions; no physical truth implied |
| E2 | Deterministic computation with supplied inputs/tool/results | Reproduced behavior within recorded domain |
| E3 | Simulation with code, parameters, seeds, protocol and outputs | Model behavior; not empirical validation |
| E4 | Empirical observations with source dataset, measurement/selection model and uncertainty | Evidence for the declared observed setting |
| E5 | Independently reproduced/attested result with comparable scope | Independent evidence, not universal correctness |

Grades classify provenance, not a single maturity score; an E1 theorem and an E4 measurement answer different questions. Record unsupported assertions at E0 and supplied formulas as formalized inputs rather than labeling them proven derivations. Current software checks may support E2 for their exercised paths. There is no supplied E4/E5 evidence for P5×S³/8S mechanics.

## Question and hypothesis register

| ID / question | Falsifiable hypothesis | Design and null/comparator | Falsification criterion | Current status |
|---|---|---|---|---|
| `H-P5S3-001` Does the augmented representation improve prediction? | A completely specified M8 achieves preregistered held-out score gain above epsilon_gain against capacity-matched M7 | Paired held-out observations; equal search budget; ablations; null gain ≤ margin | Confidence interval fails the preregistered gain rule or gain disappears under fair matching | FORMALIZED-INPUT; score/data/model absent |
| `H-RESIDUAL-001` Is the added column independently informative? | Residual eta_ind exceeds a prespecified noise/conditioning null on untouched data | SVD/pseudoinverse protocol; measurement-noise controls; rank-matched synthetic matrices | Residual compatible with noise/null, unstable to solver tolerance or leakage | PROPOSED numerical study |
| `H-PENTERACT-001` Is mapping semantically reversible? | Finite supported fields preserve every selected sample/index under encoding/decoding and adapter axis permutations | Exact bit/sample comparison; exhaustive small-domain plus bounded randomized cases | Any unexplained sample/axis/type/transform mismatch | Engineering hypothesis; core fixtures only |
| `H-DISTRIBUTED-001` Does regional content addressing improve retrieval efficiency? | For a fixed workload, verified regional retrieval reduces transferred bytes and duplicate storage without changing accepted samples | Fixed data, request trace and faults; full-object baseline; identical caches/security | No cost benefit or any integrity/consistency failure in claimed scope | Architecture hypothesis; backend results absent |
| `H-METRICS-001` Are product indicators externally calibrated? | Fully defined metrics predict preregistered outcomes better than simple domain baselines and retain calibration under temporal shift | Temporal holdout; outcome definitions; domain controls; missingness/selection analysis | Poor calibration, no improvement, instability or ungoverned decision use | Labels only; no executable calibration/data |

The master gate's source `eta_ind >= epsilon_ind AND delta_8S > epsilon_gain` is a research condition, not a completed hypothesis test. The admission module also preserves a conditional catalog state and human authorization requirement. Fulfilling a statistical margin does not grant a capability.

## Methods and uncertainty

`research/MECHANICS_CRITICAL_REVIEW.md` establishes domain assumptions and source ambiguities; `research/EXPERIMENT_PROTOCOLS.md` specifies proposed experiment records, controls, analysis and reproducibility. Register primary endpoint, estimand, uncertainty method, exclusion criteria, sample-size justification and stopping rule before inspecting confirmatory outcomes. Distinguish exploratory findings and preregistered confirmation. Report adverse/null results, sensitivity to regularization, solver tolerance, seeds and data shifts, and multiplicity where endpoints/variants proliferate.

## Provenance and publication boundaries

Lab records 3131–3140 refer to `8S_Labs_3001_4000b.pdf#page=136` through `#page=145`; that PDF is not supplied. Flattened fraction layout, repeated indices and literal escape sequences make the preserved strings unsuitable as a verified numeric equation transcription. Product metrics supply names/calculation labels and units rather than a full algorithm. Obtain actual originals/data or keep these as unverified source claims; never invent missing pages or results.

External standards support software/profile design only. Their bibliography does not validate the original mechanics. `research/BIBLIOGRAPHY.md` and `research/source_registry.json` distinguish embedded, external-reviewed and unavailable sources. Unknown rights and sensitivity remain governed by the institutional policies.
