# Review of the supplied 1-bit LAMB paper

**Corpus:** 2.0.0 candidate. **Review date:** 2026-10-09. **Admission:** external research reference and proposed optional optimizer profile; no implemented RUSSL training runtime or reproduced benchmark.

## Source identity and inspection

RA01 is the uploaded `2104.06069v2.pdf`, archived unchanged as `lineage/research_additions/RA01.pdf`. SHA-256: `7bb1c6dcab2ab81265d00cf79f213c12f6a141afe4425e23b96d4170161ac2b3`. It is **1-bit LAMB: Communication Efficient Large-Scale Large-Batch Training with LAMB's Convergence Speed**, Conglong Li, Ammar Ahmad Awan, Hanlin Tang, Samyam Rajbhandari and Yuxiong He, arXiv v2, 6 October 2021. The supplied PDF contains 23 numbered pages, including references and appendix. Its identity/version was checked against the [primary arXiv record](https://arxiv.org/abs/2104.06069v2).

All 23 pages of the portable normalized extraction `research/extracted_sources/RA01.txt` were read, including Algorithm 1, both convergence tables, profiling results, momentum fusion/scaling details and the assumptions/proofs in Appendix A.7. PDF pages 5, 6 and 9 were rendered and visually inspected to verify Table 2, Algorithm 1, Table 4 and Figure 3; page 1 was also visually inspected during intake. Page numbers below mean the printed PDF page, which matches one-based physical page numbering in this file. The plain-text discussion attachments RA07, RA09 and RA10 are secondary notes; they do not override this paper. Several formulas in those notes have missing symbols, so they cannot serve as executable algorithm definitions.

## What is compressed

The method targets **communication in distributed data-parallel training**. Warmup uses baseline LAMB and ordinary uncompressed communication. The later stage communicates error-compensated **momentum**, encoded by sign bits plus scale information, rather than turning all model weights, forward activations, gradients, variance tensors or local arithmetic into one-bit objects. See PDF pp. 2-3, section 2; p. 6, Algorithm 1 lines 6-11; pp. 16-17, Appendix A.5.1-A.5.2.

Both the worker and the logical aggregation server retain compression residuals. The server in Algorithm 1 is a conceptual description: the distributed collective implementation partitions aggregation responsibilities across workers (p. 7, section 5; pp. 18-19, Appendix A.7.1). This does not imply that the paper implements a centralized, unikernel parameter server.

The compressed object is not a bare sign vector whose components can be summed as packed integers. It carries scales and is decoded for numeric averaging before it is recompressed with aggregation error feedback. Replacing that operation with majority voting defines another algorithm. For example, contributions with signs `+,+,-` and magnitudes `1,1,100` have positive majority sign but negative numeric mean. Bitwise arithmetic on packed sign words is likewise not a floating-point sum. RA10's in-network majority circuit cannot be called a faithful 1-bit LAMB implementation without a new specification and convergence study.

## State and adaptive scaling: the material correction

The phrase "freeze the variance" has a precise scope. At the end of warmup, the method stores a fixed preconditioning snapshot `v_Tw` and freezes the warmup moving average `c_avg`. It **continues updating a separate fresh variance `v_t`**. Algorithm 1, p. 6, line 3 explicitly requires this, and lines 15-20 specify its role; the prose on p. 7 confirms it.

For a layer/tensor, the paper's compressed-stage construction is:

```text
g_reconstructed,t = (m_global,t - beta1 * m_global,t-1) / (1 - beta1)
v_fresh,t = beta2 * v_fresh,t-1 + (1 - beta2) * g_reconstructed,t^2
r_raw,t = infinity_norm(v_frozen / v_fresh,t)
r_step,t = clip(r_raw,t, (1 - r_threshold)*r_t-1,
                         (1 + r_threshold)*r_t-1)
r_t = clip(r_step,t, r_min, r_max)
c_t = r_t * c_avg
x_t = x_t-1 - learning_rate * c_t * m_global,t / sqrt(v_frozen)
```

This is a transcription of the algorithm's main scaling structure, **not a complete implementation**: bias correction, weight decay, epsilon/zero-denominator policy, masking, layer partitioning, momentum normalization, packing and collective details must be pinned to an implementation version. The introductory Eq. (1), p. 3, omits weight decay for simplicity and includes a numerical-stability term; its footnote also explains the authors' clipping convention relative to original LAMB. Those details must not be silently guessed from blank attachment equations.

During compression, the original instantaneous weight/update norm ratio is not simply recalculated as in vanilla LAMB. The new coefficient uses the frozen base and a clipped variance ratio. Neither "freeze all variance forever" nor "use the original LAMB trust ratio with one-bit gradients" describes the proposed algorithm. RA07/RA09/RA10 must be corrected on this point.

Momentum fusion is also substantive. The authors fuse tensor momentum into a contiguous one-dimensional view to avoid 302 separate communications for BERT-Large (p. 16, A.5.1). The fused view is explicitly not another duplicate allocation. Because a common compression scale would increase error across differently scaled layers, they compute fixed layer momentum scaling coefficients at the end of warmup, scale before communication and undo that scale after aggregation (p. 17, A.5.2). These fixed normalization coefficients are separate from the dynamically clipped learning-rate factor `r_t`.

## Benchmarks that may be retained, with scope

The paper evaluates a modified **BERT-Large** with 24 layers, hidden size 1024, 16 attention heads and about 340 million parameters, using PreLN instead of PostLN. Pretraining uses Wikipedia plus BooksCorpus. The hardware is NVIDIA V100 clusters: Ethernet has 4 GPUs/node and nominal 40 Gb/s inter-node networking with approximately 4.1 Gb/s effective bandwidth; InfiniBand has 8 GPUs/node and 100 Gb/s EDR with effective bandwidth near the nominal peak. Performance experiments use 8-256 GPUs; fine-tuning uses 4 GPUs (p. 4, section 3.2; p. 7, section 6). These are not comparable to an unidentified IdeaPad, CPU-only field processing or a single Intel integrated GPU.

| Retained result | Exact locator and denominator | Interpretation allowed |
|---|---|---|
| Up to 91% Ethernet and 52% InfiniBand allreduce share | p. 14, Table 5: Ethernet 64 nodes/256 GPUs, batch 8K, microbatch 16, accumulation 2; InfiniBand 16 nodes/128 GPUs, batch 8K, microbatch 64, accumulation 1; section 3.2 p. 4 | Measured profiles of the paper's uncompressed BERT-Large seqlen-128 setups; not universal OS overhead |
| 4.6x and 4.1x end-to-end communication-volume reduction | p. 8, section 6 performance analysis, seqlen 128/512 respectively | Paper's calculated FP16 payload reduction including uncompressed warmup; not measured total NIC traffic including all protocol overhead |
| Up to 4.5x and 3.0x compressed-stage throughput speedup | p. 9, Figure 3(a)/(e), seqlen 128/512 with batch 8K; 200-step stage measurements | Ratios between warmup/baseline throughput and compression-stage throughput; not full-run speedup |
| Up to 2.8x and 2.2x estimated end-to-end speedup | p. 9, section 6, derived from stage speedup and warmup fraction | Stage-throughput estimates; separate from Table 4's measured total pretraining time |
| 731 min to 351 min total runtime, reported 2.1x | p. 9, Table 4: 256 V100 GPUs with Ethernet; batch 64K/32K at seqlen 128/512 | Actual measured total runtime in that configuration; phases 657 to 301 min (reported 2.2x), 74 to 50 min (1.5x) |
| Comparable pretraining/fine-tuning convergence | p. 5, Table 2; p. 8, Figure 2/Table 3 | Evidence for these tasks and recipes, not universal equality across models/precisions or statistical equivalence of every endpoint |

The communication calculation is `1 / (warmup_fraction + (1 - warmup_fraction)/16)` for the paper's FP16 comparison. A one-bit sign represents 16 times fewer payload bits than FP16, and 32 times fewer than FP32, **before** scale/padding/message overhead. The 4.6x claim is not a 4.6x shrinkage of model parameters, memory use or all storage. The paper chooses 1000/5993 warmup steps (16.7%) for sequence length 128 and 107/555 (19.3%) for length 512 (p. 8). Those choices are empirical recipes, not generic stopping criteria.

For the matched in-paper Table 2 comparison, LAMB (ours), LAMB + basic 1-bit and 1-bit LAMB have validation losses `1.451`, `1.494`, `1.443`; SQuAD mean F1 `90.265`, `90.069`, `90.524`; and max F1 `90.555`, `90.409`, `90.788`. They use pretraining batches 64K/32K at seqlen 128/512 and 32 fine-tuning runs. The `90.584` max F1 belongs to **LAMB (You et al., 2020)**, not the matched LAMB (ours) column. RA07 mixes these baselines. Table 3 gives aggregate GLUE medians over 32 runs, average `83.9` for LAMB and 1-bit LAMB versus `82.1` for the basic one-bit variant. Do not turn these development-set comparisons into a universal accuracy guarantee or a RUSSL result.

The simpler "LAMB + basic 1-bit" variant is reported as having slower/suboptimal convergence and poorer final scores (p. 5, Table 2; pp. 15-16, A.4). The paper does not justify replacing this specific result with a blanket statement that every such run diverged catastrophically. Similarly, results from LAMB, Adam, 1-bit Adam, SmoothQuant, AWQ, Loihi and unikernel database benchmarks have distinct workloads/denominators and cannot be multiplied together to predict an integrated speedup.

## Implementation, restart and theorem limits

The paper's NCCL-based implementation uses a three-phase compressed collective: gather partitioned chunks using Alltoall/AllGather, average received chunks locally, distribute compressed aggregate chunks using AllGather (p. 7, section 5). The generic phrase ReduceScatter + AllGather does not by itself specify this custom compressed reduction. In particular, a standard summing ReduceScatter over bitfields is wrong. NCCL outperforms their MPI implementation on Ethernet and is comparable on InfiniBand in Figure 7 (p. 17, A.6); this says nothing about a ported unikernel or Intel iGPU backend.

The paper itself records **additional memory**, a persistent fresh variance copy and temporary previous-momentum copy. The Ethernet V100s have 16 GB rather than 32 GB; some larger batches do not fit with fewer GPUs (p. 7). Compression therefore does not eliminate full-width optimizer state or establish a RAM reduction.

The [official DeepSpeed tutorial source](https://raw.githubusercontent.com/deepspeedai/DeepSpeed/master/docs/_tutorials/onebit-lamb.md), sections 1.2.3 and 1.4-1.4.1, was checked because the historical public tutorial URL returned 404 in this review. It describes accelerator-specific packing support, user-supplied momentum masks for invariant-zero gradients and checkpoint-loading residual resets. It warns that frequent **loading** can harm convergence; it does not say that every checkpoint save resets residuals. Correct resume needs rank-specific local and aggregation errors and compatible worker topology, or a documented reset policy tested for the task. These implementation observations are version-sensitive; pin a commit for any future experiment. The tutorial's historic dependency instructions are not an instruction to alter this host.

Appendix A.7, pp. 17-23, analyzes the compression stage as preconditioned, error-compensated momentum SGD, with Lipschitz-gradient, bounded stochastic-variance and bounded compression-error assumptions. The asymptotic worker-count rate is conditional on those premises and the specified learning-rate construction. It is not a proof of arbitrary p-adic training, unrestricted majority voting, physical hardware linear scaling, or any P5 x S3/8S mechanics. No new formal proof or independent empirical replication was performed here.

## Proposed optional RUSSL profile and experiment

`PROFILE-OPT-1BLAMB-RESEARCH/0.1` is a **design proposal** outside core field semantics. It treats the five-axis `4 x 4 x 4 x 16 x 16` field as typed input data with an explicit mapping to model training examples; its 16,384 sites are not automatically optimizer parameters or neurons. A future adapter would record model/data digests, parameter and layer partitions, precision, baseline LAMB implementation, warmup schedule, frozen/fresh variance, frozen `c_avg`, factor clipping, momentum normalization, sign/scale encoding, exact-zero mask, collective topology, both residual classes, worker count and restart policy. No such adapter is claimed implemented in the reference parser/container tools.

`EXP-OPT-01` would first compare uncompressed LAMB and faithful 1-bit LAMB on a fixed small, lawful dataset/model using identical sample order, batch, initialization, schedule and tuning budget. A one-worker run is a correctness/control experiment; with no inter-worker transfer, the paper's communication-saving mechanism offers no basis for a speedup claim. A later multiworker stage would preregister the model/data/backend/driver commits, number of workers, network measurements, actual bytes including scales and warmup, peak state memory, failure/restart conditions, seeds/repetition budget and paired uncertainty method.

The primary efficacy endpoint is held-out loss/score at the same processed-sample budget with a prospectively chosen noninferiority margin. The separate performance endpoint is total time to the preregistered quality target, including warmup, packing, synchronization and restart costs. Abort on nonfinite state, persistent loss divergence, inconsistent replicas or unexplained state mismatch; report failed/null runs. Ablate residual feedback, fresh variance adaptation and momentum normalization as distinct exploratory variants. Numerical masking and scale/state comparisons are necessary before timing, but passing them is not a convergence proof. Existing research evidence or favorable scores never grant `read`, `write`, `emit`, `persist`, `commit` or external actuation authority.

Machine-readable dispositions are in `research/additional_systems_claims.json`; the broader systems review is `research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md`.
