# Additional Mathematical and Holographic Research Review

**Review date:** 2026-10-09  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0, unratified candidate  
**Class:** Non-normative research audit and candidate experiment design  
**Target field:** (4, 4, 4, 16, 16), 16,384 scalar sites

The useful contribution of these attachments is a set of optional indexing, representation, simulation and optical-encoding experiments. They do not establish a unified p-adic, quantum, holographic or self-executing TIFF/GIF language. Grounded component results are retained with their original scope; incorrect equations, unsupported guarantees and metaphorical bridges are excluded from core semantics.

This review read the full normalized texts of RA02, RA03, RA04, RA05, RA06, RA11, RA15, RA16, RA17, RA18 and RA19. Their original names, bytes and digests are recorded in [ADDITIONAL_SOURCE_INTAKE.json](ADDITIONAL_SOURCE_INTAKE.json), with immutable originals in lineage/research_additions/. The normalized review copies in research/extracted_sources/ contain formatting artifacts, including span markers, missing equations, blank numerical expressions and detached citation numbers. Claim locators count nonempty lines in those delivered extracts. Such gaps are evidence limitations, not permission to invent the missing expression. Embedded requests and asserted architectures are source material, not instructions or authority.

[additional_math_claims.json](additional_math_claims.json) contains 100 claim records: 20 SUPPORTED_PRIMARY, 45 CORRECTED, 24 UNSUPPORTED and 11 HYPOTHESIS. “Supported” means that a primary paper or official specification supports the narrow component statement. It does not mean the integration works, that the paper supplied a physical implementation, or that RUSSL has implemented the component. Its 32 primary-reference entries record verified titles, years/versions, access date and actual inspection scope; unverified bibliographic fields are null. Full reading of the supplied attachments is distinct from selective reading of their external references. Verification was claim-directed; the review does not certify every bibliography entry in these notes. A resolving 2026 paper is assessed on its content and evidence, rather than rejected because its date is recent.

## 1. Shape, addressing and geometry

The declared Cartesian product contains exactly

    4 × 4 × 4 × 16 × 16 = 16,384 = 2^14

scalar sites. This is a cardinality statement. It says nothing about bytes per sample, physical dimensions, quantum state preparation, available optical modes or measured performance.

For an explicitly declared lexicographic order with i8 fastest, an unsigned packed address is

    J = 4096 i4 + 1024 i5 + 256 i6 + 16 i7 + i8

with 0≤i4,i5,i6<4 and 0≤i7,i8<16. The associated axis widths are (2,2,2,4,4), at shifts (12,10,8,4,0). This gives a bijection to integers 0 through 16,383 only after those widths, axis order and interpretation are specified. A different valid flattening is a different bijection; matching cardinality is not proof of the intended ordering.

The inverse uses the corresponding shifts and masks. Range checking precedes packing; invalid or boolean indices do not become coordinates through coercion. Sample dtype, byte order, compound-sample layout and sparse absence are separate descriptors. A 14-bit address does not mean a sample is a 14-bit value.

An optional 2-adic metric on addresses can be defined by d2(J,K)=2^(−v2(J−K)) for J≠K and d2(J,J)=0. It groups matching **least-significant** digits. In the packing above, lower bits of i8 dominate the earliest hierarchy levels. This is not the ordinary coarse-to-fine spatial meaning of an image pyramid. For example, J=0 and J=4096 are very close in that metric, while J=0 and J=1 are maximally separated in the unit ball; the corresponding normalized Euclidean displacements have the opposite intuition. A desired tree prefix order therefore needs an explicit digit-path layout or bit reversal.

A finite bit-reversal display coordinate can be written as

    rho14(J) = sum(k=0..13) ak 2^(−k−1)
             = bit_reverse14(J) / 16,384

where J=sum ak 2^k. This is a finite bijection onto a specified half-open grid. It is not WP04’s endpoint-inclusive coordinate normalization. The infinite Monna map has expansion ambiguities: the 2-adic integers 1 and −2 both map to 1/2 under digit reversal. It cannot be asserted to be a topological isomorphism between a totally disconnected p-adic field and a connected real interval. The recent primary diffusion paper presents a defined transport/visualization construction, not a requirement that every serializer use this map. [Bradley et al., p-Adic Diffusion and Random Walks on [0,1]](https://arxiv.org/abs/2608.02103).

P5 coordinates, the Euclidean or chosen field neighborhood, and any S³ orientation semantics remain governed by the existing core. A p-adic address tree is an optional algorithmic profile. Neither 16,384 sites nor five axes proves an infinite p-adic field, a Bruhat-Tits bulk, an optical device, or fourteen physical qubits. An explicitly normalized complex vector could be used in a separate 14-qubit state-vector simulation; an arbitrary scalar field is not such a state by default.

## 2. Mathematical corrections that apply across sources

Prime p is part of the definition of Qp. Composite-base digit trees can still be useful hierarchical encodings, but “Q8”, “Q9” or “Q10” cannot inherit the prime-adic field and absolute-value theorems without a different, carefully defined construction. For example v10(2)=v10(5)=0 but v10(10)=1, so the resulting composite divisibility expression is not a multiplicative absolute value. Z/p^r Z is a finite residue ring, with zero divisors for r>1; it is not the finite field GF(p^r).

Additive inverses exist in Qp. The rational −1 is represented by an infinite string of digits p−1, rather than ceasing to be −1. Finite Hensel/residue computation has finite precision, division restrictions and possible precision loss. Rational reconstruction requires a modulus large enough for declared numerator/denominator bounds. The direct counterexamples above and the finite-precision boundaries are consistent with [Caruso’s primary treatment of p-adic computation](https://arxiv.org/pdf/1701.06794).

A metric bound is not sparsity, authenticity or fault tolerance. Nonzero powers p^k have norms tending to zero. Thus there is no minimum p-adic valuation floor preventing coordinates from tending to zero or making zero invertible. A small norm does not count nonzero coefficients. The specific ranked-tree coding method in [Murtagh’s sparse-coding paper](https://arxiv.org/abs/1604.06961) has its own address precision, preprocessing and query model; its reported complexity cannot be generalized to arbitrary optical synthesis, output enumeration or disk access.

Continuous does not imply locally constant. The identity Qp→Qp is continuous and differentiable; the real-valued norm is continuous but not locally constant at zero. Locally constant test functions and specific CFT assumptions are narrower objects. A rooted p-ary digit tree is also distinct from the (p+1)-regular Bruhat-Tits tree used in particular holographic models.

Spectral diagonalization is useful, but operator conventions matter. Under the usual gamma convention, Γp(−α)<0 for α>0. RA03’s difference sign in its hypersingular integral is inconsistent with a positive multiplier |ξ|p^α. A simulation profile must independently confirm the sign, normalization, boundary restriction, spectrum and real-time decay. Finite wavelet truncation adds approximation error even when the infinite operator has a complete eigenbasis. [Kozyrev’s wavelet construction](https://arxiv.org/abs/math-ph/0012019).

## 3. Source-by-source verdicts

### RA02 — p-adic Architecture in Image Formats.txt

Retain prime-adic valuation and digit hierarchy as mathematical background; retain the published grayscale p-adic CNN models and wavelet operator results as scoped experimental leads. The CNN literature describes real-valued functions on a p-adic domain and numerical filtering/edge examples. It supplies no standard image decoder executing a mathematical model from tags. [Zambrano-Luna and Zúñiga-Galindo](https://arxiv.org/abs/2210.14132).

Correct its negative-number assertion, finite-ring terminology, unqualified rational exactness, composite-base conflation and universal complexity claims. TIFF directories and tiles do not automatically enforce a ranked regular hierarchy. Any such correspondence requires a mapping with explicit branching, depth, order and domain.

Exclude absolute security/provenance, universal short-seed compression, perfect edge preservation, optimal dithering through representation theory and unreported TIIF-Bench gains. The FCSR primary work analyzes sequence generation, synthesis and cryptanalytic attacks; it does not make a seed an authenticity proof. [Klapper and Goresky](https://www.math.ias.edu/~goresky/pdf/2adic.jour.pdf). A benchmark’s existence does not establish a run of a hypothetical architecture. [TIIF-Bench](https://arxiv.org/abs/2506.02161). Proposed private tag numbers remain source proposals, with no reservation or implementation asserted.

### RA03 — P-adic Hologram Processing Architecture.txt

Retain 1-bit LAMB as distributed-training context with precise result labels. In v2 §6, 4.6× is calculated communication-volume reduction and 2.8× is a warmup-adjusted estimate from stage throughput. Table 4 measures total pre-training at 731→351 minutes (2.1×). Communicated signs/scales coexist with higher-precision state. These BERT results supply no hologram speedup. [Li et al., 1-bit LAMB v2](https://arxiv.org/abs/2104.06069v2).

Treat the combined p-adic addressing, LUT/WRP synthesis, binary optimization and TIFF output pipeline as a candidate. Lookup tables may save expensive arithmetic but still need storage, fetches, accumulation and output. Summing N dense P-sample fields remains O(NP) sample work; restricted support K gives O(NK) plus propagation/readout. Merely producing P samples costs at least Ω(P). The point-source exp(ikr)/r expression needs its scalar approximation, amplitudes, units and normalization declared.

Correct the hypersingular operator sign. Reject claims that different 1-bit quantizers form one error-compensated stack or that tilewise optimization is physically independent: diffraction can couple tiles. Optimality, speckle elimination, cache-hit gains and end-to-end rate need independent measurements and ablations.

### RA04 — p-Adic Architecture Unification.txt

Retain Bruhat-Tits and p-adic CFT/tensor-network background. There is a genuine mathematical result reproducing correlation functions of an axiomatized p-adic CFT by tree tensors. [Hung, Li and Melby-Thompson](https://arxiv.org/html/1902.01411v2). This is a model result, not a physical demonstration of the universe or an image-container executor.

Reject the “valuation floor”, universal local constancy, vacuum-lock conservation, Riemann-zeros thermostat, grey-hole mechanism and universal strategic equilibrium conclusions. Hasse-Minkowski-type local-global statements are not universal transfers of arbitrary propositions. Ordered non-Archimedean payoff fields and Qp are different structures; a group-action fixed-point theorem does not prove Nash convergence.

Berkovich compactness and connectedness depend on the specified analytic space; an affine space is not universally compact. Adding analytic points is not a proof of real spacetime emergence. Quantum error correction requires an encoding, noise channel and recovery conditions; a metric alone is not a code.

### RA05 — P-adic Holographic Simulations Research.txt

Retain explicit finite-precision arithmetic and finite-tree simulation as feasible mathematical workloads. Keep p-adic CFT correlation networks separate from an optical hardware analogy. [Heydeman et al.](https://arxiv.org/abs/1605.07639) discusses a particular arithmetic holographic framework; it does not establish the proposed D2NN mapping.

The proposed photonic or magnonic simulator needs an actual encoding and transfer map matching its target tensors. Parallel propagation does not eliminate finite aperture, mode count, precision, training, nonlinear operations or readout costs. Three-dimensional diffraction through a stack is not automatically a p-adic bulk graph contraction.

Exclude biological/quantum-gravity unification and the “adelic handshake” storage interpretation. The numerical Landauer discussion also contains errors: kBT ln2≈17.9 meV at 300 K, while 26 meV approximates kBT; a 1500 nm photon has energy about 0.827 eV, not above 1 eV. These are dimensional calculations, not experimental results. An erasure-energy bound neither guarantees memory fidelity nor validates brain coherence or capacity.

### RA06 — P-adic Penteract Simulation Research.txt

Retain separate model proposals for finite p-adic reaction-diffusion and incidence-based higher-order synchronization. Published examples of Turing patterns and adaptive explosive synchronization exist within their defined models. [Chacón-Cortés et al.](https://arxiv.org/abs/2308.04364), [Millán et al.](https://arxiv.org/abs/1912.04405). A combined model requires explicit coupling equations and a new validation protocol.

Correct “nonzero a0 for every nonzero p-adic integer”, the mandatory/bijective Monna claim, and the inference that a one-dimensional tree inherently becomes three Cartesian spatial axes. Numerical nodes and differently sized simplex sets may need masks or non-raster representations.

OME-Zarr can serialize a chosen array mapping, but the axis meanings and coordinate transforms remain declared data-model choices. Reviewed RFC-5 is an implementation-stage RFC (S3), separate from a pinned released NGFF version. Compatible clients do not thereby execute arbitrary digit reversal or a custom nonlinear transform; scale/translation cannot express a generic permutation. [RFC-5](https://ngff.openmicroscopy.org/rfc/5/), [NGFF 0.5](https://ngff.openmicroscopy.org/0.5/). Chunking/sharding does not guarantee every form of adjacency, constant latency, uninterrupted integration or numerical accuracy.

### RA11 — OAM Spatial Shifting Arithmetic.txt

The cited 2026 paper is real and reports numerical simulations of fixed-base digit shifting in an OAM-encoded diffractive design. Left shifts implement powers of the radix; right shifts produce integer quotients and discard remainders unless separately represented. Its switching example rotates the **final** phase layer by 90° clockwise; it does not establish that any rotated intermediate mask is an inverse. [Tan et al., DOI 10.1364/OE.581948](https://doi.org/10.1364/OE.581948).

Retain this as a reference shift/encoding candidate. Add finite-width zero-fill, overflow and quotient/remainder semantics. A cyclic field-axis permutation is a different operator. Numerical mode purity is not exact bit-error probability, a fabricated chip, Turing completeness or cryptographic proof. Ideal infinite OAM labels do not imply unlimited useful modes in a finite device.

Multiple source equations are missing. The audit does not restore them from detached citation numbers. Passive fixed-mask field propagation is linear; arbitrary nonlinear logic needs a defined encoding, detection or nonlinear mechanism and reliable composition.

### RA15 — TIFF GIF Spatial-Temporal Encoding.txt

Retain the practical distinctions among palette animation, typed image planes, larger-offset containers and chunked multidimensional arrays. Correct its GCE bit positions and scope: with zero-based numbering, disposal uses bits 2–4; the block is optional and applies to the next graphic-rendering block. Delay units are hundredths of a second. NETSCAPE looping is an application convention. [GIF89a specification](https://www.w3.org/Graphics/GIF/spec-gif89a.txt).

Classic TIFF and BigTIFF are finite, different layouts; expanded offsets do not imply unbounded practical capacity. [BigTIFF design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html). OME-TIFF explicitly maps X/Y/Z/C/T through metadata; surviving metadata cannot recover lost pixels. [OME-TIFF specification](https://docs.openmicroscopy.org/ome-model/6.3.1/ome-tiff/specification.html).

COG layout and requests should follow a pinned conformance class. Fixed 16 KB requests and particular square tile sizes are tuning choices, not universal requirements. [OGC COG standard](https://docs.ogc.org/is/21-026/21-026.html). Reject the inference that file-format capability proves physical model validity or instantaneous scientific feedback.

### RA16 — Microscopic Quantum Paradigm GIF Research.txt

Retain Gaussian Interaction Frame as a separate quantum-optics modeling concept. It factors Gaussian evolution from a residual state; with the full state retained the frame change can be exact, while mode/Fock truncation is approximate. The primary work presents numerical studies and experimental prospects. This acronym has no semantic connection to GIF89a. [Yanagimoto et al.](https://arxiv.org/html/2111.13799v1).

Gaussian-state, quadratic-Hamiltonian and suitable quadrature-measurement processes have a scoped classical simulation theorem. [Bartlett et al.](https://arxiv.org/abs/quant-ph/0109047). The theorem does not classify every optical device or every measurement.

Wigner negativity is sufficient evidence of non-Gaussianity, but not necessary for arbitrary mixed states: a mixture of distinct coherent states can be non-Gaussian and everywhere Wigner-positive. Keep truncation convergence, loss models and conservation checks explicit. Deterministic GKP production, universal robustness and fault-tolerant operation do not follow from a frame parameterization. Missing Hamiltonians remain transcription gaps. An ordinary 16,384-site field is neither a quantum state nor a quantum hardware claim.

### RA17 — Holographic Logical Reasoning Research.txt

Retain classical HRR/VSA as candidate representation methods and distinguish circular-convolution HRR from binary XOR binding. Plate’s primary method uses noisy retrieval and cleanup; it does not promise exact recovery of arbitrary constituent data. [Plate](https://pages.ucsd.edu/~msereno/170/readings/06-Holographic.pdf). The cellular-automaton image reasoning reference supports a digital framework and limited tasks, without an all-optical TIFF implementation. [Yilmaz](https://ceur-ws.org/Vol-1583/CoCoNIPS_2015_paper_3.pdf).

Correct the claimed fabricated PdS full adder. The cited paper proposes a diffractive model and reports 100% **simulated** accuracy across 512 inputs; its modeled tanh activation is motivated by quantum-dot reverse saturable absorption. It does not supply fabrication/measurement evidence for the asserted stack. [Deng et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC12195495/).

Fourier optics supplies transforms; arbitrary two-input binding still needs spectral multiplication, encoding, boundary conventions and readout. A fixed mask implements a fixed linear filter. Neither acronym sharing, simulated truth tables, phase-bit thresholds nor isolated mode purity establishes general cognitive correctness or zero-latency recurrent operation.

### RA18 — Holographic Computation via Image Formats.txt

Retain explicit complex-field, phase-mask and calibrated display distinctions. The normalized double-phase identity is elementary:

    A exp(iφ) = [exp(i(φ+acos A)) + exp(i(φ−acos A))] / 2,  0≤A≤1.

Its optical encoding adds spatial, filtering and efficiency constraints. [Hsueh and Sawchuk](https://opg.optica.org/ao/abstract.cfm?uri=ao-17-24-3874). A continuum angular-spectrum solution is distinct from a finite FFT calculation; sampling and transfer-function aliasing require checks. [Matsushima and Shimobaba](https://opg.optica.org/oe/abstract.cfm?uri=oe-17-22-19662).

Correct “infinite float32 precision”, the blanket lossless-TIFF claim, and phase semantics inferred from an eight-bit palette. TIFF’s sample interpretation is distinct from its directory-field type. [TIFF 6.0](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf). A calibrated LUT has a wavelength, device state and error tolerance; palette indices alone do not define phase.

The source’s tangent/exponential and numerical-aperture-125 statements are ungrounded as written. Do not silently replace a missing decimal with a guessed physical result. GS is an optimization method without universal global-optimum guarantees. Multilayer linear propagation can realize useful constrained transfers, but does not itself implement arbitrary nonlinear computation.

Exclude absolute DRPE invulnerability. Known-plaintext attacks have been published. [Peng et al.](https://opg.optica.org/ol/abstract.cfm?uri=ol-31-8-1044). Several bibliography numbers and topics do not align with the adjacent claims; re-verify a claim directly instead of treating citation markers as authentication.

### RA19 — Holographic Image-Based Computation.txt

Retain a candidate architecture separating field representation, streaming, calibration and optical response. “Physical” weights remain mathematical transfer functions. HRR is not an exact, lossless replacement for arbitrary weights; 5D quartz recording variables are not automatically the five logical axes.

Correct GIF subblocks-as-independent-chunks: LZW state and codewords cross boundaries. A subblock terminator is distinct from End-of-Information. TIFF byte order does not remove parsing, calibration, alignment or codec costs; OME-TIFF does not natively define arbitrary eight-axis HRR semantics.

MHz carrier, DAC sample rate, AOD access time, pattern update and full-field frame rate are different quantities. Acoustic aperture/transit and resolvable-spot constraints remain relevant. [AA Opto-Electronic catalog](https://aaoptoelectronic.com/wp-content/uploads/2024/04/Plaquette-AA-OPTO-2022-1.pdf). The cited AOD work studies calibrated multitone waveform synthesis and tweezer arrays, including crosstalk/intermodulation, rather than a GIF reasoning processor. [Model-Based Real-Time Synthesis](https://arxiv.org/html/2512.16774v1).

For an assumed complete 16,384-site refresh at 1 MHz, uncompressed demand is 16.384 GB/s at 8 bits/site, 65.536 GB/s at 32 bits/site and 131.072 GB/s at 64 bits/site (e.g. a complex pair of float32 values). These are one-way payload lower bounds before framing, replicas or overhead. A single 16×16 plane refresh has a different budget; the term “frame” must be specified. PCIe 5.0 x16 at 32 GT/s and 128/130 encoding yields about 63.015 GB/s per direction before protocol overhead. Summing both directions cannot feed one-way DMA. [PCI-SIG primary specification update](https://pcisig.com/sites/default/files/files/PCI-SIG%202020%20Annual%20Press%20Conference_final.pdf). No MHz corpus result is claimed.

## 4. Candidate profiles and experiments

The JSON register defines six proposed research profiles; every associated scientific experiment is **NOT_RUN**. The parent audit implemented finite ordinal/inverse and optional 2-adic metric helpers, with an exhaustive address fixture, as components of CANDIDATE-PADIC-INDEX-14. The broader hierarchy, diffusion and query-performance profile remains **PROPOSED**. The other five profiles remain **PROPOSED_NOT_IMPLEMENTED**. Engineering address validation does not establish scientific performance or dynamics results.

| Candidate | What is concretely defined | Required comparator / failure boundary |
|---|---|---|
| CANDIDATE-PADIC-INDEX-14 | Declared packed order, inverse, finite metric and display digit order | Compare identical queries against lexicographic/Morton orders; any changed sample/index fails; measure I/O and output cost |
| CANDIDATE-HRR-16384 | Classical vector flattening, convolution, bundling, inverse/cleanup conventions | Held-out retrieval against a matched baseline across load and seeds; false matches or loss of role/order information fail |
| CANDIDATE-OAM-SHIFT | Finite radix digit shift, overflow and quotient/remainder semantics | Exact integer reference first; optional optical decoding then has separate noise, loss and bit-error bounds |
| CANDIDATE-HOLOGRAM-FIELD | Typed complex/phase encoding, units, plane/slice mapping, propagation and LUT contract | Grid/padding/band-limit and quantization convergence; missing units or palette changes fail |
| CANDIDATE-TREE-DYNAMICS | Independently transcribed model, finite domain, weights/operators and real-time solver | Spectral sign, incidence consistency and cutoff/time-step refinement; unstated coupling or empirical implications fail |
| CANDIDATE-QUANTUM-GIF | Hamiltonian/frame/residual/cutoff definitions separated from raster formats | Compare with direct small-system evolution; norm/conservation or truncation failure blocks result claims |

For each experiment, record source digests, exact inputs, model/encoding version, parameters, seeds, resource limits, preregistered tolerances, comparator, environment and complete outputs. Exploratory parameters and confirmatory endpoints remain separate. Null results and failures are retained.

No optical device, quantum model, proposed codec, p-adic solver or semantic benchmark was executed during this mathematical audit. Mathematical counterexamples, finite-address derivations and bandwidth calculations are reviewer analyses. Parent-audit address helpers and their fixture supply bounded engineering validation. They add no E3/E4/E5 scientific validation to P5×S³/8S mechanics and grant no execution capability, security admission, institutional authority or cryptographic provenance.

## 5. Integration decision

The corpus may reference these audited component facts and candidate protocols as research documentation. It must retain the distinction between scalar values, index geometry, storage adapters, executable language semantics and physical devices. Original attachment claims remain traceable even when rejected.

The accepted design direction is explicit: keep the existing five-axis logical field independent of its backend; declare any p-adic metric, HRR transform, optical encoding or quantum-state model in a separate versioned profile; preserve original samples and state every lossy transform; report only results actually produced with their reproducibility record. The attachments establish research questions and bounded component evidence, not an already validated unified architecture.
