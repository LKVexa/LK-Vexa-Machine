# Proposed Experiment and Preregistration Protocols

**Corpus:** 2.0.0. **Status:** designs awaiting inputs/implementations; no experiment is represented as completed. **Date:** 2026-10-09.

## Common preregistration record

Before confirmatory outcome inspection, deposit a dated immutable record containing: protocol ID/version and predecessor; question/hypothesis/null; claim/evidence grade; model/source/module digests; complete algorithm and domain/units; data source/license/selection and hash; primary endpoint/estimand; comparators/controls; train/validation/test split; tuning budget; sample-size/power or precision justification; randomization and seed generation; exclusion/missingness rule; stopping rule; uncertainty estimator; multiplicity control; sensitivity analyses; compute/runtime/solver/dependency versions; expected outputs and analysis scripts; reviewer/conflict record; deviations policy. Missing fields yield `DESIGN_INCOMPLETE`, not a filled-in placeholder result.

If outcome data have already been seen, label the work exploratory and preregister an untouched independent replication. Hashing a protocol after observing results is not prospective preregistration. Freeze the primary analysis, record deviations before executing them where possible, and publish both primary and exploratory results. This corpus does not register studies with an external registry on the user's behalf.

## EXP-01 — Residual independence and numerical stability

**Question:** Does the source eta criterion separate known rank-4 span, controlled new directions and noise? **Prerequisites:** agreed C4/e dimensions, normalization, epsilon and SVD cutoff. **Synthetic design:** generate exact in-span e, controlled orthogonal e, near-rank-deficient C4, zero e and scaled copies; add prespecified noise levels with independent streams. Compare float implementation against analytic exact cases and higher-precision calculations where meaningful.

**Primary estimand:** eta estimation error in analytic cases and false-positive rate against a stated measurement-noise null. **Controls:** rank/condition strata, no-noise baseline, column permutation, unchanged span under scale-normalized representation. **Sensitivity:** SVD threshold, regularization epsilon, magnitude, condition number, dtype and noise law. Record numerical uncertainty separately from simulated sampling uncertainty. Reject negative/nonfinite outputs or unexplained instability; do not infer physical novelty from successful analytic discrimination.

Sample count and tolerances must come from required precision/noise assumptions, not a convenient replication count copied from lab text. Seeds and analytic construction are published before runs. Report every condition, including unstable ones.

## EXP-02 — Added-representation predictive gain

**Prerequisites:** complete M7/M8 algorithms, target task, lawful empirical/simulation dataset, score definition and epsilon_gain. These are not supplied. Define whether larger scores are better and whether gain is absolute/relative. Freeze train/validation/test splits; block by time/entity where leakage is possible.

**Comparator:** M7 with matched capacity, optimizer, preprocessing and tuning budget. **Ablations:** no added residual term, shuffled/irrelevant added features, equal-capacity alternative and simple task baseline. **Primary analysis:** paired score difference on untouched test observations with a confidence interval whose method respects temporal/entity dependence. Preregister the confidence level and margin rule; for a one-sided scientific gain claim require the lower bound above epsilon_gain, not merely a positive point estimate. Select thresholds on training/validation only.

**Uncertainty:** measurement error, finite sample, tuning randomness and distribution shift separately. Use block/cluster resampling or a justified model for dependent data; do not treat repeated seeds on the same dataset as new empirical subjects. Correct multiplicity for claimed endpoint families. Report effect sizes, intervals, calibration and adverse subgroup/time outcomes. A simulation result remains E3 even if it reproduces the source's preferred direction.

## EXP-03 — Logical field and adapter equivalence

**Question:** Do supported transformations preserve shape, coordinates, dtype and selected samples? Exhaust small shapes including singleton axes and odd dimensions; use independent mapping code and decoded-sample comparisons as oracle. Generate bounded randomized shapes/types with recorded seeds; test index→coordinate→index round trips under explicit numerical tolerance. Compare dense/sparse views without collapsing undefined samples into zeros.

For TIFF/OME-Zarr variants, use external genuine fixtures with writer/version/hash provenance. Test declared axis permutation and its inverse, metadata/calibration, orientation, fill/labels and multiscale relationships separately. Compare bytes only when byte-reversibility is claimed; otherwise compare sample bits and declared semantics. Negative fixtures must reject ambiguous maps, unsupported types, escaping paths, inconsistent metadata and corrupted payloads. Since adapters are not supplied, external-format substudies remain `NOT_EXECUTABLE`.

## EXP-04 — Distributed retrieval and reproducibility

**Prerequisites:** actual adapters/fabric implementation and authorized isolated environment. Freeze dataset, region request trace, logical block scheme, storage layout, cache policy, machine/network specifications and concurrent load. Compare full-object retrieval, regional retrieval and deduplication under equal integrity/access checks.

Record bytes transferred, unique stored bytes, verification CPU, wall latency distributions, failures/timeouts, cold/warm cache distinction and rejected-corrupt results. Inject missing/corrupt replicas, source mutation, reorder/delay, stale mutable heads and interrupted writes. Retry policy and consistency expectations are preregistered. Confirm every accepted sample through independent logical digest/bit comparison. No speed improvement excuses integrity or authorization failure. A successful isolated study does not claim universal distributed availability.

## EXP-05 — Product-indicator validation

**Prerequisites:** original equations/data, operational calculation for every metric, target outcomes, domain expertise and authorized institutional setting. Define reference population, temporal horizon, missingness and selection mechanisms. Use simple domain baselines, temporal holdout and shift evaluation; calibrate on development data only. Review recommendations through accountable humans; no operational action is authorized by this protocol.

Report calibration, discrimination where applicable, score stability, measurement error, confidence intervals and domain-dependent harm/cost tradeoffs. Separate diagnostic calculation from causal-policy claims. Missing original definitions make this study `DESIGN_INCOMPLETE`.

## Reproduction package and result record

Publish protocol and deviations, input/module/source hashes, code/tool environment, seeds, split IDs, complete raw outputs, analysis, uncertainties/counterexamples and reviewer disposition. A result includes exact claim supported and excluded populations/variants. Sensitive observations may remain restricted with approved access and sufficient non-sensitive synthetic fixtures. Cross-platform numerical disagreement is recorded, not hidden by regenerating goldens from the disputed implementation.

No invented p-values, confidence intervals, benchmark speeds, experimental observations or external registrations accompany these proposed protocols.
