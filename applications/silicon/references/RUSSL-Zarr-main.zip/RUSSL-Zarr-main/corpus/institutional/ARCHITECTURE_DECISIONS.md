# Architecture Decision Records — Corpus 2.0.0

These are documented design dispositions of the audited candidate, not fabricated historical committee votes. Institutional acceptance remains pending. Each decision is scoped to the corpus baseline and linked to its defeaters.

## ADR-01 — Preserve logical semantics independently of storage

**Problem:** the superseded prototype exposes storage-specific state types/paths as core operands. **Disposition:** logical field, source/IR/tuple and mathematical identities remain core; TIFF/OME-Zarr/object storage are explicit adapters. **Rationale:** physical reorganization should not redefine a logical computation. **Evidence:** architecture charter, WP04/WP13, prototype supersession, adapter contracts. **Consequences:** raw source/export identities differ from logical sample equivalence; adapter receipts record loss and permutation; deployment performance is separately tested. **Defeater:** hidden backend assumptions in future implementations need differential verification.

## ADR-02 — Preserve source bytes and classify claims

**Problem:** MSSL true assertions and missing PDF references can be mistaken for proven experiments. **Disposition:** preserve bytes and distinguish assertions, definitions, simulations, observations and replication. **Evidence:** source hashes, visual master-image review, research foundation and critical mechanics review. **Consequences:** no guessed equations or invented datasets/results; a corrected transcription is a new derivative. **Defeater:** authentic originals and independent experiments are still required.

## ADR-03 — Retain RUSSL/1.0 identity compatibility

**Problem:** stronger external canonicalization terminology could change hashes silently. **Disposition:** identify the legacy Python JSON profile accurately; retain existing language/domain meaning unless a separately versioned migration is adopted. **Evidence:** WP17, reference serialization helper, canonicalization note. **Consequences:** JCS is a comparison, not a replacement label; cross-runtime proof remains scoped to actual vectors. **Defeater:** serializer/numeric/Unicode behavior outside tested accepted inputs can disagree.

## ADR-04 — Fail closed on unavailable authorization

**Problem:** mathematical admission or schema-shaped signatures can masquerade as permission for external effects. **Disposition:** require actual deployed verification; unavailable verifier/trust keeps effects unavailable. **Evidence:** WP09–WP11 and limitations. **Consequences:** reference validation cannot promise a deployed execution engine, key ownership or institutional consent. **Defeater:** configuration of a production trust/revocation path requires independent security review.

## ADR-05 — Proposed governance without invented ratification

**Problem:** construction GO can be misread as institutional acceptance. **Disposition:** use a candidate status and proposed review roles/quorum; real records alone can elevate status. **Evidence:** governance charter, assurance and change-control policies. **Consequences:** independent review, rights/privacy/custody and deployment decisions remain explicit. **Defeater:** no appointed institution, quorum or external certificate is supplied.
