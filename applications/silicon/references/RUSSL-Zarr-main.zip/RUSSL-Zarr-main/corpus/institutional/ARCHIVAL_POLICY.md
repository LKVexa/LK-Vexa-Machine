# Archival, Fixity and Custody Policy

**Baseline:** corpus 2.0.0. **Status:** proposed institutional policy; no repository or retention authority is appointed here.

## Objects and inventory

Separate supplied original sources, released derivatives and operational evidence. A release deposit preserves sources, specifications, schemas, registries, examples, tools/tests, actual results, limitations, citations, provenance, decisions and manifest. A derived export never replaces the source deposit. A file known only by digest is unavailable, not archived.

Record deposit ID, corpus/language/profile versions, origin archive hash, manifest hash, finished archive hash outside that archive, custodians, storage locations, access class and disposition. Avoid self-reference: the manifest does not hash itself; an external receipt binds the finished manifest. Checksums authenticate neither publisher nor rights without an independently verified trust process.

## Custody workflow

| Stage | Required record | Failure disposition |
|---|---|---|
| Accession | Original name/size/hash, time, supplied origin, safe inventory, rights/privacy status | Quarantine corruption/ambiguous paths; preserve source |
| Assembly | Change log, inventory, tools/runtime, current evidence and limits | Do not substitute stale results |
| Deposit | Two checked copies on separate failure domains plus one recoverable offline/immutable copy when available | Mark redundancy pending until established |
| Fixity | SHA-256 at accession/transfer/restore; quarterly complete scans after adoption | Preserve suspect copy; compare independent copy; open incident |
| Recovery | Annual clean restoration and declared verifier run, including failures/time | Downgrade recovery claim until repaired |
| Migration | New object/format ID, tools, before/after hashes, losses and decision | Preserve previous deposit |
| Disposal | Written retention authority, scope, reason and metadata tombstone | No deletion inferred from supersession |

Timing/copy counts above are proposed targets, not completed activities. Adoption requires accountable custodians and actual service targets.

## Correction and discovery

Released deposits are immutable snapshots. Issue a new version with erratum/withdrawal and predecessor link. Changed source bytes create a new accession; preserve the original four MSSL modules and image even if corrected transcriptions arrive later. Restrict sensitive data while keeping appropriate discovery/access metadata.

Goals of findability, governed access, interoperable description and reuse draw on the [FAIR Guiding Principles, 2016](https://pmc.ncbi.nlm.nih.gov/articles/PMC4792175/) (accessed 2026-10-09). This is not FAIR certification. DOI registration, indexing, persistent access and affirmative licensing require external custody decisions.

A proposed provenance crosswalk treats immutable files as entities, extraction/build/test/migration as activities, and accountable custodians/tools as agents, with usage/generation/derivation/association/invalidation relationships. This draws on [PROV-DM, W3C Recommendation 2013-04-30](https://www.w3.org/TR/2013/REC-prov-dm-20130430/) (accessed 2026-10-09). It does not assert that packaged receipts are valid PROV serializations or that unidentified agents have authenticated identities.
