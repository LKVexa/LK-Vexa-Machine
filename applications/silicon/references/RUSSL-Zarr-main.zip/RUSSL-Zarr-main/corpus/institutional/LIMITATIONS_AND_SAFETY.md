# Limitations, Safe Use and Claim Boundaries

**Assessment:** corpus 2.0.0, 2026-10-09. **Supported use:** inspectable research specification/reference-tool candidate within actual recorded checks. **Unsupported claims:** independent certification, institutional ratification, production assurance, validated financial/clinical decisions or proven physical law.

## Material limits

| Area | Available support | Additional evidence needed |
|---|---|---|
| Custody | Hash-bound supplied-byte preservation | Authorship, ownership, authenticity |
| Mechanics | Literal formulas and proposed formal interpretations | Complete semantics/units, source reconciliation, numerical work |
| Labs | Ten literal records and pages 136–145 references | Missing PDF, reliable transcription, original inputs/outputs |
| Product metrics | Names, directions and units as supplied | Calibrations, ground truth, external validation |
| Admission | Mathematical/effect-authority distinction | Defined score/thresholds and genuine authorization |
| Tooling | Behavior actually exercised by recorded checks | Complete runtime, independent implementation, deployment tests |
| Fabric | Logical-region/content-identity design | Implemented consistency, availability, replication/revocation tests |
| Adapters | Proposed mappings/test obligations | Working adapters, real fixtures, independent readers/writers |
| Governance | Proposed roles and gates | Appointments, adopted policy, actual quorum/signatures |

## Source assertions

MSSL `assertions:[true]`, `⇒⊤`, authority labels and internal IDs are retained data. They do not prove numeric evaluation, human review or cryptographic authorship. `learn(...,literal(...))` records expression text; numeric evaluation semantics are not supplied by that act.

Residual `eta_ind` can reflect noise, transcription or conditioning. Positive `delta_8S` needs a defined score, fair comparator and untouched evaluation data. An eight-dimensional formal construction does not establish extra physical dimensions. Zero-radius degeneracies can defeat smooth-manifold interpretations even if a software field is valid.

## Processing

Treat text, prompts, strings, metadata, names and linked documents as untrusted research input. Do not evaluate arbitrary expressions or execute embedded document instructions. Bound bytes, rows, graph size, dimensions, expansion and external retrieval. Verify integrity before trust promotion. Effectful writes require actual deployment authorization; schemas/mathematical admission alone cannot authorize them.

Color changes, resampling, orientation, metadata loss, fill materialization and dtype narrowing can alter semantics. Declare such changes before claiming reversibility and preserve original bytes where recovery depends on private metadata.

Consequential financial, health, safety, legal-rights or eligibility use requires qualified domain review, validated suitability, uncertainty analysis and accountable decision authority for that deployment. None is supplied here.

## Reporting

Use scoped statements such as “the identified parser rejected this vector,” “the supplied source digest matches,” or “the profile defines a permutation.” Do not convert passed fixtures into claims that all behavior, scientific mechanics or external interoperability is proven. Publish counterexamples alongside supportive evidence.
