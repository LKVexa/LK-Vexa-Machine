# Change Control and Release Policy

**Corpus:** 2.0.0. **Language/identity:** RUSSL/1.0 unless an explicit versioned change states otherwise. **Status:** proposed operating policy.

## Separate version axes

Bundle, language, tuple ABI, schema, adapter, identity domain and tool implementation have distinct versions. A corpus major release can improve documentation/evidence while retaining RUSSL/1.0 meaning. It cannot silently change accepted syntax, identity bytes or effects. Evaluate compatibility against artifacts and behavior, not filename/version alone.

Patch changes preserve conforming meaning; minor changes are additive within the declared profile; accepted-meaning/identity changes require migration analysis. A security fix may intentionally reject previously accepted unsafe inputs: record that compatibility effect.

## Proposal dossier

Record ID, sponsor, problem evidence, affected requirements/files, exact before/after behavior, version axes, compatibility matrix, security/privacy/research impact, migration/rollback, checks, reviewers/conflicts, dissent, decision and predecessor. Identity changes include raw hash-input vectors and old/new identity mapping; migration creates new objects without overwriting old evidence.

Grammar/lowering, Unicode/numbers, tuple order, coordinates, effects/grants, trust roots, bindings, adapters and resource limits need technical, security and reproducibility review. Mechanics changes also need source/provenance and domain review. Rights changes require actual rights-holder authority.

## Gates

| Gate | Review question | Evidence |
|---|---|---|
| `CC-1` Inventory | Are sources preserved and files intentional? | Safe inventory, hashes, explicit exclusions |
| `CC-2` Behavior | Which requirements are implemented versus documentary? | Current tests, adverse vectors, code/oracle review, gaps |
| `CC-3` Compatibility | Is promised RUSSL/1.0 meaning/identity retained? | Old/new fixture comparison, migrations, identity vectors |
| `CC-4` Research | Are assumptions and evidence grades honest? | Hypothesis register, provenance gaps, supplied results |
| `CC-5` Deployment | Are real effects/trust/backend/resource policies configured? | Deployment evidence; never inferred from corpus run |
| `CC-6` Institution | Have appointed reviewers accepted a concrete use? | Dated quorum/conflict record; otherwise candidate |
| `CC-7` Publication | Are custody, rights/privacy and destination authorized? | Custodian decision, rights inventory, access class |

Researchers may assemble/review a candidate without ratification. Institutional acceptance, deployment and public release are separate decisions. A gate failure affects the scope it covers.

Proposed security practices include protecting source/release artifacts, requirements review, boundary verification and vulnerability response. They are informed by [NIST SP 800-218, SSDF 1.1, February 2022](https://csrc.nist.gov/pubs/sp/800/218/final) (accessed 2026-10-09). Full SSDF implementation and NIST endorsement are not claimed.

## Emergency correction

Contain compromise or authorization bypass, preserve failing artifacts/environments, issue a scoped advisory, and create reviewed correction with regression checks. Emergency status does not bypass trust/identity review. Restore a known-good immutable release only after checking it will not reintroduce the defect. Keep withdrawn versions and permitted research-only uses explicit.
