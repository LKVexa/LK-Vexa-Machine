# RUSSL Institutional Assurance Case

**Corpus release:** 2.0.0. **Language compatibility:** RUSSL/1.0. **Status:** research and institutional review candidate. **Assessment date:** 2026-10-09.

## Scope and decision

This is a structured argument for using the package as a bounded research specification and reference implementation baseline. It is not an institutional acceptance decision. A passing local verifier supports the exact checks it performed on the identified release; it does not establish completeness, correctness of every implementation, safe deployment, or scientific validity.

The top claim `AC-0` is: **the release is inspectable, reproducible to its declared extent, and suitable for independent technical review when residual limitations accompany downstream claims.** Acceptance conditions are a verified inventory, preserved inputs, explicit separation of experimental mechanics, software requirements, authorization and adapters, actual executable-check results, and an unresolved-evidence register. Its decision is `CANDIDATE`, not `RATIFIED`.

## Claim–argument–evidence–defeater register

| Claim | Argument and control | Evidence a reviewer should inspect | Defeater / residual limit | Acceptance scope |
|---|---|---|---|---|
| `AC-1` Source custody is reviewable | Preserve original MSSL/image/lineage bytes; distinguish commentary from sources | `SOURCE_AUTHORITY.md`; MSSL baseline registry; source image; manifest and checksum set | Digests prove byte identity, not authorship, ownership or accuracy. Missing PDF/parent sources remain absent | Supplied-byte preservation |
| `AC-2` Boundaries are explicit | Core language, field and tuple identity independent of physical formats; separate adapters | Architecture charter; WP04/WP13/WP16; adapter profiles; actual leakage checks | Lexical leakage tests cannot prove semantic independence; future backends can add hidden assumptions | Design plus tested fixtures |
| `AC-3` Identity paths are repeatable | Identified normalization, canonicalization profile, domains and module digests | WP17; reference tool; identity vectors; verified examples | Python JSON serialization is not automatically RFC 8785 JCS; alternate runtimes and numeric/Unicode edges require differential tests | Reference accepted-input domain |
| `AC-4` Evidence differs from authorization | Mathematical admission does not grant effects; missing deployment verification keeps effects unavailable | WP09–WP11; capability schema/fixtures; limitations statement | Schema validity/signature-shaped text is not verified signature; no deployed trust/revocation infrastructure supplied | Denial and structural validation |
| `AC-5` Conformance is auditable | Separate documentary coverage, fixture checking, behavioral tests and independent witness | Requirement/test registries; current conformance results; verifier code | Generic assertions, self-generated goldens and counts do not establish independent correctness | Check-specific actual outcomes |
| `AC-6` Research claims are bounded | Formalized inputs, falsifiable protocols, preregistration and explicit provenance gaps | Research foundation, experiment protocols and mechanics review | No numerical result/empirical dataset arises from writing protocols; undefined scores defeat study readiness | Study-design readiness |
| `AC-7` Adapters are reviewable | Versioned mappings, losses, rejections and test obligations | TIFF/OME-Zarr profiles; research source registry | No actual external-format adapter or certification is established by documentation | Proposed contracts |
| `AC-8` Operations are accountable | Proposed independent roles, gates, custody, response, rights and privacy | Governance charter and institutional policies | Roles unappointed; quorum, custody and signing have not occurred; policy is not operating evidence | Proposed adoption process |

## Evidence qualification

Each evidence entry needs path/ID, digest where material, producing tool/version, input scope, run time, result and review status. Absence is `NOT_SUPPLIED`; planned work is `PROPOSED`; `PASS` requires an actual recorded run. Do not aggregate these into a percentage implying scientific or production readiness.

Legacy completion `GO` is construction bookkeeping. It is not external ratification or institutional authorization. Current release evidence and limitations govern this package's status.

## Review procedure

1. Recompute inventory from clean extraction; compare preserved source digests with the original archive.
2. Review implemented boundaries and adversarial checks, including the test harness and oracle.
3. Challenge parser, identity and coordinate assumptions through independent reviewers/implementations.
4. Classify each claim `SUPPORTED_WITHIN_SCOPE`, `PARTIAL`, `UNSUPPORTED` or `WITHDRAWN`; append evidence and decisions.
5. Authorize an institutional use only through appointed human roles and an adopted decision record.

No external assessor, regulator, university, publisher or standards organization has attested to these claims in supplied evidence.
