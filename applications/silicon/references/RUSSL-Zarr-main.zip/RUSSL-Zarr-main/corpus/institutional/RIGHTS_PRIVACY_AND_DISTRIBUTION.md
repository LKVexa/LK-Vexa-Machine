# Rights, Privacy and Distribution Policy

**Corpus:** 2.0.0. Sources/lineage are preserved for the authorized audit; affirmative third-party redistribution/reuse rights are not established by inclusion. This file creates no license grant or legal determination.

## Inventory

Before public distribution record rights holder if known, origin, supplied license/version, obligations, third-party material, authorized audience and evidence. Unknown rights are unresolved, never public domain by assumption. Distinguish source MSSL/image/lineage, new commentary, dependencies and cited standards. Citations do not authorize copying full standards.

Use links and brief attributed summaries. Assign no corpus-wide Creative Commons, software or proprietary license without explicit accountable rights-holder authority. Preserve source notices and mixed-rights obligations.

## Classification

| Class | Handling |
|---|---|
| Publicly authorized | Approved release/provenance only; preserve permission |
| Internal research | Approved research audience/access record |
| Confidential/personal | Restricted access; minimum copies; separate identifying evidence |
| Unknown | Review before external sharing; preserve accession |

MSSL names/authority strings are unverified provenance, not contacts or appointments. Image metadata may contain subjects, locations/devices or acquisition information; decide explicitly before external export. Security/access logs also need minimization, retention and restricted handling.

Publication records audience, rights/privacy review, redactions, omissions and link to retained full accession. Redacted derivatives receive new identities/loss statements. Institutions handle restriction/takedown requests with retained decisions; sources are not silently rewritten. Non-sensitive synthetic fixtures may accompany methods when observations remain restricted.

No rights-holder appointments, original PDF license, privacy review, public publication authorization or complete dependency-rights review is supplied. These are external decisions; private inspection and improvement within the authorized audit do not require inventing them.
