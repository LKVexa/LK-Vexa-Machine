# Integrity and Security Incident Response Policy

**Status:** proposed custodian/implementer operating policy. No team, contact or response deadline is represented as established.

## Classification

`IR-1`: corruption, unauthorized mutation or release hash mismatch. `IR-2`: parser/schema/authorization bypass. `IR-3`: key, credential or publishing compromise. `IR-4`: restricted/personal material disclosure. `IR-5`: materially false provenance or scientific claim. Severity depends on boundary, exposure, reproducibility and consequence.

## Workflow

1. Assign ID, discovery time, affected versions/paths, hash-bound reproducer, observed/expected behavior, exposure and owner. Restrict secrets/personal evidence.
2. Quarantine suspect artifacts and suspend affected effects/publication. Revoke compromised authority through the actual deployment mechanism. Preserve original evidence.
3. Reconstruct source/build/release chain, defect scope and affected identities; retain tool/environment versions. Unexplained failures remain unresolved.
4. Produce a reviewed new release/configuration, meaningful regression vector, compatibility/identity explanation and relevant rerun evidence.
5. Recover from verified clean deposits and trust configuration; measure actual expected behavior.
6. Accountable institutions determine disclosure recipients/timing. Advisories state affected versions, scope, fix/workaround and uncertainty without secrets.
7. Record root cause, control gaps, retained evidence, owners and closure criteria; preserve predecessor/advisory records.

Urgent containment requires an adopted incident role; it is not retrospective ratification. This policy triggers no unsolicited third-party notification.

The proposed procedure is informed by [NIST SP 800-61 Rev. 3, April 2025](https://csrc.nist.gov/pubs/sp/800/61/r3/final) (accessed 2026-10-09), which integrates response with cybersecurity risk management. No NIST assessment or operating effectiveness is claimed.
