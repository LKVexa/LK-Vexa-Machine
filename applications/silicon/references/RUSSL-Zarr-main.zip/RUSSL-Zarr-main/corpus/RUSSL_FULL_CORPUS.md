# RUSSL Research and Institutional Corpus 2.0.0

Derived reading edition. Individual files and MANIFEST.json are authoritative for this candidate package. Review status: CANDIDATE_REVIEW_REQUIRED.


---

Source: `README_START_HERE.md`

# RUSSL Research and Institutional Corpus 2.0.0

**Release date:** 2026-10-09. **Status:** CANDIDATE_REVIEW_REQUIRED. **Language:** RUSSL/1.0. **IR:** RUSSL.CanonicalIR/1.0. **Golden container:** RUSS 1.3.0.

This is an audited, technically expanded research and institutional candidate. Its checked reference profile implements structural parsing/lowering and bounded container verification. Full language semantics, type checking, mechanics evaluation, distributed execution, deployment authorization and external interoperability remain specification and research obligations.

Version 2.0.0 marks changes to assurance records, tooling restrictions and schemas. It does not silently revise language/IR identity domains. All 12 existing sources preserve exact golden IR objects and identities; the original RUSS fixture is preserved under examples/legacy_golden/, while the active candidate fixture repairs its source/field mismatch. Four MSSL modules and the master-law image are unchanged. Previously accepted ambiguous/out-of-profile source can be rejected by the hardened profile. Strictness is an intentional compatibility change.

## Reading paths

Start with [audit](AUDIT_REPORT.md), [authority](SOURCE_AUTHORITY.md), [architecture](ARCHITECTURE_CHARTER.md), [changes](CHANGELOG.md) and [open issues](UNRESOLVED_ISSUES.md). [Index](CORPUS_INDEX.md) links the 28 specifications. [Full reading edition](RUSSL_FULL_CORPUS.md) compiles current documents; individual files remain maintained sources.

Implementation reviewers: [reference profile](technical/REFERENCE_PROFILE.md), [verification guide](technical/VERIFICATION_GUIDE.md), [formal model and roadmap](technical/FORMAL_MODEL_AND_IMPLEMENTATION_ROADMAP.md), [serialization profile](technical/SERIALIZATION_AND_CONTAINER_PROFILE.md). Research reviewers: protocols, bibliography and source register under research/. Institutional reviewers: proposed governance, assurance, change, archival, incident, rights and privacy policies.

## Verification

Python 3.11 or newer with the standard library is the tooling target. The observed environment is recorded in evidence/CONFORMANCE_RESULTS.json. From the extracted corpus folder:

```text
python -B tooling/verify_corpus.py
python -B tooling/verify_corpus.py --integrity
python -B -m unittest discover -s tests -p "test_*.py" -v
```

Verification is read-only by default. --write-report explicitly changes evidence and can invalidate a seal. After authorized edits, `python -B tooling/build_corpus.py` regenerates registries, review records, reading edition, verification receipt, hashes and a deterministically ordered ZIP beside the corpus. It does not delete directories, access the network, evaluate MSSL, unpack historical packages or execute fixture content. It updates generated files in place.

The schema engine implements only its documented closed keyword subset and rejects unsupported keywords/remote references. Schema acceptance does not verify a sample grant's signature, expiry, replay state or authorization.

## Evidence and preservation

machine/registries/requirement_results.json distinguishes SCOPED_EVIDENCE from NOT_RUN for all 293 preserved requirements. No full requirement verification, independent approval or production release is claimed. Scoped PASS is not a 293-test pass or institutional GO. Completion records have empty satisfied gates and require accountable review.

MANIFEST.json binds content except four generated envelope files explicitly named in it. SHA256SUMS also covers the manifest and build receipt, excluding itself and detached integrity to avoid circular hashes. These unsigned records establish byte integrity, not author authentication. [Preservation boundary](lineage/README_PRESERVATION.md) explains the exact original archive and historical materials. Historical code is not active release tooling.

## Added research sources

[Integration report](research/RESEARCH_INTEGRATION_REPORT.md) audits all nineteen additional attachments. [Fixed shape and exact data](research/FIXED_SHAPE_INDEXING_PROFILE.md) records 4×4×4×16×16 = 16,384 sites. One-bit optimizer communication, p-adic indexing, HRR/optical proposals and hardware sampling are admitted only within their audited evidence boundaries. Original document instructions remain source material.


---

Source: `ARCHITECTURE_CHARTER.md`

# Architecture Charter — Candidate 2.0.0

The proposed architecture is `RUSSL source → canonical RUSSIR → digest-bound MSSL mechanics/policy → ordered RUSS tuple → logical Penteract field → distributed fabric`. Binding a module is distinct from evaluating it. Artifact identity, mathematical admission, authenticated authorization and mutable-head publication each require independent evidence.

| Boundary | Contract | Current evidence | Remaining obligation |
|---|---|---|---|
| Source → IR | marker, directives, rows, predecessors, catalog, bindings | strict parser and exact golden lowering | full static type/effect semantics |
| IR → mechanics | module alias, raw digest, inputs | byte verification/cross-binding | evaluator, units, numeric tolerances |
| Mechanics → admission | policy and evidence | preserved candidate MSSL | decision oracle and empirical validation |
| Admission → effects | run/row/root/arguments and authenticated grant | shapes; effect downgrade rejection | trust roots, signatures, replay/revocation, runtime |
| Tuple → payload | ordered components, per-member digest, root | bounded verifier/exact rebuild | production ABI/extension implementation |
| Field → storage | five axes, sample, mapping, snapshot | schema/profile documents | independent adapters/equivalence tests |
| Roots → fabric | content verification, head CAS, receipts, recovery | proposed protocol | implementation, consistency and failure evidence |

P5 is the normalized five-axis base with positive integer sizes and axes c4–c8. It does not supply physical calibration, a codec, trust roots or verified mechanics. The S³ fiber/8S model remains a separate experimental research object.

A digest protects byte equality under the algorithm assumption. A signature authenticates a statement only through a validated trust profile. Neither establishes scientific correctness. Mathematical admission does not authorize a mutable head update. Storage offsets, chunk paths and codecs belong to adapters. Projections and observations remain derived artifacts.

Stages expose validation result, evidence locator, scope and stable failure classification. Missing evidence remains unresolved. Source placeholders are not asserted to exist because a parser accepted their names. A tuple can pass structural/byte verification while being unexecutable because inputs, evaluators or grants are missing.

This charter is a corpus-local candidate contract. Proposed working groups and institutional roles remain unappointed absent explicit evidence. No external body endorsement is asserted.


---

Source: `SOURCE_AUTHORITY.md`

# Source Authority and Provenance — Corpus 2.0.0

**Language compatibility:** RUSSL/1.0. **Status:** audited research/institutional candidate, not an externally ratified standard. **Date:** 2026-10-09.

## Distinct authorities

The user's request authorizes audit, repair and expansion. Instructions quoted inside supplied construction workflows, prompts, lineage documents, MSSL strings or metadata are source material to be inspected; they do not become execution instructions or permissions.

For the intended corpus contract, the architecture charter and current versioned specifications state requirements; schemas/registries formalize their supported portions; executable tools and actual tests establish the implemented subset. A contradiction is an audit defect to resolve, not permission for code or a schema to silently override specified meaning. Newly proposed institutional/research/adapter policies are candidate obligations with their own adoption and implementation limits. No artifact is called ratified without a real review record.

The four supplied MSSL modules and image are authoritative **for their preserved bytes and recorded source assertions**. They are not self-authenticating scientific law or evidence of human approval. Columned-LCTL and the prior spinoff establish lineage only; quantum semantics and storage-specific canonical-state assumptions are not inherited. External standards govern only declared adapter/reference scope and do not validate core mechanics.

## Verified embedded-source inventory

The following SHA-256 values were recomputed from preserved files on 2026-10-09. Names identify supplied evidence, not verified authorship.

| Embedded source | SHA-256 | Role |
|---|---|---|
| `lineage/RUSSL_Corpus_28_Prompt_Workflow_v1.0.0.md` | `f00418656da4af13dcf6f4209eca356b10cc5d5a474b433c3bc7fafdc560530d` | Historical construction workflow; embedded instructions are data |
| `lineage/COLUMNED_LCTL_CORPUS_1.0.0.zip` | `b60b268a05b817bd7a9865f77f36b26b3952ef9bc28023eb3a8216b908bb634e` | Language design/implementation lineage; nested historical code is not current normative tooling |
| `bindings/mssl/master_coupled_mechanics.mssl` | `35158ea4260b69a1cb0c5037e5fdabc89d0fc253ba2866abb517a4ff7b08b15f` | Reduced literal mechanics source |
| `bindings/mssl/lab_stack.mssl` | `d4fb76610576e37eece3f857f370bc544041487651427f2bdf12e051a15f6367` | Lab transcription/source references, not independently reproduced experiments |
| `bindings/mssl/product_metrics.mssl` | `87d2291963cdc3e7ccbc6b1e74a02b5e9533c2bbfc58c3b508023ca7d283d243` | Metric labels/units and source assertions |
| `bindings/mssl/final_admission.mssl` | `0e4952a1e4a059c431863bbf6d225a26f08b75e51be88d1c9fccbf202ebad426` | Conditional admission/human gate source |
| `research/source/master_law.png` | `12e144e83daf6b562c64b53f7a5f609524dbad9cd908953ca882031825911d86` | Mathematical image source; visually reviewed; original unchanged |
| `lineage/RUSSL_v1.0.0_RUSS_v1.2.0_LCTL_Spinoff.zip` | `e80c83a824135ef57fa8c089c0d6b596fe1f2d3e7ac31dbe819882934c96a1dd` | Superseded prototype archive |
| `lineage/RUSS_P5S3_v1.2.0_prestandard.russl` | `0d3069ee9ecb78f18ae2a4a2f22220d71483cf7ea17ac56d2ee0095e068efa85` | Prototype source only |
| `lineage/RUSS_P5S3_v1.2.0_prestandard.russir.json` | `065982d79d1c299def5212c22a7e6f4f34a5a5f19bc1969a12313b157bca1062` | Prototype IR only |
| `lineage/RUSS_P5S3_v1.2.0_prestandard.russ` | `08524bc903b07804b6869ca6b1299922588dccc964e0f3b2840ad9901453d76b` | Prototype container only |

Original user archive SHA-256: `8f900e895c0e403885d82b8b84d2de756391908e95e9380d9ea471ef5dc3b1c8`. The rebuilt v2 bundle receives a different release identity; it does not overwrite the original accession.

## Declared but unavailable/unauthenticated sources

The parent RUSS 1.1 artifact hash `b51d0f360d1afbdfe2703720cbd1d98cdf1c824f0e93423dd5683d18ac9eb262` is declared in lineage records; the original parent artifact is not independently available as a source object here. It is a declared lineage reference, not a freshly verified accession. Lab PDF `8S_Labs_3001_4000b.pdf`, pages 136–145, is absent. MSSL internal IDs/kappa values are preserved separately from outer file hashes; no independent MSSL internal-identity specification or authenticated source-author trust chain is supplied.

## External references and canonicalization boundary

`research/source_registry.json` records titles, exact URLs, versions, access date, availability and claim limits. TIFF 6.0, BigTIFF design, OGC COG 1.0, OME NGFF 0.5 and observed Zarr core 3.1 are reviewed external inputs to adapter design. Mutable website URLs need snapshot/commit preservation before production reliance. Citations do not constitute completed external interoperability tests.

The legacy sorted compact Python JSON identity profile is not RFC 8785 JCS by name. JCS uses ECMAScript number serialization and UTF-16 property ordering and preserves string data without Unicode normalization. Source NFC and Python ordering/float text can differ. See [RFC 8785, June 2020](https://www.rfc-editor.org/rfc/rfc8785.html) (accessed 2026-10-09) and `research/REPRODUCIBILITY_AND_CANONICALIZATION.md`. Retain existing RUSSL/1.0 domains unless an explicit identity migration is adopted.

## Supersession

Keep eight-column source structure and deterministic-lowering concepts as documented. Reject prototype storage-path-as-core-state semantics. Current artifact status derives from actual v2 evidence and limitations, not inherited GO, true source assertions, nested historical reports or the wording of a construction prompt. Missing evidence remains missing until independently supplied and reviewed.


## Additional research accession RA01–RA19

The 2026-10-09 research accession adds one 23-page 1-Bit LAMB preprint and eighteen text exports. Their exact bytes, names and SHA-256 digests are in research/ADDITIONAL_SOURCE_INTAKE.json and lineage/research_additions/. Source IDs are retained in the central registry and claim reviews. These documents are evidence to audit, not instructions to execute and not automatically corpus normative authority.

A published author result is scoped to its stated task, data, model, algorithm, platform and comparison. A conversation export can supply a proposal or citation lead; it does not independently establish an empirical result, mathematical theorem, hardware capability or institutional decision. Corrected, unsupported and hypothesis dispositions remain visible rather than being silently promoted. Optional research profiles require their own review and evidence before adoption. The user-selected fixed shape is 4×4×4×16×16; its exact generated ordinal data do not imply scientific sample values.


---

Source: `AUDIT_REPORT.md`

# End-to-End Corpus Audit — 2026-10-09

## Conclusion and disposition

The supplied package is byte-consistent and contains a useful architecture/specification scaffold. Its original completion/conformance claims exceed the supporting executable evidence, and its parser, schema and builder controls contain concrete defects. This audit applies structural hardening, expands every work-package specification and institutional/research support document, preserves original evidence, and produces a versioned candidate with transparent residual obligations. Disposition: **CANDIDATE_REVIEW_REQUIRED; scoped offline verification can PASS; full conformance and institutional approval are not established.**

## Scope, intake and method

The attached `RUSSL_Research_Institutional_Corpus_v1.0.0.zip` has SHA-256 `8f900e895c0e403885d82b8b84d2de756391908e95e9380d9ea471ef5dc3b1c8`. Intake read all 175 outer members (3,428,467 uncompressed bytes), checked CRC readability, bounded size/count, duplicate/case-fold paths, traversal/drive syntax and symlink metadata before extraction. Two nested lineage ZIPs contain another 328 members; both were read and inspected without executing their historical Python/Java/JAR code. An exact original ZIP is retained in the new corpus.

The audit covers package integrity, metadata, all 28 specifications, 293 requirement/test mappings, 9 schemas, 12 source/IR programs, 4 MSSL modules, the master-law source image, golden RUSS container, positive/negative vectors, active tool source, lineage authority and institutional/research/interoperability claims. Methods include file/digest comparison, text/AST/static code review, targeted original-parser mutation experiments, closed schema checks, bounded container checks, executable regression testing and dated official-source research. It is an artifact/software/design audit; no production service, real institutional identity, private laboratory source, scientific dataset or live distributed deployment was supplied.

Original manifest verification checked 171 content entries with zero mismatches. Original SHA256SUMS checked 174 entries with zero mismatches. All 28 original completion output hashes agree with their files. These correct hashes establish preservation consistency, not the correctness of the assertions inside those files.

The original verifier could not run unchanged in the observed clean bundled Python environment because `jsonschema` was absent and its dependency was undeclared. Its source and recorded 15 aggregate check results were reviewed; the historical recorded GO was not reclassified as a newly reproduced whole-suite result. Targeted controls and all candidate tooling were executed separately. The new verifier uses only the standard library and has an explicit supported-schema subset.

## Findings and applied remediation

Severity is qualitative relative to use of this candidate tooling, not a deployment vulnerability score. High means the issue can misstate authority or invalidate a safety boundary if treated as authoritative. Medium means ambiguity, inadequate verification or reproducibility. No exploit of a production system is alleged.

| ID | Severity | Finding and evidence | Applied disposition |
|---|---|---|---|
| A01 | High | 293 test registrations contain only two unique generic procedures; 70 are labeled executable without fixture/command/oracle results per requirement | preserve IDs; rewrite methods/oracles; record partial evidence/NOT_RUN; full conformance false |
| A02 | High | 28 records assert GO/G0–G9 without identifiable review signatures or actual review decisions | candidate records replace blanket approvals; history retained |
| A03 | High | original parser accepts STATE_COMMIT with `eff=read` | require catalog effect agreement; negative regression |
| A04 | Medium | rows before columns, duplicate column headings and a defaults directive inside a frame are accepted | explicit parse phases and structural rejection |
| A05 | Medium | duplicate unit/ARG keys overwrite earlier values | reject duplicates; reject unknown directive/structured-profile fields |
| A06 | Medium | original phi accepts NaN anchor, fractional and boolean indices/domain sizes | finite, integer and bounded coordinate profile |
| A07 | High | original schemas accept `axes=[]` and numeric tuple/digest values because prefixItems lacked minItems and pattern lacked type | exact rank/axis cardinality and explicit digest string types |
| A08 | Medium | broad additionalProperties and unspecified operator/tuple shapes weaken known contracts | close known schema objects; constrain enum/order/bounds and add semantic cross-checks |
| A09 | High | original builder recursively deletes an environment-selected output path at startup | preserve as historical text; new active builder never recursively deletes |
| A10 | Medium | original verifier depends on undeclared jsonschema, uses assertions for gates and writes evidence on every run | offline stdlib verifier, explicit conditions and optional writes |
| A11 | Medium | golden container verifier omits important flags, declared-size, path, component/reference and cross-binding defenses | bounded verifier and hostile mutations, including recomputed tuple IDs |
| A12 | Medium | algorithm sections duplicate high-level prose and examples are frequently generic/empty | package-specific formal rules, algorithms, edge cases and implementation roadmap |
| A13 | High | authority/ratification and coverage language can be read as more assurance than exists | candidate authority and assurance defeaters; distinguish review/test/science/authentication |
| A14 | Medium | external TIFF/NGFF standards were unpinned/unverified in original adapter notes | dated primary sources and version-specific mapping/negative obligations; no adapter certification |
| A15 | Medium | research mechanics, external laboratory pages and scientific validity lack supplied empirical evidence | preserved source digests, provenance gap register and preregistered experiment designs |
| A16 | Medium | archival/change/governance policies are short statements without accountable operational process | expanded proposed roles, review/quorum, archival fixity/recovery, incident and change workflows |
| A17 | Medium | rights/privacy/trust-root/runtime obligations are unresolved | explicitly documented residual work; no invented permissions, signatures or results |

The original mutation observations are retained in `evidence/ORIGINAL_ADVERSARIAL_OBSERVATIONS.JSON`; all eleven selected malformed/numeric/schema cases were accepted by the original control. Candidate regression tests cover the corrected boundaries. Tests demonstrate observed behavior for selected inputs rather than exhaustive absence of defects.

## Compatibility and changes

All 293 requirement identifiers and normative requirement tables are retained. The package's editorial and assurance version is 2.0.0; RUSSL/1.0, CanonicalIR/1.0 and the golden RUSS 1.3 framing remain the selected compatibility profile. All 12 valid program IR objects/IDs remain exact. Four MSSL modules, master-law image and example sources/lowered IR remain unchanged. Exact original tuple bytes are preserved under examples/legacy_golden/. The active coherent fixture has new identities after correcting its descriptor to the declared 4×4×4×16×16 f64 field. Historical prompts inside lineage remain data. The new parser intentionally rejects previously accepted ambiguous or out-of-profile forms. A complete language implementation must make its own declared conformance claim with further tests.

## Evidence and release decision

Current executable results are `evidence/CONFORMANCE_RESULTS.json`, with separate byte integrity in `evidence/RELEASE_INTEGRITY.json`. Requirement-level evidence and scope limits are in `machine/registries/requirement_results.json`. Content hashes, build receipt and checksums are regenerated after reviewable edits. The ZIP is sorted with fixed member timestamps and standard compression; repeated same-environment sealing is checked for identical archive bytes. This is deterministic packaging of the current edited tree, not independent reconstruction of the corpus from the original unavailable external sources.

Remaining scientific, implementation, trust, rights and institutional questions have named closure criteria in [unresolved issues](UNRESOLVED_ISSUES.md), the implementation roadmap and proposed policies. A lack of external evidence is retained as an open issue rather than filled with model-generated approval. The intended next research stage is reviewed implementation and controlled experiments, followed by independent replication and accountable institutional decisions.

## Audit limits

No formal proof, general JSON Schema conformance, independent cryptographic review, exhaustive fuzz campaign, cross-platform runtime matrix, production penetration test, JAR execution, full historical compiler validation or empirical mechanics replication was performed. Remote standards were reviewed through their primary publisher pages at the stated access date; immutable copies/licensing are future archival obligations. These limits permit release of a documented candidate but prevent calling it certified, production authorized or scientifically validated.


## Independent tooling review and final corrections

A separate read-only review challenged the first candidate using hostile schemas, rebuilt tuple hashes and contradictory integrity metadata. The original probes are retained in evidence/INDEPENDENT_TOOLING_REVIEW.json, with final disposition in evidence/TOOLING_REVIEW_RESOLUTION.json.

| Additional finding | Applied change |
|---|---|
| Original golden source f64 shape 4,4,4,16,16 conflicts with u8 descriptor shape 1,1,3,64,64 | Preserve legacy fixture, reject its binding, construct a coherent current fixture and test shape forgery despite recomputed roots |
| Recursive schema negation swallowed resource failures | Reject cyclic references; separate instance mismatch from schema/resource failure |
| Malformed keyword declarations accepted | Validate supported keyword value types/cardinalities and reject invalid declarations |
| Tuple metadata and policy role could be replaced after rehashing | Pin known golden identity/geometry profile; policy must bind a declared ADMISSION_EVAL module |
| Integrity metadata could contradict bound reports | Pin version/domain/exclusion/count policies; verify receipt/report status and digest consistency |
| First-seal count changed on second seal | Validate generated JSON but exclude its volatile presence from stable input-record counts |
| Missing vector/test inventories could pass vacuously | Require four positive/five negative source vectors and required regression files |
| Seal writes preceded symlink checks | Reject path escapes/symlinks/caches before generated writes |
| Whole-file reads and schema comparison work lacked early bounds | Stream hashes, bound JSON/container reads, enforce schema-node/comparison budgets |

Additional user-supplied research intake comprises one 23-page paper preprint and eighteen text exports. Their exact bytes/hashes are retained under lineage/research_additions/ with research/ADDITIONAL_SOURCE_INTAKE.json. The new research reviews distinguish publication evidence, corrected conversation claims, hypotheses and rejected connections. The 4×4×4×16×16 indexing fixture enumerates all 16,384 sites; it is generated mathematical data, not measured mechanics, optical or optimizer output. The final integration report records relevance and source-by-source dispositions.

## Final additional-research review

The final synthesis includes 159 unique source-linked decisions: 24 supported primary component claims, 64 corrections, 53 unsupported claims or extrapolations, seven explicit rejections and eleven hypotheses. The registers retain each reviewer's original terminology and the normalization map. Eleven broader research profiles remain proposed; finite address/inverse and optional metric helpers are implemented separately. Three visually inspected paper pages are delivered with exact source/render digests. No empirical observations or benchmarks were generated.

A final read-only consistency review corrected the LAMB estimate/measured-runtime distinction, paragraph ranges and intermediate-path portability. V14 now cross-checks actual per-source claim coverage, unique IDs, original/normalized counts, the exact evidence index, source/extract hashes, rendered-page provenance and fixed-shape data. Six targeted negative mutations are rejected against a passing unchanged control, recorded in [research-index mutation results](evidence/RESEARCH_INDEX_MUTATION_RESULTS.json). This evidence is limited to the declared indexing and verification behavior.


---

Source: `CHANGELOG.md`

# Change Log — 2.0.0

Package 2.0.0 supersedes unsupported blanket completion/ratification claims while preserving the language marker, original requirement IDs, raw mechanics sources and golden compatibility fixtures.

| Area | Applied change | Result |
|---|---|---|
| Assurance | Replace 28 G0–G9 GO records with review-pending, digest-bound records | no invented approval |
| Traceability | Separate 293 registrations, partial evidence and unexecuted obligations | registration cannot imply a test pass |
| Parser | Enforce directive phases/keys, ordering, symbols, dependencies, quotes and input limits | malformed/ambiguous inputs reject |
| Effects | Reject overrides that hide or broaden catalog effects | commit cannot relabel itself read |
| JSON | Reject duplicate keys, nonfinite/overflow values and invalid Unicode/resource limits | deterministic interpretation |
| Field | Exactly five axes; reject bool/fractional/nonpositive dimensions and invalid coordinate inputs | stable structural contract |
| Schemas | Type digests, close known objects, constrain ordering/enums/cardinality | demonstrated bypasses close |
| Container | Bound lengths/paths and check declared sizes, tuple order, source/IR/MSSL references | corrupted/forged bindings reject |
| Tooling | Replace recursive-delete builder and undeclared third-party dependency | offline candidate checks |
| Verification | Add adversarial tests, read-only verifier and separate scoped PASS | reviewable evidence |
| Specifications | Expand all 28 with specific formal/algorithmic/edge-case interpretation | detailed implementation obligations |
| Research | Add provenance, protocols, uncertainty, controls and bibliography | falsifiable future research |
| Adapters | Pin external standards and detail mapping/failure behavior | design candidates with validation gaps |
| Institution | Expand governance, assurance, archival/change/incident/rights/privacy policies | actionable proposed controls |
| Preservation | Include exact original ZIP; archive old tools as text | recoverable audit trail |
| Coherent fixture | Correct original source/field shape and dtype contradiction; preserve legacy fixture | exact current 4×4×4×16×16 f64 declaration binding |
| Added research | Audit nineteen supplied sources, record claim corrections, add exact indexing data and optional experimental profiles | traceable upgrades without importing source instructions |
| Release | Generate reading edition, registries, hashes, unsigned receipts and deterministic ZIP | inspectable distribution |

Strict profile rejections intentionally break compatibility for previously accepted malformed or out-of-profile source. Canonical IDs of all packaged valid source-to-IR programs remain unchanged. The active RUSS fixture has a new tuple/container identity because its field descriptor is corrected; exact original bytes remain under examples/legacy_golden/. Hardened schemas remain a corpus profile of the 1.0 schema labels; consumers must select this package's schema bytes explicitly. No deployment, external publication, trust-root enrollment or empirical validation occurred.


---

Source: `UNRESOLVED_ISSUES.md`

# Unresolved Evidence and Implementation Register

**Corpus:** 2.0.0. **Assessment:** 2026-10-09. Entries describe concrete external or unimplemented gaps; they are not erased by stronger documentation or passing internal checks.

| ID / priority | Gap and impact | Evidence needed to close | Current disposition |
|---|---|---|---|
| `U-01` High | Lab PDF pages 136–145 absent; fraction/variable transcription uncertain | Actual PDF accession/hash/rights, independent equation transcription and correspondence review | OPEN; preserved literal bytes only |
| `U-02` High | Master mechanics symbols, units, score, thresholds and full numerical semantics incomplete | Authoritative definitions, complete algorithm, domain/units dictionary, solver and executable vectors | OPEN; explicit obligations in mechanics review |
| `U-03` High | No empirical mechanics/indicator validation or independent replication | Preregistered lawful data, full code/outputs/uncertainty, qualified review and independent replication | OPEN; no E4/E5 claims |
| `U-04` High | No deployment trust roots, real cryptographic signature verification or revocation authority supplied | Institution-approved trust policy, actual verification implementation and adverse tests | OPEN; effects remain fail closed in reference scope |
| `U-05` High | Production runtime and fabric are not established by reference conformance tooling | Implemented runtime/consistency contract, resource limits, fault/authorization tests, deployment assurance | OPEN; no production authorization |
| `U-06` High | TIFF/BigTIFF/COG adapters and class-specific tests absent | Pinned implementations, genuine fixture hashes, independent readers/writers, claimed OGC class results | OPEN; detailed candidate profile replaces underspecified design |
| `U-07` High | NGFF 0.5/Zarr v3 adapter and independent validation absent | Implemented mappings/codecs/transforms, genuine versioned fixtures and round-trip/loss evidence | OPEN; detailed candidate profile only |
| `U-08` Medium | Mutable external specification URLs lack archived immutable snapshot/commit identities | Verified retained text and hashes/commit plus versioned extension/codec pins | OPEN; version/date/URLs recorded |
| `U-09` High | No appointed institutional reviewers/quorum or external approval | Real role appointments, adopted policy, scoped decision records and signatures | OPEN; charter is proposed |
| `U-10` High | Source/lineage reuse rights, privacy and public distribution authority unknown | Rights inventory and actual rights-holder/institutional disposition | OPEN; no invented license |
| `U-11` Medium | Parent RUSS 1.1 exists as declared hash/reference, not independently accessible original | Original source accession with digest and provenance | OPEN; declared lineage only |
| `U-12` Medium | Independent MSSL internal-ID/kappa semantics and source authorship unverified | Authoritative format/identity construction and authenticated trust chain | OPEN; outer hashes verified, internal fields preserved |
| `U-13` Medium | Independent implementation/formal completeness not shown by self-generated fixtures | Differential implementation, oracle review and proofs or stronger behavior-specific coverage | OPEN; conformance limited to actual checks |
| `U-14` Medium | Long-term archival redundancy/recovery/indexing are policies, not performed service | Custodian, actual redundant deposits, fixity scans/recovery logs and access commitments | OPEN; adoption pending |

## Resolved within authorized scope

Preserved-source outer digests were recomputed and match; source assertions and embedded instructions are explicitly separated from authority; institutional ratification claims are bounded; external primary-standard versions/URLs are researched; adapter mapping/loss/security obligations are expanded; experiments are specified as proposed and falsifiable. These fix audit/documentation defects without pretending to close the evidence gaps above.

Core reciprocal dependencies recorded in `WORKFLOW_ERRATA.md` are historical construction decisions, not external amendments. Current executable, schema, inventory and test repairs are reported in the v2 audit artifacts. Do not treat the historical v1 reports as current evidence.

## Closure rule

A closure record identifies the source/result supplied, hash/version, independent reviewer, scope, counterevidence, decision and affected corpus version. Partial evidence reduces only the gap it actually addresses. A source hash or a new paragraph alone cannot close empirical, cryptographic, institutional or production claims.


## Additional-source research gates

RA01–RA19 do not close U-01–U-14 by being attached. In particular, the laboratory PDF cited by lab_stack.mssl is still absent; the supplied optimizer paper is a different source. Optional p-adic/HRR/optical/optimizer/unikernel proposals require complete algorithms, lawful real inputs, hardware/software identities, measurements, statistical uncertainty and independent reproduction. Conversation equations with missing symbols are preserved as incomplete text, not guessed into normative mechanics. Actual laptop memory characteristics, kernel access and accelerator capabilities were not measured. Source-specific claims and corrections are in the added research reviews and integration report.


---

Source: `spec/WP01_RUSSL_Language_Specification.md`

# WP01 — RUSSL Language Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the normative surface syntax and source canonical form.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** Columned-LCTL lineage, Architecture Charter.

**Mandatory deliverables:**
- lexical grammar
- eight-column syntax
- directives
- namespaces and versions
- canonical source form

## 5. Normative model
### Formal source model
The source unit is a sequence `U=(H,D,B*,F+)` consisting of a fixed header, unit/default directives, zero or more digest-bound MSSL declarations, and one or more frames. Each frame contains the fixed eight-column heading and an ordered list of rows. `ID` is syntactic identity; `CTRL` names dependency predecessors; `IN` carries zero, one, or two primary operands; `ARG` carries operator parameters; `META` carries effect/scope/proof overrides.

The language inherits the Columned-LCTL design law—write only what changes, infer what is stable, lower before authority—but not LCTL quantum operators or runtime semantics. Core semantics are defined by the RUSSL operator registry and RUSSIR, not by physical storage names.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP01-REQ-0001` | Source MUST begin with `RUSSL/1.0` and contain exactly one `@unit` directive. | `WP01-TEST-0001` |
| `WP01-REQ-0002` | Every instruction row MUST contain exactly eight cells in `ID│LANE│OP│OUT│CTRL│IN│ARG│META` order. | `WP01-TEST-0002` |
| `WP01-REQ-0003` | Row IDs MUST be unique within a unit and MUST NOT be inferred. | `WP01-TEST-0003` |
| `WP01-REQ-0004` | Operator aliases MUST lower to registered canonical operators without changing semantics. | `WP01-TEST-0004` |
| `WP01-REQ-0005` | Core RUSSL source MUST NOT name a physical storage backend as the canonical state substrate. | `WP01-TEST-0005` |
| `WP01-REQ-0006` | A conforming reference-profile unit MUST declare `fail=closed`. | `WP01-TEST-0006` |
| `WP01-REQ-0007` | At most two primary input operands MAY be packed in `IN` using U+203A `›`. | `WP01-TEST-0007` |
| `WP01-REQ-0008` | MSSL module declarations MUST carry a SHA-256 digest. | `WP01-TEST-0008` |
| `WP01-REQ-0009` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP01-TEST-0009` |
| `WP01-REQ-0010` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP01-TEST-0010` |
| `WP01-REQ-0011` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP01-TEST-0011` |
| `WP01-REQ-0012` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP01-TEST-0012` |

## 7. Technical interpretation and algorithms

### Parsing as a finite-state process
The hardened reference profile uses states `HEADER → UNIT → DEFAULTS? → BINDINGS* → FRAMES+ → END`. A frame has states `OPEN → COLUMNS → ROWS+ → CLOSED`. The columns heading appears once before rows; nested frames, late global directives, unmatched `@end`, repeated defaults, and an empty frame have no accepting transition. Comments and blank lines are lexical trivia, while source identity remains the identity of canonical text, including comments.

Each row separates on exactly seven literal U+2502 characters. There is no cell-level escape for that delimiter in this profile. `_` is the explicit absent-cell sentinel. ASCII identifier rules and reserved namespaces prevent invisible Unicode characters from being interpreted as distinct authority-bearing symbols. Quoted structured values use the profile's documented string escaping; quotes do not turn an instruction cell into executable code. U+203A separates at most two primary operands; it is distinct from ASCII `>`.

### Structural and data-flow checks
Maintain symbol tables for row IDs, frame IDs, output handles, and MSSL aliases. For a row at ordinal `k`, every control predecessor occurs at an ordinal less than `k`. Thus the accepted control graph is acyclic by construction. A produced handle consumed by row `r` is backed by a unique earlier producer reachable through the transitive closure of `CTRL(r)`. This is stronger than a textual earlier-definition check: unrelated branches do not automatically become dependencies.

The reserved `source.*` convention denotes unresolved external inputs in packaged examples. It is a syntactic interface convention, not evidence that bytes exist, have a particular dtype, or have been authorized. MSSL evaluation operands identify a declared alias. Operator aliases resolve through the catalog before effect checks, and a declared row effect agrees with that operator's registered effect.

### Complexity and limits
Single-pass lexical and namespace checks are linear in source size. Reachability can be computed by predecessor sets or graph traversal; a naive traversal per operand can approach quadratic work. Source bytes, line and cell lengths, frame counts, row counts, and dependency fan-out are bounded before untrusted expansion. Implementation limits are profile limits and produce diagnostics rather than truncated successful programs.

### Structured-key profile boundary
The hardened parser recognizes the current unit/default/frame/MSSL directive keys and `META={eff,scope,proof}`; ARG is `_` or structured key/value pairs. Repeated keys and opaque textual ARG/META fallback are rejected. The supported demonstrated ARG keys include field shape/sample/axes/sparse, population mapping, slice/region selector, pyramid levels/downsample/spatial_axes, mechanics mode/lab_ids/coupling, admission policy/authorization, projection selector/output, receipt content_bound/expected, shard partition/count, root hash, and commit grant. Other catalog operators can be recognized lexically with absent arguments; recognition is not a complete parameter, arity, type, or evaluation contract.

The exact implemented directive values, per-operator ARG key table, quoted-string exclusions, symbol grammar, and frozen default budgets are documented in [the reference profile](technical/REFERENCE_PROFILE.md). Only `scope=self` and deterministic/exact/read/self defaults are accepted by the current parser. MSSL_EVAL and ADMISSION_EVAL require a declared alias plus one data handle. Nonempty ARG key recognition does not validate values or required parameters. Frame, row, and output names remain distinct namespaces.

## 8. Worked example

A minimal structural example, with language version independent of document version:

```text
RUSSL/1.0
@unit id=demo.syntax version=1.0.0 profile=russl.core target=russ fail=closed
@frame id=F0 parent=ROOT module=demo.syntax phase=construct-evaluate
ID│LANE│OP│OUT│CTRL│IN│ARG│META
F1│field│FD│field.main│_│_│shape=1,1,1,2,3;sample=u16;axes=c4,c5,c6,c7,c8│_
P1│field│FP│field.ready│F1│field.main›source.pixels│mapping=origin│eff=derive
@end
```

This shows syntax and structural lowering. `source.pixels` remains an external-input obligation. The field descriptor has six samples; this example does not prove their existence or evaluate them. The full packaged ladder is under `examples/source/`.

## 9. Boundary and adversarial cases

| Input defect | Failure rationale |
|---|---|
| `@defaults` after the first frame | Global environment is no longer unambiguously fixed. |
| Two directives assign the same key twice | Last-write-wins would make authority depend on parser behavior. |
| A row precedes the columns heading | Cell interpretation has no established frame heading. |
| `CTRL=R9` before row R9 | Forward dependency is outside this profile. |
| P1 consumes F1's handle but has no control ancestry to F1 | Evaluation readiness is not established by source order alone. |
| `eff=read` on `STATE_COMMIT` | A syntactic override would conceal the true effect. |
| An extra delimiter appears inside a quoted ARG value | Quoting does not escape the row delimiter. |

## 10. Security and failure considerations

Parsing is an ingestion boundary. Numeric-looking strings are not trusted scalar values until typed by a later phase. Filenames and module names are resolver data, not paths the parser is authorized to open. A storage-leakage scan is a useful architecture lint; it cannot prove that every backend dependency or malicious spelling has been removed.

## 11. Verification obligations and current evidence boundary

The reference parser and lowerer support a bounded, explicitly named profile. Positive examples, malformed ordering, duplicate symbols, ancestry failures, effect mismatches, and MSSL-alias negatives are the relevant executable checks. A parser pass establishes syntactic and structural acceptance only. General semantic validity, dimensional type soundness, external input availability, and execution authority remain separate obligations.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP06 records the explicit lowering result; WP03 owns type validity; WP05 owns byte-bound MSSL resolution; WP09 owns grants. The EBNF and Python profile are reviewed together. A prose example with a `source.*` input is not a self-contained dataset.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP02_RUSSL_Semantic_Specification.md`

# WP02 — RUSSL Semantic Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines deterministic meaning, dependency evaluation, state transitions, and failure behavior.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, MSSL binding model.

**Mandatory deliverables:**
- semantic domains
- dependency DAG
- evaluation order
- state transition semantics
- halt/failure semantics

## 5. Normative model
### Operational relation
Let `G=(V,E)` be the row dependency DAG after lowering. Configuration is `⟨G,σ,e,a⟩`, where `σ` is the immutable handle environment, `e` is the evidence log, and `a` is the authorization context. A row may step only when every predecessor is terminal-success and its input handles are available. A derive/project step extends `σ`; it does not mutate an existing handle. An effectful step additionally requires `authorize(a,row,effect)=true`.

Deterministic mode chooses the least source ordinal among eligible rows. Failure produces a terminal diagnostic and suppresses downstream effectful transitions.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP02-REQ-0001` | Program meaning MUST be defined over the lowered dependency graph, not source text alone. | `WP02-TEST-0001` |
| `WP02-REQ-0002` | A row MUST become eligible only after all declared control dependencies are satisfied. | `WP02-TEST-0002` |
| `WP02-REQ-0003` | Among simultaneously eligible rows, deterministic mode MUST use source ordinal as the tie-breaker unless a profile specifies an equivalent deterministic order. | `WP02-TEST-0003` |
| `WP02-REQ-0004` | A failed verification, binding, type, authorization, or canonicalization precondition MUST halt the affected commit path. | `WP02-TEST-0004` |
| `WP02-REQ-0005` | Derived operations MUST NOT mutate an admitted root. | `WP02-TEST-0005` |
| `WP02-REQ-0006` | Execution observations MUST distinguish candidate state from committed fabric state. | `WP02-TEST-0006` |
| `WP02-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP02-TEST-0007` |
| `WP02-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP02-TEST-0008` |
| `WP02-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP02-TEST-0009` |
| `WP02-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP02-TEST-0010` |

## 7. Technical interpretation and algorithms

### Configuration and eligible rows
Refine the operational configuration to `K=⟨G,σ,q,e,a,h⟩`, where `q:V→{pending,running,succeeded,failed,blocked}` records row state and `h` contains external mutable-head observations. Let `pred(r)` include declared control predecessors and validated data-flow obligations. The eligible set is `Ready(K)={r | q(r)=pending ∧ ∀p∈pred(r),q(p)=succeeded ∧ inputs(r)⊆dom(σ)}`.

In deterministic sequential mode select `argmin ordinal(r)` from `Ready(K)`. Evaluation produces either `Ok(values,receipts)` or `Err(diagnostic)`. Success extends the handle environment by fresh names and marks the row succeeded. Failure records a primary cause and blocks descendants on the affected effect path. An empty ready set with pending rows is a liveness failure or missing-input condition; it is not successful completion.

### Pure and effectful transition rules
For derivation, `eval(op,inputs,args,module_profile)=v` yields `σ'=σ[out↦v]` without modifying existing bindings. The preservation obligation is `∀x∈dom(σ), σ'(x)=σ(x)`. Projection obeys the same immutable-input rule even when values are reduced.

For an effectful row, successful evaluation constructs an effect plan first. Application is a separate transition guarded by verified identity, matching input root, matching argument digest, live grant, and deployment state preconditions. A plan records intended changes; it does not report those changes as already committed. Parallel schedulers may reorder independent pure rows only when their observations and canonical output identities match the declared deterministic profile.

### Safety and liveness claims
Candidate safety is the invariant that failed or unauthorized rows cannot advance a mutable head. Exactly-once application is not implied by a DAG or a deterministic tie-breaker: retries require WP08/WP12 transaction records. Liveness additionally depends on finite module evaluation, external input availability, and a progressing adapter. These assumptions are made explicit in a proof or test report rather than absorbed into a language-level success claim.

## 8. Worked example

Suppose R1 defines a field; R2 and R3 independently derive regions with `CTRL=R1`; R4 builds a candidate root with `CTRL=R2,R3`. After R1 succeeds the eligible set is `{R2,R3}`; sequential deterministic mode chooses R2 if its ordinal is smaller. R4 is blocked until both regions succeed.

If R3 fails integrity verification, R2's derived immutable value may remain observable as candidate data, but R4 cannot produce a valid commit path. A later independent read can be handled only under an explicitly chosen failure profile. No rollback is needed to erase immutable candidate bytes; rollback concerns mutable authority-bearing state.

## 9. Boundary and adversarial cases

| Scenario | Semantic consequence |
|---|---|
| A scheduler runs R4 after only R2 succeeds | Dependency readiness is violated. |
| Derivation updates an existing admitted root in place | Handle immutability is violated. |
| A missing external sample is treated as zero | Program meaning changes through an implicit input. |
| A receipt says committed when only a plan was produced | Candidate and committed observations are conflated. |
| Parallel reducers use nondeterministic accumulation order | The claimed numeric/determinism profile is not established. |

## 10. Security and failure considerations

Untrusted mechanics can fail to terminate or demand unbounded resources even when source syntax is declarative. A runtime therefore needs budgeted evaluation and a defined cancellation boundary. The parser's finite DAG checks establish ordering, but no interpreter, complete semantic evaluator, or liveness proof is supplied by that fact.

## 11. Verification obligations and current evidence boundary

Planned evidence includes transition-trace tests, differential schedulers, immutability assertions, injected module failures, and a model checker for the commit-path invariant. Structural dependency tests are partial evidence only. No full operational-semantics conformance is claimed for the packaged lowerer.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01's source-order restriction is a profile choice; WP02 defines meaning over the lowered graph. WP08 supplies lifecycle transitions, WP09 supplies authorization, and WP12 supplies mutable-head consistency.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP03_RUSSL_Type_System.md`

# WP03 — RUSSL Type System

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines static and runtime types for values, coordinates, fields, modules, evidence, grants, and tuple handles.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP02, WP04.

**Mandatory deliverables:**
- type grammar
- dimensional typing
- unit rules
- effect typing
- inference limits

## 5. Normative model
### Type judgments
Core judgments have the form `Γ;Ε ⊢ row : τ ! ε`, where `Γ` maps handles to value types and `Ε` maps the row to its declared effect. Representative types are `Digest`, `Coord5`, `Shape5`, `Region5`, `Field<T,5>`, `MSSL<Module>`, `Evidence`, `Grant<Scope>`, `Root`, and `RUSSTuple`. `Field<T,5>` is invariant in rank; projections explicitly change rank.

Units are carried as qualified metadata and may constrain arithmetic or projection profiles, but a numeric value without unit metadata is never silently promoted to a physical quantity.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP03-REQ-0001` | The type system MUST include scalar, digest, coordinate, shape, field, MSSL-module, evidence, grant, root, and tuple-handle types. | `WP03-TEST-0001` |
| `WP03-REQ-0002` | A `Field<T,5>` MUST have exactly five indexed domains. | `WP03-TEST-0002` |
| `WP03-REQ-0003` | Dimension-changing operations MUST state their output rank and axis mapping. | `WP03-TEST-0003` |
| `WP03-REQ-0004` | Physical units MUST be metadata with explicit unit identifiers and MUST NOT be inferred from raw magnitudes. | `WP03-TEST-0004` |
| `WP03-REQ-0005` | Unknown or conflicting types MUST fail closed before effectful execution. | `WP03-TEST-0005` |
| `WP03-REQ-0006` | Floating-point values used in identity-critical structures MUST follow WP17 canonical representation rules. | `WP03-TEST-0006` |
| `WP03-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP03-TEST-0007` |
| `WP03-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP03-TEST-0008` |
| `WP03-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP03-TEST-0009` |
| `WP03-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP03-TEST-0010` |

## 7. Technical interpretation and algorithms

### Type domains and environments
A proposed type grammar is `τ ::= Bool | Int<w,s> | Float<w> | Decimal<p,s> | Digest<domain,alg> | Coord<rank> | Shape<rank> | Region<rank> | Field<sample,rank,axes> | Module<contract,digest> | Evidence<claim> | Grant<scope> | Root<domain> | Tuple<abi>`. Width, signedness, rank, coordinate basis, and digest domain are refinements; their erasure into a display label is not a proof of compatibility.

Use `Γ;Δ;Π ⊢ r : τ ! ε`, with handle environment Γ, module contracts Δ, and feature/numeric profile Π. The catalog's result labels such as `field_descriptor` are lowering annotations; a complete checker would verify these judgments rather than copy a label.

### Representative typing rules
For field construction, `shape=(n4,…,n8)`, all dimensions are positive integers, axes are five distinct declared domains, and dtype is supported; then `FIELD_DEFINE : Field<T,5>`. Population additionally checks source cardinality and sample compatibility. For a region `[la,ua)`, require `0≤la≤ua≤na` on each axis. A slice over a rank-k output declares exactly k surviving axes in a unique order, with fixed indices in range.

For evaluation, a declared MSSL alias resolves to a module contract `(τ1,…,τm)→τo`; operand arity and refinements agree with the contract. For commit, the candidate has a sealed-root type, arguments bind the observed head, and the effect is `commit`; policy evidence has a distinct type and is not coercible to `Grant<commit>`.

Unit compatibility is a profile relation `compatible(u,v)` accompanied by a declared conversion. Raw magnitudes have no physical unit. Numeric widening, signed conversion, overflow, rounding, and nullable/missing samples require explicit profile policies; the checker never repairs an unknown type by guessing.

### Soundness obligations and inference limits
Progress means a well-typed ready pure row either returns a declared result or a declared bounded failure. Preservation means successful evaluation maintains all output refinements and existing handle types. These are intended proof obligations, not established theorems. Inference is limited to registered operator defaults and uniquely known handle information; it does not infer absent calibration, module contracts, or authority.

## 8. Worked example

A `u16` field of shape `(1,1,1,2,3)` requires six samples in the canonical index traversal. Population by six integers in `[0,65535]` can satisfy an exact-value contract. Population by six floats requires a declared conversion; population by five samples fails cardinality checking.

A slice fixing c4, c5, and c6 yields `Field<u16,2,[c7,c8]>`. Reversing the output axes yields a different descriptor. An evidence digest and payload-root digest are both hexadecimal strings but have different domain-refined types.

## 9. Boundary and adversarial cases

| Defect | Intended type failure |
|---|---|
| `shape=1,1,1,2,0` | Empty dense axis violates the field-domain refinement. |
| Boolean used as an integer index | Host-language subtype behavior is not the intended index type. |
| Rank-3 transform attached to rank-5 input | Matrix and axis domains disagree. |
| A meter value is added to an unlabelled scalar | Unit inference would fabricate physical meaning. |
| Admission disposition used in a grant position | Policy and authorization types are disjoint. |
| Digest from another identity domain is accepted by spelling alone | String shape does not establish domain validity. |

## 10. Security and failure considerations

Type labels do not establish trust. Even a well-typed input can carry malicious bytes, false provenance, or an expired grant. Runtime checks remain necessary for externally supplied handles, module contracts, and range-dependent refinements. Opaque `source.*` handles remain unresolved until a resolver supplies typed, digest-bound inputs.

## 11. Verification obligations and current evidence boundary

The delivered tooling performs selected structural, operator-effect, and field-coordinate checks; it is not a general dimensional type checker. Required future tests include each rule's positive and negative derivations, overflow boundaries, unit conversions, missing-value cases, and a proof or mechanized review of progress/preservation for the implemented operator subset.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP04 defines dimensions and coordinates; WP05 defines module byte and contract binding; WP17 defines canonical identity-critical numbers. Package version 2.0.0 does not introduce a new language type syntax into `RUSSL/1.0`.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP04_Penteract_Field_Specification.md`

# WP04 — Penteract Field Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the storage-independent five-dimensional sample field used in place of a TIFF-like raster.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP03, Imaging requirements, P5×S³ research input.

**Mandatory deliverables:**
- field model
- coordinate normalization
- dense/sparse realizations
- regions/chunks
- multiresolution pyramids
- slicing/population

## 5. Normative model
### Field definition
For finite domains `Da={0,…,na−1}`, the canonical logical field is `F:D4×D5×D6×D7×D8→S`. For `na>1`, `φa(i)=-1+2i/(na−1)`. For `na=1`, `φa(0)=anchor_a`, with default `anchor_a=0`. This defines Penteract coordinates independent of storage.

A 2D raster of height `H` and width `W` can be embedded as shape `(1,1,1,H,W)` with `c4=c5=c6=0`, `c7=φ7(y)`, `c8=φ8(x)`. RGB may use a packed pixel sample or shape `(1,1,C,H,W)` with `c6` as channel. Sparse and dense realizations are logically equivalent where samples are defined.

A logical region is the Cartesian product of five half-open index intervals. A pyramid level declares a deterministic reduction transform and maintains the same normalized field extent.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP04-REQ-0001` | The canonical Penteract field MUST be storage-independent. | `WP04-TEST-0001` |
| `WP04-REQ-0002` | A finite dense realization MUST declare shape `(n4,n5,n6,n7,n8)` with each `na ≥ 1`. | `WP04-TEST-0002` |
| `WP04-REQ-0003` | For `na>1`, the default normalized coordinate MUST be `ca=-1+2*i/(na-1)`. | `WP04-TEST-0003` |
| `WP04-REQ-0004` | For singleton axes, the coordinate MUST use an explicit anchor in `[-1,1]`, defaulting to `0`. | `WP04-TEST-0004` |
| `WP04-REQ-0005` | Sparse realizations MUST preserve the same logical coordinate semantics as dense realizations. | `WP04-TEST-0005` |
| `WP04-REQ-0006` | A 2D raster embedding MUST be expressible by fixing three axes and varying two axes. | `WP04-TEST-0006` |
| `WP04-REQ-0007` | Multiresolution levels MUST preserve the same logical field extent and record their reduction transform. | `WP04-TEST-0007` |
| `WP04-REQ-0008` | Logical regions/chunks MUST be defined by coordinate ranges independent of physical object layout. | `WP04-TEST-0008` |
| `WP04-REQ-0009` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP04-TEST-0009` |
| `WP04-REQ-0010` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP04-TEST-0010` |
| `WP04-REQ-0011` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP04-TEST-0011` |
| `WP04-REQ-0012` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP04-TEST-0012` |

## 7. Technical interpretation and algorithms

### Index geometry and exact coordinates
The authoritative finite index space is `D=∏a=4..8 {0,…,na−1}`. Its size is `N=∏na`, computed with checked arithmetic before allocation. Normalization maps indices to logical coordinates; it does not convert them into length or time. For `na>1`, evaluate the rational expression `(2i−(na−1))/(na−1)`; endpoints are exactly −1 and +1 mathematically. Floating implementations specify rounding and tolerance separately.

The inverse is `i=(c+1)(na−1)/2`, valid only when it is an integer in range. A nearest-neighbor policy can map other coordinates to indices, but that resampling policy is profile behavior. For a singleton axis, an explicit finite anchor in `[-1,1]` represents its location; there is no inverse that recovers multiple indices.

### Regions, dense traversal, and sparse absence
A region is `R=∏[la,ua)` with integer bounds `0≤la≤ua≤na`; empty regions have a zero extent on at least one axis. The dense field itself still has positive dimensions. A useful canonical sample traversal is lexicographic index order with c8 fastest, followed by c7 through c4; any implementation adopting it records dtype, byte order, and sample packing in the payload profile. This traversal proposal is not inferred from physical chunk filenames.

Sparse realizations distinguish an absent coordinate from an explicitly stored zero, null sample, mask, or NaN in a numeric payload. A sparse contract declares coverage and absence behavior. Dense/sparse equivalence is extensional equality on the same declared domain and sample-presence policy; matching values only at stored points is insufficient.

### Pyramids and extent
A pyramid descriptor binds parent root, per-level shape, reduction kernel, boundary policy, sampling phase, and coordinate transform. Preserving logical extent means coarse-level coordinates remain related to the same parent domain; it does not mean a downsampled image preserves sample values. A singleton coarse axis needs a chosen anchor. Overlapping regions agree on any shared defined sample or produce an explicit conflict; insertion order cannot decide authoritative value.

## 8. Worked example

For shape `(1,1,1,3,5)` with default singleton anchors, index `(0,0,0,1,3)` maps to `(0,0,0,0,1/2)`. Region `[0,1)×[0,1)×[0,1)×[1,3)×[2,5)` contains six samples and excludes y=3 and x=5.

A level with shape `(1,1,1,2,3)` can span the same normalized endpoints as the parent. Its middle x coordinate is 0, while the parent has more samples. The recorded reducer explains how those new values were generated; coordinate agreement alone does not establish value equivalence.

## 9. Boundary and adversarial cases

| Boundary case | Required interpretation of existing requirements |
|---|---|
| Zero or negative dense dimension | Invalid finite realization. |
| Anchor NaN or infinity | Not an element of the normalized interval. |
| Fractional, boolean, or out-of-range index | Not a domain index. |
| Overflow in product of dimensions | Reject before allocation. |
| Sparse absence silently filled with zero | Coverage semantics change. |
| Two chunks claim different values at the same logical coordinate | Conflict is unresolved. |
| Pyramid shape changes without reduction/placement metadata | Extent and sample meaning are not reconstructible. |

## 10. Security and failure considerations

Shape multiplication, region fan-out, and decompression can exhaust resources before mechanics evaluation. Validation precedes materialization. Coordinate normalization supplies a geometric indexing convention only; it does not establish a five-dimensional physical space or validate P5×S³ mechanics.

## 11. Verification obligations and current evidence boundary

Coordinate-vector and strict-input tests exercise `phi` for singleton and nonsingleton axes. Full field conformance needs payload cardinality, dtype, endian, region partition, overlap, sparse-coverage, and pyramid-reduction tests. Metamorphic checks include endpoint preservation, monotonicity, and independence from chunk partition.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

Additional research selects the explicit 4×4×4×16×16 finite domain. The informative [fixed-shape indexing profile](research/FIXED_SHAPE_INDEXING_PROFILE.md) supplies 16,384 exact ordinal/index pairs, rational normalized coordinates and an optional 2-adic ordinal metric. The optional topology does not replace P5 geometry or physical calibration.

## 13. Cross-specification consistency

WP14 and WP15 attach imaging or scientific meaning through profiles. WP12 indexes immutable regions, and WP13 changes physical layout without changing logical coordinates. WP03 owns rank/refinement typing.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP05_RUSSL_MSSL_Binding_Specification.md`

# WP05 — RUSSL–MSSL Binding Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines digest-bound discovery, import, parameterization, invocation, and result binding for MSSL.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP02, Baseline MSSL family.

**Mandatory deliverables:**
- module reference
- digest/version binding
- parameter binding
- result binding
- capability boundary
- failure behavior

## 5. Normative model
### Binding function
A binding record is `B=(alias,module,source_version,file_digest,capabilities,metadata)`. Resolution returns module bytes only if `SHA256(bytes)=file_digest`; otherwise resolution fails. The MSSL internal identity and κ value may be recorded as additional provenance, but the file digest is the corpus byte-binding authority.

The supplied baseline modules are mechanics (`master_coupled_mechanics`), laboratory stack (`lab_stack`), product metrics (`product_metrics`), and final admission (`final_admission`). Evaluation is performed by an MSSL interpreter under the invoking row's effect/capability envelope.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP05-REQ-0001` | Each MSSL binding MUST identify module name, source version, alias, and file digest. | `WP05-TEST-0001` |
| `WP05-REQ-0002` | The bound module bytes MUST be verified against the declared digest before evaluation. | `WP05-TEST-0002` |
| `WP05-REQ-0003` | RUSSL MUST treat MSSL as the mechanics/policy authority and MUST NOT substitute a storage adapter for an MSSL module. | `WP05-TEST-0003` |
| `WP05-REQ-0004` | Module inputs and outputs MUST be explicitly bound by symbolic handles. | `WP05-TEST-0004` |
| `WP05-REQ-0005` | An MSSL module MUST NOT acquire effects beyond the invoking row grant. | `WP05-TEST-0005` |
| `WP05-REQ-0006` | The baseline registry MUST include the four supplied MSSL modules by exact file digest. | `WP05-TEST-0006` |
| `WP05-REQ-0007` | Unresolved or digest-mismatched MSSL bindings MUST fail closed. | `WP05-TEST-0007` |
| `WP05-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP05-TEST-0008` |
| `WP05-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP05-TEST-0009` |
| `WP05-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP05-TEST-0010` |
| `WP05-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP05-TEST-0011` |

## 7. Technical interpretation and algorithms

### Resolution protocol
Treat a binding as both a lookup descriptor and a byte-integrity obligation. Resolve a module name and source version through an explicit allow-listed registry. Read the candidate bytes once into a bounded immutable buffer, calculate SHA-256 over those exact bytes, compare with the declared digest, and pass that verified buffer to the interpreter. Reopening a mutable path after verification creates a check/use race.

The baseline digest is a raw-file digest, separate from any MSSL internal identity or mathematical κ expression. Different newline normalization changes raw-file identity. The caller records both identities if both are meaningful, rather than substituting one for the other.

### Contract and authority boundaries
A module interface describes named parameters, their types/units, allowed modes, result fields, numerical regime, failure dispositions, and imported dependencies. Binding verifies that an invoking row supplies compatible symbolic handles and named arguments. Evaluation sees only the capability envelope explicitly delegated to it; filesystem, network, clock, and publication access are not implicit consequences of a module's text.

The effective effect set is the intersection of the row's permitted effects, authenticated grant scopes, and the interpreter sandbox profile. A missing grant does not become valid because mechanics produced a favorable result. Module output is candidate data plus evidence until a separate authorization path establishes a state-changing effect.

### Dependencies and determinism
The closure of transitive module imports is digest-bound and acyclic under the chosen interpreter profile, or explicitly treated as an unsupported recursive contract. Evaluation budgets bound steps, recursion, memory, and wall-time as deployment controls. Deterministic evaluation fixes numeric routines, reduction order, seeds, and external observations. The corpus ships four preserved baseline files; preserving and hashing them is distinct from implementing their full language semantics.

## 8. Worked example

The packaged `master_coupled_mechanics` alias can be resolved only to the exact bytes registered under that name and source version. If a space or comment is edited, the raw file digest changes, even if a human considers the mechanics expression equivalent.

An `MSSL_EVAL` row consuming `master›field.populated` first establishes that `master` is a declared alias. Lowering records the binding. Only a later interpreter can establish that `field.populated` satisfies the module's actual input contract and compute a result.

## 9. Boundary and adversarial cases

| Defect | Binding consequence |
|---|---|
| Alias resolves to an unregistered local filename | Resolution authority is missing. |
| Correct module name but altered bytes | Declared file digest does not match. |
| Verified bytes are then replaced before execution | The execution object is no longer bound to the check. |
| Module requests publication while row permits derivation | Capability amplification attempt. |
| Missing referenced research PDF is fabricated | Research provenance is corrupted. |
| κ is substituted for the SHA-256 file digest | Mathematical/internal identity is confused with byte binding. |

## 10. Security and failure considerations

Digest verification establishes consistency with the declared bytes, not author legitimacy or scientific truth. A malicious but digest-matching module remains untrusted code/data. The baseline files are immutable source inputs to this package; changes require new bindings and review rather than silent repair.

## 11. Verification obligations and current evidence boundary

Raw-byte digest checks for all four baseline modules are executable. Alias declaration checks are structural. General module parsing, parameter/result contracts, sandbox enforcement, numerical mechanics, dependency closure, and termination are unimplemented obligations unless a separately identified interpreter supplies evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP06 carries binding descriptors into IR; WP07 binds modules in tuple component M; WP09 caps delegated authority; WP11 keeps policy result separate from authorization.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP06_RUSSL_Intermediate_Representation.md`

# WP06 — RUSSL Intermediate Representation

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines canonical RUSSIR and deterministic source-to-IR lowering.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP02, WP03, WP05.

**Mandatory deliverables:**
- IR schema
- normalized instruction graph
- resolved modules
- lowering
- canonical identity
- golden vectors

## 5. Normative model
### Lowering function
`lower : CanonicalRUSSL → RUSSIR` resolves operator aliases, infers registered face/type/default effect, expands dependencies and packed inputs, and copies unit/default/MSSL declarations. No storage adapter is selected during lowering.

`ir_id = russir:sha256:SHA256("RUSSIR/1.0\0" || canonical_json(IR_without_ir_id))`. Source identity uses the independent `RUSSL-SOURCE/1.0` domain.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP06-REQ-0001` | RUSSIR MUST contain explicit canonical operators, faces, effects, dependencies, inputs, arguments, and metadata. | `WP06-TEST-0001` |
| `WP06-REQ-0002` | RUSSIR MUST preserve source row IDs and source order. | `WP06-TEST-0002` |
| `WP06-REQ-0003` | MSSL aliases in RUSSIR MUST resolve to digest-bound declarations. | `WP06-TEST-0003` |
| `WP06-REQ-0004` | The source-to-IR transformation MUST be deterministic for identical canonical source and compiler profile. | `WP06-TEST-0004` |
| `WP06-REQ-0005` | RUSSIR identity MUST be domain-separated from source and tuple identities. | `WP06-TEST-0005` |
| `WP06-REQ-0006` | IR serialization MUST use WP17 canonical JSON rules. | `WP06-TEST-0006` |
| `WP06-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP06-TEST-0007` |
| `WP06-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP06-TEST-0008` |
| `WP06-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP06-TEST-0009` |
| `WP06-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP06-TEST-0010` |

## 7. Technical interpretation and algorithms

### Deterministic lowering pipeline
The profile pipeline is `canonicalize → parse → validate_structure → resolve_operator_aliases → annotate → serialize → identify`. Operator resolution is a finite catalog lookup. Annotation supplies the registered face, result label, and effect; explicit effects agree with the catalog. Lowering copies declared module descriptors, expands primary inputs, records control dependencies, and preserves frame and row order.

An implementation can check that `program = concat(frame.rows)` by value and order. The duplicated frame/program views are consistency-sensitive: a modified copy in one view is invalid even if the JSON shape remains acceptable. A supplied IR is untrusted until both schema shape and cross-field invariants are verified.

### Identity preimage
Let `J` be the IR object before `ir_id` is inserted. Compute `h=SHA256(ASCII("RUSSIR/1.0") || 0x00 || CJSON(J))`; represent identity as `russir:sha256:h`. Verification removes only the self-identifying `ir_id` field from the preimage and recomputes the digest; removing arbitrary other fields would weaken identity.

The IR schema tag remains `RUSSL.CanonicalIR/1.0` for this package. A compiler/profile identifier belongs in release and reproduction evidence unless a new IR contract explicitly adds it. Identical current IR bytes can retain their previous identities; package version 2.0.0 does not force the language/schema identity domain to change.

### Source positions and equivalence
This IR includes `source_line` annotations and a source digest. Thus adding a comment or blank line can change source identity and source-position fields even when operators behave the same. Semantic equivalence, canonical-source equality, and IR-byte equality are different relations. The lowerer provides deterministic structural translation, not proof that source and runtime semantics are equivalent.

The expected consistency properties are: row IDs preserved; all aliases canonicalized; all referenced aliases declared; no physical adapter chosen; graph order valid; no output produced twice; and the self-identity recomputes under the exact serializer profile.

## 8. Worked example

The source alias `FD` lowers to `FIELD_DEFINE`, with face `FIELD`, result label `field_descriptor`, and effect `derive`. A populated-field operand string `field.main›source.pixels` becomes two ordered inputs.

```json
{"op":"FIELD_DEFINE","face":"FIELD","type":"field_descriptor","effect":"derive"}
```

This fragment is illustrative and not a complete valid IR record. The type label reflects the catalog. It does not certify shape validity, sample cardinality, or the existence of the external input.

## 9. Boundary and adversarial cases

| Modification | Verification failure |
|---|---|
| `frames` row differs from its `program` copy | Cross-view consistency is broken. |
| Alias spelling remains in a canonical operator field | Lowering normalization is incomplete. |
| Module operand names an undeclared alias | Binding relation is unresolved. |
| `ir_id` is trusted without recomputation | Content substitution remains possible. |
| Hash preimage includes `ir_id` recursively | Identity construction is ill-founded. |
| Source-line annotations are discarded during verification | The stated identity no longer covers the supplied object. |

## 10. Security and failure considerations

An IR supplied by another compiler can contain contradictory effects or duplicated authority-bearing fields. Revalidation is independent of having a plausible source hash. A compiler's own digest is supply-chain provenance; it does not certify its correctness.

## 11. Verification obligations and current evidence boundary

Golden source-to-IR comparison, identity recomputation, flattened-view consistency, schema validation, and malformed structural cases are the appropriate current checks. Full semantic preservation and type-correct lowering await an implemented evaluator/checker and independent differential evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 fixes the surface profile; WP03 explains the difference between annotations and types; WP17 fixes exact bytes. WP18 binds compiler identity and profile in reproducibility evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP07_RUSS_Tuple_ABI.md`

# WP07 — RUSS Tuple ABI

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the ABI from RUSSIR and MSSL bindings into a versioned .russ tuple-executable.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP06, WP04, WP05.

**Mandatory deliverables:**
- tuple registry
- component order
- identity
- compatibility
- golden manifest
- container framing

## 5. Normative model
### Normative tuple
The corpus defines the ordered ABI tuple `T=(I,L,G,S,C,M,A,P,F,E,X)`: Identity, Language, Geometry, State, Coupling, Mechanics, Admission, Projection, Fabric, Evidence, Execution. Ordering is identity-significant.

The candidate RUSS 1.3 framing retains the existing RUSS magic/header/record concept but replaces backend-specific canonical state with a logical Penteract descriptor. `tuple_id = russ:sha256:SHA256("RUSS-TUPLE/1.0\0" || canonical_json(T))`. The golden fixture is conformance evidence, not a production authorization.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP07-REQ-0001` | The normative tuple order MUST be `(I,L,G,S,C,M,A,P,F,E,X)`. | `WP07-TEST-0001` |
| `WP07-REQ-0002` | The `L` component MUST bind RUSSL source and RUSSIR identity. | `WP07-TEST-0002` |
| `WP07-REQ-0003` | The `M` component MUST bind MSSL modules by digest. | `WP07-TEST-0003` |
| `WP07-REQ-0004` | The `S` component MUST describe logical Penteract state without requiring a physical backend. | `WP07-TEST-0004` |
| `WP07-REQ-0005` | The `A` component MUST state that commit authorization is independent of mathematical admission. | `WP07-TEST-0005` |
| `WP07-REQ-0006` | Tuple identity MUST be computed over the ordered tuple using a domain-separated digest. | `WP07-TEST-0006` |
| `WP07-REQ-0007` | Every embedded payload member MUST be individually content-addressed. | `WP07-TEST-0007` |
| `WP07-REQ-0008` | The corpus golden `.russ` fixture MUST rebuild byte-for-byte deterministically. | `WP07-TEST-0008` |
| `WP07-REQ-0009` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP07-TEST-0009` |
| `WP07-REQ-0010` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP07-TEST-0010` |
| `WP07-REQ-0011` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP07-TEST-0011` |
| `WP07-REQ-0012` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP07-TEST-0012` |

## 7. Technical interpretation and algorithms

### Ordered logical tuple and member binding
Represent the ABI as an ordered sequence of eleven component descriptors `[I,L,G,S,C,M,A,P,F,E,X]`. A JSON object with alphabetically sorted keys is not a substitute for the specified tuple order. Each component's internal object can use canonical JSON while the enclosing sequence preserves its order.

Identity is computed over the canonical ordered logical tuple in the `RUSS-TUPLE/1.0` domain. A container-file digest identifies physical bytes independently. Repacking the same tuple and members can retain logical identity while changing container bytes; the deterministic golden fixture imposes an additional byte-equality constraint for its particular build profile.

### Framing and bounded verification
The package's .russ framing is a candidate container profile, not a standardized universal RUSS runtime ABI. A verifier first establishes magic, supported version, declared header/record bounds, finite member count, and exact end-of-file consumption. Each offset/length is checked with overflow-safe arithmetic and lies within the container; overlaps and trailing undeclared bytes are rejected under the strict profile.

Logical member names are normalized safe relative paths. Absolute, drive-qualified, parent-traversing, separator-confused, duplicate, or platform-colliding member paths are not safe extraction targets. Validate the member table and payload digests before extraction; parsing never authorizes executing any embedded script. A member descriptor binds its name, logical role, exact size, and digest.

### Graph completeness
Component L binds source and IR; M binds exact mechanics files; S describes logical field state; A distinguishes policy disposition from commit authority. For every required reference `r`, either a verified embedded member supplies it or a declared external resolution contract identifies it. A bare filename, boolean verification flag, or fabricated successful receipt does not discharge reference integrity or authorization.

Dependency closure verification is separate from archive-byte validity. A small structurally valid fixture need not contain scientific payloads or prove a runnable MSSL stack.

## 8. Worked example

The logical tuple can bind `L.source_id` and `L.ir_id`, four MSSL digests in M, and a shape descriptor in S. The container stores source/IR/module members with raw byte digests. To verify it, recompute both member digests and the domain-separated tuple identity; comparing only the outer file checksum cannot establish that internal references match.

Two rebuilds of the golden fixture with the same framing and member order are expected to be byte-identical. This applies to the golden build profile, not every conceivable container encoding of the tuple.

## 9. Boundary and adversarial cases

| Attack or defect | Verifier obligation |
|---|---|
| Member named `../outside` or a drive path | Refuse unsafe namespace. |
| Declared size exceeds actual remaining bytes | Reject truncated/overflowing record. |
| Two members resolve to the same normalized path | Reject ambiguous extraction target. |
| Correct outer digest but L points to another IR | Reject broken internal binding. |
| Payload digest matches but tuple component order changes | Logical ABI identity changes. |
| An embedded receipt claims grants were verified | Treat assertion as untrusted data, not a signature check. |

## 10. Security and failure considerations

Compressed/external member resolution requires independent resource and decompression limits. Container parsing and deterministic construction are implemented support utilities; no production loader, arbitrary-code execution, or full tuple runtime is implied by a successful rebuild.

## 11. Verification obligations and current evidence boundary

Current evidence can establish deterministic fixture bytes, framing bounds, path safety, member digests, and cross-reference consistency. ABI compatibility across independent implementations, all component semantics, and execution behavior require separate runtime and interoperability evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The original golden source and field descriptor contradicted one another in shape and sample dtype. Exact original bytes are retained under examples/legacy_golden/ and rejected by the hardened binder. The active candidate fixture binds the source declaration 4×4×4×16×16/f64 to a coherent descriptor, with new payload/tuple/container identities. No source.state sample data or execution result is supplied.

## 13. Cross-specification consistency

WP17 separates logical identity from raw container/member hashes. WP12 binds graphs, WP10 treats packaging as a trust boundary, and WP20 scopes a tuple claim to the checks actually executed.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP08_RUSSL_Execution_Model.md`

# WP08 — RUSSL Execution Model

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines lifecycle, deterministic scheduling, replay, rollback, resource accounting, and evidence.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP07, WP02, WP09.

**Mandatory deliverables:**
- execution phases
- state machine
- replay
- checkpoint/rollback
- receipts
- effect application

## 5. Normative model
### Execution state machine
`LOAD → VERIFY → RESOLVE → EVALUATE → AUTHORIZE_EFFECTS → APPLY_EFFECTS → EVIDENCE → FINALIZE`; any fail-closed error transitions to `ERROR`, while an authorized rollback transitions through `ROLLBACK` to a bound checkpoint. Candidate data may be derived before commit, but sealed roots are immutable.

The runtime interprets an allow-listed declarative operator set. Source text does not grant arbitrary code-loading authority.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP08-REQ-0001` | The execution lifecycle MUST include verify, resolve, evaluate, authorize-effects, evidence, and finalize/rollback phases. | `WP08-TEST-0001` |
| `WP08-REQ-0002` | Effectful rows MUST NOT execute before applicable grants are verified. | `WP08-TEST-0002` |
| `WP08-REQ-0003` | Candidate roots MUST be immutable after sealing. | `WP08-TEST-0003` |
| `WP08-REQ-0004` | Replay MUST use the same canonical inputs, module digests, execution profile, and deterministic order. | `WP08-TEST-0004` |
| `WP08-REQ-0005` | Rollback MUST target a digest-bound checkpoint and itself require commit authority. | `WP08-TEST-0005` |
| `WP08-REQ-0006` | Execution receipts MUST record tuple ID, run ID, phase, effects, and authorization state. | `WP08-TEST-0006` |
| `WP08-REQ-0007` | Arbitrary native, shell, Python, or WebAssembly code MUST NOT execute merely because it is embedded in RUSSL source. | `WP08-TEST-0007` |
| `WP08-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP08-TEST-0008` |
| `WP08-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP08-TEST-0009` |
| `WP08-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP08-TEST-0010` |
| `WP08-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP08-TEST-0011` |

## 7. Technical interpretation and algorithms

### Phase state and evidence
Define `phase∈{load,verify,resolve,evaluate,authorize,apply,evidence,finalize,error,rollback}`. Each transition records run identity, tuple identity, inputs, planned or applied effects, and primary failure. Verification precedes resolving executable interpretation; evaluation can produce a sealed candidate before any mutable state changes.

The phase invariant is `Applied(effect) ⇒ VerifiedInputs ∧ VerifiedGrant ∧ PreconditionsHeld`. A receipt distinguishes `planned`, `attempted`, `applied`, and `durably_recorded`. Crashes between application and receipt persistence are explicitly uncertain until a durable transaction record reconciles them; a restarted runtime does not infer that missing evidence means no effect occurred.

### Commit, retry, and rollback
A deployment transaction binds request identity, current state tip, new candidate root, grant nonce, and idempotency key. Compare-and-swap (CAS) checks the observed tip before changing it. Repeating the same request returns the previously recorded result; reusing its nonce for a different request fails. Correctness requires an atomicity contract among mutable-head update, nonce consumption, and durable result recording. A reference design without such storage guarantees is only a design.

Rollback updates a mutable reference to a digest-bound checkpoint under a fresh authorized transaction. Immutable content is preserved. A rollback can compensate a logical head transition; it does not erase an already published file, external notification, or replicated byte copy. Any broader compensation belongs to the deployment profile.

### Resource and replay profile
Evaluation fixes operator implementations, module digests, numeric behavior, reduction order, seed, and externally observed inputs. A runtime can impose instruction, memory, deadline, and cancellation budgets, with stable failure receipts. Embedding Python, shell, native, or WebAssembly text does not register a new operator or provide a grant.

Replay has two modes: pure derivation replay, which checks content equality, and historical effect reconstruction, which consults immutable receipts. Replaying effects against a live head is a fresh authorization decision and never an automatic consequence of successful pure replay.

## 8. Worked example

A commit plan binds old head H0 and candidate root H1. The grant also binds H0. If another actor changes the head to H2 before application, CAS rejects the stale plan; the original grant is not broadened to authorize H2→H1.

If the process crashes after H0→H1 but before publishing a receipt, restart reads a durable transaction record and returns the recorded outcome. Without that record the state is indeterminate, and the runtime halts automatic retry until reconciliation.

## 9. Boundary and adversarial cases

| Event | Required treatment |
|---|---|
| Grant expires after evaluation but before apply | Revalidate at the application boundary. |
| Nonce reused with new arguments | Reject replay/substitution. |
| Rollback reference is a mutable alias | Resolve immutable checkpoint before authorization. |
| Cancellation occurs during effect application | Report durable outcome or explicit uncertainty. |
| Receipt says success before adapter durability | Evidence overstates completion. |
| Embedded script is automatically executed | Declarative language authority is bypassed. |

## 10. Security and failure considerations

Exactly-once effects, crash consistency, authentic grants, and safe sandboxing require runtime and storage implementation work. A lowerer does not establish any of them. Operational deployments need measured budgets and recovery exercises rather than solely favorable schema checks.

## 11. Verification obligations and current evidence boundary

A complete runtime claim needs phase-transition tests, expiration/replay negatives, stale-tip races, crash injection at each durability boundary, rollback tests, and deterministic replay traces. These are roadmap obligations; the package does not include a full runtime executing this state machine.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP02 owns graph eligibility; WP09/WP10 own grants and authentication; WP11 owns policy/authorization separation; WP12 owns mutable-head storage consistency; WP18 owns replay envelopes.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP09_RUSSL_Capability_and_Effect_System.md`

# WP09 — RUSSL Capability and Effect System

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines least-privilege effects and digest-bound grants.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP03, WP08.

**Mandatory deliverables:**
- capability vocabulary
- effect declarations
- scope attenuation
- grant fields
- enforcement
- negative tests

## 5. Normative model
### Grant model
A capability grant is a signed, digest-bound authorization object over `(run_id,tuple_id,row_id,sequence,input_root,planned_effects,args_sha256,scopes,state_tip,rollback_checkpoint,nonce,expires_at,actor,reviewers)`. Verification validates signature, time, nonce/replay state, scope, and exact effect/argument bindings.

Capabilities form no implicit hierarchy. In particular, `write:state` does not imply `commit`, and `commit` does not imply `publish`.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP09-REQ-0001` | The core capability vocabulary MUST include `read`, `derive`, `project`, `write:evidence`, `write:state`, `commit`, `replicate`, and `publish`. | `WP09-TEST-0001` |
| `WP09-REQ-0002` | No capability MUST imply another capability. | `WP09-TEST-0002` |
| `WP09-REQ-0003` | An effectful row MUST be authorized by a grant whose scope covers that row and effect. | `WP09-TEST-0003` |
| `WP09-REQ-0004` | A grant MUST bind run ID, tuple ID, row ID, sequence, input root, planned effects, arguments digest, scopes, state tip, rollback checkpoint, nonce, expiration, actor, and signature. | `WP09-TEST-0004` |
| `WP09-REQ-0005` | Commit-capable grants MUST be replay-resistant and expiration-checked. | `WP09-TEST-0005` |
| `WP09-REQ-0006` | Scope attenuation MAY reduce but MUST NOT widen an upstream grant. | `WP09-TEST-0006` |
| `WP09-REQ-0007` | Boolean flags such as `signature_verified:true` MUST NOT substitute for cryptographic verification. | `WP09-TEST-0007` |
| `WP09-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP09-TEST-0008` |
| `WP09-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP09-TEST-0009` |
| `WP09-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP09-TEST-0010` |
| `WP09-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP09-TEST-0011` |

## 7. Technical interpretation and algorithms

### Effect sets and non-amplification
Model authority as a set of explicit capabilities, each with a target scope. The vocabulary `read, derive, project, write:evidence, write:state, commit, replicate, publish` is flat: membership in one set does not imply another. A row's effect is derived from its canonical operator, so changing `META.eff` cannot hide a commit under a read label.

A proposed judgment is `grant ⊨ (run,tuple,row,input,args,effect,scope,tip)`. It holds only when all signed bindings match the planned operation, the cryptographic profile accepts the signature and signer, the key is authorized for that scope, the grant is live, and nonce/sequence policy permits its use. Parsing the grant object establishes none of these facts.

### Scope attenuation
Represent a scope as a predicate over targets and operations. Delegation from parent P to child C is valid only if `∀x,C(x)⇒P(x)`, and the child's expiration, effect set, target roots, and argument constraints are no broader. String prefix matching is not a general scope algebra: `dataset/a` and `dataset/ab` are different targets unless a declared hierarchical profile explicitly relates them.

Grant signing specifies a byte preimage, signature algorithm, key identifier, trust anchor, and canonicalization profile. The signed body excludes the signature itself and includes all fields that can change effect meaning. A signature-verified boolean is an observation supplied by an untrusted object, never the verifier's result.

### Application-time validation
Validate once to construct a plan, then revalidate expiry, revocation applicability, nonce availability, and state tip immediately before application. Atomically couple nonce consumption to the effect transaction or use a durable idempotency record; merely checking and later inserting a nonce admits races. Sequence numbers have an explicit monotonic scope and do not replace nonce binding.

A grants profile also specifies trusted time, maximum clock skew, unknown-key behavior, key rotation, revocation transport, and unavailable-revocation policy. These choices remain deployment controls pending implementation and review.

## 8. Worked example

A grant for `write:state` can authorize uploading candidate bytes to a CAS adapter. It does not authorize moving `heads/project-a` to that root. The latter operation requires a matching `commit` capability and current-head binding. Publishing the root to another audience requires a distinct `publish` capability.

A child grant limited to one immutable root, one row, and an earlier expiration is an attenuation if every requested operation already lies in the parent's scope. Changing only the actor's display name does not establish a new authenticated principal.

## 9. Boundary and adversarial cases

| Manipulation | Reason authority fails |
|---|---|
| Add publish to a derive-only grant | Capability set widens. |
| Reuse valid signature with another row or argument digest | Signed operation binding differs. |
| Set `signature_verified=true` without a signature verifier | Data asserts its own authority. |
| Check nonce and apply in separate non-atomic steps | Concurrent replay can pass twice. |
| Treat a policy ADMIT value as commit permission | Authority domains are conflated. |
| Allow an unknown key because the JSON schema validates | Key trust is unestablished. |

## 10. Security and failure considerations

The package defines grant data shapes and negative design obligations but does not ship a cryptographic grant service, trusted clock, revocation service, replay store, or transaction coordinator. Sample grants are fixtures. No fixture authorizes an operational effect.

## 11. Verification obligations and current evidence boundary

The executable parser can enforce registered operator effects; schema and cross-field checks can inspect grant shape. Authentic signature, expiry/skew, replay-race, attenuation, revocation, key rotation, and application-time tests are outstanding for a security/runtime claim.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP10 defines trust boundaries; WP08 couples authorization to application; WP11 separates policy disposition; WP12 scopes mutable-head targets.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP10_RUSSL_Security_Model.md`

# WP10 — RUSSL Security Model

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines threats, trust boundaries, identities, integrity, replay protection, evidence, and supply-chain controls.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP09, WP07, WP08.

**Mandatory deliverables:**
- threat model
- trust boundaries
- authentication
- integrity
- replay
- rollback
- security profile

## 5. Normative model
### Trust boundaries
Trust boundaries exist at source ingestion, MSSL resolution, RUSSIR compilation, tuple packaging, fabric retrieval, actor/reviewer authentication, grant verification, effect execution, and evidence publication. Content identities protect integrity; they do not establish authorization or scientific validity.

The corpus threat model includes substitution, digest collision assumptions, path traversal, replay, confused deputy, privilege amplification, rollback mismatch, mutable-head races, dependency poisoning, and diagnostic leakage.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP10-REQ-0001` | Security verification MUST fail closed on source, MSSL, tuple, payload, or evidence digest mismatch. | `WP10-TEST-0001` |
| `WP10-REQ-0002` | Authenticated actor identity MUST be distinct from reviewer identity when a profile requires independent review. | `WP10-TEST-0002` |
| `WP10-REQ-0003` | Nonce and expiration MUST be enforced for commit-capable grants. | `WP10-TEST-0003` |
| `WP10-REQ-0004` | Evidence and rollback checkpoint references MUST be immutable content identities. | `WP10-TEST-0004` |
| `WP10-REQ-0005` | Supply-chain manifests MUST bind compiler/runtime identities and dependencies. | `WP10-TEST-0005` |
| `WP10-REQ-0006` | Security-sensitive diagnostics MUST support redaction without suppressing stable error codes. | `WP10-TEST-0006` |
| `WP10-REQ-0007` | The reference corpus MUST NOT claim independent attestation or production authorization. | `WP10-TEST-0007` |
| `WP10-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP10-TEST-0008` |
| `WP10-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP10-TEST-0009` |
| `WP10-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP10-TEST-0010` |
| `WP10-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP10-TEST-0011` |

## 7. Technical interpretation and algorithms

### Assets, actors, and trust boundaries
Assets are canonical bytes, module bindings, candidate/committed roots, grant keys, replay state, research provenance, and audit evidence. Actors include source producers, module providers, compiler operators, runtime operators, storage peers, grant issuers, reviewers, and external researchers. None is trusted solely because their object has a content digest.

Treat each boundary as a verification function producing a decision plus evidence: `ingest(bytes)`, `bind(module)`, `validate(ir)`, `verify(tuple)`, `resolve(root)`, `authenticate(principal)`, `authorize(plan)`, and `publish(receipt)`. Evidence references the exact checked object. A later mutation invalidates the relationship.

### Threat/control/evidence matrix
| Threat | Control design | Evidence needed |
|---|---|---|
| Duplicate-key or Unicode ambiguity | Strict parsing and explicit canonical profile | Differential malformed-input vectors |
| Module substitution | Verify exact bytes before interpretation | Digest negatives and check/use race test |
| Archive traversal | Safe relative namespace and bounded framing | Traversal, drive path, collision vectors |
| Confused deputy | Exact run/row/root/args/scope binding | Cross-target grant rejection |
| Replay or concurrent commit | Durable nonce and CAS transaction | Concurrent/crash injection tests |
| Supply-chain replacement | Compiler/runtime/dependency digests | Rebuild and dependency provenance |
| Diagnostic leakage | Stable codes and redacted restricted context | Sensitive-value redaction test |

### Assurance boundaries and recovery
Integrity protects equality to a stated digest under algorithm assumptions. Authentication binds a principal to a key under a trust policy. Authorization binds that principal to a permitted action. Scientific validity concerns claims and evidence. These four predicates remain independent; no checksum combines them.

Independent review compares authenticated principal identifiers under a declared separation policy, not free-text names. Quarantine preserves suspect bytes and hashes without executing or publishing them. Recovery from compromised keys records affected grants/runs, revocation scope, forensic evidence, and fresh authority. Recovery from content corruption retrieves another replica and verifies it; it never rewrites bytes under an old digest.

Security budgets bound parse size, graph fan-out, member counts, recursive validation, decompression, and external fetches. Each limit has a visible profile value and stable failure instead of silently producing partial success.

## 8. Worked example

A member with the correct checksum but an unexpected executable role is still unauthorized. A reviewed candidate root remains uncommitted until a grant binds the intended head transition. If a source path exposes private directory names, a public diagnostic can retain the source-ingestion error code and row location while replacing the path value with a redaction marker.

## 9. Boundary and adversarial cases

| Event | Fail-closed response |
|---|---|
| Trusted module name with wrong bytes | Reject binding. |
| Reviewer and actor use the same authenticated principal under independent-review policy | Review gate remains unsatisfied. |
| Payload path escapes extraction directory | Refuse extraction and preserve primary code. |
| Evidence references a mutable URL as its immutable identity | Require a content binding before reliance. |
| Exception prints a token or private signature material | Redact detail while retaining causal class. |

## 10. Security and failure considerations

The hardening performed in this package is local ingestion, structure, identity, framing, and evidence hygiene. It is not a penetration test of a deployed fabric or an independent security assessment. Secrets, valid grants, production keys, and institutional endorsement are not created by the corpus.

## 11. Verification obligations and current evidence boundary

Current bounded-parser and container/schema negatives provide concrete local evidence. A complete security profile still needs independent adversarial review, crypto implementation tests, runtime isolation, replay-store durability, recovery exercises, and measured resource-limit behavior.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP17 supplies canonical bytes; WP09 supplies capability semantics; WP19 supplies diagnostic redaction; WP27 supplies the assurance case and explicit limitations.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP11_RUSSL_Admission_Model.md`

# WP11 — RUSSL Admission Model

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Separates MSSL mathematical/policy disposition from authorization, commit, and publication.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP05, WP10, WP08.

**Mandatory deliverables:**
- admission state model
- baseline MSSL states
- authorization separation
- evidence
- fail-closed behavior

## 5. Normative model
### Two-layer admission model
The supplied `final_admission.mssl` declares policy dispositions `ADMIT`, `CONDITIONAL`, `REVIEW`, and `HOLD`, and explicitly requires a human authorization reference. RUSSL execution uses separate authorization progression `OBSERVE → REVIEW → ADMIT → COMMIT`.

A policy disposition may inform the authorization state but can never skip capability/grant verification. With the supplied baseline module and no external authorization artifact, the safe corpus outcome is no commit authority.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP11-REQ-0001` | The baseline MSSL policy dispositions `ADMIT`, `CONDITIONAL`, `REVIEW`, and `HOLD` MUST be represented without silently redefining them. | `WP11-TEST-0001` |
| `WP11-REQ-0002` | The execution authorization states `OBSERVE`, `REVIEW`, `ADMIT`, and `COMMIT` MUST be distinct from MSSL policy dispositions. | `WP11-TEST-0002` |
| `WP11-REQ-0003` | An MSSL mathematical `ADMIT` result MUST NOT by itself authorize `COMMIT`. | `WP11-TEST-0003` |
| `WP11-REQ-0004` | A human authorization requirement declared by the baseline admission module MUST remain unsatisfied when no authorization artifact is supplied. | `WP11-TEST-0004` |
| `WP11-REQ-0005` | Policy `CONDITIONAL`, `REVIEW`, or `HOLD` MUST NOT advance to commit without an authorized transition. | `WP11-TEST-0005` |
| `WP11-REQ-0006` | Admission evidence MUST record the evaluated MSSL module digest and inputs digest. | `WP11-TEST-0006` |
| `WP11-REQ-0007` | Unknown policy state or missing required gate MUST fail closed. | `WP11-TEST-0007` |
| `WP11-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP11-TEST-0008` |
| `WP11-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP11-TEST-0009` |
| `WP11-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP11-TEST-0010` |
| `WP11-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP11-TEST-0011` |

## 7. Technical interpretation and algorithms

### Product state, not a shared ADMIT enum
Define state `A=(policy,authority)`, where `policy∈{ADMIT,CONDITIONAL,REVIEW,HOLD,unknown}` and `authority∈{OBSERVE,REVIEW,ADMIT,COMMIT}`. The coincident spelling ADMIT does not equate the two domains. Every policy result binds evaluated module digest, exact inputs, numerical profile, thresholds, and result evidence.

A transition relation `A —event→ A'` records who or what supplied the event, gate evaluation, input root, and immutable authorization reference. Positive mathematical disposition can satisfy a policy gate; human authorization, verified grants, independent review, and state-tip checks remain separate gates.

### Commit predicate
A useful design predicate is `CanCommit = PolicyGate ∧ RequiredHumanAuthorization ∧ VerifiedGrant ∧ CurrentTipMatches ∧ EvidenceComplete`. Each conjunct cites its evidence. Unknown states and absent required evidence evaluate to false rather than inheriting a favorable default. The predicate is explanatory; the package does not include an executable authentic authorization service.

CONDITIONAL records explicit unresolved conditions and the authority allowed while they remain unresolved. REVIEW requests an authenticated review decision. HOLD inhibits progress until a new authorized event changes applicable conditions. A transition logs the superseded disposition instead of overwriting provenance.

### Policy evolution and re-evaluation
A result computed against module M and root R cannot be reused as a result for M' or R'. Changed mechanics bytes, thresholds, input population, or calibrated transform trigger re-evaluation under a new evidence binding. A grant can authorize an action only within its signed bindings; it does not repair missing policy evidence or retroactively convert an experimental model into validated science.

The baseline human-authorization requirement remains unresolved if no authentic artifact is supplied. A local example can demonstrate the required reference position without supplying a real authorizer.

## 8. Worked example

Suppose `final_admission.mssl` produces policy ADMIT for root R. The authorization state can remain OBSERVE because the required human authorization reference is absent. The output receipt records policy ADMIT and `commit_authorized=false`; it does not print a blanket admission success for the state-changing path.

If a reviewed grant later authorizes a different root R2, the grant does not apply to R. Both policy and authority bindings are checked for the same intended candidate.

## 9. Boundary and adversarial cases

| Defect | Admission interpretation |
|---|---|
| Unknown disposition treated as ADMIT | Unsafe default. |
| Policy ADMIT auto-advances to COMMIT | Mathematical decision is mistaken for authority. |
| Required human reference is an empty string or placeholder | Required gate is unresolved. |
| Old policy result reused after module replacement | Evaluation identity no longer matches. |
| A condition disappears from a revised receipt without evidence | Conditional policy history is falsified. |

## 10. Security and failure considerations

Research thresholds and mechanics may be incomplete or scientifically unvalidated. A perfectly reproduced admission calculation proves only that the declared calculation was repeated. Organizational permission additionally depends on authentic institutional roles and signed authorization, which are not supplied.

## 11. Verification obligations and current evidence boundary

Static checks can verify baseline module bytes and the presence of stated gate vocabulary. Full claim evidence needs interpreter result vectors, transition traces, authentic authorization negatives, unknown-state failures, and policy/module/input substitution tests. The package cannot assert operational admission conformance from text inspection.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP05 governs mechanics binding, WP09 governs grants, WP08 governs effects, and WP26 governs scientific evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP12_RUSSL_Distributed_Fabric_Specification.md`

# WP12 — RUSSL Distributed-Fabric Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines content-addressed roots, partial retrieval, deduplication, replication, and consistency independent of a network.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP07, WP10, WP04.

**Mandatory deliverables:**
- content addressing
- Merkle DAG
- replication
- partial retrieval
- deduplication
- consistency

## 5. Normative model
### Fabric model
A fabric is a directed acyclic graph of immutable content-addressed objects plus separately authorized mutable head references. Logical field regions, tuple payloads, evidence, and projections may be independently addressed. A root is a canonical digest over ordered child descriptors.

Deduplication follows identity equality. Replication copies bytes without changing identity. A network adapter may provide locality, pinning, erasure coding, or incentives, but those are not RUSSL semantics.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP12-REQ-0001` | Fabric objects MUST be addressable by content digest. | `WP12-TEST-0001` |
| `WP12-REQ-0002` | A fabric root MUST identify an immutable graph of logical objects and member digests. | `WP12-TEST-0002` |
| `WP12-REQ-0003` | Identical logical objects MAY deduplicate by identical content identity. | `WP12-TEST-0003` |
| `WP12-REQ-0004` | Clients MUST be able to request a declared logical region without downloading unrelated field regions when the adapter supports partial retrieval. | `WP12-TEST-0004` |
| `WP12-REQ-0005` | Replication MUST preserve object identity and MUST NOT mutate content under an existing digest. | `WP12-TEST-0005` |
| `WP12-REQ-0006` | Mutable heads MUST be separate from immutable candidate roots and require commit authority. | `WP12-TEST-0006` |
| `WP12-REQ-0007` | Fabric semantics MUST NOT require IPFS, Filecoin, or any single network implementation. | `WP12-TEST-0007` |
| `WP12-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP12-TEST-0008` |
| `WP12-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP12-TEST-0009` |
| `WP12-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP12-TEST-0010` |
| `WP12-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP12-TEST-0011` |

## 7. Technical interpretation and algorithms

### Immutable graph construction
Let every node have bytes `b_v`, domain `d_v`, and identity `id_v=H(d_v || 0x00 || b_v)`. A root descriptor lists ordered child roles, logical regions, sizes, and identities. Verify every traversed edge's declared role and digest; cycle detection and depth/member limits protect against malformed graphs even when the intended format is a DAG.

A graph's identity changes when an identity-significant child descriptor changes. Network location and replica count are deployment metadata unless explicitly included in an identified object. Deduplication follows equality of the chosen byte/domain profile, not equality of a filename or an approximate numerical value.

### Partial retrieval and proofs
A region request selects descriptors whose logical regions intersect the request. Retrieve matching objects plus the metadata/proof path needed to connect them to the declared root. A byte range without an authenticated containing object is not an integrity proof. A flat chunk list can verify membership by retrieving the whole list; logarithmic Merkle proofs require a separately specified tree construction and child ordering.

Coverage validation distinguishes missing data, known sparse absence, and temporarily unavailable replicas. Region overlap and gaps are checked against the field's coverage policy. A deployment that lacks partial retrieval reports that capability; it does not claim that arbitrary region access is available.

### Mutable heads and consistency
A mutable head maps a named scope to an immutable root plus monotonically managed revision. Commit uses `CAS(head,expected_revision,expected_root,new_root,grant)`. If preconditions differ, the update fails. Multi-head atomicity, quorum reads, conflict resolution, and consensus are optional deployment contracts; a content-addressed DAG alone supplies none of them.

Replication verifies incoming bytes and adds another location for the same identity. Availability, durability, retention, erasure coding, and repair are measured storage properties. Deletion/garbage collection respects pinning and reachable evidence roots; authority to collect storage is distinct from the ability to read an object.

## 8. Worked example

Two logical regions share an identical immutable sample payload. Their region descriptors can point to the same payload identity while preserving different placement descriptors. This deduplicates payload bytes without collapsing coordinate meaning.

A client asks for `y=[0,64),x=[128,256)`. The adapter supplies intersecting chunks and a verified root/member description. Missing replicas yield an availability error; returning a zero-filled area would change the field's declared samples.

## 9. Boundary and adversarial cases

| Defect | Fabric consequence |
|---|---|
| Return altered bytes under the requested digest | Integrity rejection. |
| Root references a missing required child | Closure is incomplete. |
| Chunk object names are used as coordinates | Backend layout leaks into logical geometry. |
| Stale head update overwrites a newer root | Commit precondition is violated. |
| Replication mutates a member instead of copying | Identity preservation fails. |
| Byte-level membership is called a Merkle proof without a tree definition | Proof claim is unsupported. |

## 10. Security and failure considerations

Network partitions and availability failures are independent of deterministic content identity. The package contains descriptions/fixtures, not a distributed consensus system, replica service, or proven partial-retrieval protocol.

## 11. Verification obligations and current evidence boundary

Planned fabric tests cover corruption, coverage gaps/overlaps, replica loss, region proof validation, stale-tip CAS, racing commits, garbage collection, and adapter substitution. Current container/member checks are local graph-binding evidence only.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [systems research review](research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md) distinguishes optimizer communication compression from field sample quantization, content identity and fabric consensus. A compressed optimizer collective remains an optional training profile with warmup, scale/error-feedback state, communication scope and separate grants; it does not implement RUSS distributed-state publication.

## 13. Cross-specification consistency

WP04 defines regions; WP07 defines tuple members; WP13 defines adapters; WP09 authorizes changes; WP18 records observed network inputs during replay.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP13_RUSSL_Storage_Independence_Specification.md`

# WP13 — RUSSL Storage Independence Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the boundary and adapter contract between logical RUSS semantics and physical storage.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP12.

**Mandatory deliverables:**
- adapter interface
- canonical/derived distinction
- backend capabilities
- adapter profiles
- conformance

## 5. Normative model
### Adapter contract
A conforming adapter exports `put(bytes)->digest`, `get(digest)->bytes`, `has(digest)->bool`, `verify(digest,bytes)`, and `capabilities()`. Optional region/range methods may accelerate partial retrieval. Adapter choice is recorded in the fabric component or deployment profile, never in core field identity unless adapter-specific bytes themselves are being identified.

The profile catalog includes native CAS, filesystem/object-store, TIFF-family import/export, and OME-Zarr interoperability. They are subordinate representations.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP13-REQ-0001` | Core RUSSL semantics MUST be invariant under substitution of conforming physical storage adapters. | `WP13-TEST-0001` |
| `WP13-REQ-0002` | An adapter MUST implement logical `put`, `get`, `has`, integrity verification, and capability reporting. | `WP13-TEST-0002` |
| `WP13-REQ-0003` | Adapter metadata MUST identify whether an output is canonical, derived, or cache-only. | `WP13-TEST-0003` |
| `WP13-REQ-0004` | Zarr/OME-Zarr and TIFF-family behaviors MUST be confined to adapter/interoperability profiles. | `WP13-TEST-0004` |
| `WP13-REQ-0005` | A storage adapter MUST NOT redefine Penteract coordinates or MSSL semantics. | `WP13-TEST-0005` |
| `WP13-REQ-0006` | Lossy adapter behavior MUST be explicitly declared and provenance-bound. | `WP13-TEST-0006` |
| `WP13-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP13-TEST-0007` |
| `WP13-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP13-TEST-0008` |
| `WP13-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP13-TEST-0009` |
| `WP13-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP13-TEST-0010` |

## 7. Technical interpretation and algorithms

### Adapter operations and error contracts
The abstract adapter interface operates on bounded immutable byte objects and digest domains. `put` returns the calculated content identity after the declared durability level is achieved; `get` returns verified bytes or a typed missing/corrupt/unavailable error; `has` is only a hint unless the profile promises stronger consistency. Presence checks do not replace fetching and verifying.

Capabilities describe supported object sizes, digest algorithms, atomic put behavior, partial retrieval, conditional head updates, consistency, durability, and retention. Unsupported optional functions are discoverable and produce explicit failures. Retry policy distinguishes idempotent immutable writes from state-changing head transactions.

### Observational equivalence
For adapters A and B, storage independence is the relation `observe(exec(P,A)) ≃ observe(exec(P,B))` over canonical logical outputs for the same verified inputs and execution profile. Location, latency, retry counts, and availability receipts can differ. Semantic equality is not asserted when one adapter loses metadata, applies resampling, or returns different bytes.

Three output roles are distinct: canonical objects define the field contract; derived objects bind a transformation and source identity; cache-only objects are dispensable accelerators with verification and invalidation rules. A cache path or physical chunk key is not a canonical root.

### Representation levels
Raw encoding identity concerns the exact bytes of a payload/descriptor. Logical sample equivalence concerns decoded values, axis placement, and missingness. Profile equivalence concerns application meaning such as color or calibrated units. Two codecs can produce equal logical samples and different byte identities. The current package does not define a codec-independent semantic digest for all samples; such a digest would require its own numeric, ordering, coverage, and domain contract.

Import/export adapters register supported external versions, codecs, loss classes, metadata policies, and round-trip comparison domains. These properties belong to profile manifests and do not grant arbitrary filesystem or network authority.

## 8. Worked example

A filesystem CAS and an object-store CAS can both return the same digest-bound payload bytes. Their storage addresses differ while logical field coordinates remain unchanged. If one adapter transcodes a u16 payload to u8, it produces a derived lossy output with a new identity rather than an equivalent canonical object.

A decoded-sample comparison can demonstrate value preservation across compression changes. It cannot demonstrate byte-identity equality unless the encoded bytes also match.

## 9. Boundary and adversarial cases

| Behavior | Contract problem |
|---|---|
| `has=true` followed by unverified bytes accepted | Presence is mistaken for integrity. |
| Cache path determines field coordinates | Logical semantics depend on storage. |
| Transcoding is labeled canonical without provenance | Loss classification is concealed. |
| An adapter silently opens network paths from core ARG | Core text acquires undeclared effects. |
| Backend replacement changes dtype or sparse default | Observational equivalence fails. |

## 10. Security and failure considerations

Backend independence is an architecture property requiring evidence over concrete adapters. It is not proven by banning a format name with a regular expression. Loss reports and storage credentials remain deployment responsibilities.

## 11. Verification obligations and current evidence boundary

Adapter conformance awaits implementations of the abstract interface. Evidence includes put/get corruption tests, negative capability discovery, round-trip loss checks, canonical-output equality across two adapters, and separate performance/durability experiments. No TIFF/NGFF adapter execution is claimed.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [mathematical and image-computation review](research/ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md) treats TIFF/GIF as encoded carriers. Metadata is declarative data unless an identified verified interpreter gives it meaning. Acquisition/codec transformations and arbitrary script execution are not inferred from file extension or chunk structure.

## 13. Cross-specification consistency

WP12 defines object graphs; WP17 defines byte identities; WP23/WP24 define external mappings. WP14/WP15 own semantic metadata, not the underlying object key layout.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP14_RUSSL_Imaging_Profile.md`

# WP14 — RUSSL Imaging Profile

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines pixels/samples, color/channels, bit depth, masks, metadata, tiles, and pyramids on the Penteract field.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP03, WP13.

**Mandatory deliverables:**
- sample model
- color/channel metadata
- numeric rules
- pyramids
- masks/regions
- metadata

## 5. Normative model
### Imaging data model
An imaging field sample declares dtype and either scalar intensity or a pixel/vector channel structure. Channel semantics, alpha, color space/profile, transfer characteristics, orientation, and calibration are explicit metadata. Tiles are logical regions; a physical adapter may store them however it chooses.

Lossless profile operations preserve sample values. Multiresolution image levels are derived projections with recorded reduction kernels and parent identities.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP14-REQ-0001` | An imaging sample MUST declare numeric type, bit depth, and channel interpretation. | `WP14-TEST-0001` |
| `WP14-REQ-0002` | Channels MAY be packed in a sample or mapped to a Penteract axis, but the choice MUST be explicit. | `WP14-TEST-0002` |
| `WP14-REQ-0003` | Color profile and transfer metadata MUST be preserved when supplied. | `WP14-TEST-0003` |
| `WP14-REQ-0004` | Masks and regions MUST share or explicitly transform the parent field coordinate system. | `WP14-TEST-0004` |
| `WP14-REQ-0005` | Image pyramids MUST declare per-level reduction transforms. | `WP14-TEST-0005` |
| `WP14-REQ-0006` | Lossless imaging profiles MUST preserve source sample values exactly. | `WP14-TEST-0006` |
| `WP14-REQ-0007` | A 2D image MUST be representable as a Penteract field population. | `WP14-TEST-0007` |
| `WP14-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP14-TEST-0008` |
| `WP14-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP14-TEST-0009` |
| `WP14-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP14-TEST-0010` |
| `WP14-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP14-TEST-0011` |

## 7. Technical interpretation and algorithms

### Sample representation and metadata
An imaging contract declares signedness, numeric width, packing, byte order, channel model, and sample-presence policy. Color channels, scientific channels, and alpha are distinct meanings. A packed RGB vector and a scalar channel-axis field are equivalent only under an explicit reversible mapping; their encoded payload identities can differ.

Color metadata identifies a supplied profile, transfer function, alpha association, and orientation. Absence of an ICC profile does not authorize inventing one. Lossless migration preserves stored sample values before any display conversion; conversion to linear light, alpha unpremultiplication, color gamut mapping, or orientation normalization is a recorded derivation.

### Pyramids, boundaries, and masks
A reduction profile records kernel, support radius, phase, edge extension, channel/alpha treatment, rounding, clipping, and output dtype. A box mean over unsigned integers specifies whether accumulation widens and how ties are rounded. Integer overflow in the accumulator is not a valid lossless reduction. Pyramid values are derived even if their coordinate extent is preserved.

Masks and label maps declare alignment with the parent field. Nearest-neighbor label reduction has different semantics from averaging intensity samples. Region and ROI geometry states whether bounds address pixel centers, pixel edges, or logical indices. Packed-channel metadata and axis-channel metadata have explicit channel labels and ordering.

### Equality domains
Exact sample equality compares decoded sample values under the same dtype and layout policy. Bitwise equality additionally distinguishes representational cases such as signed zero or NaN payloads when allowed by the sample encoding profile. Display equality, visual similarity, and scientific feature agreement are weaker application observations and do not prove a lossless sample contract.

## 8. Worked example

A 2×2 u16 plane with samples `[[0,2],[4,6]]` embedded as shape `(1,1,1,2,2)` has a box mean of 3 using exact integer accumulation. A 1×1 derived level binds that reducer and an anchor choice. It does not replace the four original samples.

For RGBA data, averaging premultiplied channels and averaging straight channels can yield different pixels near transparent edges. The pyramid profile therefore states alpha association rather than relying on an application default.

## 9. Boundary and adversarial cases

| Missing or wrong declaration | Consequence |
|---|---|
| RGB/BGR order is inferred from three channels | Channel meaning is ambiguous. |
| Orientation is applied but not recorded | Coordinates and original samples are no longer reconstructible. |
| Label masks are linearly interpolated | Label semantics are corrupted. |
| Alpha association is dropped | Subsequent reductions are ambiguous. |
| Sample clipping occurs in a claimed lossless migration | Exact-value obligation fails. |
| NaN metadata enters identity-critical JSON | WP17 rejection applies even if binary pixels can carry NaN. |

## 10. Security and failure considerations

Large dimensions, codec expansion, malformed metadata, and accumulator overflow need bounded validation. No claim of clinical suitability, measurement accuracy, or standardized color management follows from structural corpus validation.

## 11. Verification obligations and current evidence boundary

Required imaging evidence includes packed/axis channel round trips, endian and dtype boundaries, orientation transformations, mask alignment, alpha-sensitive reductions, and sample-exact migration vectors. The delivered profile is a detailed candidate contract; a full imaging executor is not supplied.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

Additional image-format proposals are audited in the [research integration report](research/RESEARCH_INTEGRATION_REPORT.md). GIF89a image encoding and a proposed Gaussian Interaction Frame are different uses of the acronym. Optical/phase/vector samples require explicit signal/units/quantization contracts; a one-bit optimizer communication claim does not establish one-bit image fidelity.

## 13. Cross-specification consistency

WP04 supplies geometry; WP03 supplies dtype/rank constraints; WP16 supplies projection provenance; WP23 supplies TIFF mapping.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP15_RUSSL_Scientific_Volumetric_Profile.md`

# WP15 — RUSSL Scientific/Volumetric Profile

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines calibrated 3D/4D/5D scientific data and interoperability axis mappings.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP14, WP03.

**Mandatory deliverables:**
- axes/units
- coordinate transforms
- volume semantics
- calibration
- TCZYX mapping
- datasets/tests

## 5. Normative model
### Calibrated axes
A scientific axis carries `(name,semantic,unit,index_to_physical_transform)`. The interoperability profile may map `t,c,z,y,x` onto `c4…c8`, but this is a declared mapping, not a universal meaning of the Penteract axes.

Physical coordinates are computed after logical index normalization and profile calibration. Ambiguous axis order or unit conversion is a validation error for calibrated operations.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP15-REQ-0001` | Scientific profiles MUST declare axis names, units, and coordinate transforms. | `WP15-TEST-0001` |
| `WP15-REQ-0002` | TCZYX interoperability MAY map to the five Penteract axes only through an explicit profile mapping. | `WP15-TEST-0002` |
| `WP15-REQ-0003` | Calibration metadata MUST be versioned and provenance-bound. | `WP15-TEST-0003` |
| `WP15-REQ-0004` | 3D, 4D, and 5D slicing MUST preserve declared physical coordinate transforms. | `WP15-TEST-0004` |
| `WP15-REQ-0005` | Unknown units or ambiguous axis order MUST fail closed for calibrated operations. | `WP15-TEST-0005` |
| `WP15-REQ-0006` | Scientific test datasets MUST include expected coordinate and slicing results. | `WP15-TEST-0006` |
| `WP15-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP15-TEST-0007` |
| `WP15-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP15-TEST-0008` |
| `WP15-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP15-TEST-0009` |
| `WP15-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP15-TEST-0010` |

## 7. Technical interpretation and algorithms

### Index, normalized, and physical coordinate spaces
Keep three spaces separate: integer indices i, normalized Penteract coordinates `φ(i)`, and calibrated physical coordinates p. A calibration can be specified as `p=A·i+b` or as a transform of normalized coordinates, but its declared input basis resolves which expression is intended. Applying both normalizations without checking the basis double-transforms the data.

Each axis descriptor binds name, semantic role, unit identifier, direction, transform basis, and provenance. TCZYX maps t,c,z,y,x to c4…c8 only when that mapping is declared. A channel index is usually categorical metadata in this profile, not a physical distance; nonscientific axes can retain logical semantics without a fabricated physical unit.

### Slicing and affine composition
For an affine transform `p=A i+b`, a slice fixing selected indices `i_f=k` retains free-index transform `p=A_free i_free+(b+A_fixed k)`. Retained axis order and output rank are explicit. If an output coordinate basis uses cropped indices `j=i−l`, the new offset becomes `b+A l`. Permutation composes the matrix with the declared axis permutation.

Time interpolation, anisotropic spatial resampling, and unit conversion bind their own kernels and conversion factors. Calibration uncertainty is recorded separately from numeric serialization precision. A deterministic float calculation can still have measurement uncertainty and model error.

### Validity and degeneracy
Transforms specify rank, matrix dimensions, invertibility, and finite coefficients. Singular transforms can be usable for a projection but not for an operation claiming an inverse. Unit conversion follows a registered unit system and exact/rational factors where applicable; unknown units remain unresolved. Unsupported curved/nonlinear transformations are preserved as provenance or rejected for calibrated operations.

## 8. Worked example

For a volume with z spacing 2 μm and z origin 10 μm, `p_z=2 i_z+10`. Fixing `i_z=3` yields a plane at 16 μm. Cropping y indices from 5 upward shifts the y origin by `5·spacing_y` when output indexing restarts at zero.

The normalized c6 value describes placement in the declared logical axis. It is not 16 μm. The profile links that logical index to the calibrated z coordinate explicitly.

## 9. Boundary and adversarial cases

| Defect | Scientific-coordinate failure |
|---|---|
| Array dimensions interpreted as TCZYX without mapping | Axis role/order is guessed. |
| Millimeters treated as micrometers | Scale differs by 1000. |
| Crop restarts index at zero without offset adjustment | Physical placement changes. |
| Inverse requested from a singular transform | Operation is undefined. |
| NaN calibration coefficient | Transform cannot be reliably evaluated. |
| Calibration provenance absent but precision claimed | Measurement evidence is missing. |

## 10. Security and failure considerations

A coordinate transform is a data-model contract, not validation of an instrument or a biological/physical conclusion. Measurement accuracy needs instrument evidence, uncertainty analysis, and external observation. No calibrated executor or empirical dataset is synthesized by this package.

## 11. Verification obligations and current evidence boundary

Planned vectors cover affine composition, axis permutation, cropping offsets, singleton axes, anisotropic volumes, unit conversion, singular matrices, and unknown units. Tests distinguish exact rational expectations from declared floating tolerances. These require a future profile implementation beyond parser lowering.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [systems review](research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md) separates optogenetic, photothermal, barcode-connectomics and super-resolution techniques into distinct evidence domains. Such data can motivate sample/provenance profiles but cannot establish P5×S³ physical mechanics, experimental outcomes or device capabilities.

## 13. Cross-specification consistency

WP04 supplies index geometry; WP14 supplies sample/channel interpretation; WP16 supplies output transformations; WP24 supplies explicit external version mapping.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP16_RUSSL_Projection_Specification.md`

# WP16 — RUSSL Projection Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines deterministic lower-dimensional slices and derived projections from Penteract/P5×S³ state.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP14, WP15, WP05.

**Mandatory deliverables:**
- projection model
- 2D/3D/4D/5D
- P5×S³ profile
- determinism
- provenance
- golden vectors

## 5. Normative model
### Projection function
A projection is `Π=(source_root,selector,transform,reducer,output_rank,parameters)`. Slice projections use selectors without reduction; aggregate projections declare a reducer. Output identity binds all six elements plus relevant MSSL module identities.

Projection provenance records whether the transformation is invertible, value-preserving, approximate, or lossy.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP16-REQ-0001` | A projection MUST identify source root, selector, transform/reducer, output rank, and provenance. | `WP16-TEST-0001` |
| `WP16-REQ-0002` | Projection outputs MUST be derived and MUST NOT silently replace canonical field state. | `WP16-TEST-0002` |
| `WP16-REQ-0003` | Identity/slice projections MUST preserve selected sample values exactly. | `WP16-TEST-0003` |
| `WP16-REQ-0004` | Non-invertible projections MUST be marked lossy. | `WP16-TEST-0004` |
| `WP16-REQ-0005` | P5×S³ derived projections MUST identify the MSSL mechanics module and parameters used. | `WP16-TEST-0005` |
| `WP16-REQ-0006` | Equivalent deterministic projection requests over the same root MUST yield the same projection identity. | `WP16-TEST-0006` |
| `WP16-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP16-TEST-0007` |
| `WP16-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP16-TEST-0008` |
| `WP16-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP16-TEST-0009` |
| `WP16-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP16-TEST-0010` |

## 7. Technical interpretation and algorithms

### Selector, transform, and reducer
Decompose a projection into a selector over source indices, an output-axis mapping, a transform, and an optional reducer. An identity selection preserves rank, order, values, and missingness. A slice fixes axes and records retained-axis order. A reduction combines values along named axes and records numeric regime, accumulation order, missing-value policy, and rounding.

A mean is undefined for an empty selected domain unless the profile provides an explicit missing result. A max projection declares ties and any associated location selection. Floating reductions use a fixed order or another documented reproducible algorithm; a mathematically commutative expression alone does not establish byte-identical results.

### Identity and provenance
Projection identity binds source root, canonical selector, transform/reducer version, parameters, output rank, numeric profile, and relevant module bindings. If two textual selectors describe the same region but serialize differently, their requests are not automatically byte-equivalent. Canonical selector normalization needs a published rule or the equivalence claim is limited to identical canonical requests.

Mark invertibility, sample preservation, approximation, and information loss independently. A slice preserves selected values yet discards unselected values; in the whole-source round-trip sense it is non-invertible and therefore lossy under WP16-REQ-0004. This resolves the original tension between exact slice values and non-invertible projection classification.

### Mechanics-derived projections
P5×S³ projection binds an experimental mechanics algorithm and parameters through MSSL. Its output is an identified derived dataset. The projection does not promote that mechanics algorithm to a validated physical law or alter canonical field state. Unsupported transforms remain explicit errors or separately preserved metadata.

## 8. Worked example

For a 2×2 plane `[[1,4],[3,2]]`, a max over y returns `[3,4]` in retained x order. A slice at y=0 returns `[1,4]` exactly, but is lossy with respect to reconstructing the original full plane.

A request changing reducer from max to mean has a different transform contract and identity even if a particular dataset happens to produce the same values.

## 9. Boundary and adversarial cases

| Defect | Projection failure |
|---|---|
| Reducer axes omitted | Aggregation domain is ambiguous. |
| Empty mean silently returns zero | Invented output value. |
| Slice called fully reversible without preserved complement | Round-trip classification is false. |
| Parameters or mechanics digest excluded from identity | Different algorithms can collide at the request level. |
| Derived output overwrites the canonical parent root | Source authority is replaced. |
| Parallel accumulation order varies across runs | Determinism claim lacks a numeric contract. |

## 10. Security and failure considerations

Projection can hide information or alter scientific interpretation despite deterministic output. Provenance exposes that transformation; it does not certify its appropriateness. Rendering/export can introduce additional color, dtype, or metadata losses beyond the logical projection.

## 11. Verification obligations and current evidence boundary

Planned evidence includes identity/slice exact-value tests, empty selections, reducer boundary cases, canonical-selector equivalence, deterministic floating reductions, and provenance/loss checks. No general projection evaluator is supplied in the structural lowerer.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [mathematical review](research/ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md) and [systems review](research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md) constrain HRR/holographic binding to defined approximate retrieval tasks. Cleanup, cross-talk, quantization and reconstruction errors require declared oracles. Their use as derived projections does not supply a general lossless field compressor.

## 13. Cross-specification consistency

WP04 owns selection geometry; WP03 owns output rank; WP14/WP15 own profile meaning; WP17 owns identity; WP26 owns the experimental mechanics boundary.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP17_Canonicalization_and_Cryptographic_Identity.md`

# WP17 — Canonicalization and Cryptographic Identity

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines canonical source/data forms, digest domains, and identity URIs.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP06, WP07.

**Mandatory deliverables:**
- Unicode normalization
- numeric representation
- map ordering
- canonical JSON
- domain hashes
- test vectors

## 5. Normative model
### Canonical identities
Canonical source uses UTF-8/NFC/LF/no-BOM/trailing-whitespace removal. Corpus canonical JSON sorts object keys and emits no insignificant whitespace; NaN and infinities are invalid. Identity domains are prefixed with an ASCII domain and NUL separator before hashing.

Domains include `RUSSL-SOURCE/1.0`, `RUSSIR/1.0`, `RUSS-TUPLE/1.0`, `RUSS-PAYLOAD/1.0`, and `RUSS-EVIDENCE/1.0`, preventing cross-domain digest confusion.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP17-REQ-0001` | Canonical RUSSL source MUST be UTF-8, NFC, LF-terminated, BOM-free, and free of trailing SP/TAB. | `WP17-TEST-0001` |
| `WP17-REQ-0002` | Identity-critical JSON MUST use UTF-8, sorted keys, no insignificant whitespace, and MUST reject NaN/Infinity. | `WP17-TEST-0002` |
| `WP17-REQ-0003` | Identity-critical exact decimals SHOULD be represented as canonical strings where binary-float ambiguity would alter identity. | `WP17-TEST-0003` |
| `WP17-REQ-0004` | Source, RUSSIR, tuple, payload-root, and evidence identities MUST use domain-separated hash inputs. | `WP17-TEST-0004` |
| `WP17-REQ-0005` | SHA-256 is the baseline digest algorithm for corpus 1.0. | `WP17-TEST-0005` |
| `WP17-REQ-0006` | Cross-version identities MUST include the defining schema/version domain. | `WP17-TEST-0006` |
| `WP17-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP17-TEST-0007` |
| `WP17-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP17-TEST-0008` |
| `WP17-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP17-TEST-0009` |
| `WP17-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP17-TEST-0010` |

## 7. Technical interpretation and algorithms

### Exact preimages and separate identity levels
For a domain D and canonical payload B, `digest(D,B)=SHA256(ASCII(D)||0x00||B)`. The displayed `sha256:` or URI prefix is not part of B unless explicitly specified by that object's schema. Module/member file digests instead hash raw bytes; a verifier distinguishes these operations.

Source canonicalization decodes strict UTF-8, normalizes CRLF/CR to LF, applies NFC, removes trailing SP/TAB per line, removes excess trailing empty lines, and emits one final LF without BOM. Canonicalization is idempotent: `C(C(s))=C(s)`. It preserves comments and significant cell text. A strict ingestion policy can reject unsafe controls before normalization; normalization never establishes syntactic validity.

### Corpus JSON profile
The current serializer emits compact UTF-8 JSON with recursively sorted string keys, preserved array order, and finite numeric values. Python key ordering uses Unicode code-point order. Duplicate keys, nonfinite constants, invalid Unicode, and unsupported values are rejected by strict ingestion before identity reliance. Exact decimals can remain canonical strings with a declared decimal grammar; strings are not automatically converted into binary floats.

This is the corpus-specific Python serialization profile, not RFC 8785/JCS. JCS uses ECMAScript numeric serialization and UTF-16 property ordering, and preserves JSON string data without Unicode normalization. Cross-language consumers therefore use the published corpus bytes/vectors or implement the exact stated profile; substituting a JCS library can change identity. [RFC 8785, §§3.1–3.2](https://www.rfc-editor.org/rfc/rfc8785.html)

### Floating and migration boundaries
Finite `1`, `1.0`, and `-0.0` need not serialize identically in this profile. Numeric equality does not imply JSON-byte equality. Binary sample payload NaNs, if allowed by a separate dtype profile, are different from NaN in identity-critical JSON metadata.

The source/IR/tuple domains retain /1.0 because their defining language/profile remains 1.0. A new canonicalization rule requires an explicit migration and identity-domain decision. The corpus package version records document/tooling change; it is not silently substituted into an existing identity preimage.

## 8. Worked example

For object `{"b":2,"a":1}`, the corpus canonical JSON bytes are UTF-8 `{"a":1,"b":2}`. Domain-separated hashing prepends `RUSSIR/1.0`, a single NUL byte, and those bytes. Hashing the pretty-printed input or the textual characters `\\0` produces a different result.

Two source files differing only in CRLF versus LF canonicalize to the same source bytes. A source file with an extra retained comment can have different identity despite equivalent row behavior.

## 9. Boundary and adversarial cases

| Defect | Identity consequence |
|---|---|
| Duplicate JSON keys | Ambiguous object; reject before hashing. |
| NaN/Infinity JSON numbers | No valid finite canonical representation. |
| Sorting tuple-array elements | ABI order and identity change. |
| Hashing a raw module using the source domain | Wrong identity relation. |
| Swapping JCS for Python serializer without migration | Unicode/numeric outputs can diverge. |
| Excluding a security-sensitive field ad hoc | Identity no longer binds the complete contract. |

## 10. Security and failure considerations

SHA-256 equality assumes collision/preimage resistance and correct implementation. It supplies no signer authenticity, permission, or scientific validation. Canonicalization also does not eliminate visually confusable but distinct identifiers; authority-bearing syntax needs lexical restrictions and review.

## 11. Verification obligations and current evidence boundary

Current evidence includes source/hash vectors, strict JSON negatives, domain separation, idempotence, and golden identities. Independent cross-language numeric/Unicode vectors are still needed before claiming broad canonicalization interoperability. The package explicitly avoids a JCS conformance claim.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 fixes source canonical text; WP06 and WP07 state self-identity exclusion and tuple ordering; WP18 binds the exact serializer/toolchain in reproduction evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP18_Reproducibility_Specification.md`

# WP18 — Reproducibility Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines deterministic build, dependency, environment, replay, and reproducibility receipts.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP17, WP08, WP05.

**Mandatory deliverables:**
- build manifest
- compiler/runtime identity
- dependency lock
- replay envelope
- environment
- receipt

## 5. Normative model
### Reproducibility envelope
A reproducibility envelope binds source digests, corpus version, compiler/runtime identifiers, schemas, MSSL modules, deterministic mode, locale/encoding, environment constraints, and all explicit seeds. Identity-critical output must not depend on wall-clock time, filesystem metadata, unordered directory traversal, or implicit random state.

Receipts distinguish deterministic reproduction from external validation or authorization.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP18-REQ-0001` | A reproducible build MUST record corpus version, source digests, compiler/runtime identity, dependency lock, and environment constraints. | `WP18-TEST-0001` |
| `WP18-REQ-0002` | Rebuilds under the same declared deterministic profile MUST reproduce canonical artifacts byte-for-byte. | `WP18-TEST-0002` |
| `WP18-REQ-0003` | Non-deterministic inputs such as wall clock, random seed, locale, or filesystem order MUST be fixed or excluded from identity-critical outputs. | `WP18-TEST-0003` |
| `WP18-REQ-0004` | Replay receipts MUST distinguish observed external inputs from deterministic internal derivations. | `WP18-TEST-0004` |
| `WP18-REQ-0005` | Reproducibility success MUST NOT be represented as external scientific validation. | `WP18-TEST-0005` |
| `WP18-REQ-0006` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP18-TEST-0006` |
| `WP18-REQ-0007` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP18-TEST-0007` |
| `WP18-REQ-0008` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP18-TEST-0008` |
| `WP18-REQ-0009` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP18-TEST-0009` |

## 7. Technical interpretation and algorithms

### Reproduction targets
Declare what is reproduced: canonical source, IR bytes, tuple members, physical .russ bytes, pure evaluation outputs, or effect receipts. These are different targets. A container rebuild can be deterministic while its mechanics has never been evaluated. Historical grant timestamps and external observations remain recorded inputs rather than fresh values inserted during reproduction.

An envelope binds input digests, corpus package/language/profile versions, compiler and runtime bytes, dependency versions/hashes, platform, encoding, locale, numeric libraries, seeds, and selected resource limits. A tool name or version string is weaker than a verified executable/dependency identity.

### Hermetic procedure
1. Verify the release manifest and required inputs before construction.
2. Select the declared interpreter/compiler environment and serializer profile.
3. Enumerate sources and members in a fixed order; fix encoding, locale, and archive metadata.
4. Construct canonical artifacts without reading implicit clock/random/network state.
5. Compare every declared output to an independent expected digest/byte fixture.
6. Produce an execution receipt that identifies checks, failures, exclusions, and observed external inputs.

At least one rebuild uses a clean destination so stale generated files cannot supply apparent success. Comparing only final checksums can miss untracked extras; archive membership and manifest closure are checked too.

### Numeric and environmental reproducibility
Bit-identical numerical outputs require a declared arithmetic profile, library versions, hardware behavior where relevant, threading/reduction order, and rounding. Tolerance-based scientific comparisons are useful but do not satisfy the byte-for-byte obligation for a claimed deterministic artifact profile. A report states which domain used exact bytes and which used numeric tolerances.

External input snapshots bind their observed bytes and observation context. Reproducing that snapshot is computational reproducibility; it does not repeat the physical measurement or validate the original observation.

## 8. Worked example

A rebuild can verify that all twelve source examples lower to the same canonical IR and that the golden .russ fixture is byte-identical. This establishes those build targets only. It does not show that a full MSSL interpreter produced field values or that a distributed commit is replay-safe.

A performance experiment records hardware, data sizes, warm/cold cache state, thread count, and repeated-run samples in addition to input/module hashes. Those results remain separate from deterministic identity checks.

## 9. Boundary and adversarial cases

| Hidden input | Reproduction risk |
|---|---|
| Directory enumeration order | Member/program ordering can vary. |
| Current clock in identified manifest | Rebuild digest changes. |
| Unpinned dependency | Serializer/parser behavior can drift. |
| Cached output reused without rebuilding | Test does not demonstrate construction. |
| Network source re-fetched without digest | Observation can change. |
| Float tolerance called byte identity | Claimed target is misstated. |

## 10. Security and failure considerations

Self-reproduction by a single implementation can preserve a shared bug. Independent implementations, property checks, and externally reviewed expected vectors strengthen evidence. Reproduction never supplies missing institutional authorization or empirical science.

## 11. Verification obligations and current evidence boundary

Current package checks can demonstrate local canonical artifact/golden rebuild equality. Multi-platform/cross-language builds, interpreter replay, independent expected-vector derivation, and measured performance are outstanding. Reports preserve this scope instead of promoting build success to all-class GO.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

Nineteen added attachments have exact raw-byte preservation and source IDs RA01–RA19 in research/ADDITIONAL_SOURCE_INTAKE.json. Published-paper results, corrected conversation claims, prospective protocols and generated index vectors have distinct evidence types. Reproducing an index formula does not replicate an optimizer, optical simulation or laboratory experiment.

## 13. Cross-specification consistency

WP17 fixes bytes; WP06/WP07 define artifact construction; WP08 defines historical effects; WP26 defines experiment reporting.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP19_RUSSL_Error_and_Diagnostic_Standard.md`

# WP19 — RUSSL Error and Diagnostic Standard

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines stable errors, severities, locations, causal chains, and redaction.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP03, WP08, WP11.

**Mandatory deliverables:**
- error namespace
- stable codes
- severity
- source locations
- causal chains
- redaction

## 5. Normative model
### Diagnostic model
A diagnostic is `(code,severity,class,message,location,cause_chain,redactions)`. Stable codes are authoritative for automation; message wording may improve in compatible releases. Security-sensitive values such as signatures, secret tokens, or private paths are redacted while the code and structural cause remain observable.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP19-REQ-0001` | Every normative failure class MUST have a stable machine-readable error code. | `WP19-TEST-0001` |
| `WP19-REQ-0002` | Diagnostics MUST include a severity and causal class. | `WP19-TEST-0002` |
| `WP19-REQ-0003` | Source diagnostics SHOULD include row ID and source line when available. | `WP19-TEST-0003` |
| `WP19-REQ-0004` | Security redaction MUST NOT change the stable code or conformance result. | `WP19-TEST-0004` |
| `WP19-REQ-0005` | Multiple causal failures MAY be chained but MUST preserve the primary fail-closed cause. | `WP19-TEST-0005` |
| `WP19-REQ-0006` | Unknown errors MUST map to a stable generic class rather than leaking implementation exceptions. | `WP19-TEST-0006` |
| `WP19-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP19-TEST-0007` |
| `WP19-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP19-TEST-0008` |
| `WP19-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP19-TEST-0009` |
| `WP19-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP19-TEST-0010` |

## 7. Technical interpretation and algorithms

### Structured failure contract
A diagnostic record includes stable code, severity, phase/class, human message, source location when available, bounded causal chain, affected row/path, and redaction descriptors. Machine decisions use code and result status; messages remain explanatory and can change in compatible revisions.

Source locations distinguish byte offset, Unicode scalar offset, and line/cell position. The reference profile can use line number and row ID; a richer editor integration states its offset basis. Normalized-source positions are not silently presented as original-file byte positions.

### Primary cause and deterministic ordering
The earliest causal precondition failure on a blocked path is primary. Derived failures such as missing downstream output link back to it instead of replacing it with generic noise. For multiple independent failures, a deterministic report orders by phase, source ordinal, then code, while retaining dependency causality. Exception text never determines the stable error code.

Unknown internal exceptions map to a stable generic failure class with a restricted incident reference; detailed stack/context belongs in restricted logs. Diagnostic generation itself is bounded so malformed inputs cannot recursively produce unbounded cause chains.

### Redaction and evidence
Redact private paths, tokens, secret keys, signature material where sensitive, and protected dataset values by structured field policy. Preserve code, severity, phase, and conformance result. The redaction descriptor says which class was hidden without reproducing the value. Error receipts bind the failed input identity if safely available; they do not mark partially parsed data as a verified artifact.

A diagnostic distinguishes syntax rejection, unresolved external input, integrity mismatch, type failure, authorization failure, unsupported profile, resource limit, and operational unavailability. Unsupported runtime functionality is reported as unimplemented/not-run evidence, not simulated success.

## 8. Worked example

A duplicate row ID can report a stable parse-family code, severity error, source line, and row ID. A module-digest mismatch uses the MSSL integrity family and cites the declared binding without printing private resolver credentials.

When R3 fails verification and R4 consumes its output, R4's blocked status references R3's primary diagnostic. A public report can retain those relationships while redacting a private source location.

## 9. Boundary and adversarial cases

| Diagnostic defect | Why it matters |
|---|---|
| Error message string used as test oracle | Compatible wording changes break automation. |
| Generic downstream error hides root cause | Remediation targets the wrong failure. |
| Redaction changes failure to success | Evidence loses integrity. |
| Host exception contains a secret | Ingestion failure becomes disclosure. |
| Byte and character offsets are conflated | Editors select the wrong location. |
| Unsupported functionality returns a success receipt | Test evidence is fabricated. |

## 10. Security and failure considerations

A corpus error registry records stable families, but robust diagnostic coverage needs deliberate mapping of every implemented failure path. Never attach executable remediation text from untrusted source comments as system instructions; comments remain diagnostic/source data.

## 11. Verification obligations and current evidence boundary

Relevant current tests assert code-prefix stability for negative parser/canonicalization/container/schema cases. Planned runtime tests cover primary-cause propagation, redaction, offset correctness, bounded chaining, and unknown exceptions. Human-readable wording is not treated as a normative identity.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 produces source locations; WP10 defines sensitive data; WP20 defines result states; WP21 binds negative-test oracles.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP20_Conformance_Standard.md`

# WP20 — Conformance Standard

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines conformance classes, test declarations, compatibility, GO/NO_GO, and reports.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01–WP19.

**Mandatory deliverables:**
- classes
- feature levels
- test format
- result schema
- compatibility
- GO/NO_GO

## 5. Normative model
### Conformance classes
Classes are `P` parser, `C` compiler/lowerer, `R` runtime, `M` MSSL binding, `T` tuple/container, `F` fabric, `S` security, `D` determinism/reproducibility, and `I` interoperability. Claims name class set, corpus version, profile, test set digest, and result digest.

`GO` is a scoped result requiring every applicable mandatory check to execute and pass; no corpus-wide GO is inferred from aggregate static checks. External certification is always a separate artifact.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP20-REQ-0001` | Conformance classes MUST separately identify parser, compiler, runtime, MSSL binding, tuple, fabric, security, determinism, and interoperability claims. | `WP20-TEST-0001` |
| `WP20-REQ-0002` | A conformance claim MUST name the corpus version and feature profile. | `WP20-TEST-0002` |
| `WP20-REQ-0003` | A `GO` corpus result MUST require every mandatory check to PASS. | `WP20-TEST-0003` |
| `WP20-REQ-0004` | Skipped mandatory tests MUST produce `NO_GO`. | `WP20-TEST-0004` |
| `WP20-REQ-0005` | Conformance reports MUST state that they are not external certification unless independently certified. | `WP20-TEST-0005` |
| `WP20-REQ-0006` | Version compatibility MUST be explicit and MUST fail closed for unknown major versions. | `WP20-TEST-0006` |
| `WP20-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP20-TEST-0007` |
| `WP20-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP20-TEST-0008` |
| `WP20-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP20-TEST-0009` |
| `WP20-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP20-TEST-0010` |

## 7. Technical interpretation and algorithms

### Claims are sets of bounded assertions
A claim identifies implementation/tool bytes, class set, feature subset, language/profile version, corpus package version, requirements in scope, test-suite digest, environment, and result evidence. Classes are P parser, C compiler, R runtime, M MSSL binding, T tuple, F fabric, S security, D reproducibility/determinism, and I interoperability. Class labels alone are not executable evidence.

A result model separates per-check `PASS, FAIL, NOT_RUN, NOT_IMPLEMENTED, NOT_APPLICABLE` from release decisions. Applicability is decided from a documented profile before results are inspected. Unimplemented semantics remain visible; documentation completeness does not substitute for execution.

### Decision rule
For a declared scoped claim Q, let M(Q) be its mandatory applicable checks. A scoped GO requires every member of M(Q) to have executed and passed with valid evidence. A skipped, unimplemented, or not-run member fails the mandatory condition. An empty mandatory set cannot justify a substantive conformance claim; it signals an incomplete claim definition.

Corpus-wide GO quantifies over all applicable mandatory requirements across claimed classes. Fifteen aggregate verifier checks or hundreds of registry links are not hundreds of executed behavioral checks. A test ID proves traceability only after it resolves to a real oracle and evidence. Coverage is reported at requirement granularity with implementation, test, and evidence status separately.

### Document status versus operational status
This 2.0.0 package is a hardened research/institutional candidate. Its specs are proposed contracts with preserved IDs. A successful local artifact verifier reports the bounded checks it actually performed. It does not mark all work packages, runtime semantics, experimental mechanics, security controls, or adapter profiles GO.

A release decision is a human/institutional governance artifact with authentic decision authority. External certification is another artifact entirely. Unknown language/schema majors fail closed; package-major changes can correct assurance and structure without inventing a new `RUSSL/1.0` syntax.

## 8. Worked example

A precise current claim can read: “The identified Python tool passed the recorded syntax/structural-lowering vectors, source/IR hash checks, bounded tuple checks, and local schema/cross-field checks under the 2.0.0 hardened reference profile.” Its report lists exact checks.

A separate runtime claim lists scheduler, module evaluation, grant verification, state commit, and replay requirements. If these are unimplemented, their mandatory evidence is NOT_IMPLEMENTED/NOT_RUN and the runtime claim receives NO_GO.

## 9. Boundary and adversarial cases

| Overclaim | Correct assessment |
|---|---|
| Every registry row is counted as a test pass | Registry linkage is not execution. |
| Unknown or skipped mandatory check counted as pass | Scoped GO condition fails. |
| Text includes “MUST” so behavior is declared implemented | Specification and implementation status differ. |
| Local checksum success called external certification | No certifier evidence exists. |
| Empty feature profile used to claim all-class conformance | Claim scope is vacuous/invalid. |

## 10. Security and failure considerations

Conformance reports are security-relevant evidence. If tool output can mark unsupported tests passed or omit mandatory tests, downstream assurance becomes unreliable. The report schema and verifier need independent review and negative cases for missing/contradictory evidence.

## 11. Verification obligations and current evidence boundary

The revised package requires honest scoped reporting. The original blanket Internal GO and all-requirement conformance implications are superseded. Executed check evidence, not this prose, determines any local PASS. Full corpus semantics and external certification remain unestablished.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP21 owns actual oracles; WP27 owns assurance claims; WP25 owns authentic release decisions; WP28 validates report shape but not the truth of a pass assertion.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP21_Normative_Test_Corpus.md`

# WP21 — Normative Test Corpus

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines and supplies positive, negative, golden, and security/conformance vectors.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP20, All normative specs.

**Mandatory deliverables:**
- syntax vectors
- semantic/type vectors
- field vectors
- MSSL vectors
- security negatives
- hash vectors
- golden artifacts

## 5. Normative model
### Test taxonomy
Tests are positive parse/lower vectors, negative fail-closed vectors, field coordinate vectors, canonicalization identities, MSSL byte bindings, JSON-schema validation, deterministic fixture rebuild, requirements traceability, and architectural leakage scans. Golden expected hashes are stored with the vectors.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP21-REQ-0001` | The test corpus MUST include valid and invalid syntax vectors. | `WP21-TEST-0001` |
| `WP21-REQ-0002` | The test corpus MUST include Penteract coordinate vectors. | `WP21-TEST-0002` |
| `WP21-REQ-0003` | The test corpus MUST verify all four baseline MSSL file digests. | `WP21-TEST-0003` |
| `WP21-REQ-0004` | The test corpus MUST include canonicalization/hash vectors. | `WP21-TEST-0004` |
| `WP21-REQ-0005` | The test corpus MUST include at least one deterministic golden `.russ` fixture. | `WP21-TEST-0005` |
| `WP21-REQ-0006` | Negative tests MUST include storage-semantic leakage, missing MSSL digest, duplicate row ID, and forward dependency. | `WP21-TEST-0006` |
| `WP21-REQ-0007` | Golden artifacts MUST record expected hashes. | `WP21-TEST-0007` |
| `WP21-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP21-TEST-0008` |
| `WP21-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP21-TEST-0009` |
| `WP21-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP21-TEST-0010` |
| `WP21-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP21-TEST-0011` |

## 7. Technical interpretation and algorithms

### A test is an oracle plus executable evidence
A test record identifies the target behavior, requirement links, setup/input digests, execution procedure, expected result, comparison domain, tool/profile, applicability, and output evidence. A title such as “verify WP03-REQ-0005” is a plan until a real test determines that unknown types are rejected before effects.

Golden values are reviewed inputs, not values regenerated and immediately declared expected by the same implementation. Updating goldens records the semantic reason and old/new identities. Identity vectors include the exact preimage bytes so another implementation can calculate expectations independently.

### Coverage dimensions
| Dimension | Positive evidence | Negative or boundary evidence |
|---|---|---|
| Syntax | Canonical source accepted | Ordering, delimiter, duplicate key/ID, incomplete frame |
| Data flow | Producer reachable through controls | Missing ancestor, future dependency, duplicate output |
| Identity | Exact known source/IR/tuple hash | Duplicate JSON keys, nonfinite values, wrong domain |
| Geometry | Endpoint/singleton/region expectations | Invalid indices, anchors, dimensions, overflow |
| Tuple | Deterministic verified fixture | Truncation, traversal, member mismatch, broken reference |
| Schemas | Declared samples valid | Wrong type, missing field, unknown property, cross-field conflict |
| Runtime/authority | Future transition/grant traces | Future replay, expiry, races, crash/recovery |

Metamorphic tests assert relationships rather than mirror code: source canonicalization idempotence, alias normalization equality for unchanged canonical content where applicable, adapter-independent coordinate mapping, and tampered-byte rejection. Property-based generation remains bounded and records seeds.

### Status and aggregation
Requirement coverage distinguishes `registered`, `implemented`, `executed`, and `passed`. Some shared architectural/governance requirements require review artifacts rather than code execution; their evidence is recorded as review, not numeric unit-test success. Full runtime/type/mechanics/adapter tests remain planned when no implementation exists.

A suite exits unsuccessfully on a mandatory applicable failure or not-run obligation for its declared claim. A bounded tooling suite can pass its own checks while broader corpus conformance remains NO_GO. Failure artifacts preserve reproducing inputs and stable diagnostic codes.

## 8. Worked example

For a forward-dependency negative, store a small source where R1 names R2 before R2 appears, identify its input bytes, execute the parser, and compare the dependency error family. “File exists” is not the oracle.

For a tuple traversal negative, alter a member path to `../escape` while keeping framing coherent, then establish that the verifier rejects it before extraction. An invalid outer checksum alone does not isolate traversal validation.

## 9. Boundary and adversarial cases

| Weak test design | Defect |
|---|---|
| Golden generated by the tested function during the test | Circular expectation. |
| Registry record without executed procedure | Planned, not passed. |
| All negatives rejected by one earlier failure | Later controls remain untested. |
| Runtime behavior inferred from a schema-valid receipt | Receipt data is not an execution trace. |
| Missing cases silently excluded after a failure | Applicability decision is biased. |

## 10. Security and failure considerations

Fuzzing can find failures but cannot prove absence of all failures. Store minimized cases without exposing confidential input material. Test scripts included in the corpus are inspected code; attachment presence alone does not authorize executing arbitrary scripts.

## 11. Verification obligations and current evidence boundary

The package adds meaningful local hardening tests and preserves broader test IDs for future work. Current aggregate checks do not establish all 293 original requirement obligations. Exact counts and statuses come from the final requirements/test registries and executed report.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The supplemental finite-layout tests enumerate all 16,384 sites and check exact ordinal/index consistency. Their data and scope are documented in the [fixed-shape profile](research/FIXED_SHAPE_INDEXING_PROFILE.md). These tests add concrete mathematical evidence but do not close all original language/runtime/scientific requirements.

## 13. Cross-specification consistency

WP20 defines claims and GO; WP19 defines stable errors; WP18 defines repeatability; WP28 validates records without fabricating behavioral evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP22_Reference_Programs.md`

# WP22 — Reference Programs

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Supplies canonical RUSSL examples from a single sample through distributed candidate publication.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01–WP11.

**Mandatory deliverables:**
- single sample
- 2D image
- RGB/pyramid
- 3D/5D
- sparse field
- MSSL stack
- distributed examples

## 5. Normative model
### Reference-program ladder
The program suite grows from one sample to raster, RGB pyramid, 3D volume, native 5D, sparse coupling, full MSSL stack, distributed candidate root, guarded commit, and projection. A TIFF migration profile example is included without making TIFF a core data model. Each source has canonical RUSSIR output.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP22-REQ-0001` | Reference programs MUST cover a single sample, 2D image, RGB/pyramid, 3D volume, native 5D field, sparse field, MSSL stack, distributed candidate, guarded commit, and projection. | `WP22-TEST-0001` |
| `WP22-REQ-0002` | Reference RUSSL programs MUST lower successfully with the corpus reference lowerer. | `WP22-TEST-0002` |
| `WP22-REQ-0003` | Core reference programs MUST NOT contain a storage-backend path as canonical state. | `WP22-TEST-0003` |
| `WP22-REQ-0004` | Commit examples MUST show an external grant requirement rather than self-authorizing. | `WP22-TEST-0004` |
| `WP22-REQ-0005` | Reference outputs MUST include canonical RUSSIR artifacts. | `WP22-TEST-0005` |
| `WP22-REQ-0006` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP22-TEST-0006` |
| `WP22-REQ-0007` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP22-TEST-0007` |
| `WP22-REQ-0008` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP22-TEST-0008` |
| `WP22-REQ-0009` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP22-TEST-0009` |

## 7. Technical interpretation and algorithms

### Pedagogic progression and evidence grade
The reference-program ladder separates syntax demonstrations from executed scientific workloads. Each program records its objective, required inputs, module aliases, expected lowering features, and unsupported runtime obligations. The existing corpus covers single sample, plane, RGB/pyramid, volume, native 5D, sparse coupling, MSSL stack, distributed candidate, guarded commit, projection, and migration profile examples.

A program is self-contained only if every external handle resolves to supplied digest-bound data with a declared type. `source.*` names are unresolved interface placeholders in the current examples. They allow structural lowering but do not supply pixels, calibrated datasets, network nodes, or authorizers.

### Review protocol
For each example: canonicalize and parse; compare source/IR identities; verify all module descriptors against preserved baseline files; inspect control ancestry and effect annotations; classify external dependencies; and list expected evaluator/adapter behavior separately. A reference output can be canonical IR without being a calculated image, mechanics result, or state commit.

The guarded-commit example explicitly demonstrates that the language has a commit operator and grant argument position. It remains non-authorizing unless authentic external grant evidence is supplied. Distributed examples can describe shard/root plans without constructing a live fabric.

### Expansion policy
New runnable examples need a small supplied dataset, a declared numeric/axis profile, an independently reviewed expected result, reproducible execution procedure, and negative sibling cases. Benchmark-scale data belongs in separately digest-bound packages with acquisition provenance; generating arbitrary pixels is suitable for synthetic correctness tests, not empirical validation.

Reference examples do not become normative syntax by accidental parser permissiveness. Closed operator-argument keys in the hardened profile are based on documented demonstrated contracts; recognition of other operators does not imply their parameter or runtime semantics are implemented.

## 8. Worked example

The single-sample source declares field population and mechanics/admission evaluation, but its `source.sample` operand is an external placeholder. Its canonical IR is a valid lowering fixture. A runnable variant would supply one u16 sample, bind its digest/type, and evaluate under a separately implemented MSSL contract.

The 2D program demonstrates shape `(1,1,1,H,W)`; its expected coordinates can be computed from WP04. The compiler fixture does not prove any image decoder ran.

## 9. Boundary and adversarial cases

| Example misuse | Why it is unsupported |
|---|---|
| Program filename says “scientific” so output is empirical | Names do not supply observations. |
| Source input is replaced silently with random data | Program input contract changes. |
| Grant placeholder is treated as a real capability | Example self-authorizes. |
| IR fixture is called an execution receipt | Lowering and evaluation are different stages. |
| Adapter name is used as canonical field substrate | Architecture boundary is crossed. |

## 10. Security and failure considerations

Examples are strong teaching artifacts but weak assurance if their external assumptions are hidden. The hardened profile records structural acceptance while the package's limitations keep runtime and empirical obligations explicit.

## 11. Verification obligations and current evidence boundary

All supplied source examples are intended to parse/lower under the bounded profile and compare against canonical IR fixtures. Full end-to-end execution, synthetic dataset result vectors, distributed behavior, and real adapter round trips remain separate work.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01/WP06 govern source and IR; WP03/WP05 govern runtime inputs; WP09 governs grant authenticity; WP26 governs empirical versus synthetic evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP23_TIFF_RUSS_Migration_Specification.md`

# WP23 — TIFF→RUSS Migration Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines loss-aware migration between TIFF-family image structures and Penteract field populations.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP14, WP04, WP13.

**Mandatory deliverables:**
- IFD/tag mapping
- strips/tiles
- metadata
- BigTIFF
- sample preservation
- field placement
- round-trip classes

## 5. Normative model
### Migration mapping
TIFF-family input is treated as an adapter source. Logical samples map into a Penteract field according to an explicit placement profile: image plane coordinates map to two axes; page/channel/time/depth may map to remaining axes or packed sample metadata. IFD/tags and embedded metadata are preserved in a provenance namespace when no direct RUSS profile field exists.

Round-trip classification is `LOSSLESS`, `REVERSIBLE_WITH_METADATA`, or `LOSSY`; byte-for-byte TIFF reconstruction is not required unless a profile explicitly stores the original bytes.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP23-REQ-0001` | TIFF migration MUST classify each mapping as lossless, reversible-with-metadata, or lossy. | `WP23-TEST-0001` |
| `WP23-REQ-0002` | Pixel/sample values MUST be preserved exactly in a lossless migration. | `WP23-TEST-0002` |
| `WP23-REQ-0003` | TIFF pages, channels, tiles/strips, and pyramid levels MUST map through an explicit Penteract placement profile. | `WP23-TEST-0003` |
| `WP23-REQ-0004` | ICC/EXIF/XMP or equivalent source metadata MUST be preserved or explicitly reported unsupported. | `WP23-TEST-0004` |
| `WP23-REQ-0005` | BigTIFF offset width MUST NOT alter logical sample semantics. | `WP23-TEST-0005` |
| `WP23-REQ-0006` | Round-trip tests MUST compare sample values and preserved metadata, not byte-for-byte container identity. | `WP23-TEST-0006` |
| `WP23-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP23-TEST-0007` |
| `WP23-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP23-TEST-0008` |
| `WP23-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP23-TEST-0009` |
| `WP23-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP23-TEST-0010` |

## 7. Technical interpretation and algorithms

### TIFF-family ingestion stages
The candidate migration procedure separates container inspection, sample decoding, placement, metadata preservation, field construction, and round-trip assessment. Inspect byte order, classic TIFF versus BigTIFF header, IFD graph, tags, sample dtype/width, photometric interpretation, planar layout, compression, orientation, strips/tiles, and subimage relationships before allocating or decoding.

Offset and count arithmetic is checked against file bounds; IFD cycles, overlapping ranges, excessive tag counts, codec expansion, and unsupported codecs produce explicit failures. Classic/BigTIFF offset width is a container concern, not a change to decoded sample semantics. The official libtiff documentation describes TIFF support and its tools; exact adapter implementation/version still requires its own declared profile. [libtiff documentation](https://libtiff.gitlab.io/libtiff/)

### Placement and metadata mapping
Map image-plane y,x to two explicitly chosen logical axes. Pages, channels, time, depth, and pyramid levels use declared mappings; page index is not assumed to mean z or t. Preserve original orientation and raw sample order for sample-exact migration, or apply an identified orientation transform to a derived field.

Retain unfamiliar tags and ICC/EXIF/XMP blocks in a namespaced provenance record when safe and supported. Opaque metadata bytes can be preserved without claiming semantic understanding. Referenced external resources are not fetched automatically. Associated alpha, palette lookup, YCbCr subsampling, and codec-specific conversions are reviewed separately from simple grayscale sample copying.

### Round-trip domains and classification
LOSSLESS means exact decoded sample values under the declared dtype/placement and required semantic metadata contract. REVERSIBLE_WITH_METADATA means the declared source-level information can be reconstructed using preserved side information. LOSSY means required information cannot be reconstructed. State these domains rather than suggesting that every TIFF file can be rebuilt byte-identically.

Original-file preservation can support exact container recovery as a separate archival claim. Re-encoding, tag ordering, strip/tile layout, compression, and offsets commonly change file bytes while samples remain equal. A migration receipt binds source file digest, source profile/version, target root, mapping, losses, and unsupported features.

## 8. Worked example

A grayscale TIFF plane with dimensions H×W can map to shape `(1,1,1,H,W)`. Tile boundaries are decoding/storage metadata; sample coordinate (y,x) stays the same regardless of tiling. Multiple pages require an explicit page-axis meaning.

A TIFF with orientation metadata can be imported with unchanged stored samples plus preserved orientation. A normalized displayed orientation is a separate derived transform and gets a separate provenance record.

## 9. Boundary and adversarial cases

| Defect | Migration classification/failure |
|---|---|
| Page index implicitly treated as depth | Placement semantics are guessed. |
| Unsupported compression accepted as empty pixels | Sample preservation fails. |
| Palette expanded to RGB without provenance | Stored sample representation changes. |
| Orientation/ICC dropped | Required interpretation metadata is lost. |
| IFD offset overflows host arithmetic | Reject before decoding. |
| Re-encoded bytes compared as sole sample oracle | Container equality is confused with sample equality. |

## 10. Security and failure considerations

TIFF is a complex attack surface; a production adapter relies on maintained decoders, bounded allocation, and adversarial tests. This package defines a migration candidate and examples, not an implemented TIFF decoder or certified archival workflow.

## 11. Verification obligations and current evidence boundary

Future evidence covers endian variants, sample widths, planar/packed channels, strip/tile partitions, pyramids, BigTIFF, orientation, palettes, metadata retention, malformed offsets, and unsupported codecs. No successful runtime round trip is asserted without actual source/output files and comparison evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP14 defines image meaning; WP04 defines placement; WP13 defines adapter roles; WP17 separates source-file bytes from logical/root identities.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP24_OME_Zarr_RUSS_Interoperability_Specification.md`

# WP24 — OME-Zarr→RUSS Interoperability Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines OME-Zarr/NGFF interoperability without making it a canonical language substrate.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP15, WP13, WP16.

**Mandatory deliverables:**
- axis mapping
- multiscales
- chunks/metadata
- labels/transforms
- loss classification
- adapter tests

## 5. Normative model
### Interoperability mapping
OME-Zarr/NGFF arrays are imported through an adapter that maps axes, multiscales, coordinate transforms, labels, and metadata into logical RUSS field/profile structures. Physical chunk keys do not become logical coordinates. Export is a derived projection and records all mappings and losses.

This document intentionally mentions the external storage/interoperability format because it is the designated adapter profile; no RUSSL core program depends on it.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP24-REQ-0001` | OME-Zarr/NGFF interoperability MUST be an adapter/profile and MUST NOT redefine canonical RUSSL state. | `WP24-TEST-0001` |
| `WP24-REQ-0002` | Axis mappings MUST be explicit and versioned. | `WP24-TEST-0002` |
| `WP24-REQ-0003` | Multiscale transforms MUST map to Penteract pyramid transforms without changing canonical field extent. | `WP24-TEST-0003` |
| `WP24-REQ-0004` | Chunk layout changes MUST NOT change logical sample coordinates. | `WP24-TEST-0004` |
| `WP24-REQ-0005` | Unsupported labels or coordinate transforms MUST be classified as preserved, transformed, or lossy. | `WP24-TEST-0005` |
| `WP24-REQ-0006` | Interoperability tests MUST declare the external profile version used. | `WP24-TEST-0006` |
| `WP24-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP24-TEST-0007` |
| `WP24-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP24-TEST-0008` |
| `WP24-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP24-TEST-0009` |
| `WP24-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP24-TEST-0010` |

## 7. Technical interpretation and algorithms

### External versions are pinned inputs
Select a declared NGFF/OME-Zarr version and underlying Zarr version before import. The reviewed informative target here is NGFF 0.5, whose specification uses Zarr v3 and defines image axes/multiscale metadata. This is an external profile selection, not the corpus's implementation claim or an automatic promise to support any newer version. [NGFF 0.5 specification](https://ngff.openmicroscopy.org/0.5/)

The 0.5 mapping reads ordered axes, dataset paths, per-dataset coordinate transforms, group transforms, labels, and relevant rendering metadata. Transform vector lengths agree with axis count. Scale/translation composition follows the declared source order; group transforms compose after per-level transforms for this version. Physical chunk keys remain storage implementation details.

### Mapping procedure
1. Validate source metadata and resolve safe relative dataset references.
2. Read source axes and construct an explicit injective placement into c4…c8; pad absent axes with declared singleton anchors.
3. Decode samples under the selected Zarr datatype/codec contract, preserving dtype, channel meaning, and missingness.
4. Map each resolution level to a derived field descriptor with parent relation, transform, shape, and reduction provenance when supplied.
5. Preserve supported labels, image-label relationships, calibration, and opaque metadata with source identities.
6. Report transformed, unsupported, and lost information; bind the resulting root and comparison domain.

Source units/calibration do not redefine normalized Penteract coordinates. Coordinate transforms can establish different sample-center positions across levels; preserving the canonical parent extent requires a declared embedding and may be approximate or lossy. WP24-REQ-0003 does not justify silently rewriting source physical transforms to force equal endpoints.

### Export and compatibility
Export is an identified derived representation. It selects external versions, axis order, dtype, codecs, chunk layout, label handling, and transform representation. Exact sample preservation, physical-coordinate preservation, metadata reversibility, and container/store byte identity are separately assessed. Unknown custom transforms or label meanings are preserved opaquely or explicitly marked unsupported; guessing a transform is not interoperability.

## 8. Worked example

An NGFF 0.5 TCZYX array maps its ordered axes to c4=t,c5=c,c6=z,c7=y,c8=x under a named profile. A scale vector `[1,1,2,0.5,0.5]` and declared units describe calibration; they do not replace WP04's normalization formula.

Changing chunks from 64×64 to 128×128 can preserve all samples and calibrated coordinates while changing stored bytes and keys. Target logical equivalence is verified at the decoded/profile level; raw storage identity is assessed separately.

## 9. Boundary and adversarial cases

| Defect | Interoperability consequence |
|---|---|
| Version omitted or guessed from directory name | External contract is unknown. |
| Axis names assumed to be TCZYX despite metadata | Placement can be wrong. |
| Scale/translation order reversed | Physical offsets change. |
| Unknown codec silently skipped | Sample data are missing. |
| Label IDs interpolated as intensities | Label semantics are destroyed. |
| Coarse-level calibration overwritten to match normalized endpoints | Source meaning is altered. |

## 10. Security and failure considerations

Metadata retrieval, codecs, referenced paths, and large arrays need bounded validation and explicit resolver authority. Future external specs can differ materially, so each version receives reviewed mapping tests. The corpus ships no functioning NGFF/Zarr importer/exporter.

## 11. Verification obligations and current evidence boundary

Planned evidence includes pinned-version fixtures, 2D–5D axis maps, omitted singleton dimensions, transform composition, labels, chunk repartition, unsupported codecs/transforms, and sample/calibration/metadata round trips. Structural examples and profile prose are not these test results.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP15 owns calibrated coordinate bases; WP04 owns normalized geometry; WP13 confines external storage; WP16 owns derived export/loss provenance.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP25_Language_Governance.md`

# WP25 — Language Governance

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines authority, RFCs, registries, versions, deprecation, errata, advisories, and release roles.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** All prior specs.

**Mandatory deliverables:**
- charter
- RFC lifecycle
- extensions
- versioning
- errata
- security advisories
- release authority

## 5. Normative model
### Governance process
Normative proposals use states `DRAFT → REVIEW → PROVISIONAL → RATIFIED`, with `REJECTED` and `SUPERSEDED` terminal alternatives. Each proposal records problem statement, specification delta, compatibility, security impact, research impact, migration, tests, reviewers, and release decision.

Semantic-breaking changes require a major version. Additive backward-compatible features require minor; clarifications/errata with no semantic change use patch.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP25-REQ-0001` | Specification authority and release roles MUST be documented and separable. | `WP25-TEST-0001` |
| `WP25-REQ-0002` | Normative changes MUST use an RFC/change proposal with impact and compatibility analysis. | `WP25-TEST-0002` |
| `WP25-REQ-0003` | Experimental extensions MUST use a registered namespace and MUST NOT silently become core semantics. | `WP25-TEST-0003` |
| `WP25-REQ-0004` | Major/minor/patch version rules MUST be defined. | `WP25-TEST-0004` |
| `WP25-REQ-0005` | Errata MUST preserve an immutable record of the superseded text. | `WP25-TEST-0005` |
| `WP25-REQ-0006` | Security advisories MUST support coordinated disclosure and version applicability. | `WP25-TEST-0006` |
| `WP25-REQ-0007` | No governance document MUST imply external institutional endorsement that has not been supplied. | `WP25-TEST-0007` |
| `WP25-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP25-TEST-0008` |
| `WP25-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP25-TEST-0009` |
| `WP25-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP25-TEST-0010` |
| `WP25-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP25-TEST-0011` |

## 7. Technical interpretation and algorithms

### Authorities and decision records
Proposed roles separate spec editing, technical review, security review, research-method review, release assembly, release approval, and external certification. The package does not assign authentic institutional persons or invent signatures. Role placeholders in templates remain unfilled until supplied by real participants.

A proposal record binds identifier, problem statement, affected requirements, old/new text, implementation impact, compatibility, numeric/identity effects, security/research consequences, migration, test plan, reviewer decisions, and release decision. A state change from DRAFT to REVIEW or RATIFIED requires an authentic recorded event; changing a status string in a generated document is not ratification.

### Version axes
Four version axes are independent: corpus package, source language, machine schema/identity profile, and external adapter profile. Package 2.0.0 corrects assurance claims and hardens tooling while the language header remains `RUSSL/1.0`. Program `@unit version` is program metadata, not language grammar authority.

A source-language semantic break requires its own major-version process. Schema changes invalidating formerly normative artifacts require a schema-major decision. Additive features are reviewed for closed-world validators and identity preimages; a superficially additive key can still break interoperability or change every hash.

### Extension and errata lifecycle
Extensions have a namespace, owner or explicitly vacant role, problem scope, security boundary, proposed tests, compatibility, status, and references. EXPERIMENTAL does not grant core semantics. Promotion records actual evidence and review. Unknown extensions fail closed where required for execution; safely preserved opaque metadata does not imply execution support.

Errata preserve the old text and reason, identify affected releases, and state whether semantics/identity changed. Security advisories record applicability, affected tools/profiles, exploit preconditions, mitigations, fixed artifact identities, disclosure handling, and unresolved risk without inventing incident history.

The original Internal GO wording is preserved only as historical audit evidence in the original release. It is not a current approval decision.

## 8. Worked example

A proposal to replace the current Python JSON profile with JCS would list numeric/Unicode differences, changed source/IR/tuple identity expectations, migration vectors, new domain/version choices, and dependent tool changes. It is not treated as a harmless serializer cleanup.

A documentation-only correction to remove an unsupported external-certification claim can be a package release change while preserving RUSSL/1.0 syntax and baseline module bytes.

## 9. Boundary and adversarial cases

| Governance defect | Consequence |
|---|---|
| Generated reviewer names/signatures | Institutional provenance is fabricated. |
| Status set to RATIFIED without a decision record | Lifecycle evidence is absent. |
| Identity-changing rule called editorial only | Migration impact is hidden. |
| Experimental extension appears in core silently | Semantics change without review. |
| Old erroneous text deleted without history | Audit trail is lost. |

## 10. Security and failure considerations

Governance quality depends on authentic participants and durable records. This package supplies processes and reviewable artifacts; it does not establish a standards body, regulator approval, committee ratification, or deployed release authority.

## 11. Verification obligations and current evidence boundary

Review checks establish document presence, proposed role separation, version distinctions, and truthful status wording. Actual governance conformance needs signed/authenticated proposal and decision records from responsible parties. Templates are not completed approvals.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP20 separates conformance from approval; WP27 archives decisions; WP17 exposes identity consequences; WP26 preserves research-grade evidence boundaries.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP26_Research_Foundation.md`

# WP26 — Research Foundation

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines mathematical/research framing, hypotheses, evidence grades, experiments, and citations.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP05, MSSL research inputs.

**Mandatory deliverables:**
- glossary
- assumptions
- hypotheses
- algorithms
- experiments
- evidence grades
- citation policy

## 5. Normative model
### Research evidence model
Research statements are tagged `DEFINITION`, `ASSUMPTION`, `HYPOTHESIS`, `DERIVATION`, `SIMULATION_RESULT`, `EMPIRICAL_RESULT`, or `EXTERNAL_REPLICATION`. Evidence grades increase only with supplied artifacts; the corpus never upgrades a hypothesis by wording alone.

The master-law image and MSSL modules are preserved as research inputs. References inside the lab module to source PDFs not supplied in this conversation are recorded as provenance gaps, not reconstructed from imagination.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP26-REQ-0001` | The research foundation MUST distinguish definitions, assumptions, hypotheses, derived propositions, and empirical claims. | `WP26-TEST-0001` |
| `WP26-REQ-0002` | P5×S³ and 8S mechanics MUST be identified as research/mechanics inputs rather than proven physical law by corpus fiat. | `WP26-TEST-0002` |
| `WP26-REQ-0003` | Experiments MUST record inputs, module digests, parameters, seeds, environment, outputs, and analysis method. | `WP26-TEST-0003` |
| `WP26-REQ-0004` | Evidence grades MUST distinguish formal derivation, deterministic computation, simulation, empirical observation, and external replication. | `WP26-TEST-0004` |
| `WP26-REQ-0005` | Missing source material referenced inside MSSL MUST be recorded as an unresolved research provenance issue rather than invented. | `WP26-TEST-0005` |
| `WP26-REQ-0006` | Citations MUST identify whether a source is embedded, externally referenced, or unavailable. | `WP26-TEST-0006` |
| `WP26-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP26-TEST-0007` |
| `WP26-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP26-TEST-0008` |
| `WP26-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP26-TEST-0009` |
| `WP26-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP26-TEST-0010` |

## 7. Technical interpretation and algorithms

### Claim ledger and evidence levels
For each research claim record claim ID, exact statement, classification, assumptions, derivation dependencies, evidence artifacts, method, counterexamples/limitations, responsible reviewer, and status. The ledger distinguishes a definition chosen by the authors from a statement about the physical world.

Formal derivation evidence cites its assumptions and checkable proof steps. Deterministic computation cites executable algorithm and vectors. Simulation cites numerical model, validation checks, sensitivity, and synthetic conditions. Empirical evidence cites real observation provenance, instrument/process, uncertainty, and analysis. External replication cites independent actors/data and outcomes. None is upgraded by repeating the claim in institutional prose.

### Penteract and mechanics scope
The finite field model is a mathematical/data-model definition. P5×S³/8S mechanics and κ expressions in baseline MSSL are experimental research inputs. Mapping an image into five indices does not demonstrate a five-dimensional physical mechanism. An image of a master law is source material requiring transcription review; it is not executable validation or empirical confirmation.

For a computational study, predeclare question, algorithm/modules, parameter domain, expected invariants, comparison baseline, precision, convergence/stability checks, and falsification conditions. For empirical work, add sampling design, measurement calibration, controls, exclusions, uncertainty, and analysis plan before looking at results.

### Numerical and reproducibility protocol
Record exact input/module identities, equations, discretization, tolerances, seeds, initial/boundary conditions, stopping criteria, solver versions, and environment. Report convergence failures, instability, negative/null results, and sensitivity rather than discarding them. Distinguish numerical error, measurement error, model discrepancy, and systematic bias.

A meaningful validation ladder first checks transcription and dimensional consistency, then reproduces a small analytic case, tests invariants/limits, compares an independent implementation, performs sensitivity/convergence studies, and finally assesses external observations where available. This ladder is a plan; the corpus does not supply absent data or completed empirical studies.

## 8. Worked example

A synthetic experiment evaluating a mechanics expression over a fixed field can be labelled deterministic computation or simulation, depending on the model. It binds module bytes and inputs and compares declared outputs. It does not receive EMPIRICAL_RESULT merely because the input has imaging-style axes.

A reference PDF named inside `lab_stack.mssl` but absent from the archive stays UNAVAILABLE/UNRESOLVED. Its content and supporting claims are not reconstructed from a title or memory.

## 9. Boundary and adversarial cases

| Research defect | Evidence consequence |
|---|---|
| Synthetic samples described as measured observations | Evidence grade is false. |
| Missing source is cited as reviewed | Provenance gap is concealed. |
| Numerical reproducibility called physical validation | Distinct evidence types are conflated. |
| Threshold tuned after results without disclosure | Analysis history is incomplete. |
| Failed runs omitted | Selection bias is hidden. |
| A definition is described as an experimentally proven law | Claim category is overstated. |

## 10. Security and failure considerations

Mechanics correctness, usefulness, and scientific validity remain open research questions. The package does not create peer review, ethics approval, instrument records, independent replication, or external institutional endorsement.

## 11. Verification obligations and current evidence boundary

Executable local checks can verify preserved research-source hashes and deterministic build artifacts. Scientific validation requires substantive new experiments, derivations, independent review, and observation evidence. The research program and provenance-gap record keep these obligations explicit.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [additional-source integration report](research/RESEARCH_INTEGRATION_REPORT.md) audits one 23-page 1-Bit LAMB paper and eighteen text exports. Source/claim registers preserve locators, primary references, corrections, hypotheses and rejected links. Optional p-adic/indexing, HRR, communication-optimizer, optical and systems profiles remain informative research candidates; no attachments are promoted automatically to normative authority.

## 13. Cross-specification consistency

WP04 supplies mathematical geometry; WP05 supplies preserved module bytes; WP18 supplies reproduction envelopes; WP27 links assurance claims only to evidence actually present.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP27_Institutional_Documentation.md`

# WP27 — Institutional Documentation

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines ADRs, assurance, safety/limitations, provenance, releases, interoperability, and archives.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP10, WP25, WP20, WP26.

**Mandatory deliverables:**
- ADRs
- assurance case
- limitations
- interop policy
- change control
- provenance
- archival policy

## 5. Normative model
### Assurance structure
Institutional assurance uses claim–argument–evidence triples. Claims cite specification requirements; arguments describe controls; evidence cites conformance tests, hashes, review records, or external attestations. Missing external attestations remain explicitly missing.

Archival packages preserve source authorities, specifications, schemas, tests, examples, manifests, receipts, and hash sets.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP27-REQ-0001` | Institutional documentation MUST include ADRs, assurance claims, limitations, provenance, change control, release policy, interoperability policy, and archival policy. | `WP27-TEST-0001` |
| `WP27-REQ-0002` | Assurance claims MUST cite supporting controls and test evidence. | `WP27-TEST-0002` |
| `WP27-REQ-0003` | Limitations MUST include experimental-status and absence-of-external-certification statements. | `WP27-TEST-0003` |
| `WP27-REQ-0004` | Release records MUST bind the immutable manifest and checksum set. | `WP27-TEST-0004` |
| `WP27-REQ-0005` | Archival policy MUST preserve specifications, schemas, tests, source authorities, and hashes. | `WP27-TEST-0005` |
| `WP27-REQ-0006` | Change control MUST require compatibility and security review for normative changes. | `WP27-TEST-0006` |
| `WP27-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP27-TEST-0007` |
| `WP27-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP27-TEST-0008` |
| `WP27-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP27-TEST-0009` |
| `WP27-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP27-TEST-0010` |

## 7. Technical interpretation and algorithms

### Claim–argument–evidence structure
An assurance claim names a bounded property, applicability, requirement IDs, and implementation scope. The argument explains why particular controls establish it; evidence names exact artifacts and observed results. A hash supports integrity of a referenced file, not every behavioral claim in it. A schema-valid receipt supports shape validity, not the authenticity of its success assertion.

Use three statuses: supported within scope, partially supported with named gaps, and unsupported/planned. Negative evidence and unresolved issues remain attached. A claim that depends on unimplemented runtime behavior is not promoted by documenting the proposed runtime.

### Institutional artifact set
Architecture decision records state context, alternatives, decision, consequences, dependency/version impact, security and research effects, and review status. The release record binds source archive digest, transformed package version, manifest/checksum identities, tooling identity, executed checks, unresolved obligations, and actual approver artifacts if supplied.

The archival package contains the immutable original source evidence or its verifiable preservation reference, all current specs/schemas/registries, source authorities, examples, tests, tooling, final results, audit findings, migration/change records, and checksums. Source lineage distinguishes untouched inherited files from modified/generated artifacts. Archival checks periodically verify completeness and recoverability; a single stored hash does not demonstrate long-term preservation.

### Review and operational readiness
A staged review can assess editorial consistency, machine integrity, bounded tooling behavior, semantic implementation, security controls, scientific method, and institutional authority separately. Deployment readiness includes recovery procedures, resource limits, authorization operations, incident response, monitoring, and ownership. This corpus provides candidate processes and explicit limitations; it does not fabricate institutional sign-off.

Interoperability policy identifies supported versions and implemented mappings; pending profiles stay pending. Retention/access policy distinguishes public specification, protected data, private evidence, and signing material. A public release never needs to bundle real secrets to demonstrate the grant schema.

## 8. Worked example

An assurance claim “all baseline MSSL bytes match their declared file digests” can cite the registry, preserved files, and executed digest checks. A claim “the mechanics is scientifically valid” cannot cite the same hashes as sufficient evidence.

An ADR for flat capabilities explains why write:state, commit, and publish remain separate, states implications for grants/runtime, and records review status. It is a reviewable decision proposal until authentic governance evidence exists.

## 9. Boundary and adversarial cases

| Documentation defect | Assurance impact |
|---|---|
| Every work package marked Internal GO | Scope/evidence distinctions disappear. |
| Manifest/checksums bind different file sets | Release integrity is ambiguous. |
| External reviewer named without source evidence | Endorsement is fabricated. |
| Limitations hidden in an unrelated footnote | Operational users can overclaim readiness. |
| Original provenance overwritten | Reproducible lineage is broken. |

## 10. Security and failure considerations

Institutional presentation can make weak evidence look stronger. Every release-facing claim therefore carries a precise scope and limitations. This package is research-grade in structure, technical depth, and evidence discipline; no external certification or operational authorization is claimed.

## 11. Verification obligations and current evidence boundary

Local document/link/registry/manifest checks establish consistency and completeness of the candidate package. Institutional release approval, independent assurance, security audit, and empirical validation require separately supplied authentic evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP20 scopes conformance; WP25 scopes governance; WP26 scopes science; WP18/WP17 bind reproducible artifacts.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `spec/WP28_Machine_Readable_Schemas.md`

# WP28 — Machine-Readable Schemas

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines authoritative grammars, schemas, registries, and schema tests.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP06, WP07, WP20, WP25.

**Mandatory deliverables:**
- grammar artifact
- RUSSIR schema
- tuple schema
- MSSL binding schema
- receipts
- conformance schema
- extension registry

## 5. Normative model
### Schema authority
JSON schemas use Draft 2020-12 identifiers under `urn:russl:schema:*`. The EBNF grammar is the machine-readable source syntax artifact. Registries for operators, errors, capabilities, MSSL bindings, and extensions are versioned corpus resources. Schema conformance is tested by the packaged verifier.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP28-REQ-0001` | Machine-readable schemas MUST be versioned and carry stable identifiers. | `WP28-TEST-0001` |
| `WP28-REQ-0002` | The corpus MUST publish schemas for RUSSIR, Penteract field descriptors, MSSL bindings, tuple manifests, capability grants, evidence receipts, execution receipts, conformance results, and extension registries. | `WP28-TEST-0002` |
| `WP28-REQ-0003` | Schema samples MUST validate under the declared JSON Schema draft. | `WP28-TEST-0003` |
| `WP28-REQ-0004` | Schema changes that break previously valid normative artifacts MUST require a major schema version. | `WP28-TEST-0004` |
| `WP28-REQ-0005` | The grammar artifact MUST match the surface syntax described in WP01. | `WP28-TEST-0005` |
| `WP28-REQ-0006` | The extension registry schema MUST preserve explicit lifecycle status. | `WP28-TEST-0006` |
| `WP28-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP28-TEST-0007` |
| `WP28-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP28-TEST-0008` |
| `WP28-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP28-TEST-0009` |
| `WP28-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP28-TEST-0010` |

## 7. Technical interpretation and algorithms

### Schema dialect and implementation scope
The corpus publishes JSON schemas with stable identifiers and declared Draft 2020-12 dialects. Dialect identification is not proof that a validator implements every vocabulary. Draft 2020-12 separates format annotation from format assertion; a validator using annotation mode does not automatically reject an invalid timestamp solely because `format=date-time` appears. [JSON Schema Draft 2020-12](https://json-schema.org/draft/2020-12)

The package's local dependency-free validator has an explicitly bounded supported-keyword contract and fail-closed behavior for unsupported constructs. It is not advertised as a complete general Draft 2020-12 implementation. A future full validator is pinned and tested against the actual dialect/vocabularies.

### Structural and cross-field layers
Structural validation checks required keys, primitive types, arrays/tuples, allowed values, patterns, bounds, and closed-world property policy under supported keywords. A JSON integer is not a host boolean. Strict ingestion rejects duplicate keys and nonfinite numbers before schema validation; a schema cannot recover fields discarded by a permissive parser.

Cross-field validation checks relations that schemas alone may not express: unique row/output namespaces, consistent flattened program/frame rows, operator/effect agreement, declared alias usage, rank/axis/shape length, tuple member/reference binding, matching grant identifiers, and self-identity recomputation. Authentic signatures, actual module evaluation, and truth of conformance results lie beyond schema shape.

### Closed-world evolution
Authority-bearing records use explicit allowed properties; extensions enter designated namespaces with lifecycle and version rather than arbitrary unknown executable fields. Opaque provenance fields remain inert data. New fields are reviewed for validator compatibility and hash-preimage impact.

Schema resources resolve through a local, versioned allow-list. No automatic network `$ref` resolution occurs merely because a schema requests it. Reference depth and cyclic processing are bounded. Schema and EBNF edits are reviewed with example fixtures and parser behavior to prevent a prose/grammar/implementation split.

## 8. Worked example

A tuple schema can require eleven components and named identities. The semantic verifier still checks their order, referenced member digests, and actual content. A grant schema can require `signature`, `nonce`, and `expires_at`; only a cryptographic/runtime verifier can establish that the signature is trusted, the nonce unused, and expiry live.

A field schema checks five positive dimensions. A cross-field checker additionally relates axis names and sample-count expectations where supplied. Neither check loads or computes missing scientific pixels.

## 9. Boundary and adversarial cases

| Artifact | Validation boundary |
|---|---|
| Boolean where shape integer is expected | Reject type confusion. |
| Unknown property on a closed authority record | Reject undeclared semantics. |
| Duplicate JSON key | Reject during ingestion, before schema. |
| External `$ref` points to an arbitrary URL | Resolution authority absent. |
| Valid IR shape but inconsistent program/frame copies | Cross-field rejection. |
| Schema-valid receipt asserts runtime success | Truth/authenticity is not established. |

## 10. Security and failure considerations

Unbounded references and complex schema constructs can exhaust validation resources. A bounded internal validator needs a supported-keyword inventory and adversarial tests; silently ignoring an unknown validation keyword would create false assurance.

## 11. Verification obligations and current evidence boundary

Current checks establish schema/sample structure and selected cross-field rules under the bundled local profile. Full Draft 2020-12 metaschema/official-suite conformance, external-validator parity, exhaustive semantic validation, and authentic receipts remain outside that claim.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 and grammar govern syntax; WP06/WP07 govern identity-sensitive records; WP09 governs grants; WP20 governs truthful result semantics; WP25 governs schema/version changes.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.


---

Source: `technical/FORMAL_MODEL_AND_IMPLEMENTATION_ROADMAP.md`

# Formal model and implementation roadmap

**Package:** RUSSL Research & Institutional Corpus 2.0.0  
**Language:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)  
**Status:** Informative technical design and verification plan; unratified  
**Evidence basis:** Supplied archive and local audit; external primary sources where cited  
**Scope:** Language/compiler/tuple/field/runtime/fabric contracts and their implementation boundaries

This document converts the corpus architecture into a checkable engineering program. It does not claim that a full type checker, MSSL interpreter, runtime, distributed fabric, or TIFF/NGFF adapter exists. The final verification report is authoritative about which local checks executed. The original 293 requirement IDs remain the normative traceability anchors; this roadmap introduces no new requirements.

## 1. Entities, identities, and authority

Define a source unit U, canonical source C(U), lowered IR J, ordered logical tuple T, logical field F, mechanics binding B, candidate root R, grant G, receipt E, and mutable head H. Keep the following relations separate:

| Relation | Meaning | What it cannot establish alone |
|---|---|---|
| Raw file digest equality | Exact supplied file bytes match | Authorship, permission, scientific truth |
| Domain-separated object identity | Canonical object bytes match under a named profile | Semantic equivalence of different representations |
| Type compatibility | Values obey a declared structural/numeric contract | Input authenticity or operational permission |
| Policy disposition | A mechanics/policy evaluation produced a result | A verified grant or human authorization |
| Authentic authorization | A trusted principal permitted a bound action | Scientific validity of mechanics |
| Reproduction | Declared outputs repeat under fixed inputs/profile | Independent empirical validation |

The architecture is `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. This is a separation of contracts. It is not a claim that every stage has an executing implementation. Backend paths and external container layouts live in adapter profiles; they do not define the core field.

## 2. Current implementation boundary

| Layer | Delivered or intended bounded support | Outstanding implementation/evidence |
|---|---|---|
| Source ingestion | Strict canonical text and finite-state parsing; bounded input | Independent parser differential review; broader language profiles |
| Structural compiler | Alias resolution, graph/order/handle/effect checks, canonical IR | General arity/parameter contracts, type soundness, semantic preservation |
| JSON ingestion/identity | Strict duplicate/nonfinite handling and compact corpus serializer | Independent cross-language numeric/Unicode equivalence |
| Geometry helper | Finite index/anchor checks and normalized-coordinate vectors | Complete dense/sparse/pyramid evaluator |
| Module binding | Four preserved files and exact digest checking | Complete MSSL parsing/evaluation, contracts, sandbox budgets |
| Tuple tools | Deterministic golden construction and bounded verification | Full loader/ABI runtime, independent compatibility implementations |
| Schema checks | Bounded supported-keyword validation plus selected cross-field checks | Complete Draft 2020-12 suite/validator parity and semantic coverage |
| Runtime/grants/fabric | Detailed contracts and examples | Authentic signature/grant service, replay store, transactions, distributed operations |
| TIFF/NGFF profiles | Versioned mappings, loss and round-trip plans | Actual import/export adapters and fixture round trips |
| Research/institutional | Evidence taxonomy, limitations, proposed assurance/governance | Authentic review/approval, empirical observations, external replication |

Recognition of an operator catalog entry is not evaluation support. Result labels attached during lowering are not a complete type judgment. Sample grant/receipt JSON objects are inert fixtures, not authentic operational evidence. Reserved `source.*` handles in existing examples designate unresolved external inputs.

## 3. Structural compiler invariants

Let `ord(r)` be source ordinal. A parsed row is
`r=(id,lane,op,out,ctrl,inputs,arg,meta)`, with a registered canonical operator and eight explicit source cells.

The hardened source profile admits a finite-state parse: header, one unit, optional defaults, zero or more module declarations, and one or more nonempty closed frames. Each frame establishes its columns exactly once before rows. Global declarations do not occur within a frame. Authority-bearing identifiers use a constrained lexical profile; duplicate keys are rejected rather than overwritten.

For every row r:

1. Row identity and produced output are unique within the applicable unit namespace.
2. Every p in ctrl(r) has ord(p) < ord(r).
3. Every produced input consumed by r has a unique producer p in the transitive control ancestry of r.
4. Module operands identify a declared digest-bound alias.
5. The explicit effect, if present, agrees with the registered operator effect.
6. Primary input count is at most two under this surface profile.

Property 2 proves the accepted control graph acyclic: a cycle would imply a strict ordinal inequality back to the same row. Property 3 establishes structural readiness rather than mere earlier textual definition. It does not prove that external inputs exist or that module results have the right type.

The grammar remains RUSSL/1.0. Package version 2.0.0 hardens the recognized reference profile and assurance discipline. Program `@unit version`, corpus version, schema version, and external adapter version are independent axes.

## 4. Operational semantics proposal

Use configuration `K=⟨G,σ,q,e,a,h⟩`. G is the lowered DAG, σ the immutable handle environment, q row status, e evidence, a authorization context, and h observed mutable-head state.

`Ready(K)={r | q(r)=pending ∧ ∀p∈pred(r),q(p)=succeeded ∧ inputs(r)⊆dom(σ)}`.

Sequential deterministic evaluation selects the smallest ordinal in Ready(K). A pure transition returns fresh output values and extends σ. Its preservation invariant is `∀x∈dom(σ),σ'(x)=σ(x)`. A failed precondition emits a stable primary cause and blocks descendants on the affected effect path.

An effectful row first produces a plan. Its application guard is the conjunction of verified content, compatible input contracts, live exact-bound grant, unused nonce/idempotency record, and unchanged state preconditions. An evaluation success is a candidate result until this guarded transition succeeds.

Safety statement: an unauthorized or failed commit path does not advance a mutable head. Liveness additionally assumes available inputs, finite/budgeted module evaluation, and a progressing adapter. Neither property is proved merely by a deterministic DAG scheduler.

## 5. Type-system proposal

A proposed judgment is `Γ;Δ;Π ⊢ r:τ!ε`, where Γ maps handles to refined types, Δ contains digest-bound module contracts, and Π specifies numeric/profile behavior.

Representative refinements include `Digest<domain,algorithm>`, `Coord<rank,basis>`, `Shape<rank>`, `Region<rank>`, `Field<sample,rank,axes>`, `Module<contract,digest>`, `Evidence<claim>`, `Grant<scope>`, and `Root<domain>`.

Field construction requires five positive integer dimensions, five distinct axes, and a supported sample contract. Population additionally relates cardinality, dtype, packing, coverage, and missingness to the source values. Slicing names fixed indices and output-axis order. Module evaluation requires an actual module contract rather than an alias name alone. Policy dispositions and grants are disjoint types.

Unit identifiers are explicit metadata. Physical arithmetic verifies compatibility and declared conversion; it does not infer units from magnitudes. Unknown external handle types remain unresolved. Overflow, clipping, signed conversion, null/missing values, binary sample NaN behavior, and rounding are declared profile choices.

Future soundness work has two obligations: progress for supported ready pure rows, and preservation of all handle/result refinements under successful evaluation. These are proposed theorem statements, not established corpus results.

## 6. Field, calibration, and sample equality

For positive integer shape `(n4,…,n8)`, domain `D=∏{0,…,na−1}` has size `N=∏na`, checked before allocation. Normalization is `φa(i)=(2i−(na−1))/(na−1)` for na>1, with finite declared singleton anchor otherwise.

The three coordinate spaces are integer index, normalized logical coordinate, and calibrated physical coordinate. If calibration is `p=A i+b`, a slice fixing indices k yields `p=A_free i_free+b+A_fixed k`. A crop starting at l yields an offset b+A l in rebased indices. A transform's input basis prevents double normalization.

A sparse absent sample is different from stored zero or null. Dense/sparse equivalence requires the same declared domain and presence/default policy. Logical regions use half-open bounds. Pyramid extent preservation and sample-value preservation are different obligations.

Equality also has several domains: encoded bytes, decoded samples, axis placement, calibrated coordinates, color/channel meaning, and scientific observations. The current digest model is byte/domain identity; it does not specify a universal codec-independent semantic sample hash. A change in compression can preserve samples and change payload bytes.

## 7. Canonicalization and identity

For canonical bytes B in domain D,
`H(D,B)=SHA256(ASCII(D)||0x00||B)`.
Raw module/member digests hash exact file bytes instead.

Source canonicalization is UTF-8/NFC/LF/no-BOM, trailing SP/TAB removal, and one final LF. It is idempotent and retains comments. Source identity is therefore not semantic-equivalence identity.

The corpus JSON profile is compact Python serialization with recursively sorted string keys and preserved array order. It is explicitly distinct from RFC 8785/JCS: numeric serialization and Unicode property ordering can differ; JCS preserves JSON string data without normalization. [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785.html)

The IR preimage excludes only its self-identifying ir_id. It includes source identity and source_line annotations. Tuple identity covers the ordered eleven-component logical tuple. A container-file digest covers framing/physical bytes. Version migration reviews all affected preimages and keeps old vectors; switching serializers is a semantic identity change, not formatting.

## 8. Commit transaction and crash states

A transaction record binds run, tuple, row, sequence, input root, arguments digest, head scope, observed tip/revision, candidate root, grant, nonce, and idempotency key.

The abstract application operation is
`CAS(head,expected_revision,expected_root,new_root,grant)`.
Success atomically establishes the new head, consumes authority according to nonce policy, and stores a durable result. If the adapter cannot provide that atomicity, the deployment declares its weaker contract and recovery procedure.

Crash analysis distinguishes: before effect, during effect, after effect before receipt, and after durable result. A missing receipt is not proof no effect occurred. Retry reads durable idempotency state; it does not reapply arbitrary actions. Rollback is a new authorized head update to an immutable checkpoint, preserving history. It does not erase publication or replication.

Exactly-once behavior is a transaction/storage property. DAG ordering, schema validation, and a nonce field alone do not supply it.

## 9. Interoperability contracts

TIFF migration separates safe container inspection, decode, explicit axis placement, metadata retention, and round-trip classification. Original byte recovery, exact sample recovery, and metadata reconstruction are distinct targets. The maintained official libtiff documentation provides format/library context; an adapter still pins its supported decoder/version/codecs. [libtiff documentation](https://libtiff.gitlab.io/libtiff/)

NGFF mapping pins external and Zarr versions. The informative 0.5 target uses Zarr v3 and explicit ordered axis/multiscale metadata. Scale/translation composition, dtype, labels, and unsupported metadata are preserved or classified; newer versions are not inferred compatible. [NGFF 0.5 specification](https://ngff.openmicroscopy.org/0.5/)

Schema dialect declarations identify the intended JSON Schema contract. A local bounded validator is not a complete general dialect implementation. Format annotation versus assertion and unsupported keywords are handled explicitly. Cross-field validators check semantic relationships and identity; no schema proves grant authenticity or scientific truth. [Draft 2020-12](https://json-schema.org/draft/2020-12)

## 10. Verification and release gates

Each evidence obligation records requirement ID, implementation status, applicability rationale, actual test procedure, expected oracle, input/suite/tool identities, environment, result, and evidence digest. Planned registry entries remain NOT_RUN. Review artifacts are labelled review evidence rather than invented unit-test passes.

A scoped GO requires every applicable mandatory check in the declared claim to execute and pass. An empty mandatory set is not a substantive claim. Whole-corpus GO is unestablished when mandatory runtime, mechanics, security, adapter, or institutional obligations remain unimplemented. A successful local hardening verifier is reported as such.

The next engineering milestones are:

| Milestone | Concrete deliverable | Exit evidence |
|---|---|---|
| M1. Independent grammar/profile review | Grammar, parser contracts, closed keys/limits | Differential valid/invalid vectors; ambiguity review |
| M2. Refined type checker | Supported operator/module signatures and numeric rules | Positive/negative judgments; preservation review |
| M3. Pure evaluator | Field population, slicing, projection subset | Analytic exact cases; invariant/metamorphic tests |
| M4. MSSL interpreter | Bounded verified-buffer evaluation | Baseline contract vectors; sandbox/termination negatives |
| M5. Grant verifier | Pinned signature/preimage/trust profile | Invalid key/signature/scope/expiry/replay tests |
| M6. Transaction runtime | Durable CAS/idempotency/recovery | Races and crash injection at all boundaries |
| M7. Two CAS adapters | Identical verified immutable object behavior | Corruption/availability/substitution vectors |
| M8. TIFF/NGFF adapters | Version-pinned import/export implementations | Sample/metadata/calibration round trips |
| M9. Independent reproducibility | Another environment or implementation | Byte/numeric-profile parity and source lineage |
| M10. Scientific/institutional review | Actual reviewer/observation artifacts | Evidence-grade assessment and authentic decisions |

No calendar date or completion status is invented for these milestones. Readiness depends on the stated evidence, not document volume.

## 11. Research evaluation protocol

A research claim states exact assumptions, mathematical/data-model definitions, algorithm/module identities, parameter domain, expected invariants, falsification criteria, analysis method, and evidence grade. Computational studies fix seeds, boundary/initial conditions, precision, convergence criteria, solver versions, and environment. Empirical studies add real observation acquisition, sampling, calibration, controls, uncertainty, and exclusions.

Start with transcription/dimensional review, small analytic cases, limiting cases and invariants, independent implementation, sensitivity/convergence studies, then external observations where appropriate. Report null/failed results and separate numerical error, measurement error, model discrepancy, and bias.

P5×S³/8S mechanics remains experimental. A five-index field, a preserved MSSL hash, or deterministic simulation does not establish a physical law. Missing PDFs and authentic external authorization remain unresolved provenance/authority obligations. The package's technical detail supports honest research; it cannot manufacture the missing science or institutional decisions.


---

Source: `technical/REFERENCE_PROFILE.md`

# RUSSL/1.0 hardened reference profile

**Profile status:** implemented static validation and deterministic lowering subset.  
**Corpus package:** 2.0.0.  
**Source header and IR schema:** `RUSSL/1.0` and `RUSSL.CanonicalIR/1.0`.  
**Implementation:** `tooling/russl_reference.py`.  
**Executable regressions:** `tests/test_reference_hardening.py`.

## 1. Authority and compatibility boundary

This profile defines the exact acceptance behavior of the packaged reference validator. Package version 2.0.0 records a corpus and assurance upgrade; it does not introduce a RUSSL/2.0 language, alter the RUSSL/1.0 digest domains, or declare an external language standard. Acceptance establishes bounded syntax, selected name-binding rules, selected dependency rules and effect-label consistency. It does not establish complete language conformance, scientific validation, runtime authorization or institutional approval.

The original implementation accepted malformed directive order, repeated defaults, rows before the column declaration, duplicate structured keys, unstructured META that bypassed effect checks, arbitrary effect annotations, unresolved data symbols and repeated output handles. Those acceptance behaviors were defects. They are explicitly removed by this closed profile. Extensions need an approved contract and separate profile identifier before they can change this parser's accepted key sets or effect rules.

All twelve supplied source examples produce exactly their original canonical IR objects and IDs under the hardened implementation. Their source header, program metadata version, source digest domain and IR digest domain remain unchanged. The regression compares full objects, not only selected fields. Syntax is narrower outside those examples: single-quoted values, opaque ARG/META text, unknown keys and unregistered effect substitutions are rejected. This is a declared reference-profile restriction, not evidence that every such input is invalid in every possible future RUSSL profile.

## 2. Source processing pipeline

The static pipeline is:

1. Accept a Python text string with valid Unicode scalar values and enforce the UTF-8 byte budget before normalization.
2. Remove one initial U+FEFF byte-order mark if present; convert CRLF and CR to LF; normalize Unicode to NFC.
3. Reject embedded U+FEFF, other Unicode format controls (`Cf`), control characters (`Cc`) except LF/TAB, U+2028/U+2029 and surrogate code points.
4. Remove trailing SP/TAB from each physical line, discard empty terminal lines and append exactly one LF.
5. Apply the optional storage-name lexical filter, validate source structure, normalize operator aliases and perform the profile's static checks.
6. Construct the legacy IR, serialize its identity preimage and calculate the domain-separated SHA-256 identifier.

The source canonicalizer is idempotent for accepted text. It preserves comments, internal empty lines, case, field order, significant quoted whitespace and source ordinals. Two semantically similar programs with different comments or source spellings can therefore have different source-bound IR identities. Alias normalization preserves the operator's lowered descriptor; it does not make different source spellings share one source digest.

The default storage filter searches the entire canonical text, including comments, for the packaged `STORAGE_LEAK` expression. This is a conservative lexical guard, not a proof of storage independence and not a storage-adapter implementation. `parse_russl(..., reject_storage_leak=False)` explicitly disables that guard. The flag must be an actual boolean. `lower_russl` always uses the default guard.

## 3. Structural state machine

The accepted order is a header, exactly one unit directive, at most one defaults directive, zero or more MSSL bindings, and one or more nonempty frames. Blank lines and full-line comments beginning with `#` may appear between complete lines after the header. Leading whitespace before a comment or directive is not ignored. Inline comments are not a syntax feature.

Each frame contains one frame directive, exactly one fixed `ID│LANE│OP│OUT│CTRL│IN│ARG│META` heading, one or more rows, and exactly one `@end`. Rows before the heading, duplicate headings, headings after rows, empty frames, nested frames and any unit/default/MSSL directive inside a frame fail. Once any frame has been completed, the preamble cannot reopen. Unknown directives fail.

Directive separators accept SP or TAB. Directive values are either bare values or double-quoted JSON strings. There is no shell interpretation, command expansion, filesystem resolution, networking or execution during parsing.

| Directive | Required keys | Optional keys | Additional checks |
|---|---|---|---|
| `@unit` | `id`, `version`, `fail` | `profile`, `target` | `fail=closed`; optional `profile=russl.core`; optional `target=russ`; version is exactly three nonnegative decimal components with no leading zeros |
| `@defaults` | none, but at least one field is required | `mode`, `regime`, `effect`, `scope` | Accepted supplied values are `deterministic`, `exact`, `read`, `self`, respectively |
| `@mssl` | `alias`, `module`, `source_version`, `digest` | none | SHA-256 digest is `sha256:` plus 64 lowercase hexadecimal digits; source version has two or three nonnegative decimal components |
| `@frame` | `id`, `parent`, `module` | `phase` | Parent is `ROOT` or a previously completed frame ID; frame ID is unique and cannot be `ROOT` |

Omitted optional keys are not inserted into the IR. Unit `version` is program metadata, not the source language version. Module source versions are parsed as metadata; parser acceptance does not verify compatibility between MSSL interpreter versions and module contents.

## 4. Lexical and structured-field contract

Each row has exactly eight nonempty cells separated by U+2502 `│`. Empty cells fail; `_` is the absence sentinel where the relevant field permits absence. Input packing uses U+203A `›` and permits zero, one or two nonempty operands. Empty packed operands, `_` inside a packed pair, repeated separators and more than two operands fail.

Identity-bearing symbols are ASCII segments separated by a dot. Each segment starts with a letter or underscore and continues with letters, digits, underscores or hyphens. The standalone `_` is reserved. These rules apply to unit IDs, frame IDs/parents/modules, MSSL aliases/modules, row IDs, lane annotations, outputs, inputs and control predecessors. Operator names and aliases are matched exactly and case-sensitively against the packaged registry. Lane names are descriptive annotations; the parser does not enforce a lane-to-face typing relation.

ARG and META are either `_` or semicolon-separated `key=value` fields. Keys start with an ASCII letter or underscore and continue with ASCII letters, digits, `_`, `-` or `.`. Duplicate keys fail in every directive and structured cell, even when both values are identical. Empty fields, missing equals signs, empty values, leading/trailing semicolons, mixtures of key-value fields and opaque text, and malformed quoting fail. There is no fallback from an unsuccessful structured parse to an opaque string.

Double-quoted values use JSON string escaping: for example `mapping="a;b=2 \"quoted\""`. A semicolon inside a quoted value is data. JSON escapes decode before further checks; decoded empty strings, controls, format controls, surrogates, U+2502, U+203A and Unicode line separators fail. U+2502 and U+203A cannot be smuggled through escaped text. Bare values cannot contain SP/TAB, apostrophes, double quotes or backslashes. The validator does not interpret text values as executable code or mathematical expressions.

META permits only `eff`, `scope` and `proof`. `proof` is retained as text and is not verified. The only accepted explicit `scope` is `self`; that annotation is not a runtime grant. `eff`, when supplied, must equal the operator catalog's effect exactly. Capabilities have no implicit hierarchy, so neither `commit→read` nor `derive→publish` nor any other substitution is accepted. Unit defaults do not replace operator-inferred effects. Omitting `eff` cannot turn an effectful operator into a read operation.

## 5. Operator parameter acceptance and implementation limits

The full operator catalog is recognized for descriptors, types-as-labels and default effects. Parameter contracts are implemented only as the following closed lexical key sets. Values remain strings. Recognition is not operator execution or complete type checking.

| Canonical operator | Accepted ARG keys |
|---|---|
| `SOURCE_BIND` | `media`, `profile` |
| `FIELD_DEFINE` | `shape`, `sample`, `axes`, `sparse` |
| `FIELD_POPULATE` | `mapping` |
| `FIELD_SLICE`, `FIELD_REGION` | `selector` |
| `PYRAMID_DEFINE` | `levels`, `downsample`, `spatial_axes` |
| `COUPLING_DEFINE` | `neighborhood`, `radius`, `representation` |
| `MSSL_EVAL` | `mode`, `lab_ids`, `coupling` |
| `ADMISSION_EVAL` | `policy`, `authorization` |
| `PROJECT` | `selector`, `output` |
| `EMIT_RECEIPT` | `content_bound`, `expected` |
| `SHARD` | `partition`, `count` |
| `ROOT_BUILD` | `hash` |
| `STATE_COMMIT` | `grant` |
| Every other registered operator | none; ARG must be `_` |

The table derives from the supplied example vocabulary, with `FIELD_REGION` sharing the selector vocabulary. It is deliberately incomplete. In particular, `CONST` is registered but has no implemented nonempty parameter contract. An ARG of `_` is permitted for any registered operator; parser acceptance therefore does not establish required argument presence. Shape rank, dimension positivity, sample type, axis compatibility, selector syntax, mapping semantics, coupling types, neighborhood definitions, module parameter types, effect scopes and full operator arities are outside this module's checks. They remain execution or specialized validation prerequisites. An accepted `authorization=absent` or `grant=external:required` is documentary data, never authorization.

## 6. Binding and dependency rules

Row IDs are unique unit-wide, including across frames. Output handles are immutable names and unique unit-wide. Outputs cannot shadow a declared MSSL alias or an external-input placeholder already consumed; a row cannot consume its own output. Non-control operators require a named output; control operators may use `_`. A named output under `source.*` can be produced only by `SOURCE_BIND`. Frame IDs, row IDs and output handles are distinct namespaces; frame parenthood does not replace row control edges.

Every CTRL predecessor must name a prior row; duplicate predecessors, self references, unknown names and forward references fail. Thus source order is a topological ordering of the checked control graph. The implementation represents each row's transitive ancestry as a bounded bitset, avoiding a recursive graph walk. For every consumed produced handle, the producing row must be a member of the consumer's CTRL ancestry. A merely earlier producer without a control path is insufficient. A referenced `coupling` ARG handle receives the same availability check, but its producer's result type is not validated.

MSSL aliases are unique preamble declarations. `MSSL_EVAL` and `ADMISSION_EVAL` require exactly two inputs: a declared alias followed by a data handle. A second module alias is not a data handle. Module aliases cannot appear in other operators except `VERIFY_MSSL`. The parser validates the digest token's syntax but does not read module files. Byte verification is a separate caller-selected `verify_mssl` operation; neither operation interprets MSSL.

### Reserved external-input convention

To preserve the twelve original examples, an unproduced input named `source.<symbol>` is accepted as a reserved external-input placeholder. This records an unresolved external requirement, not a successful binding. The parser's return object intentionally preserves the original IR shape and does not append `resolved` or `authorized` flags. Any execution environment must independently bind every consumed placeholder to immutable, typed, digest-identified data and fail if it cannot. Unresolved symbols outside this reserved namespace fail during static validation. A `SOURCE_BIND` row declaring a source handle is also a declaration only; its media/profile annotations do not prove the bytes exist or satisfy an adapter contract.

## 7. Canonical JSON and identity contract

`canonical_json_bytes` keeps the RUSSL/1.0 Python serialization profile: sort string keys, use compact separators, retain Unicode as UTF-8, and disallow NaN and infinities. Input must comprise plain dictionaries with string keys, plain lists, valid strings, finite Python floats, bounded Python integers, booleans and null. Cycles, unsupported containers/objects, invalid Unicode, excessive nesting and oversized output fail.

This is not RFC 8785/JCS. Python float spellings and negative zero are preserved; numbers are not normalized into a cross-language canonical mathematical form. Object keys are not NFC-normalized by the JSON helper. Consumers in other languages must reproduce this profile exactly or negotiate a separately versioned identity profile with migration evidence.

`strict_json_loads` accepts UTF-8 bytes or text and rejects duplicate keys at every object depth, including escape-equivalent keys such as `"a"` and `"\u0061"`; invalid syntax; extra trailing content; byte-order marks; invalid Unicode; `NaN`, `Infinity`, `-Infinity`; and exponent overflow such as `1e999`. It scans nesting outside JSON strings before recursive decoding, then validates the decoded object. JSON control characters expressed through valid string escapes are ordinary JSON data; RUSSL field validation imposes its additional control prohibition separately.

The identity equations remain:

```text
source_sha256 = SHA256(ASCII("RUSSL-SOURCE/1.0") || 0x00 || UTF8(canonical_source))
ir_id = "russir:sha256:" || SHA256(ASCII("RUSSIR/1.0") || 0x00 || canonical_json(IR_without_ir_id))
```

The canonical IR still includes frame rows, a flattened program array, source-line ordinals and the original directive records. `domain_hash` requires a nonempty ASCII domain without embedded NUL and a byte payload. SHA-256 equality proves byte equality subject to the hash assumption; it does not authenticate origin, correctness or authority.

## 8. Numeric coordinate helper

`phi(i,n,anchor=0.0)` implements `-1 + 2*i/(n-1)` for `n>1`, and the specified anchor for `n=1`. Indices and extents must be actual Python integers, excluding booleans, with `n≥1` and `0≤i<n`. The binary64 reference profile limits `n≤2^53`. The anchor is always validated, even when `n>1`: it must be an integer or float excluding booleans, must convert to a finite binary64 value, and must lie in `[-1,1]`.

Coordinates are approximate binary64 values. The extent limit prevents integers outside the reference conversion range; it does not guarantee unique floating coordinates at every index or correctly rounded exact rational results. Applications needing exact rational coordinates or stronger numerical guarantees require a separate implementation and explicit conformance evidence.

## 9. Resource policy

| Resource | Default bound |
|---|---:|
| Input and canonical source | 1,048,576 UTF-8 bytes |
| Physical line | 65,536 Unicode characters |
| Row cell | 16,384 Unicode characters |
| Identity symbol | 256 ASCII characters |
| Rows per unit | 10,000 |
| Completed frames per unit | 1,024 |
| MSSL binding declarations | 256 |
| Control predecessors per row / total | 128 / 100,000 |
| Fields per directive or ARG/META cell | 64 |
| JSON input / canonical JSON output | 4,194,304 bytes |
| JSON nesting / traversed value-node budget | 64 / 100,000 |
| Integer magnitude | fewer than 4,097 decimal digits |
| MSSL bytes read by one verification | 67,108,864 bytes |

`ReferenceLimits` is a frozen policy object with positive integer fields; `parse_russl` and `lower_russl` accept it through a keyword-only `limits` parameter. Invalid policy values fail. JSON decode budgets can be adjusted with `max_bytes` and `max_depth`; object validation still applies the module's global JSON size/node safeguards. Custom budgets are caller policy, not encoded language semantics or granted capabilities. Python process memory, host filesystem policy, interpreter isolation, input read limits before this API and wall-clock limits remain the caller's responsibility. MSSL verification reads 65,536-byte chunks, bounds total bytes and reports unavailable bytes without copying private paths into its diagnostic.

## 10. API and diagnostic contract

Existing public functions remain: `canonical_json_bytes`, `canonical_source`, `domain_hash`, `parse_kvs`, `parse_structured`, `parse_russl`, `lower_russl`, `phi` and `verify_mssl`. The required parse/lower return shape and verified-file boolean return are retained. `parse_kvs` and `parse_structured` are lexical helpers; only `parse_russl` applies directive/operator key sets, source budgets and binding checks. Helpers do not constitute a safe untrusted-input processing entry point by themselves.

New interfaces are `strict_json_loads`, `ReferenceLimits`, `DEFAULT_LIMITS` and `RUSSLValidationError`. The exception subclasses `ValueError` and carries `code`, `severity`, `cause_class`, optional `source_line` and optional `row_id`. Where a valid row ID has already been parsed, a subsequent failure records it. Messages describe structural causes without echoing source values or caller file paths. This is a local exception contract; it does not implement the full WP19 causal-chain, redaction audit and multi-error reporting model.

| Diagnostic | Implemented cause family |
|---|---|
| `RUSSL-E-PARSE-001` | header, directive order, unsupported reference annotations, incomplete source, invalid source Unicode/control policy |
| `RUSSL-E-PARSE-002` | columns/cells, structured syntax, unknown/duplicate keys, required fields, symbols and packed operands |
| `RUSSL-E-PARSE-003` | duplicate row/frame IDs or reserved frame identity |
| `RUSSL-E-OP-001` | operator is not registered |
| `RUSSL-E-DEP-001` | missing/forward/duplicate predecessor, frame parent or unavailable producer ancestry |
| `RUSSL-E-BIND-001` | unresolved input/output/coupling or output shadowing |
| `RUSSL-E-MSSL-001` | declaration/digest syntax, alias or invocation role |
| `RUSSL-E-MSSL-002` | unavailable module bytes or byte digest mismatch |
| `RUSSL-E-EFFECT-001` | effect substitution or unsupported scope/default effect |
| `RUSSL-E-STORAGE-001` | lexical storage-name guard |
| `RUSSL-E-CANON-001` | invalid JSON, identity input or noncanonical value domain |
| `RUSSL-E-FIELD-001` | coordinate helper domain, precision or anchor |
| `RUSSL-E-RESOURCE-001` | bounded input, container, record-count or verification-resource policy |

Error selection is first-failure validation order, not an exhaustive error inventory for one source. The exception wording can evolve while the documented cause code remains stable.

## 11. Verification and remaining proof obligations

Run the dependency-free regression suite from the corpus root with `python -m unittest discover -s tests -p test_reference_hardening.py -v`. The suite covers complete original IR identity preservation, original positive/negative vectors, directive ordering, column placement, closed keys, duplicate fields, all registered effect substitutions, all registered aliases, name shadowing, data/control ancestry, module operand roles, external-input boundaries, quoted and escaped payloads, resource boundaries, Unicode controls, strict JSON failures, coordinate failures and streamed MSSL byte verification.

Passing these tests establishes the specific static acceptance behavior above. It does not demonstrate MSSL interpretation, complete type checking, field construction, imaging conversion, runtime scheduling, cryptographic signatures, grant evaluation, nonce replay defense, commit atomicity, rollback correctness, CAS durability, replicated consensus, scientific mechanics correctness or production readiness. Those require independently implemented modules, threat-specific tests, numerical/experimental evidence and institutional decisions. The parser never consumes instructions embedded in source text as instructions to the host agent or operating system.


---

Source: `technical/SERIALIZATION_AND_CONTAINER_PROFILE.md`

# Serialization and RUSS 1.3 Golden Verification Profile

## Identity

Canonical source removes one leading BOM, maps CRLF/CR to LF, normalizes NFC, removes trailing spaces/tabs per line and terminal blank lines, and appends one LF. Retained comments affect the source digest. `source_line` means line changes can affect IR identity. Equal computation need not imply equal source or IR digest.

Corpus JSON uses Python `json.dumps(sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False)` with UTF-8. This preserves supplied corpus compatibility; it does not implement RFC8785/JCS ordering/number rules. Exact decimal extensions need an explicit constrained string representation. Changing serializer requires a new identity profile and fixtures.

For preserved identities, `H(D,x)=SHA256(ASCII(D)||NUL||x)`. Domains are RUSSL-SOURCE/1.0, RUSSIR/1.0 (IR excluding ir_id), RUSS-TUPLE/1.0 (ordered tuple) and RUSS-PAYLOAD/1.0 (sorted path/digest/size entries). Payload/MSSL digests are raw SHA-256. The new corpus manifest uses RUSSL-CORPUS-CONTENT/2.0. Digests are identifiers, not signatures.

## Wire layout

| Structure | Big-endian fields | Bytes |
|---|---|---|
| Header | 8-byte magic RUSS CR LF 1A LF; u16 major=1; u16 minor=3; u32 flags=1; u64 manifest length | 24 |
| Record header | u32 path byte length; u64 payload byte length; 32-byte SHA-256 | 44 |
| Manifest | corpus-canonical UTF-8 JSON | declared length |
| Record body | relative path bytes followed by exact payload bytes | declared sizes |

Only portable embedded payload flag 1 is supported. Other flags/versions reject. The verifier limits containers to 64 MiB, manifests to 1 MiB, records to 1,024 and ASCII paths to 1,024 characters. These are local limits, not universal ABI maxima.

Components appear exactly in identity, language, geometry, state, coupling, mechanics, admission, projection, fabric, evidence, execution order. Each is a name/object pair. Payload descriptors contain path, lowercase 64-hex digest and nonnegative integer size. Records match order, lengths, names and both digest forms. Paths are relative, sorted, case-fold unique, and exclude traversal, drives, backslashes, empty/dot segments, trailing dots and Windows device names. Verification never extracts payloads.

## Binding checks

1. Validate fixed header and every length before slicing. Reject unsupported flags, truncated records and trailing bytes.
2. Strictly load manifest JSON and compare with canonical bytes. Validate each record/digest and recompute payload root.
3. Check tuple order and recompute identity; require fabric root equality.
4. Resolve source/IR references within verified members. Lower source and require exact IR and language ir_id agreement.
5. Bind every IR MSSL module to declared bytes/digest. Reject missing or unbound modules and missing policy/provenance/field references.
6. Check field rank/geometry axes, source FIELD_DEFINE shape/dtype correspondence, policy module role, known identity/geometry profile and structural schemas. Preserve independent authorization and no-arbitrary-code boundaries.
7. Return structural evidence. Evaluate no mechanics and grant no effect permission.

Rebuilding uses the sidecar manifest and fixture payload tree, then verifies the result. Exact active coherent fixture equality is the rebuild oracle. The original inconsistent fixture remains in examples/legacy_golden/ and is rejected. It does not regenerate scientific content. Production profiles require complete tuple-subobject semantics, trust/signatures, capability context and independent security review.


---

Source: `technical/VERIFICATION_GUIDE.md`

# Verification, Coverage and Evidence Guide

## Scope

The offline verifier checks candidate package consistency, the documented structural reference profile, source-to-IR compatibility, bounded container binding, and adversarial regressions. It reports `full_conformance=false`. None of the 293 requirements is labeled fully verified. SCOPED_EVIDENCE identifies applicable check families; NOT_RUN identifies obligations without an executed requirement-specific test or accountable review.

A check's PASS means its declared observations matched its oracle for packaged inputs. It does not generalize to every implementation/input, runtime semantics, signatures, real data, platforms or empirical validity. The complete requirement text remains the review target. Tests sharing an implementation/oracle are useful regressions but weaker evidence than independent implementation comparison.

| Check | Observable | Limit |
|---|---|---|
| V01 | strict current JSON/JSONL parsing | historical content separately audited |
| V02 | exact specification-to-registry ID mapping | text consistency is not behavior correctness |
| V03 | 12 sources equal golden IR; 5 original bad sources rejected | external source placeholders remain unbound |
| V04 | schema keywords supported; selected samples validate | closed subset, not full Draft 2020-12 |
| V05 | four MSSL digests and image digest agree | no module evaluation or scientific validation |
| V06 | coordinate results match vectors | not physical calibration |
| V07 | canonical source/vector digests agree | corpus JSON differs from RFC8785 |
| V08 | bounded container, cross-bindings and exact rebuild | no tuple execution |
| V09 | adversarial/compatibility unittest suite | regression sampling, not formal proof |
| V10 | catalog and aliases agree with tooling | registered operators are not implemented runtime semantics |
| V11 | 28 review-pending records bind current specs | no independent review/ratification |
| V12 | local Markdown links resolve | remote sources can change |
| V13 | active tree excludes symlinks/caches/old destructive builder | not production penetration testing |
| V14 | 19 new source digests/review coverage and exact shape/index fixtures | no empirical research result implied |

## Evidence lifecycle

From the corpus, run `python -B tooling/verify_corpus.py` and `python -B tooling/verify_corpus.py --integrity`. Exit zero accompanies scoped PASS. Explicit conditions rather than Python assertions enforce release gates. `--write-report` changes evidence and can break a seal. The builder regenerates candidate records, coverage, reading edition, report, manifest, receipt, checksums, integrity report and sorted ZIP; a failing verification stops sealing. No network installation is needed.

The manifest excludes itself, build receipt, checksums and detached integrity report. Everything else, including the scoped report, is content-bound. SHA256SUMS additionally covers the manifest/build receipt, excluding only itself and detached integrity. The detached report is unsigned. Hashes protect byte integrity under SHA-256 assumptions; authenticity needs a separately governed signature profile.

## Schema-engine contract

`schema_subset.py` supports type, enum/const, required/properties/additionalProperties, local `$defs` references, prefixItems/items/cardinality/uniqueness, length/pattern/bounds and allOf/anyOf/oneOf/not. Unsupported schema keywords and remote references fail. Annotation keywords are allowlisted. This is not a JSON Schema meta-schema validator or an implementation of formats, dynamic references, unevaluated properties, dependent schemas, patternProperties or vocabulary negotiation. Additions require tests and a compatibility decision.

Strict JSON loading rejects duplicate object keys and nonfinite/overflow literals. Structural schemas reject numeric digests, short/reordered axes, invalid shapes, unknown known-object fields, duplicate effects and invalid enumerations. Date validity, grant internals, cryptographic signatures and runtime context still require semantic/trust validation. Opaque provenance or operator parameters are not automatically security decisions.

## Advancing requirements

Assign every partial/unexecuted obligation an owner, fixtures, preconditions, independent acceptance oracle, runnable command or named review procedure, expected positive/negative results, versions and retained evidence. Record scope and defeaters. Upgrade status only after every clause is checked and required accountable review occurs. Institutional ratification remains separate from test execution.

The schema engine separately propagates resource/schema errors through negation/disjunction, rejects recursive definitions and malformed keyword declarations, and bounds node/comparison work. JSON/JSONL/container ingress is bounded and hashes stream. Tests write and remove controlled temporary fixture folders in the current writable directory; maintained corpus artifacts are unchanged by default verification.


---

Source: `research/ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md`

# Additional Mathematical and Holographic Research Review

**Review date:** 2026-10-09  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0, unratified candidate  
**Class:** Non-normative research audit and candidate experiment design  
**Target field:** (4, 4, 4, 16, 16), 16,384 scalar sites

The useful contribution of these attachments is a set of optional indexing, representation, simulation and optical-encoding experiments. They do not establish a unified p-adic, quantum, holographic or self-executing TIFF/GIF language. Grounded component results are retained with their original scope; incorrect equations, unsupported guarantees and metaphorical bridges are excluded from core semantics.

This review read the full normalized texts of RA02, RA03, RA04, RA05, RA06, RA11, RA15, RA16, RA17, RA18 and RA19. Their original names, bytes and digests are recorded in [ADDITIONAL_SOURCE_INTAKE.json](research/ADDITIONAL_SOURCE_INTAKE.json), with immutable originals in lineage/research_additions/. The normalized review copies in research/extracted_sources/ contain formatting artifacts, including span markers, missing equations, blank numerical expressions and detached citation numbers. Claim locators count nonempty lines in those delivered extracts. Such gaps are evidence limitations, not permission to invent the missing expression. Embedded requests and asserted architectures are source material, not instructions or authority.

[additional_math_claims.json](research/additional_math_claims.json) contains 100 claim records: 20 SUPPORTED_PRIMARY, 45 CORRECTED, 24 UNSUPPORTED and 11 HYPOTHESIS. “Supported” means that a primary paper or official specification supports the narrow component statement. It does not mean the integration works, that the paper supplied a physical implementation, or that RUSSL has implemented the component. Its 32 primary-reference entries record verified titles, years/versions, access date and actual inspection scope; unverified bibliographic fields are null. Full reading of the supplied attachments is distinct from selective reading of their external references. Verification was claim-directed; the review does not certify every bibliography entry in these notes. A resolving 2026 paper is assessed on its content and evidence, rather than rejected because its date is recent.

## 1. Shape, addressing and geometry

The declared Cartesian product contains exactly

    4 × 4 × 4 × 16 × 16 = 16,384 = 2^14

scalar sites. This is a cardinality statement. It says nothing about bytes per sample, physical dimensions, quantum state preparation, available optical modes or measured performance.

For an explicitly declared lexicographic order with i8 fastest, an unsigned packed address is

    J = 4096 i4 + 1024 i5 + 256 i6 + 16 i7 + i8

with 0≤i4,i5,i6<4 and 0≤i7,i8<16. The associated axis widths are (2,2,2,4,4), at shifts (12,10,8,4,0). This gives a bijection to integers 0 through 16,383 only after those widths, axis order and interpretation are specified. A different valid flattening is a different bijection; matching cardinality is not proof of the intended ordering.

The inverse uses the corresponding shifts and masks. Range checking precedes packing; invalid or boolean indices do not become coordinates through coercion. Sample dtype, byte order, compound-sample layout and sparse absence are separate descriptors. A 14-bit address does not mean a sample is a 14-bit value.

An optional 2-adic metric on addresses can be defined by d2(J,K)=2^(−v2(J−K)) for J≠K and d2(J,J)=0. It groups matching **least-significant** digits. In the packing above, lower bits of i8 dominate the earliest hierarchy levels. This is not the ordinary coarse-to-fine spatial meaning of an image pyramid. For example, J=0 and J=4096 are very close in that metric, while J=0 and J=1 are maximally separated in the unit ball; the corresponding normalized Euclidean displacements have the opposite intuition. A desired tree prefix order therefore needs an explicit digit-path layout or bit reversal.

A finite bit-reversal display coordinate can be written as

    rho14(J) = sum(k=0..13) ak 2^(−k−1)
             = bit_reverse14(J) / 16,384

where J=sum ak 2^k. This is a finite bijection onto a specified half-open grid. It is not WP04’s endpoint-inclusive coordinate normalization. The infinite Monna map has expansion ambiguities: the 2-adic integers 1 and −2 both map to 1/2 under digit reversal. It cannot be asserted to be a topological isomorphism between a totally disconnected p-adic field and a connected real interval. The recent primary diffusion paper presents a defined transport/visualization construction, not a requirement that every serializer use this map. [Bradley et al., p-Adic Diffusion and Random Walks on [0,1]](https://arxiv.org/abs/2608.02103).

P5 coordinates, the Euclidean or chosen field neighborhood, and any S³ orientation semantics remain governed by the existing core. A p-adic address tree is an optional algorithmic profile. Neither 16,384 sites nor five axes proves an infinite p-adic field, a Bruhat-Tits bulk, an optical device, or fourteen physical qubits. An explicitly normalized complex vector could be used in a separate 14-qubit state-vector simulation; an arbitrary scalar field is not such a state by default.

## 2. Mathematical corrections that apply across sources

Prime p is part of the definition of Qp. Composite-base digit trees can still be useful hierarchical encodings, but “Q8”, “Q9” or “Q10” cannot inherit the prime-adic field and absolute-value theorems without a different, carefully defined construction. For example v10(2)=v10(5)=0 but v10(10)=1, so the resulting composite divisibility expression is not a multiplicative absolute value. Z/p^r Z is a finite residue ring, with zero divisors for r>1; it is not the finite field GF(p^r).

Additive inverses exist in Qp. The rational −1 is represented by an infinite string of digits p−1, rather than ceasing to be −1. Finite Hensel/residue computation has finite precision, division restrictions and possible precision loss. Rational reconstruction requires a modulus large enough for declared numerator/denominator bounds. The direct counterexamples above and the finite-precision boundaries are consistent with [Caruso’s primary treatment of p-adic computation](https://arxiv.org/pdf/1701.06794).

A metric bound is not sparsity, authenticity or fault tolerance. Nonzero powers p^k have norms tending to zero. Thus there is no minimum p-adic valuation floor preventing coordinates from tending to zero or making zero invertible. A small norm does not count nonzero coefficients. The specific ranked-tree coding method in [Murtagh’s sparse-coding paper](https://arxiv.org/abs/1604.06961) has its own address precision, preprocessing and query model; its reported complexity cannot be generalized to arbitrary optical synthesis, output enumeration or disk access.

Continuous does not imply locally constant. The identity Qp→Qp is continuous and differentiable; the real-valued norm is continuous but not locally constant at zero. Locally constant test functions and specific CFT assumptions are narrower objects. A rooted p-ary digit tree is also distinct from the (p+1)-regular Bruhat-Tits tree used in particular holographic models.

Spectral diagonalization is useful, but operator conventions matter. Under the usual gamma convention, Γp(−α)<0 for α>0. RA03’s difference sign in its hypersingular integral is inconsistent with a positive multiplier |ξ|p^α. A simulation profile must independently confirm the sign, normalization, boundary restriction, spectrum and real-time decay. Finite wavelet truncation adds approximation error even when the infinite operator has a complete eigenbasis. [Kozyrev’s wavelet construction](https://arxiv.org/abs/math-ph/0012019).

## 3. Source-by-source verdicts

### RA02 — p-adic Architecture in Image Formats.txt

Retain prime-adic valuation and digit hierarchy as mathematical background; retain the published grayscale p-adic CNN models and wavelet operator results as scoped experimental leads. The CNN literature describes real-valued functions on a p-adic domain and numerical filtering/edge examples. It supplies no standard image decoder executing a mathematical model from tags. [Zambrano-Luna and Zúñiga-Galindo](https://arxiv.org/abs/2210.14132).

Correct its negative-number assertion, finite-ring terminology, unqualified rational exactness, composite-base conflation and universal complexity claims. TIFF directories and tiles do not automatically enforce a ranked regular hierarchy. Any such correspondence requires a mapping with explicit branching, depth, order and domain.

Exclude absolute security/provenance, universal short-seed compression, perfect edge preservation, optimal dithering through representation theory and unreported TIIF-Bench gains. The FCSR primary work analyzes sequence generation, synthesis and cryptanalytic attacks; it does not make a seed an authenticity proof. [Klapper and Goresky](https://www.math.ias.edu/~goresky/pdf/2adic.jour.pdf). A benchmark’s existence does not establish a run of a hypothetical architecture. [TIIF-Bench](https://arxiv.org/abs/2506.02161). Proposed private tag numbers remain source proposals, with no reservation or implementation asserted.

### RA03 — P-adic Hologram Processing Architecture.txt

Retain 1-bit LAMB as distributed-training context with precise result labels. In v2 §6, 4.6× is calculated communication-volume reduction and 2.8× is a warmup-adjusted estimate from stage throughput. Table 4 measures total pre-training at 731→351 minutes (2.1×). Communicated signs/scales coexist with higher-precision state. These BERT results supply no hologram speedup. [Li et al., 1-bit LAMB v2](https://arxiv.org/abs/2104.06069v2).

Treat the combined p-adic addressing, LUT/WRP synthesis, binary optimization and TIFF output pipeline as a candidate. Lookup tables may save expensive arithmetic but still need storage, fetches, accumulation and output. Summing N dense P-sample fields remains O(NP) sample work; restricted support K gives O(NK) plus propagation/readout. Merely producing P samples costs at least Ω(P). The point-source exp(ikr)/r expression needs its scalar approximation, amplitudes, units and normalization declared.

Correct the hypersingular operator sign. Reject claims that different 1-bit quantizers form one error-compensated stack or that tilewise optimization is physically independent: diffraction can couple tiles. Optimality, speckle elimination, cache-hit gains and end-to-end rate need independent measurements and ablations.

### RA04 — p-Adic Architecture Unification.txt

Retain Bruhat-Tits and p-adic CFT/tensor-network background. There is a genuine mathematical result reproducing correlation functions of an axiomatized p-adic CFT by tree tensors. [Hung, Li and Melby-Thompson](https://arxiv.org/html/1902.01411v2). This is a model result, not a physical demonstration of the universe or an image-container executor.

Reject the “valuation floor”, universal local constancy, vacuum-lock conservation, Riemann-zeros thermostat, grey-hole mechanism and universal strategic equilibrium conclusions. Hasse-Minkowski-type local-global statements are not universal transfers of arbitrary propositions. Ordered non-Archimedean payoff fields and Qp are different structures; a group-action fixed-point theorem does not prove Nash convergence.

Berkovich compactness and connectedness depend on the specified analytic space; an affine space is not universally compact. Adding analytic points is not a proof of real spacetime emergence. Quantum error correction requires an encoding, noise channel and recovery conditions; a metric alone is not a code.

### RA05 — P-adic Holographic Simulations Research.txt

Retain explicit finite-precision arithmetic and finite-tree simulation as feasible mathematical workloads. Keep p-adic CFT correlation networks separate from an optical hardware analogy. [Heydeman et al.](https://arxiv.org/abs/1605.07639) discusses a particular arithmetic holographic framework; it does not establish the proposed D2NN mapping.

The proposed photonic or magnonic simulator needs an actual encoding and transfer map matching its target tensors. Parallel propagation does not eliminate finite aperture, mode count, precision, training, nonlinear operations or readout costs. Three-dimensional diffraction through a stack is not automatically a p-adic bulk graph contraction.

Exclude biological/quantum-gravity unification and the “adelic handshake” storage interpretation. The numerical Landauer discussion also contains errors: kBT ln2≈17.9 meV at 300 K, while 26 meV approximates kBT; a 1500 nm photon has energy about 0.827 eV, not above 1 eV. These are dimensional calculations, not experimental results. An erasure-energy bound neither guarantees memory fidelity nor validates brain coherence or capacity.

### RA06 — P-adic Penteract Simulation Research.txt

Retain separate model proposals for finite p-adic reaction-diffusion and incidence-based higher-order synchronization. Published examples of Turing patterns and adaptive explosive synchronization exist within their defined models. [Chacón-Cortés et al.](https://arxiv.org/abs/2308.04364), [Millán et al.](https://arxiv.org/abs/1912.04405). A combined model requires explicit coupling equations and a new validation protocol.

Correct “nonzero a0 for every nonzero p-adic integer”, the mandatory/bijective Monna claim, and the inference that a one-dimensional tree inherently becomes three Cartesian spatial axes. Numerical nodes and differently sized simplex sets may need masks or non-raster representations.

OME-Zarr can serialize a chosen array mapping, but the axis meanings and coordinate transforms remain declared data-model choices. Reviewed RFC-5 is an implementation-stage RFC (S3), separate from a pinned released NGFF version. Compatible clients do not thereby execute arbitrary digit reversal or a custom nonlinear transform; scale/translation cannot express a generic permutation. [RFC-5](https://ngff.openmicroscopy.org/rfc/5/), [NGFF 0.5](https://ngff.openmicroscopy.org/0.5/). Chunking/sharding does not guarantee every form of adjacency, constant latency, uninterrupted integration or numerical accuracy.

### RA11 — OAM Spatial Shifting Arithmetic.txt

The cited 2026 paper is real and reports numerical simulations of fixed-base digit shifting in an OAM-encoded diffractive design. Left shifts implement powers of the radix; right shifts produce integer quotients and discard remainders unless separately represented. Its switching example rotates the **final** phase layer by 90° clockwise; it does not establish that any rotated intermediate mask is an inverse. [Tan et al., DOI 10.1364/OE.581948](https://doi.org/10.1364/OE.581948).

Retain this as a reference shift/encoding candidate. Add finite-width zero-fill, overflow and quotient/remainder semantics. A cyclic field-axis permutation is a different operator. Numerical mode purity is not exact bit-error probability, a fabricated chip, Turing completeness or cryptographic proof. Ideal infinite OAM labels do not imply unlimited useful modes in a finite device.

Multiple source equations are missing. The audit does not restore them from detached citation numbers. Passive fixed-mask field propagation is linear; arbitrary nonlinear logic needs a defined encoding, detection or nonlinear mechanism and reliable composition.

### RA15 — TIFF GIF Spatial-Temporal Encoding.txt

Retain the practical distinctions among palette animation, typed image planes, larger-offset containers and chunked multidimensional arrays. Correct its GCE bit positions and scope: with zero-based numbering, disposal uses bits 2–4; the block is optional and applies to the next graphic-rendering block. Delay units are hundredths of a second. NETSCAPE looping is an application convention. [GIF89a specification](https://www.w3.org/Graphics/GIF/spec-gif89a.txt).

Classic TIFF and BigTIFF are finite, different layouts; expanded offsets do not imply unbounded practical capacity. [BigTIFF design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html). OME-TIFF explicitly maps X/Y/Z/C/T through metadata; surviving metadata cannot recover lost pixels. [OME-TIFF specification](https://docs.openmicroscopy.org/ome-model/6.3.1/ome-tiff/specification.html).

COG layout and requests should follow a pinned conformance class. Fixed 16 KB requests and particular square tile sizes are tuning choices, not universal requirements. [OGC COG standard](https://docs.ogc.org/is/21-026/21-026.html). Reject the inference that file-format capability proves physical model validity or instantaneous scientific feedback.

### RA16 — Microscopic Quantum Paradigm GIF Research.txt

Retain Gaussian Interaction Frame as a separate quantum-optics modeling concept. It factors Gaussian evolution from a residual state; with the full state retained the frame change can be exact, while mode/Fock truncation is approximate. The primary work presents numerical studies and experimental prospects. This acronym has no semantic connection to GIF89a. [Yanagimoto et al.](https://arxiv.org/html/2111.13799v1).

Gaussian-state, quadratic-Hamiltonian and suitable quadrature-measurement processes have a scoped classical simulation theorem. [Bartlett et al.](https://arxiv.org/abs/quant-ph/0109047). The theorem does not classify every optical device or every measurement.

Wigner negativity is sufficient evidence of non-Gaussianity, but not necessary for arbitrary mixed states: a mixture of distinct coherent states can be non-Gaussian and everywhere Wigner-positive. Keep truncation convergence, loss models and conservation checks explicit. Deterministic GKP production, universal robustness and fault-tolerant operation do not follow from a frame parameterization. Missing Hamiltonians remain transcription gaps. An ordinary 16,384-site field is neither a quantum state nor a quantum hardware claim.

### RA17 — Holographic Logical Reasoning Research.txt

Retain classical HRR/VSA as candidate representation methods and distinguish circular-convolution HRR from binary XOR binding. Plate’s primary method uses noisy retrieval and cleanup; it does not promise exact recovery of arbitrary constituent data. [Plate](https://pages.ucsd.edu/~msereno/170/readings/06-Holographic.pdf). The cellular-automaton image reasoning reference supports a digital framework and limited tasks, without an all-optical TIFF implementation. [Yilmaz](https://ceur-ws.org/Vol-1583/CoCoNIPS_2015_paper_3.pdf).

Correct the claimed fabricated PdS full adder. The cited paper proposes a diffractive model and reports 100% **simulated** accuracy across 512 inputs; its modeled tanh activation is motivated by quantum-dot reverse saturable absorption. It does not supply fabrication/measurement evidence for the asserted stack. [Deng et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC12195495/).

Fourier optics supplies transforms; arbitrary two-input binding still needs spectral multiplication, encoding, boundary conventions and readout. A fixed mask implements a fixed linear filter. Neither acronym sharing, simulated truth tables, phase-bit thresholds nor isolated mode purity establishes general cognitive correctness or zero-latency recurrent operation.

### RA18 — Holographic Computation via Image Formats.txt

Retain explicit complex-field, phase-mask and calibrated display distinctions. The normalized double-phase identity is elementary:

    A exp(iφ) = [exp(i(φ+acos A)) + exp(i(φ−acos A))] / 2,  0≤A≤1.

Its optical encoding adds spatial, filtering and efficiency constraints. [Hsueh and Sawchuk](https://opg.optica.org/ao/abstract.cfm?uri=ao-17-24-3874). A continuum angular-spectrum solution is distinct from a finite FFT calculation; sampling and transfer-function aliasing require checks. [Matsushima and Shimobaba](https://opg.optica.org/oe/abstract.cfm?uri=oe-17-22-19662).

Correct “infinite float32 precision”, the blanket lossless-TIFF claim, and phase semantics inferred from an eight-bit palette. TIFF’s sample interpretation is distinct from its directory-field type. [TIFF 6.0](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf). A calibrated LUT has a wavelength, device state and error tolerance; palette indices alone do not define phase.

The source’s tangent/exponential and numerical-aperture-125 statements are ungrounded as written. Do not silently replace a missing decimal with a guessed physical result. GS is an optimization method without universal global-optimum guarantees. Multilayer linear propagation can realize useful constrained transfers, but does not itself implement arbitrary nonlinear computation.

Exclude absolute DRPE invulnerability. Known-plaintext attacks have been published. [Peng et al.](https://opg.optica.org/ol/abstract.cfm?uri=ol-31-8-1044). Several bibliography numbers and topics do not align with the adjacent claims; re-verify a claim directly instead of treating citation markers as authentication.

### RA19 — Holographic Image-Based Computation.txt

Retain a candidate architecture separating field representation, streaming, calibration and optical response. “Physical” weights remain mathematical transfer functions. HRR is not an exact, lossless replacement for arbitrary weights; 5D quartz recording variables are not automatically the five logical axes.

Correct GIF subblocks-as-independent-chunks: LZW state and codewords cross boundaries. A subblock terminator is distinct from End-of-Information. TIFF byte order does not remove parsing, calibration, alignment or codec costs; OME-TIFF does not natively define arbitrary eight-axis HRR semantics.

MHz carrier, DAC sample rate, AOD access time, pattern update and full-field frame rate are different quantities. Acoustic aperture/transit and resolvable-spot constraints remain relevant. [AA Opto-Electronic catalog](https://aaoptoelectronic.com/wp-content/uploads/2024/04/Plaquette-AA-OPTO-2022-1.pdf). The cited AOD work studies calibrated multitone waveform synthesis and tweezer arrays, including crosstalk/intermodulation, rather than a GIF reasoning processor. [Model-Based Real-Time Synthesis](https://arxiv.org/html/2512.16774v1).

For an assumed complete 16,384-site refresh at 1 MHz, uncompressed demand is 16.384 GB/s at 8 bits/site, 65.536 GB/s at 32 bits/site and 131.072 GB/s at 64 bits/site (e.g. a complex pair of float32 values). These are one-way payload lower bounds before framing, replicas or overhead. A single 16×16 plane refresh has a different budget; the term “frame” must be specified. PCIe 5.0 x16 at 32 GT/s and 128/130 encoding yields about 63.015 GB/s per direction before protocol overhead. Summing both directions cannot feed one-way DMA. [PCI-SIG primary specification update](https://pcisig.com/sites/default/files/files/PCI-SIG%202020%20Annual%20Press%20Conference_final.pdf). No MHz corpus result is claimed.

## 4. Candidate profiles and experiments

The JSON register defines six proposed research profiles; every associated scientific experiment is **NOT_RUN**. The parent audit implemented finite ordinal/inverse and optional 2-adic metric helpers, with an exhaustive address fixture, as components of CANDIDATE-PADIC-INDEX-14. The broader hierarchy, diffusion and query-performance profile remains **PROPOSED**. The other five profiles remain **PROPOSED_NOT_IMPLEMENTED**. Engineering address validation does not establish scientific performance or dynamics results.

| Candidate | What is concretely defined | Required comparator / failure boundary |
|---|---|---|
| CANDIDATE-PADIC-INDEX-14 | Declared packed order, inverse, finite metric and display digit order | Compare identical queries against lexicographic/Morton orders; any changed sample/index fails; measure I/O and output cost |
| CANDIDATE-HRR-16384 | Classical vector flattening, convolution, bundling, inverse/cleanup conventions | Held-out retrieval against a matched baseline across load and seeds; false matches or loss of role/order information fail |
| CANDIDATE-OAM-SHIFT | Finite radix digit shift, overflow and quotient/remainder semantics | Exact integer reference first; optional optical decoding then has separate noise, loss and bit-error bounds |
| CANDIDATE-HOLOGRAM-FIELD | Typed complex/phase encoding, units, plane/slice mapping, propagation and LUT contract | Grid/padding/band-limit and quantization convergence; missing units or palette changes fail |
| CANDIDATE-TREE-DYNAMICS | Independently transcribed model, finite domain, weights/operators and real-time solver | Spectral sign, incidence consistency and cutoff/time-step refinement; unstated coupling or empirical implications fail |
| CANDIDATE-QUANTUM-GIF | Hamiltonian/frame/residual/cutoff definitions separated from raster formats | Compare with direct small-system evolution; norm/conservation or truncation failure blocks result claims |

For each experiment, record source digests, exact inputs, model/encoding version, parameters, seeds, resource limits, preregistered tolerances, comparator, environment and complete outputs. Exploratory parameters and confirmatory endpoints remain separate. Null results and failures are retained.

No optical device, quantum model, proposed codec, p-adic solver or semantic benchmark was executed during this mathematical audit. Mathematical counterexamples, finite-address derivations and bandwidth calculations are reviewer analyses. Parent-audit address helpers and their fixture supply bounded engineering validation. They add no E3/E4/E5 scientific validation to P5×S³/8S mechanics and grant no execution capability, security admission, institutional authority or cryptographic provenance.

## 5. Integration decision

The corpus may reference these audited component facts and candidate protocols as research documentation. It must retain the distinction between scalar values, index geometry, storage adapters, executable language semantics and physical devices. Original attachment claims remain traceable even when rejected.

The accepted design direction is explicit: keep the existing five-axis logical field independent of its backend; declare any p-adic metric, HRR transform, optical encoding or quantum-state model in a separate versioned profile; preserve original samples and state every lossy transform; report only results actually produced with their reproducibility record. The attachments establish research questions and bounded component evidence, not an already validated unified architecture.


---

Source: `research/ADDITIONAL_PRIMARY_REFERENCE_INDEX.md`

# Additional Primary Reference Index

Assessment date: 2026-10-09. This index joins 62 review-reference records by URL into 61 external reference locations. A reference can have different inspection scopes in the two reviews. It is not a list of 62 replicated experiments or fully inspected papers. The detailed registers preserve access limitations, authors, dates/versions where established, explicit unknowns and the precise claim decisions.

| Primary title and direct location | Version recorded | Inspection scopes | Review reference IDs |
|---|---|---|---|
| [1-bit LAMB: Communication Efficient Large-Scale Large-Batch Training with LAMB's Convergence Speed](https://arxiv.org/abs/2104.06069v2) | arXiv:2104.06069v2 (2021-10-06) | partial; complete_23_page_uploaded_text_and_selected_rendered_pages | LAMB in additional_math_claims.json; P-1BLAMB in additional_systems_claims.json |
| [3D-SHOT temporally focused holographic optogenetics](https://pmc.ncbi.nlm.nih.gov/articles/PMC5663714/) | not established | primary_paper_selected_methods_results | P-3DSHOT in additional_systems_claims.json |
| [A p-adic version of AdS/CFT](https://arxiv.org/abs/1705.00373) | arXiv:1705.00373v1 | abstract | ADS in additional_math_claims.json |
| [Acousto-Optic devices, RF drivers, Custom solutions — Catalog 2022](https://aaoptoelectronic.com/wp-content/uploads/2024/04/Plaquette-AA-OPTO-2022-1.pdf) | Catalog 2022 | partial | AO_CAT in additional_math_claims.json |
| [Analogy Making and Logical Inference on Images using Cellular Automata based Hyperdimensional Computing](https://ceur-ws.org/Vol-1583/CoCoNIPS_2015_paper_3.pdf) | not established | partial | CA in additional_math_claims.json |
| [AWQ: Activation-aware Weight Quantization for LLM Compression and Acceleration](https://arxiv.org/abs/2306.00978) | not established | primary_paper_identity_method_scope | P-AWQ in additional_systems_claims.json |
| [Band-Limited Angular Spectrum Method for Numerical Simulation of Free-Space Propagation in Far and Near Fields](https://opg.optica.org/oe/abstract.cfm?uri=oe-17-22-19662) | not established | partial | ASM in additional_math_claims.json |
| [BigTIFF Design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html) | BigTIFF format version 43; LibTIFF 4.7.2 documentation as displayed | official spec | BIGTIFF in additional_math_claims.json |
| [BitNet b1.58 2B4T Technical Report](https://arxiv.org/abs/2504.12285) | not established | primary_paper_identity_abstract | P-BITNET-2B in additional_systems_claims.json |
| [Comparative VSA experiments](https://arxiv.org/abs/2001.11797) | not established | primary_paper_selected_scope | P-VSA in additional_systems_claims.json |
| [Computations with p-adic numbers](https://arxiv.org/pdf/1701.06794) | arXiv:1701.06794v1 | partial | PADIC in additional_math_claims.json |
| [Computations with p-adic numbers](https://arxiv.org/abs/1701.06794) | not established | primary_paper_identity_and_precision_scope | P-CARUSO in additional_systems_claims.json |
| [Computer-generated double-phase holograms](https://opg.optica.org/ao/abstract.cfm?uri=ao-17-24-3874) | not established | abstract | DPM in additional_math_claims.json |
| [Continuous Optimization for p-Adic Models](https://arxiv.org/abs/2609.25501) | not established | primary_preprint_identity_abstract | P-PADIC-OPT in additional_systems_claims.json |
| [Deep-brain thermogenetic manipulation using photothermal nanotransducers](https://pmc.ncbi.nlm.nih.gov/articles/PMC9232843/) | not established | primary_paper_selected_methods_results | P-MINDS in additional_systems_claims.json |
| [DeepSpeed official 1-bit LAMB tutorial source](https://raw.githubusercontent.com/deepspeedai/DeepSpeed/master/docs/_tutorials/onebit-lamb.md) | not established | official_document_selected_sections | P-DEEPSPEED in additional_systems_claims.json |
| [Efficient Classical Simulation of Continuous Variable Quantum Information Processes](https://arxiv.org/abs/quant-ph/0109047) | arXiv:quant-ph/0109047v2 (2002-02-18) | abstract | GAUSS in additional_math_claims.json |
| [Explosive higher-order Kuramoto dynamics on simplicial complexes](https://arxiv.org/abs/1912.04405) | arXiv:1912.04405v3 (2020-05-18) | abstract | KURAMOTO in additional_math_claims.json |
| [Feedback Shift Registers, 2-Adic Span, and Combiners with Memory](https://www.math.ias.edu/~goresky/pdf/2adic.jour.pdf) | not established | partial | FCSR in additional_math_claims.json |
| [GEO GSE312903: Connectome-seq](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE312903) | not established | primary_author_dataset_record | P-CONNECTOME-DATA in additional_systems_claims.json |
| [GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers](https://arxiv.org/abs/2210.17323) | not established | primary_paper_identity_method_scope | P-GPTQ in additional_systems_claims.json |
| [Graphics Interchange Format Version 89a](https://www.w3.org/Graphics/GIF/spec-gif89a.txt) | 89a | official spec | GIF89A in additional_math_claims.json |
| [Holographic Reduced Representations](https://pages.ucsd.edu/~msereno/170/readings/06-Holographic.pdf) | not established | full text | HRR in additional_math_claims.json |
| [Intel VTune Hybrid CPU Analysis](https://www.intel.com/content/www/us/en/docs/vtune-profiler/user-guide/2026-0/hybrid-cpu-analysis.html) | not established | official_document_selected_sections | P-VTUNE in additional_systems_claims.json |
| [Known-plaintext attack on optical encryption based on double random phase keys](https://opg.optica.org/ol/abstract.cfm?uri=ol-31-8-1044) | not established | abstract | DRPE in additional_math_claims.json |
| [Lenovo IdeaPad Pro 5 16IMH9 PSREF](https://psref.lenovo.com/syspool/Sys/PDF/IdeaPad/IdeaPad_Pro_5_16IMH9/IdeaPad_Pro_5_16IMH9_Spec.pdf) | not established | official_specification_selected_pages | P-LENOVO-PRO in additional_systems_claims.json |
| [Lenovo IdeaPad Slim 5 16IRH10 PSREF](https://psref.lenovo.com/syspool/Sys/PDF/IdeaPad/IdeaPad_Slim_5_16IRH10/IdeaPad_Slim_5_16IRH10_Spec.pdf) | not established | official_specification_selected_pages | P-LENOVO-SLIM in additional_systems_claims.json |
| [Linux kernel Dynamic DMA mapping Guide](https://docs.kernel.org/core-api/dma-api-howto.html) | not established | official_document_selected_sections | P-DMA in additional_systems_claims.json |
| [Linux perf security documentation](https://docs.kernel.org/admin-guide/perf-security.html) | not established | official_document_selected_sections | P-PERF in additional_systems_claims.json |
| [Microsoft AVML README](https://raw.githubusercontent.com/microsoft/avml/main/README.md) | not established | official_source_selected_sections | P-AVML in additional_systems_claims.json |
| [MINFLUX nanoscopy at nanometer-scale resolution](https://www.nature.com/articles/s41592-019-0688-0) | not established | primary_paper_selected_results_figures | P-MINFLUX in additional_systems_claims.json |
| [Model-Based Real-Time Synthesis of Acousto-Optically Generated Laser-Beam Patterns and Tweezer Arrays](https://arxiv.org/html/2512.16774v1) | arXiv:2512.16774v1 (2025-12-18) | partial | AOD in additional_math_claims.json |
| [Nanos GPU accelerated computing tutorial](https://nanovms.com/dev/tutorials/gpu-accelerated-computing-nanos-unikernels) | not established | official_document_selected_sections | P-NANOS in additional_systems_claims.json |
| [Neuromorphic Visual Scene Understanding with Resonator Networks](https://arxiv.org/html/2208.12880v4) | arXiv:2208.12880v4 | primary_paper_selected_methods_results | P-RESONATOR in additional_systems_claims.json |
| [NVIDIA GPUDirect RDMA documentation](https://docs.nvidia.com/cuda/gpudirect-rdma/index.html) | not established | official_document_identity_selected_sections | P-CUDA-RDMA in additional_systems_claims.json |
| [OCP Microscaling Formats (MX) Specification v1.0](https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf) | v1.0 | primary_specification_selected_table | P-MX in additional_systems_claims.json |
| [OGC Cloud Optimized GeoTIFF Standard](https://docs.ogc.org/is/21-026/21-026.html) | 1.0; OGC document 21-026 | official spec | COG in additional_math_claims.json |
| [OME-TIFF specification](https://docs.openmicroscopy.org/ome-model/6.3.1/ome-tiff/specification.html) | OME Data Model and File Formats 6.3.1 documentation | official spec | OME in additional_math_claims.json |
| [OME-Zarr specification](https://ngff.openmicroscopy.org/0.5/) | Released metadata version 0.5; page history includes clarification revision 0.5.2 (2025-01-10) | official spec | NGFF in additional_math_claims.json |
| [Onset of non-Gaussian quantum physics in pulsed squeezing with mesoscopic fields](https://arxiv.org/html/2111.13799v1) | arXiv:2111.13799v1 | full text | QGIF in additional_math_claims.json |
| [Optical diffractive neural network-based orbital angular momentum mode fixed-base multiplication/division](https://doi.org/10.1364/OE.581948) | Journal version of record | partial | OAM in additional_math_claims.json |
| [Optical Full Adder Based on Integrated Diffractive Neural Network](https://pmc.ncbi.nlm.nih.gov/articles/PMC12195495/) | Journal version of record via PubMed Central | full text | ADDER in additional_math_claims.json |
| [p-adic Cellular Neural Networks: Applications to Image Processing](https://arxiv.org/abs/2210.14132) | arXiv:2210.14132v2 (2023-01-16) | abstract | CNN in additional_math_claims.json |
| [p-adic CFT is a holographic tensor network](https://arxiv.org/html/1902.01411v2) | arXiv:1902.01411v2 (2019-05-22) | partial | CFT in additional_math_claims.json |
| [p-Adic Diffusion and Random Walks on [0,1]](https://arxiv.org/abs/2608.02103) | arXiv:2608.02103v2 (2026-08-10) | abstract | MONNA in additional_math_claims.json |
| [PCI-SIG 2020 Update](https://pcisig.com/sites/default/files/files/PCI-SIG%202020%20Annual%20Press%20Conference_final.pdf) | 2020 annual press-conference presentation | full text | PCIE in additional_math_claims.json |
| [Plate1995 Holographic Reduced Representations](https://redwood.berkeley.edu/wp-content/uploads/2020/08/Plate-HRR-IEEE-TransNN.pdf) | not established | primary_host_retrieval_failed_mirror_garbled | P-PLATE in additional_systems_claims.json |
| [RFC-5: Coordinate Systems and Transformations](https://ngff.openmicroscopy.org/rfc/5/) | RFC-5 updated proposal; associated version 0.6.dev3; state S3 (Update implementations) | official spec | RFC5 in additional_math_claims.json |
| [SmoothQuant: Accurate and Efficient Post-Training Quantization for Large Language Models](https://proceedings.mlr.press/v202/xiao23c/xiao23c.pdf) | not established | primary_paper_selected_method_figure | P-SMOOTHQUANT in additional_systems_claims.json |
| [Sono-optogenetics](https://pmc.ncbi.nlm.nih.gov/articles/PMC6936518/) | not established | primary_paper_selected_methods_results | P-SONO in additional_systems_claims.json |
| [Sparse p-Adic Data Coding for Computationally Efficient and Effective Big Data Analytics](https://arxiv.org/abs/1604.06961) | arXiv:1604.06961v1 | abstract | SPARSE in additional_math_claims.json |
| [Synaptic MEMOIR preprint](https://pmc.ncbi.nlm.nih.gov/articles/PMC12703991/) | preprint v1 | primary_preprint_selected_methods_results | P-MEMOIR in additional_systems_claims.json |
| [Tensor networks, p-adic fields, and algebraic curves: arithmetic and the AdS3/CFT2 correspondence](https://arxiv.org/abs/1605.07639) | arXiv:1605.07639v2 (2017-07-03) | abstract | BT in additional_math_claims.json |
| [The Era of 1-bit LLMs: All Large Language Models are in1.58Bits](https://arxiv.org/abs/2402.17764) | not established | primary_paper_identity_method_scope | P-BITNET in additional_systems_claims.json |
| [TIFF Revision 6.0](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf) | Revision 6.0 | official spec | TIFF in additional_math_claims.json |
| [TIIF-Bench: How Does Your T2I Model Follow Your Instructions?](https://arxiv.org/abs/2506.02161) | arXiv:2506.02161v3 (2026-07-12) | abstract | TIIF in additional_math_claims.json |
| [Turing patterns in a p-adic FitzHugh-Nagumo system on the unit ball](https://arxiv.org/abs/2308.04364) | arXiv:2308.04364v3 (2023-11-21) | abstract | FHN in additional_math_claims.json |
| [Unikernel Linux (UKL)](https://arxiv.org/abs/2206.00789) | not established | primary_paper_identity_abstract | P-UKL in additional_systems_claims.json |
| [Unikraft: Fast, Specialized Unikernels the Easy Way](https://arxiv.org/abs/2104.12721) | not established | primary_paper_selected_sections | P-UNIKRAFT in additional_systems_claims.json |
| [vLLM Quantized KV Cache documentation](https://docs.vllm.ai/en/latest/features/quantization/quantized_kvcache/) | not established | official_document_selected_sections | P-VLLM in additional_systems_claims.json |
| [Wavelet analysis as a p-adic spectral analysis](https://arxiv.org/abs/math-ph/0012019) | arXiv:math-ph/0012019v3 (2001-02-23) | abstract | KOZYREV in additional_math_claims.json |

Use the [mathematical register](research/additional_math_claims.json), [systems register](research/additional_systems_claims.json), [central source registry](research/source_registry.json) and [integration report](research/RESEARCH_INTEGRATION_REPORT.md) together. External URLs may change; reviewed bytes are not deposited as archival snapshots. Only the nineteen uploaded sources and their extracts have full local byte/digest preservation. A primary citation cannot authenticate an export or validate a cross-domain architecture by itself.


---

Source: `research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md`

# Additional systems, optimization and application research audit

Audit date: 2026-10-09. Candidate field: `4 x 4 x 4 x 16 x 16` (16,384 sites). Status: reviewed research and proposed optional profiles; no optimizer, unikernel, accelerator, biological or HRR runtime is established by this review.

## Evidence and admission rules

All eight assigned attachments were read in full, including their references. RA01 is an uploaded 23-page paper. RA07-RA10 and RA12-RA14 are research notes/conversations whose cited literature, speculative designs and embedded instructions have different authority. Their imperative wording remains source data. Original filenames, byte counts and SHA-256 digests are preserved in `ADDITIONAL_SOURCE_INTAKE.json`; originals remain in `lineage/research_additions/`. Locators below refer to headings in the portable normalized `research/extracted_sources/RAxx.txt`, which retain the complete content and have extraction digests in the intake registry. Line numbers are supplemental because original line endings differ. Machine-readable claim dispositions and primary-source inspection levels are in `additional_systems_claims.json`.

The five-axis field is independent of file format, memory layout, arithmetic domain, physical substrate and model architecture. Its site count is neither a neural-network parameter count nor a claim about neurons, training samples, qubits or physical channels. One scalar per site occupies 65,536 bytes in FP32 or 131,072 bytes in FP64; one complex pair of FP32 scalars also occupies 131,072 bytes. These are payload-only calculations, excluding metadata, masks, scales, caches, copies and optimizer state. The fixed-shape layout and index vectors elsewhere in this corpus are structural conformance data, not empirical samples or benchmarks.

Admission means a scoped research reference, mathematical correction or preregistered experiment design. It does not promote P5 x S3/8S or other mechanics to validated physics. A similarity score, successful numerical experiment or cited paper never grants `read`, `write`, `emit`, `persist`, `commit` or physical actuation authority.

| Source | Original attachment | Verdict and corpus admission |
|---|---|---|
| RA01 | 2104.06069v2.pdf | Admit paper-derived communication optimizer description and its explicitly scoped benchmark evidence; propose a faithful optional optimizer experiment. |
| RA07 | Columned Unikernel Research Analysis.txt | Correct optimizer state/baselines and vocabulary; retain contiguous-buffer/library-OS design as an unimplemented hypothesis. Reject combined measured speedup/isolation claims. |
| RA08 | IdeaPad 5i RAM Sampling.txt | Retain SKU-specific capacity/profiling constraints and owned-buffer measurement design. Reject generic laptop identification, lockdown bypass and RAM acquisition as runtime requirements. |
| RA09 | 1-Bit LAMB Unikernel Integration.txt | Retain a compatibility/porting research question. Correct compressed collectives, residual/state and restart details. No integrated implementation or gain is demonstrated. |
| RA10 | p-Adic 1-Bit LAMB Architecture.txt | Retain arithmetic-domain separation and counterexamples. Proposed hardware/optimizer equivalence, majority reduction, energy and scaling are unverified hypotheses. |
| RA12 | Optogenetics, Connectivity, and Super-Resolution.txt | Admit distinct experimental methods as bounded application references and measurement metadata requirements. Correct MINDS and connectivity-method conflations; no biological/quantum runtime claim. |
| RA13 | Quantization Trade-offs and Efficiency.txt | Admit format/precision taxonomy and scoped primary-paper methods. Correct metadata, KV calculations, energy labels and cross-workload comparisons. Quantization runtime remains proposed. |
| RA14 | HRR in Cognitive Modeling.txt | Admit approximate binding/retrieval mathematics and primary resonator evidence with its task/hardware scope. Propose an advisory HRR cache; reject lossless, brain, AGI or quantum-speedup extrapolations. |

## RA01: faithful 1-bit LAMB scope

The uploaded paper is Li, Awan, Tang, Rajbhandari and He, *1-bit LAMB: Communication Efficient Large-Scale Large-Batch Training with LAMB's Convergence Speed*, arXiv:2104.06069v2 (6 October 2021). All 23 pages were inspected as extracted text. PDF pages 5, 6 and 9 were also rendered and visually inspected for the convergence comparison, Algorithm 1 and performance evidence; page 1 was visually checked in the intake workflow. Precise algorithm, benchmark, hardware and theorem locators are documented in `ONE_BIT_LAMB_PAPER_REVIEW.md`. [Primary paper](https://arxiv.org/abs/2104.06069v2).

The quantized object is distributed **momentum communication**, encoded as signs plus scale and supported by both local and aggregation error feedback, after uncompressed warmup. Weights, activations and all local adaptive state are not thereby one bit. Algorithm 1 (p. 6, lines 3 and 15-20) freezes a variance snapshot for preconditioning while updating a distinct fresh variance estimate reconstructed from compressed momentum. A bounded variance-ratio factor multiplies a frozen warmup trust-ratio average. “Freeze variance and trust ratio” is insufficient to specify the algorithm; “freeze all variance” is false. The implementation retains additional state, not a universal optimizer-memory reduction (p. 7, section 5).

The often-quoted 4.5x and 3.0x are compression-stage throughput comparisons, not complete training results. The 2.8x/2.2x figures incorporate estimated warmup effects. Table 4 (p. 9) reports measured full pretraining of BERT-Large: 731 to 351 minutes, 2.1x, on 256 V100 GPUs with the paper's Ethernet setting and 64K/32K two-phase batches. The matched SQuAD max F1 baseline is 90.555 for “LAMB (ours),” not 90.584 from the prior LAMB paper (p. 5, Table 2). None is a result for this field, a laptop, one worker, an iGPU or a unikernel. No such training was performed for this corpus.

The primary [DeepSpeed tutorial source](https://raw.githubusercontent.com/deepspeedai/DeepSpeed/master/docs/_tutorials/onebit-lamb.md) was inspected for implementation constraints. Its checkpoint-loading policy resets error state and warns about frequent loading; saving alone is not stated to reset it. Accelerator packing support, exact-zero masks and restart topology need a pinned implementation version. The historical public tutorial URL returned 404; the checked source is a current branch rather than an immutable release.

## RA07 and RA09: systems and collective correction

Relevant note locators: RA07 “Algorithmic Formulation” (line 23), “Quantitative” (37), “Serialization” (71), “Operating System” (80), “Constraints” (125); RA09 “Two-Phase” (31), “Bit Packing” (102), “Collective” (105), “Driver” (132), “Single Address” (153), references (228).

“Columned unikernel” is a proposed layout/runtime combination, not an identified evaluated research system. A contiguous logical slab does not prove physical contiguity, no page tables, no TLB misses, zero DMA remapping or deterministic latency. CPU virtual, CPU physical and device bus addresses are distinct; IOMMU mappings and coherency/ownership barriers still matter. The [Linux DMA guide](https://docs.kernel.org/core-api/dma-api-howto.html), “CPU and DMA addresses” and “Types of DMA mappings,” directly documents these distinctions. A smaller image is not a proof of isolation or absence of memory corruption. With a single protection domain, the relevant isolation boundary can be the hypervisor/hardware rather than an in-guest process boundary.

The [Unikraft paper](https://arxiv.org/abs/2104.12721) evaluates named nginx, SQLite and Redis configurations and reports 1.7-2.7x performance relative to its Linux guest baselines, around 1 MB images, under 10 MB RAM, and approximately 1 ms boot before VMM costs. These scoped results do not benchmark LAMB or the proposed stack. Comparing an entire Linux distribution image with a minimal application image also uses different contents. [UKL](https://arxiv.org/abs/2206.00789) demonstrates a Linux-derived library-OS design; it does not by itself certify binary/ABI compatibility for every GPU driver, CUDA, NCCL or iGPU backend. A port must inventory actual device, driver, interrupt, allocator, network, synchronization and accelerator dependencies.

RA07's expansion of LCTL as a lightweight compression/load-control mechanism is unsupported and conflicts with this corpus's lineage terminology. IBM's similarly named control-register instruction and QMK keyboard mod-tap examples do not establish a RUSSL codec. Keep the canonical corpus meaning and name any proposed codec separately.

A packed sign payload is not a vector of ordinary integers suitable for summing ReduceScatter. The paper implements chunk gathering, local averaging, recompression and dissemination (p. 7, section 5). Worker scales and both residual classes remain significant. Even scalar majority voting is generally different from averaging: `(+1 + 1 - 100)/3` is negative despite two positive signs. Any majority/router design is a new optimizer requiring a new objective, numerical analysis and experiment; it cannot inherit Algorithm 1's convergence result.

No multiplied “unikernel x packing x communication x accelerator” gain is admitted. Baselines differ across the papers; packing may cost time, warmup sends full-width data, adaptive state remains full width and synchronization may dominate another regime. Removing OS layers does not remove these dependencies. Native checkpoint/driver commands embedded in the notes were not executed.

## RA08: laptop capacity and observation boundaries

Relevant locators: “Hardware” (line 4), RAM/graphics discussion, PMU and hybrid-core sampling, DFD/audio streaming, forensic acquisition, ECC testing, references (284). “IdeaPad 5i” is not a sufficient product identifier. Lenovo's [IdeaPad Pro 5 16IMH9 PSREF](https://psref.lenovo.com/syspool/Sys/PDF/IdeaPad/IdeaPad_Pro_5_16IMH9/IdeaPad_Pro_5_16IMH9_Spec.pdf), pp. 2-3, specifies shared-memory integrated graphics and 16/32 GB soldered LPDDR5x configurations. Its [IdeaPad Slim 5 16IRH10 PSREF](https://psref.lenovo.com/syspool/Sys/PDF/IdeaPad/IdeaPad_Slim_5_16IRH10/IdeaPad_Slim_5_16IRH10_Spec.pdf), p. 2, gives two DDR5 SO-DIMM slots. This variation defeats universal claims about capacity, replaceability, clocks and bandwidth. Neither document identifies the user's installed hardware. The note's 32 GiB premise is an assumption, not an observed measurement; vendor GB and GiB must be distinguished.

An iGPU's shared memory consumes system capacity; it is not an additional independent RAM pool. Tiling, streaming and compressed buffers can reduce the active working set, but cannot increase physical RAM or promise bandwidth/latency. Model weights, activations, optimizer state, temporary arrays and filesystem cache require separate accounting.

The [Intel VTune hybrid CPU documentation](https://www.intel.com/content/www/us/en/docs/vtune-profiler/user-guide/2026-0/hybrid-cpu-analysis.html), “Group by Core Type,” supports separating core types and migrations when analyzing results. It does not justify blanket assertions that every E-core lacks a particular sampling facility or that a fixed load-latency threshold identifies only DRAM. Event semantics, sampling/skid, permissions, CPU model and measurement tool version must be pinned. The [Linux perf security guide](https://docs.kernel.org/admin-guide/perf-security.html) describes its access constraints. No actual CPU inventory, PMU experiment or full-memory capture was performed here.

The claim that AVML bypasses kernel lockdown is contradicted by Microsoft's [AVML README](https://raw.githubusercontent.com/microsoft/avml/main/README.md), “Memory Sources,” which says acquisition is unavailable when lockdown is enabled. Device/source access and virtualization can also constrain observations. Full-memory forensic capture is not necessary for measuring an application-owned field buffer and is not admitted as a runtime requirement. Claims about universal Windows VBS/HVCI defaults, exact hidden-page behavior and universal RAM-image completeness are unverified. Audio sample-preload sizes and maximum polyphony are workload-specific and irrelevant to a RUSSL field benchmark. On-die ECC and a clean memory test also do not prove end-to-end, permanent data integrity; keep checksums and numerical checks independent of such assumptions.

## RA10: arithmetic and hypothetical hardware

Relevant locators: “Foundations” (line 41), “Compatibility” (78), “NPU” (90), “Hensel” (92), networking (109), “Energy” (148). In `Z/2Z`, `+1` and `-1` are the same residue. A sign bit can encode the two symbols, but it does not make them distinct residue classes modulo 2. The ultrametric inequality only bounds error; membership in `2 Z_2` additionally requires the input and reconstruction to agree modulo 2. `Q_2` has no compatible ordered-field sign. An odd 2-adic unit has a square root only if it is 1 modulo 8; arbitrary frozen optimizer variance plus epsilon does not satisfy this automatically.

Odd-integer modular inverses and finite Hensel lifting can be useful computations. They do not reproduce Euclidean reciprocal square roots, norms, floating-point rounding or LAMB trust ratios without a defined encoding and proof. A finite two's-complement word models modular arithmetic, not the entire 2-adic field. Precision, valuation, invertibility, exceptional operands and reconstruction bounds must be explicit; [Caruso, *Computations with p-adic numbers*](https://arxiv.org/abs/1701.06794) is the relevant primary numerical reference. The separate mathematical audit provides detailed domain counterexamples.

The cited [*Continuous Optimization for p-Adic Models*](https://arxiv.org/abs/2609.25501) exists as a September 2026 preprint; it is not rejected merely because its date is recent. Existence and abstract-level subject verification do not validate this proposed native NPU or the notes' optimizer equivalence. Gate-count, energy, router-majority, universal-Turing-machine and linear hardware scaling claims have no reproduced measurements or supplied implementation and remain quarantined hypotheses. Communication compression does not establish lower floating-point computation energy on one worker.

## RA12: separate experimental modalities

Relevant locators: UCNP (line 64), sono-optogenetics (68), CGH (99), 3D-SHOT (103), connectivity (121), nanocolumns (153), structural interventions (157). This is an application-research survey, not a physical validation of the field's five axes. Optical phase patterns, microscopy coordinates and molecular barcode observations require different payload semantics, units, calibration and uncertainty metadata. Calling all of them “holographic” does not equate their mechanisms or make them quantum computation.

MINDS must be separated from photon upconversion. [Wu et al., 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9232843/) use injected photothermal polymer nanoparticles, near-infrared heating and ectopically expressed thermosensitive TRPV1. This is different from UCNP conversion to opsin excitation; reported responses are on a seconds scale and the preparation is invasive. [Sono-optogenetics](https://pmc.ncbi.nlm.nih.gov/articles/PMC6936518/), DOI 10.1073/pnas.1914387116, uses focused ultrasound and circulating mechanoluminescent particles with optical recharge and opsin expression in mice. It does not demonstrate unlimited depth, arbitrary-coordinate efficacy or general clinical safety.

[3D-SHOT](https://pmc.ncbi.nlm.nih.gov/articles/PMC5663714/) combines temporally focused holographic excitation with calibrated spatial targeting in the paper's preparations. Retain it as a technique reference; do not carry the notes' universal claims of thousands of simultaneously addressed neurons at a fixed millisecond response. Target count, field volume, delivered power, opsin kinetics, phototoxicity, point-spread function and off-target activation need measured limits.

Connectome-seq and Synaptic MEMOIR are distinct methods. The [author-deposited Connectome-seq dataset GSE312903](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE312903) describes mouse pontocerebellar circuitry and sequencing of nuclei/synaptosomes; it is not Synaptic MEMOIR's protein barcode/imaging scheme. [Synaptic MEMOIR's inspected preprint](https://pmc.ncbi.nlm.nih.gov/articles/PMC12703991/) describes a Drosophila proof of concept with 113 neurons in a 9.5-million-cubic-micrometre projection volume and a two-by-six epitope barcode arrangement (4,096 theoretical combinations). This is neither a complete brain connectome nor proof of millions of uniquely distinguishable cells, synaptic function or cognitive emulation.

[Gwosch et al., 2020, MINFLUX](https://www.nature.com/articles/s41592-019-0688-0) reports its nanometre-scale method under controlled labeling, optics and acquisition conditions; its PSD-95 hippocampal-neuron example in Figure 4 is after fixation. Distinguish localization precision, molecular separation/resolution, label linkage, drift and sample depth. A method-level 1-3 nm result is not a universal deep living-brain resolution or live connectivity record. Disease intervention, deep-brain safety and clinical benefit claims in these notes are outside the evidence admitted here.

## RA13: quantization scope and numerical tradeoffs

Relevant locators: “Energy” (line 8), MX (59), “E8M0 Shared Scale” (62), ternary (89), GPTQ (99), AWQ (106), SmoothQuant (113), KV cache (124), FP8 (134), numerical noise (138), spike bounds (152).

Quantization needs separate declarations for weight storage, activation storage, KV cache, communication and arithmetic/accumulator state. GPTQ is calibrated approximate-second-order, weight-focused post-training quantization; AWQ is activation-aware weight quantization; SmoothQuant moves activation difficulty into weights through equivalent rescaling for W8A8 inference. None is 1-bit LAMB or a generic rule to change every tensor. [GPTQ](https://arxiv.org/abs/2210.17323), [AWQ](https://arxiv.org/abs/2306.00978), [SmoothQuant](https://proceedings.mlr.press/v202/xiao23c/xiao23c.pdf). SmoothQuant Figure 9 (p. 7) benchmarks FasterTransformer configurations, including up to 1.56x versus its FP16 FasterTransformer baseline on one GPU for OPT-13B/30B. It does not establish the same gain for an iGPU, every LLM or this field.

The [OCP MX v1.0 specification](https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf), Table 1 (PDF p. 10), specifies the concrete MX formats with 32-element blocks and an eight-bit E8M0 scale; MXFP4 uses E2M1 elements. An ideal MXFP4 payload is therefore `4 + 8/32 = 4.25` bits per element, a derived accounting result before headers, alignment and padding. A shared exponent does not restore FP32 per-element precision or arbitrary dynamic range. “Four-bit mantissa” is wrong for E2M1.

The ternary alphabet has `log2(3) ≈ 1.585` bits of entropy per independent uniformly distributed symbol. This is not a universal minimum for every trained distribution or the physical checkpoint size; encoding, scales and alignment remain. [BitNet b1.58](https://arxiv.org/abs/2402.17764) describes native training choices, which do not establish lossless post-training conversion of arbitrary full-precision models. Its [2B4T report](https://arxiv.org/abs/2504.12285) is evidence about that trained model and its evaluations, not the unnamed field runtime.

The notes' energy table mixes technologies and operation definitions: the familiar 3.7 pJ estimate is a floating-point multiply in the cited 45 nm comparison, not a multiply-add. Memory energy depends on access size and device. Without the original table, node and operation definitions attached to each entry, the cross-node numbers and inferred universal ratios are not admitted. Likewise, a roofline bound needs actual kernel arithmetic intensity, achieved bandwidth, compute ceiling and packing/scale traffic; payload bit reduction alone is not a speedup or energy measurement.

KV cache byte count is `2 * layers * cached_tokens * batch * KV_heads * head_dim * bytes_per_element`, before allocator overhead and scales. For the explicit analytic assumptions 80 layers, eight KV heads, head dimension 128, batch one, one million tokens and two-byte elements, it is 327.68 GB (305.18 GiB), not 135 GB. This calculation makes no claim that a specific model supports or has been run at that context length. Softmax does not generically cancel quantization error: quantizing values changes the weighted output, and quantizing keys/queries changes logits. The [current vLLM documentation](https://docs.vllm.ai/en/latest/features/quantization/quantized_kvcache/), “Supported FP8 KV-Cache Quantization Schemes” and “Scale Calibration Approaches,” describes backend-dependent schemes, calibration and skipping sensitive layers. It does not establish a universal 50K-token threshold, no quality loss or FP8 as the optimum/default on this host.

Blog-derived quality drops, CATQ/ScaleQ comparative superiority, model-specific crossovers, universal ANN/SNN power comparisons and the stated 1.72-spikes-per-connection limit have not been traced to an inspected primary experiment with matching conditions. Do not admit their numbers as established bounds. Numerical errors can accumulate in feedback systems; a distribution/domain-specific error budget and recurrence stability experiment are useful research additions, not a universal guarantee.

## RA14: HRR as approximate advisory retrieval

Relevant locators: binding (line 13), unbinding (21), comparisons (28), BEAGLE (92), NEF (124), spatial semantic pointers (137), resonators (155), hardware (161). In real HRR, circular convolution binds and superposition bundles; correlation approximately unbinds general random vectors. Exact inverse behavior requires additional conditions, such as unit magnitude Fourier components for unitary vectors. Exact deconvolution with near-zero spectral components can amplify noise. Random near-orthogonality and unit norms are probabilistic/normalization properties, not deterministic exact facts. [Plate's primary HRR paper](https://redwood.berkeley.edu/wp-content/uploads/2020/08/Plate-HRR-IEEE-TransNN.pdf), sections on correlation and unitary vectors and appendices C-D, is the foundational reference; direct primary-host retrieval failed in this audit, while an author-paper university mirror was reachable with garbled text. Its formulas are therefore supported here by explicit mathematical qualifications and the inspected comparative [VSA experiment paper](https://arxiv.org/abs/2001.11797), not a claim of a full independently legible Plate-paper review.

Convolution is commutative: without roles/permutations, `a*b` and `b*a` are indistinguishable. Cleanup chooses among a finite vocabulary; noise, bundle count, depth, dimension, encoding and candidate count determine retrieval. Ties and out-of-vocabulary queries need abstention. No fixed-width, finite-precision vector losslessly stores arbitrary symbolic trees. Similarity is not semantic identity, a canonical digest, a formal proof or an effect capability. An HRR cache would retain a link to the exact symbolic source and treat retrieval as a suggestion that requires exact validation.

BEAGLE, semantic-pointer/NEF simulations and spatial semantic pointers are useful modeling families, not evidence that the human brain uses HRR or that this corpus is an AGI. Europarl BERT/GloVe percentages from different experiments have not been established as matched baselines and are excluded. Resonator factorization is iterative and can fail; it is not a general solution to arbitrary combinatorial reasoning.

The inspected primary [neuromorphic resonator paper](https://arxiv.org/html/2208.12880v4), “Neuromorphic implementation” and Figure 6, reports **171x energy-delay-product efficiency** for its largest Loihi network versus its CPU comparison; Loihi is slower per iteration. It evaluates synthetic visual-scene factorization with a specific FHRR spiking implementation. The note's 175x value and any inference of 175x throughput or general RUSSL gain are incorrect. FFT convolution's `O(n log n)` arithmetic complexity can guide a CPU experiment; a QFT gate-count argument omits state preparation, data loading and classical readout and gives no demonstrated quantum end-to-end gain here.

## Proposed optional profiles and preregistered experiments

These profile IDs describe future interfaces; no implementation is claimed. Core field ordering, types, canonicalization, lineage and effect validation retain their existing roles.

| Proposed profile | Required records and permitted use |
|---|---|
| `PROFILE-OPT-1BLAMB-RESEARCH/0.1` | Explicit model/layer mapping, frozen/fresh variance, bounded factor, momentum normalization, warmup, masks, scale coding, both residuals, topology and resume semantics; research training adapter. See detailed paper review and `EXP-OPT-01`. |
| `PROFILE-SYSTEMS-BUFFER-RESEARCH/0.1` | Shape/index mapping, scalar domain, layout/stride/alignment, owned-buffer size, all copies, pinned runtime/driver/hypervisor, DMA address/mapping/coherency and isolation boundaries; transport/layout hypothesis. |
| `PROFILE-QUANTIZATION-RESEARCH/0.1` | Separate storage/compute/accumulator/communication precision, block shape, scales/zero points, rounding/saturation, calibration dataset digest, sensitive exceptions, error units/tolerance and exact-source digest; lossy derived view. |
| `PROFILE-HRR-ADVISORY-RESEARCH/0.1` | Dimension, vector distribution/seed, role/permutation scheme, unitary policy, convolution normalization, vocabulary digest, bundle/depth limits, cleanup score/margin and abstention, exact symbolic links; advisory retrieval only. |
| `PROFILE-IMAGING-OBSERVATION-RESEARCH/0.1` | Modality, specimen/preparation, coordinate frame/units, PSF/calibration, power/exposure/time, label/barcode design, uncertainty, source dataset and exact symbolic links; recorded/synthetic observation data only. |

`EXP-SYS-01` would compare an ordinary process reference, its contiguous owned-buffer layout and an optional ported library-OS implementation, holding arithmetic/data/workload constant. First preregister CPU/SKU/RAM/backend versions, process and VM boundaries, allocation alignment, workload, cold/warm conditions, repetitions and copy accounting. Check all 16,384 index mappings and round trips before timing. Record peak resident memory, allocation/serialization/transfer latency distributions, achieved bandwidth, page faults/TLB events with CPU-specific event definitions, packet bytes and failure counts. The primary endpoint is total completed-work latency at equal numerical output; the memory endpoint includes all state and buffers. Any unavailable driver/backend ends that branch as an unsupported-port result, not an assumed performance improvement. No host-wide memory acquisition is required.

`EXP-QUANT-01` would compare a full-precision reference against each independently declared derived format, holding data/model/sample order and calibration/test separation fixed. Preregister absolute/relative error norms, held-out task score, recurrence length where relevant, quality noninferiority margin, saturation/nonfinite handling and precision-sensitive exceptions. Count scales, padding, conversions and every persistent/temporary tensor. Report bytes, total time and energy only with a pinned measurement setup; a bit-count derivation is reported separately. Test adversarial outliers and long recurrences, with failed/null runs included. Compression may be refused if the tolerance fails.

`EXP-HRR-01` would preregister seeds, dimensions, vocabulary sizes, bundle counts/depths, roles/permutations and noise distributions on symbolic data with known answers. Compare direct convolution and FFT, unitary/general random vectors, and exact symbolic lookup. Primary endpoints are correct retrieval and false acceptance/abstention rates with confidence intervals across seeds; secondary endpoints are latency and complete storage. Include swapped-role, tied-score, corrupted and unseen-symbol cases. Cleanup requires a prospectively selected score/margin threshold and exact-source validation before any downstream decision. A resonator extension has its own convergence/failure criterion and does not inherit a success guarantee.

`EXP-IMAGING-01` would use synthetic or already-accessible recorded observations to test coordinate/uncertainty metadata and reconstruction error under declared PSFs, noise and calibration. It makes no prediction of neuronal control, clinical efficacy, complete connectivity or a quantum processor, and does not authorize a physical experiment. Existing specimen-level work remains primary literature rather than RUSSL empirical data.

Across all experiments, register dataset/model/version digests, sample budget, random seeds, endpoints, inclusion/exclusion criteria, failure rules and statistical method before observing comparative results. Preserve raw measurements and exact provenance. Choose numerical tolerances and noninferiority margins prospectively for the specific task; this audit supplies no invented universally valid threshold.

## Inspection limits and next evidence needed

The uploaded sources were fully read. Relevant primary papers/specifications and official documents were inspected at the levels recorded in the JSON registry; this is a targeted claim audit, not verification of every item in the notes' long bibliographies. Some primary-host pages were unavailable, some recent references were checked only for identity/abstract, and untraced quantitative claims are explicitly excluded. No optimizer training, library-OS port, RAM/PMU measurement, quantized inference, HRR retrieval benchmark, microscopy or physical actuation occurred in this audit. Implemented field/container conformance elsewhere in the corpus does not change that status. The next useful evidence is a pinned, preregistered and reproducible experiment for each optional profile, with quality and complete resource accounting reported together.


---

Source: `research/BIBLIOGRAPHY.md`

# Research Bibliography and Source Dispositions

**Corpus:** 2.0.0. **External access date:** 2026-10-09. Machine-readable companion: `source_registry.json`. References support the scope stated here, not institutional approval or validation of P5×S³/8S.

| ID | Primary source and version | Role / limit |
|---|---|---|
| `EXT-BCP14-2119` | Bradner, [RFC 2119: requirement-level key words](https://www.rfc-editor.org/rfc/rfc2119.html), March 1997 | Terminology; no RUSSL standards status |
| `EXT-BCP14-8174` | Leiba, [RFC 8174: uppercase clarification](https://www.rfc-editor.org/rfc/rfc8174.html), May 2017 | Terminology clarification |
| `EXT-JCS` | Rundgren et al., [RFC 8785: JSON Canonicalization Scheme](https://www.rfc-editor.org/rfc/rfc8785.html), June 2020 | Comparison with corpus identity serialization; JCS conformance not claimed |
| `EXT-TIFF6` | Aldus, [TIFF Revision 6.0](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf), final 1992-06-03; original text hosted by ITU | TIFF boundary; not a generic codec/extension guarantee |
| `EXT-BIGTIFF` | LibTIFF, [BigTIFF Design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html), documentation 4.7.2 observed | Offset/directory extension; page mutable, design has no separately asserted numbered revision |
| `EXT-COG` | OGC, [Cloud Optimized GeoTIFF Standard 21-026](https://docs.ogc.org/is/21-026/21-026.html), 1.0, 2023-07-14 | Proposed class-specific adapter/hosting boundary; no executed certification |
| `EXT-NGFF` | OME, [OME-Zarr specification / NGFF](https://ngff.openmicroscopy.org/0.5/), 0.5 | Proposed adapter metadata/axis boundary |
| `EXT-ZARR3` | Zarr core developers, [Zarr core specification](https://zarr-specs.readthedocs.io/en/latest/v3/core/index.html), 3.1 observed | Zarr v3 representation; mutable URL, extension snapshots needed |
| `EXT-FAIR` | Wilkinson et al., [FAIR Guiding Principles](https://pmc.ncbi.nlm.nih.gov/articles/PMC4792175/), Scientific Data 3:160018 (2016), DOI 10.1038/sdata.2016.18 | Stewardship goals; not certification |
| `EXT-PROV` | W3C, [PROV-DM](https://www.w3.org/TR/2013/REC-prov-dm-20130430/), Recommendation 2013-04-30 | Proposed provenance crosswalk; no PROV serialization claim |
| `EXT-SSDF` | NIST, [SP 800-218: SSDF](https://csrc.nist.gov/pubs/sp/800/218/final), 1.1, February 2022 | Security-lifecycle policy input; no full implementation/endorsement |
| `EXT-IR` | NIST, [SP 800-61 Rev. 3](https://csrc.nist.gov/pubs/sp/800/61/r3/final), April 2025 | Incident-response policy input; no operating-effectiveness claim |

## Embedded and unavailable sources

The four original MSSL modules, master-law image, historical construction workflow and both lineage archives remain embedded; see `SOURCE_AUTHORITY.md` for verified hashes. The lineage implementation describes its own historical behavior; it is not executable authority over current RUSSL semantics.

The lab source `8S_Labs_3001_4000b.pdf`, pages 136–145, is unavailable. Parent RUSS 1.1 is a declared digest/lineage reference without independently accessible original bytes. Original authorship, MSSL internal-identity rules, source rights, empirical datasets and institutional attestations are not supplied. No bibliography entry fills those gaps.

## Citation policy

Cite exact version and URL, access date, embedded availability and claim scope. For mutable URLs, preserve a verified snapshot/commit before operational reliance; the registry records that this is pending. Distinguish an author's claim from a reproduced result. Standards references constrain an adapter; they do not independently establish that adapter's correctness. Do not reproduce full external standards or infer corpus redistribution rights from access to a cited page.

## Additional attachment audit references

The nineteen added sources and 159 decisions have a separate [primary reference index](research/ADDITIONAL_PRIMARY_REFERENCE_INDEX.md), with [source intake](research/ADDITIONAL_SOURCE_INTAKE.json) and a [research integration report](research/RESEARCH_INTEGRATION_REPORT.md). Identity/abstract checks, selected methods/results and complete uploaded-paper inspection are explicitly distinguished. Quantitative claims are retained only with their inspected configuration and evidence scope.


---

Source: `research/EXPERIMENT_PROTOCOLS.md`

# Proposed Experiment and Preregistration Protocols

**Corpus:** 2.0.0. **Status:** designs awaiting inputs/implementations; no experiment is represented as completed. **Date:** 2026-10-09.

## Common preregistration record

Before confirmatory outcome inspection, deposit a dated immutable record containing: protocol ID/version and predecessor; question/hypothesis/null; claim/evidence grade; model/source/module digests; complete algorithm and domain/units; data source/license/selection and hash; primary endpoint/estimand; comparators/controls; train/validation/test split; tuning budget; sample-size/power or precision justification; randomization and seed generation; exclusion/missingness rule; stopping rule; uncertainty estimator; multiplicity control; sensitivity analyses; compute/runtime/solver/dependency versions; expected outputs and analysis scripts; reviewer/conflict record; deviations policy. Missing fields yield `DESIGN_INCOMPLETE`, not a filled-in placeholder result.

If outcome data have already been seen, label the work exploratory and preregister an untouched independent replication. Hashing a protocol after observing results is not prospective preregistration. Freeze the primary analysis, record deviations before executing them where possible, and publish both primary and exploratory results. This corpus does not register studies with an external registry on the user's behalf.

## EXP-01 — Residual independence and numerical stability

**Question:** Does the source eta criterion separate known rank-4 span, controlled new directions and noise? **Prerequisites:** agreed C4/e dimensions, normalization, epsilon and SVD cutoff. **Synthetic design:** generate exact in-span e, controlled orthogonal e, near-rank-deficient C4, zero e and scaled copies; add prespecified noise levels with independent streams. Compare float implementation against analytic exact cases and higher-precision calculations where meaningful.

**Primary estimand:** eta estimation error in analytic cases and false-positive rate against a stated measurement-noise null. **Controls:** rank/condition strata, no-noise baseline, column permutation, unchanged span under scale-normalized representation. **Sensitivity:** SVD threshold, regularization epsilon, magnitude, condition number, dtype and noise law. Record numerical uncertainty separately from simulated sampling uncertainty. Reject negative/nonfinite outputs or unexplained instability; do not infer physical novelty from successful analytic discrimination.

Sample count and tolerances must come from required precision/noise assumptions, not a convenient replication count copied from lab text. Seeds and analytic construction are published before runs. Report every condition, including unstable ones.

## EXP-02 — Added-representation predictive gain

**Prerequisites:** complete M7/M8 algorithms, target task, lawful empirical/simulation dataset, score definition and epsilon_gain. These are not supplied. Define whether larger scores are better and whether gain is absolute/relative. Freeze train/validation/test splits; block by time/entity where leakage is possible.

**Comparator:** M7 with matched capacity, optimizer, preprocessing and tuning budget. **Ablations:** no added residual term, shuffled/irrelevant added features, equal-capacity alternative and simple task baseline. **Primary analysis:** paired score difference on untouched test observations with a confidence interval whose method respects temporal/entity dependence. Preregister the confidence level and margin rule; for a one-sided scientific gain claim require the lower bound above epsilon_gain, not merely a positive point estimate. Select thresholds on training/validation only.

**Uncertainty:** measurement error, finite sample, tuning randomness and distribution shift separately. Use block/cluster resampling or a justified model for dependent data; do not treat repeated seeds on the same dataset as new empirical subjects. Correct multiplicity for claimed endpoint families. Report effect sizes, intervals, calibration and adverse subgroup/time outcomes. A simulation result remains E3 even if it reproduces the source's preferred direction.

## EXP-03 — Logical field and adapter equivalence

**Question:** Do supported transformations preserve shape, coordinates, dtype and selected samples? Exhaust small shapes including singleton axes and odd dimensions; use independent mapping code and decoded-sample comparisons as oracle. Generate bounded randomized shapes/types with recorded seeds; test index→coordinate→index round trips under explicit numerical tolerance. Compare dense/sparse views without collapsing undefined samples into zeros.

For TIFF/OME-Zarr variants, use external genuine fixtures with writer/version/hash provenance. Test declared axis permutation and its inverse, metadata/calibration, orientation, fill/labels and multiscale relationships separately. Compare bytes only when byte-reversibility is claimed; otherwise compare sample bits and declared semantics. Negative fixtures must reject ambiguous maps, unsupported types, escaping paths, inconsistent metadata and corrupted payloads. Since adapters are not supplied, external-format substudies remain `NOT_EXECUTABLE`.

## EXP-04 — Distributed retrieval and reproducibility

**Prerequisites:** actual adapters/fabric implementation and authorized isolated environment. Freeze dataset, region request trace, logical block scheme, storage layout, cache policy, machine/network specifications and concurrent load. Compare full-object retrieval, regional retrieval and deduplication under equal integrity/access checks.

Record bytes transferred, unique stored bytes, verification CPU, wall latency distributions, failures/timeouts, cold/warm cache distinction and rejected-corrupt results. Inject missing/corrupt replicas, source mutation, reorder/delay, stale mutable heads and interrupted writes. Retry policy and consistency expectations are preregistered. Confirm every accepted sample through independent logical digest/bit comparison. No speed improvement excuses integrity or authorization failure. A successful isolated study does not claim universal distributed availability.

## EXP-05 — Product-indicator validation

**Prerequisites:** original equations/data, operational calculation for every metric, target outcomes, domain expertise and authorized institutional setting. Define reference population, temporal horizon, missingness and selection mechanisms. Use simple domain baselines, temporal holdout and shift evaluation; calibrate on development data only. Review recommendations through accountable humans; no operational action is authorized by this protocol.

Report calibration, discrimination where applicable, score stability, measurement error, confidence intervals and domain-dependent harm/cost tradeoffs. Separate diagnostic calculation from causal-policy claims. Missing original definitions make this study `DESIGN_INCOMPLETE`.

## Reproduction package and result record

Publish protocol and deviations, input/module/source hashes, code/tool environment, seeds, split IDs, complete raw outputs, analysis, uncertainties/counterexamples and reviewer disposition. A result includes exact claim supported and excluded populations/variants. Sensitive observations may remain restricted with approved access and sufficient non-sensitive synthetic fixtures. Cross-platform numerical disagreement is recorded, not hidden by regenerating goldens from the disputed implementation.

No invented p-values, confidence intervals, benchmark speeds, experimental observations or external registrations accompany these proposed protocols.


---

Source: `research/FIXED_SHAPE_INDEXING_PROFILE.md`

# Fixed-Shape Indexing and Experimental Topology — 4×4×4×16×16

**Status:** experimental mathematical/indexing profile, corpus 2.0.0. **Evidence:** exact generated integer/rational data and scoped regression tests. This profile does not establish sample values, an optimizer, optical hardware, quantum state, p-adic physical dynamics or an evaluated mechanics model.

## Domain and exact quantities

Let `i=(i4,i5,i6,i7,i8)`, with `0≤i4,i5,i6<4` and `0≤i7,i8<16`. There are `4³×16²=16,384` scalar sites. Axes are c4–c8. The active coherent RUSS fixture declares this shape with scalar f64, while its source.state placeholder remains unresolved. Original contradictory bytes remain under examples/legacy_golden/ and are rejected by current field-binding verification.

| Representation | Ideal scalar payload | Scope |
|---|---|---|
| f64 | 131,072 bytes / 128 KiB | eight bytes per scalar |
| f32 | 65,536 bytes / 64 KiB | four bytes per scalar |
| u16 | 32,768 bytes / 32 KiB | two bytes per scalar |
| u8 | 16,384 bytes / 16 KiB | one byte per scalar |
| packed one-bit samples | 2,048 bytes / 2 KiB | representational minimum, not lossless f64 equivalence |

These figures exclude masks, coordinates, units, tensor/channel components, headers, manifests, compression, padding, indexes, allocator overhead, gradients, optimizer states, error buffers and shared GPU memory. A one-bit communication optimizer cannot justify substituting one bit for each field sample. A complex/vector sample needs an explicit component contract and a different payload calculation.

## Bijection and observable oracle

The selected ordering is row-major with c8 fastest:

`k=((((i4×4+i5)×4+i6)×16+i7)×16+i8)`.

Strides are `(4096,1024,256,16,1)`. The index bit widths `(2,2,2,4,4)` sum to fourteen. An equivalent packed ordinal is `(i4<<12)|(i5<<10)|(i6<<8)|(i7<<4)|i8`. A 16-bit transport representation would have two unused upper bits; their interpretation and byte order need a separately identified adapter contract. Code here operates on bounded mathematical integers, not a new wire ABI.

The inverse is `ij=(k//stride_j) mod shape_j`. [Layout registry](machine/registries/fixed_shape_layout.json) fixes ordering, strides, cardinality and fixture digest. [Exhaustive vectors](tests/vectors/field/fixed_shape_index_vectors.jsonl) contain every ordinal and index tuple in ascending ordinal order. They were generated from the explicit formula. Tests check all 16,384 pairs and endpoint/stride transitions, rejecting booleans, fractional values and out-of-domain coordinates. This provides a complete finite bijection check, not a benchmark.

Normalized coordinates are exact rationals: size-four axes have `(-1,-1/3,1/3,1)`; size-sixteen axes have `cj=(2ij−15)/15`. Spacings are 2/3 and 2/15. These normalized coordinates do not establish physical length, acquisition time, channel semantics or isotropic physical sampling. Physical calibration remains separately bound metadata.

## Optional 2-adic organization

A finite bit organization can embed ordinals as integers in Z₂ or use the residue ring Z/2¹⁴Z. The finite ring is not the p-adic field Q₂. The implemented experimental distance is `d₂(a,b)=0` when equal, otherwise `2^(−v₂(a−b))`. For distinct fourteen-bit ordinals, valuations are between zero and thirteen. The strong triangle inequality describes this metric's mathematical topology; it does not establish relevance to the mechanics or to an imaging task.

This ordering is sensitive to the packed index convention. `d₂(0,1)=1`, while `d₂(0,4096)=1/4096`. Thus a change along c4 can be 2-adically close and a one-step c8 change relatively far. This does not preserve the Euclidean neighborhoods of the normalized five-dimensional base. Low-bit congruence classes and high-bit prefix blocks are different trees. Bit reversal, Morton/interleaved codes and Monna-type maps are distinct mappings and require their own definitions, collisions/order tests and evidence. No mandatory p-adic reinterpretation is applied to the core field.

The utility module checks integer domains, exact rational coordinates, ordinal packing/unpacking and the optional distance. It evaluates no source row, sample array, field coupling, S³ fiber or module. Scientific claims cannot follow solely from the fact that the coordinates are powers of two.

## Research design

Experiment FS-01 compares row-major, an explicitly defined interleaved ordering and a low-bit residue hierarchy on the same lawful immutable sample payload. Preregister the locality/query task, indexes, original sample semantics, accuracy oracle, memory accounting, preprocessing amortization and hardware. Report both normalized Euclidean and selected hierarchy distances; choose no ordering after observing which yields a favorable metric. Storage layout is an adapter concern; ordinal identity and logical sample identity are assessed separately.

Experiment FS-02 tests representation changes using f64 as a specified reference, with f32/u16/u8/packed-bit transformations each defining calibration, quantizer, rounding, clipping, missingness and reconstruction. Measure error and task-specific information loss. Byte count reduction is a derived accounting fact; it is not evidence of preserved signal, optical fidelity, optimizer convergence or system energy efficiency.

Experiment FS-03 benchmarks hierarchy querying using identical samples and independently checked query outputs. Include index construction, serialization, transfer, decode and query time. The sixteen-thousand-site field is small; extrapolation to BERT-scale optimization, microscopy acquisition or distributed clusters requires new measurements. Exact index enumeration is the only completed data-producing experiment in this profile.

All three proposed experiments remain unexecuted. Their adoption requires a reviewed implementation and a result record that names inputs, code, platform, random seeds, uncertainty and negative outcomes. The source reviews explain which attached claims motivate a hypothesis and which are rejected.


---

Source: `research/MECHANICS_CRITICAL_REVIEW.md`

# Critical Review of the Supplied Mechanics

**Scope:** interpretation of preserved image/MSSL sources; not a rewrite, implemented mechanics engine or proof of empirical validity. **Date:** 2026-10-09. **Corpus:** 2.0.0.

## Source comparison

The master image presents a five-coordinate base, radius-dependent S³ fibers, pair/higher-order coupling, phase evolution, logistic activation, radius and projection/classification constructions. The master MSSL stores selected formulas as literal text and calls its operational projection a deterministic reduced form. The other modules store lab equation strings, indicator labels and admission states. The displayed true assertions and terminators cannot establish that these formulas were numerically evaluated. Bind original bytes; any future reviewed transcription is a new derivative with an explicit correspondence table and independent equation check.

## Geometry under explicit assumptions

A possible formal reading uses base `B=[-1,1]^5` and unit sphere `S³={u in R⁴: ||u||₂=1}`. For a strictly positive, differentiable radius function `R(c,t)`, set `X(t)={(c,y) in B×R⁴: ||y||₂=R(c,t)}`. In the interior of B, `f(c,y)=||y||₂²−R(c,t)²` has nonzero y-gradient for R>0, so its level set is locally eight-dimensional in the nine-dimensional ambient space. This is a conditional mathematical derivation, not a physical-dimensional claim. Cube boundary/corner strata require a manifold-with-corners treatment. At zero radius the sphere collapses and this regularity argument fails. Negative, undefined or nonsmooth radius also defeats the stated derivation.

The image uses `r_i` for node radii and `R(c,t)` for a continuous construction, but does not supply a unique interpolation/evolution rule relating them. The software's five-dimensional array and normalized axes are a separate field model, not an implemented discretization of all these equations. A channel index is not a physical spatial coordinate simply because it occupies a Penteract axis.

## Residual criterion

Under the proposed dimensions `C4 in R^(m×4)`, `e in R^m`, with `C4_plus` the Moore–Penrose pseudoinverse, `P=C4*C4_plus` projects onto the column space. For epsilon>0,

`eta_ind = ||(I−P)e||₂² / (||e||₂²+epsilon)`.

In exact arithmetic, `0≤eta_ind<1`; e=0 gives 0. This shows how much of e is orthogonal to the existing columns under the chosen Euclidean norm. It does not establish causality, physical independence, economic value or a genuinely new mechanism. Noise or data leakage can produce nonzero residual. Numerical rank depends on scale and SVD cutoff; a stable result needs recorded column normalization, tolerance, condition numbers and sensitivity analysis. A nonpositive epsilon is outside this proposed safe domain. None of these dimensions/tolerances is filled into the original source by this review.

## Proposed symbol obligations

| Source symbol/group | Needed definition and domain | Current gap / consequence |
|---|---|---|
| `c_i=ell*n_i`, `n_i in Z⁵`, l1 bound M | ell, M, enumeration order, boundary inclusion and guarantee c in B | Lattice and normalized software indices not uniquely related |
| `q(t)=sin²(pi*t/T)` | T>0, time units, origin and numerical evaluation | A bounded periodic gate under these assumptions; physical clock meaning absent |
| `G5`, distances, `sigma_c`, `sigma_J` | Metric/PSD matrix, distance domain, positive bandwidths | Negative quadratic forms or zero bandwidths invalidate intended decays |
| `A_ij`, `W_ij`, `H_ijk` | Symmetry, sign, normalization, sparsity, units, self-interactions | No unique graph/hypergraph normalization or computation |
| Phase ODE and `K2`, `K3`, `omega` | State domain, initial/boundary conditions, solver/tolerance, units | Literal source is not an ODE simulation |
| `h_i`, beta, field/radius terms | Dimensionless logistic argument; sign/units, parameter values | Exponent cannot be interpreted without dimensional consistency |
| `p_i=1/(1+exp(-h_i))` | Finite h; overflow-stable equivalent evaluation | Numerical branch/version must be recorded; labels alone not sufficient |
| `B5=product b(c_i,a)` | Gate b, support, bounds and differentiability | Negative/undefined B5 can make noninteger powers invalid |
| `s_i=p_i*kappa_i*(1−chi_i)*(1−zeta_i)*v(omega_i)` | Bounds/meaning of each factor, missing-data behavior | Assuming [0,1] requires explicit premises, not source inference |
| `r_i=r_max*B5^alpha*s_i^(1/3)` | r_max≥0, B5/s domain, alpha and zero-base behavior | Degeneracy, complex values or discontinuity otherwise possible |
| `Pi5`, `Psi4`, projected positions | Dimensions, ranks, time dependence, normalization | Projection may merge distinct states; no unique inverse |
| Gaps, classifications and `K_ij`, `Sigma_ij` | Units, relation thresholds, labels and uncertainty | Classify is an undefined operator; classification claims untestable |
| `Score(M8)−Score(M7)` | Task, estimator, scale, direction, data split and capacity matching | No scalar “gain” can be computed fairly yet |
| epsilon thresholds | Selection rationale, noise floor and decision consequences | Data-dependent threshold selection can invalidate confirmation |

These are research definition obligations, not assumed source facts. Values must be supplied in a versioned protocol; an implementation cannot secretly choose them and advertise source fidelity.

## Labs and product indicators

Ten lab records name 100 replications and financial-policy-themed quantities. Supplied flattened strings include broken fraction layouts, repeated equation numbers and escape sequences. They are evidence of supplied transcription text, not evidence of 100 executed trials. Replication count alone supplies neither independent samples nor uncertainty. Original PDF equations, variable dictionaries, seeds, inputs and analysis code are absent.

Metric labels “adequacy,” “resilience,” “runway,” “governance,” and “recommendation” are not executable calibration formulas. Score directions and units do not define operational estimands. A domain-specific indicator needs measured targets, reference populations, normalization, missingness, drift and uncertainty treatment before predictive claims.

## What can and cannot be repaired in this release

Repair the claim boundaries, source custody, explicit domain obligations, experimental plan and uncertainty reporting. Preserve ambiguous source bytes and identify each ambiguity. Do not repair mathematical content by guessing a denominator, completing a variable definition, reconstructing an absent PDF or inventing measured performance. After authoritative sources arrive, review a new derivative transcription and compare it back to each original object.


---

Source: `research/ONE_BIT_LAMB_PAPER_REVIEW.md`

# Review of the supplied 1-bit LAMB paper

**Corpus:** 2.0.0 candidate. **Review date:** 2026-10-09. **Admission:** external research reference and proposed optional optimizer profile; no implemented RUSSL training runtime or reproduced benchmark.

## Source identity and inspection

RA01 is the uploaded `2104.06069v2.pdf`, archived unchanged as `lineage/research_additions/RA01.pdf`. SHA-256: `7bb1c6dcab2ab81265d00cf79f213c12f6a141afe4425e23b96d4170161ac2b3`. It is **1-bit LAMB: Communication Efficient Large-Scale Large-Batch Training with LAMB's Convergence Speed**, Conglong Li, Ammar Ahmad Awan, Hanlin Tang, Samyam Rajbhandari and Yuxiong He, arXiv v2, 6 October 2021. The supplied PDF contains 23 numbered pages, including references and appendix. Its identity/version was checked against the [primary arXiv record](https://arxiv.org/abs/2104.06069v2).

All 23 pages of the portable normalized extraction `research/extracted_sources/RA01.txt` were read, including Algorithm 1, both convergence tables, profiling results, momentum fusion/scaling details and the assumptions/proofs in Appendix A.7. PDF pages 5, 6 and 9 were rendered and visually inspected to verify Table 2, Algorithm 1, Table 4 and Figure 3; page 1 was also visually inspected during intake. Page numbers below mean the printed PDF page, which matches one-based physical page numbering in this file. The plain-text discussion attachments RA07, RA09 and RA10 are secondary notes; they do not override this paper. Several formulas in those notes have missing symbols, so they cannot serve as executable algorithm definitions.

## What is compressed

The method targets **communication in distributed data-parallel training**. Warmup uses baseline LAMB and ordinary uncompressed communication. The later stage communicates error-compensated **momentum**, encoded by sign bits plus scale information, rather than turning all model weights, forward activations, gradients, variance tensors or local arithmetic into one-bit objects. See PDF pp. 2-3, section 2; p. 6, Algorithm 1 lines 6-11; pp. 16-17, Appendix A.5.1-A.5.2.

Both the worker and the logical aggregation server retain compression residuals. The server in Algorithm 1 is a conceptual description: the distributed collective implementation partitions aggregation responsibilities across workers (p. 7, section 5; pp. 18-19, Appendix A.7.1). This does not imply that the paper implements a centralized, unikernel parameter server.

The compressed object is not a bare sign vector whose components can be summed as packed integers. It carries scales and is decoded for numeric averaging before it is recompressed with aggregation error feedback. Replacing that operation with majority voting defines another algorithm. For example, contributions with signs `+,+,-` and magnitudes `1,1,100` have positive majority sign but negative numeric mean. Bitwise arithmetic on packed sign words is likewise not a floating-point sum. RA10's in-network majority circuit cannot be called a faithful 1-bit LAMB implementation without a new specification and convergence study.

## State and adaptive scaling: the material correction

The phrase "freeze the variance" has a precise scope. At the end of warmup, the method stores a fixed preconditioning snapshot `v_Tw` and freezes the warmup moving average `c_avg`. It **continues updating a separate fresh variance `v_t`**. Algorithm 1, p. 6, line 3 explicitly requires this, and lines 15-20 specify its role; the prose on p. 7 confirms it.

For a layer/tensor, the paper's compressed-stage construction is:

```text
g_reconstructed,t = (m_global,t - beta1 * m_global,t-1) / (1 - beta1)
v_fresh,t = beta2 * v_fresh,t-1 + (1 - beta2) * g_reconstructed,t^2
r_raw,t = infinity_norm(v_frozen / v_fresh,t)
r_step,t = clip(r_raw,t, (1 - r_threshold)*r_t-1,
                         (1 + r_threshold)*r_t-1)
r_t = clip(r_step,t, r_min, r_max)
c_t = r_t * c_avg
x_t = x_t-1 - learning_rate * c_t * m_global,t / sqrt(v_frozen)
```

This is a transcription of the algorithm's main scaling structure, **not a complete implementation**: bias correction, weight decay, epsilon/zero-denominator policy, masking, layer partitioning, momentum normalization, packing and collective details must be pinned to an implementation version. The introductory Eq. (1), p. 3, omits weight decay for simplicity and includes a numerical-stability term; its footnote also explains the authors' clipping convention relative to original LAMB. Those details must not be silently guessed from blank attachment equations.

During compression, the original instantaneous weight/update norm ratio is not simply recalculated as in vanilla LAMB. The new coefficient uses the frozen base and a clipped variance ratio. Neither "freeze all variance forever" nor "use the original LAMB trust ratio with one-bit gradients" describes the proposed algorithm. RA07/RA09/RA10 must be corrected on this point.

Momentum fusion is also substantive. The authors fuse tensor momentum into a contiguous one-dimensional view to avoid 302 separate communications for BERT-Large (p. 16, A.5.1). The fused view is explicitly not another duplicate allocation. Because a common compression scale would increase error across differently scaled layers, they compute fixed layer momentum scaling coefficients at the end of warmup, scale before communication and undo that scale after aggregation (p. 17, A.5.2). These fixed normalization coefficients are separate from the dynamically clipped learning-rate factor `r_t`.

## Benchmarks that may be retained, with scope

The paper evaluates a modified **BERT-Large** with 24 layers, hidden size 1024, 16 attention heads and about 340 million parameters, using PreLN instead of PostLN. Pretraining uses Wikipedia plus BooksCorpus. The hardware is NVIDIA V100 clusters: Ethernet has 4 GPUs/node and nominal 40 Gb/s inter-node networking with approximately 4.1 Gb/s effective bandwidth; InfiniBand has 8 GPUs/node and 100 Gb/s EDR with effective bandwidth near the nominal peak. Performance experiments use 8-256 GPUs; fine-tuning uses 4 GPUs (p. 4, section 3.2; p. 7, section 6). These are not comparable to an unidentified IdeaPad, CPU-only field processing or a single Intel integrated GPU.

| Retained result | Exact locator and denominator | Interpretation allowed |
|---|---|---|
| Up to 91% Ethernet and 52% InfiniBand allreduce share | p. 14, Table 5: Ethernet 64 nodes/256 GPUs, batch 8K, microbatch 16, accumulation 2; InfiniBand 16 nodes/128 GPUs, batch 8K, microbatch 64, accumulation 1; section 3.2 p. 4 | Measured profiles of the paper's uncompressed BERT-Large seqlen-128 setups; not universal OS overhead |
| 4.6x and 4.1x end-to-end communication-volume reduction | p. 8, section 6 performance analysis, seqlen 128/512 respectively | Paper's calculated FP16 payload reduction including uncompressed warmup; not measured total NIC traffic including all protocol overhead |
| Up to 4.5x and 3.0x compressed-stage throughput speedup | p. 9, Figure 3(a)/(e), seqlen 128/512 with batch 8K; 200-step stage measurements | Ratios between warmup/baseline throughput and compression-stage throughput; not full-run speedup |
| Up to 2.8x and 2.2x estimated end-to-end speedup | p. 9, section 6, derived from stage speedup and warmup fraction | Stage-throughput estimates; separate from Table 4's measured total pretraining time |
| 731 min to 351 min total runtime, reported 2.1x | p. 9, Table 4: 256 V100 GPUs with Ethernet; batch 64K/32K at seqlen 128/512 | Actual measured total runtime in that configuration; phases 657 to 301 min (reported 2.2x), 74 to 50 min (1.5x) |
| Comparable pretraining/fine-tuning convergence | p. 5, Table 2; p. 8, Figure 2/Table 3 | Evidence for these tasks and recipes, not universal equality across models/precisions or statistical equivalence of every endpoint |

The communication calculation is `1 / (warmup_fraction + (1 - warmup_fraction)/16)` for the paper's FP16 comparison. A one-bit sign represents 16 times fewer payload bits than FP16, and 32 times fewer than FP32, **before** scale/padding/message overhead. The 4.6x claim is not a 4.6x shrinkage of model parameters, memory use or all storage. The paper chooses 1000/5993 warmup steps (16.7%) for sequence length 128 and 107/555 (19.3%) for length 512 (p. 8). Those choices are empirical recipes, not generic stopping criteria.

For the matched in-paper Table 2 comparison, LAMB (ours), LAMB + basic 1-bit and 1-bit LAMB have validation losses `1.451`, `1.494`, `1.443`; SQuAD mean F1 `90.265`, `90.069`, `90.524`; and max F1 `90.555`, `90.409`, `90.788`. They use pretraining batches 64K/32K at seqlen 128/512 and 32 fine-tuning runs. The `90.584` max F1 belongs to **LAMB (You et al., 2020)**, not the matched LAMB (ours) column. RA07 mixes these baselines. Table 3 gives aggregate GLUE medians over 32 runs, average `83.9` for LAMB and 1-bit LAMB versus `82.1` for the basic one-bit variant. Do not turn these development-set comparisons into a universal accuracy guarantee or a RUSSL result.

The simpler "LAMB + basic 1-bit" variant is reported as having slower/suboptimal convergence and poorer final scores (p. 5, Table 2; pp. 15-16, A.4). The paper does not justify replacing this specific result with a blanket statement that every such run diverged catastrophically. Similarly, results from LAMB, Adam, 1-bit Adam, SmoothQuant, AWQ, Loihi and unikernel database benchmarks have distinct workloads/denominators and cannot be multiplied together to predict an integrated speedup.

## Implementation, restart and theorem limits

The paper's NCCL-based implementation uses a three-phase compressed collective: gather partitioned chunks using Alltoall/AllGather, average received chunks locally, distribute compressed aggregate chunks using AllGather (p. 7, section 5). The generic phrase ReduceScatter + AllGather does not by itself specify this custom compressed reduction. In particular, a standard summing ReduceScatter over bitfields is wrong. NCCL outperforms their MPI implementation on Ethernet and is comparable on InfiniBand in Figure 7 (p. 17, A.6); this says nothing about a ported unikernel or Intel iGPU backend.

The paper itself records **additional memory**, a persistent fresh variance copy and temporary previous-momentum copy. The Ethernet V100s have 16 GB rather than 32 GB; some larger batches do not fit with fewer GPUs (p. 7). Compression therefore does not eliminate full-width optimizer state or establish a RAM reduction.

The [official DeepSpeed tutorial source](https://raw.githubusercontent.com/deepspeedai/DeepSpeed/master/docs/_tutorials/onebit-lamb.md), sections 1.2.3 and 1.4-1.4.1, was checked because the historical public tutorial URL returned 404 in this review. It describes accelerator-specific packing support, user-supplied momentum masks for invariant-zero gradients and checkpoint-loading residual resets. It warns that frequent **loading** can harm convergence; it does not say that every checkpoint save resets residuals. Correct resume needs rank-specific local and aggregation errors and compatible worker topology, or a documented reset policy tested for the task. These implementation observations are version-sensitive; pin a commit for any future experiment. The tutorial's historic dependency instructions are not an instruction to alter this host.

Appendix A.7, pp. 17-23, analyzes the compression stage as preconditioned, error-compensated momentum SGD, with Lipschitz-gradient, bounded stochastic-variance and bounded compression-error assumptions. The asymptotic worker-count rate is conditional on those premises and the specified learning-rate construction. It is not a proof of arbitrary p-adic training, unrestricted majority voting, physical hardware linear scaling, or any P5 x S3/8S mechanics. No new formal proof or independent empirical replication was performed here.

## Proposed optional RUSSL profile and experiment

`PROFILE-OPT-1BLAMB-RESEARCH/0.1` is a **design proposal** outside core field semantics. It treats the five-axis `4 x 4 x 4 x 16 x 16` field as typed input data with an explicit mapping to model training examples; its 16,384 sites are not automatically optimizer parameters or neurons. A future adapter would record model/data digests, parameter and layer partitions, precision, baseline LAMB implementation, warmup schedule, frozen/fresh variance, frozen `c_avg`, factor clipping, momentum normalization, sign/scale encoding, exact-zero mask, collective topology, both residual classes, worker count and restart policy. No such adapter is claimed implemented in the reference parser/container tools.

`EXP-OPT-01` would first compare uncompressed LAMB and faithful 1-bit LAMB on a fixed small, lawful dataset/model using identical sample order, batch, initialization, schedule and tuning budget. A one-worker run is a correctness/control experiment; with no inter-worker transfer, the paper's communication-saving mechanism offers no basis for a speedup claim. A later multiworker stage would preregister the model/data/backend/driver commits, number of workers, network measurements, actual bytes including scales and warmup, peak state memory, failure/restart conditions, seeds/repetition budget and paired uncertainty method.

The primary efficacy endpoint is held-out loss/score at the same processed-sample budget with a prospectively chosen noninferiority margin. The separate performance endpoint is total time to the preregistered quality target, including warmup, packing, synchronization and restart costs. Abort on nonfinite state, persistent loss divergence, inconsistent replicas or unexplained state mismatch; report failed/null runs. Ablate residual feedback, fresh variance adaptation and momentum normalization as distinct exploratory variants. Numerical masking and scale/state comparisons are necessary before timing, but passing them is not a convergence proof. Existing research evidence or favorable scores never grant `read`, `write`, `emit`, `persist`, `commit` or external actuation authority.

Machine-readable dispositions are in `research/additional_systems_claims.json`; the broader systems review is `research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md`.


---

Source: `research/REPRODUCIBILITY_AND_CANONICALIZATION.md`

# Reproducibility and Canonicalization Research Note

**Corpus:** 2.0.0. **Compatibility baseline:** existing RUSSL/1.0 identity domains. This note explains limits; it does not silently replace WP17 or invent a new cryptographic profile.

## Four different equalities

1. **Source byte equality:** exact accession bytes have the same ordinary SHA-256.
2. **Canonical source equality:** the identified UTF-8/NFC/LF source transformation yields equal bytes in its language domain.
3. **Structured identity equality:** the exact declared JSON serializer/domain emits equal bytes before hashing.
4. **Logical sample equivalence:** field samples/axes/types/metadata satisfy an explicitly selected comparison, which may survive changes in physical encoding.

A test of one equality does not prove another. Hash domains prevent confusion only if implementations use identical input bytes and versioned domain names. Archive checksum equality authenticates neither authorship nor approval.

## Python profile versus RFC 8785

The reference identity helper documents legacy compact sorted Python JSON. It should be named accordingly. [RFC 8785 JCS, June 2020](https://www.rfc-editor.org/rfc/rfc8785.html) (accessed 2026-10-09) additionally prescribes ECMAScript numeric serialization, UTF-16 property-key ordering, and preserved Unicode string content. Python codepoint key ordering and floating textual forms can differ. Simple no-whitespace/sorted-keys output is insufficient to claim JCS.

Examples motivating independent vectors: a floating value 1.0 can produce Python `1.0` versus JCS `1`; negative floating zero can differ; a supplementary-plane property key and a BMP key above the surrogate range can order differently. These are comparison examples, not a claim that every input path accepts all such values. Source NFC is a separate language normalization rule; applying it indiscriminately to JCS JSON strings changes their content.

Preserve RUSSL/1.0 identity behavior where compatibility is promised. If a JCS profile is adopted later, define a new versioned domain, accepted-number/string domain, cross-runtime vectors and identity migration map. Do not relabel old hashes as JCS.

## Reproduction obligations

Record exact serializer/runtime versions, accepted JSON domain, duplicate-key rejection, nonfinite rejection, resource limits, decimal/string treatment, Unicode handling, raw canonical bytes and raw domain prefix/NUL bytes. Run independent cross-runtime vectors covering key ordering, escapes, integer bounds, float magnitude and exponent notation. Reference-code regeneration of its own golden outputs is not independent verification.

For binary samples, declare endianness, dtype, shape/order, missing-sample rules and treatment of signed zero/NaN payloads. Preserve source blobs separately from normalized identities. Approximate numerical equality requires tolerances and scientific rationale; it cannot replace exact identity in integrity checks.


---

Source: `research/RESEARCH_FOUNDATION.md`

# RUSSL Research Foundation

**Corpus:** 2.0.0; software compatibility RUSSL/1.0. **Status:** research framework and formalized source inputs. **Review date:** 2026-10-09.

## Research objects and custody

The supplied `master_coupled_mechanics.mssl`, `lab_stack.mssl`, `product_metrics.mssl`, `final_admission.mssl` and `research/source/master_law.png` are immutable source objects. Their independently recomputed file digests match the supplied baseline registry. The image digest is `12e144e83daf6b562c64b53f7a5f609524dbad9cd908953ca882031825911d86`, also declared inside the master module. File digests, source internal IDs and internal kappa fields are different evidence objects; matching an outer digest does not validate an unspecified internal construction.

The image was visually inspected as a mathematical source. It contains more mechanics than the master's reduced literal strings: coupling, phase evolution, field terms, sphere/embedding relations and geometric/classification quantities. The reduced MSSL does not constitute a complete executable implementation of the image. No source bytes are changed to reconcile them.

## Statement and evidence taxonomy

Use `DEFINITION`, `ASSUMPTION`, `HYPOTHESIS`, `DERIVATION`, `SIMULATION_RESULT`, `EMPIRICAL_RESULT` and `EXTERNAL_REPLICATION`. Each statement record contains ID, wording, scope/domain, source path/digest, dependencies, evidence type/grade, uncertainty, counterevidence, reviewer status and revision. Formal derivation requires explicit premises and proof; test success is not a proof for untested inputs.

| Grade | Evidence | Permitted interpretation |
|---|---|---|
| E0 | Assertion / undeveloped proposal | No verified behavior |
| E1 | Definition, explicit mathematical derivation or complete formal specification | Meaning under stated assumptions; no physical truth implied |
| E2 | Deterministic computation with supplied inputs/tool/results | Reproduced behavior within recorded domain |
| E3 | Simulation with code, parameters, seeds, protocol and outputs | Model behavior; not empirical validation |
| E4 | Empirical observations with source dataset, measurement/selection model and uncertainty | Evidence for the declared observed setting |
| E5 | Independently reproduced/attested result with comparable scope | Independent evidence, not universal correctness |

Grades classify provenance, not a single maturity score; an E1 theorem and an E4 measurement answer different questions. Record unsupported assertions at E0 and supplied formulas as formalized inputs rather than labeling them proven derivations. Current software checks may support E2 for their exercised paths. There is no supplied E4/E5 evidence for P5×S³/8S mechanics.

## Question and hypothesis register

| ID / question | Falsifiable hypothesis | Design and null/comparator | Falsification criterion | Current status |
|---|---|---|---|---|
| `H-P5S3-001` Does the augmented representation improve prediction? | A completely specified M8 achieves preregistered held-out score gain above epsilon_gain against capacity-matched M7 | Paired held-out observations; equal search budget; ablations; null gain ≤ margin | Confidence interval fails the preregistered gain rule or gain disappears under fair matching | FORMALIZED-INPUT; score/data/model absent |
| `H-RESIDUAL-001` Is the added column independently informative? | Residual eta_ind exceeds a prespecified noise/conditioning null on untouched data | SVD/pseudoinverse protocol; measurement-noise controls; rank-matched synthetic matrices | Residual compatible with noise/null, unstable to solver tolerance or leakage | PROPOSED numerical study |
| `H-PENTERACT-001` Is mapping semantically reversible? | Finite supported fields preserve every selected sample/index under encoding/decoding and adapter axis permutations | Exact bit/sample comparison; exhaustive small-domain plus bounded randomized cases | Any unexplained sample/axis/type/transform mismatch | Engineering hypothesis; core fixtures only |
| `H-DISTRIBUTED-001` Does regional content addressing improve retrieval efficiency? | For a fixed workload, verified regional retrieval reduces transferred bytes and duplicate storage without changing accepted samples | Fixed data, request trace and faults; full-object baseline; identical caches/security | No cost benefit or any integrity/consistency failure in claimed scope | Architecture hypothesis; backend results absent |
| `H-METRICS-001` Are product indicators externally calibrated? | Fully defined metrics predict preregistered outcomes better than simple domain baselines and retain calibration under temporal shift | Temporal holdout; outcome definitions; domain controls; missingness/selection analysis | Poor calibration, no improvement, instability or ungoverned decision use | Labels only; no executable calibration/data |

The master gate's source `eta_ind >= epsilon_ind AND delta_8S > epsilon_gain` is a research condition, not a completed hypothesis test. The admission module also preserves a conditional catalog state and human authorization requirement. Fulfilling a statistical margin does not grant a capability.

## Methods and uncertainty

`research/MECHANICS_CRITICAL_REVIEW.md` establishes domain assumptions and source ambiguities; `research/EXPERIMENT_PROTOCOLS.md` specifies proposed experiment records, controls, analysis and reproducibility. Register primary endpoint, estimand, uncertainty method, exclusion criteria, sample-size justification and stopping rule before inspecting confirmatory outcomes. Distinguish exploratory findings and preregistered confirmation. Report adverse/null results, sensitivity to regularization, solver tolerance, seeds and data shifts, and multiplicity where endpoints/variants proliferate.

## Provenance and publication boundaries

Lab records 3131–3140 refer to `8S_Labs_3001_4000b.pdf#page=136` through `#page=145`; that PDF is not supplied. Flattened fraction layout, repeated indices and literal escape sequences make the preserved strings unsuitable as a verified numeric equation transcription. Product metrics supply names/calculation labels and units rather than a full algorithm. Obtain actual originals/data or keep these as unverified source claims; never invent missing pages or results.

External standards support software/profile design only. Their bibliography does not validate the original mechanics. `research/BIBLIOGRAPHY.md` and `research/source_registry.json` distinguish embedded, external-reviewed and unavailable sources. Unknown rights and sensitivity remain governed by the institutional policies.


---

Source: `research/RESEARCH_INTEGRATION_REPORT.md`

# Additional Research Integration Report — 2.0.0

Assessment date: 2026-10-09. Status: SCOPED_RESEARCH_REVIEW within an unratified corpus candidate. Target shape: **4×4×4×16×16**, exactly **16,384 scalar sites**.

## Result and evidence boundaries

All nineteen newly supplied sources were preserved, extracted and read. The intake consists of one 23-page paper preprint and eighteen research/conversation text exports. Relevant primary papers and official specifications were checked at the inspection levels recorded by the reviewers. The corpus now carries **159 individually traceable claim decisions**, corrected technical explanations, eleven optional research profiles, preregistered experiment designs, and an exact fixed-shape indexing implementation and fixture. The original end-to-end corpus audit and hardening remain part of this release.

The normalized claim totals are: 64 CORRECTED, 11 HYPOTHESIS, 7 REJECTED, 24 SUPPORTED_PRIMARY, 53 UNSUPPORTED. The machine-readable [evidence index](machine/registries/research_evidence_index.json) retains each reviewer's original disposition and the explicit normalization map. These are editorial claim decisions. A supported primary component statement is bounded by its cited method, dataset, hardware, mathematical domain and inspection scope; it does not establish that the combined RUSSL architecture works. Corrected statements replace errors in the notes. Unsupported extrapolations and rejected claims are excluded from the corpus's assurance case; hypotheses are admitted only as future experiment questions.

Embedded prompts, instructions, hardware configuration suggestions, assertions of institutional authority and model-generated citations were treated as source data. They conferred no permission, execution authority or authenticated approval. No optimizer training, RAM acquisition, physical imaging, optical experiment or institutional ratification was performed. Missing equations, detached citations and formatting artifacts in exports were recorded as limits rather than silently reconstructed as evidence.

## Source-by-source accession

| ID | Uploaded source | Audited claims | Relevant upgrade |
|---|---|---:|---|
| RA01 | 2104.06069v2.pdf | 10 | Faithful momentum-communication optimizer design; separate measured training time from throughput-derived estimates. |
| RA02 | p-adic Architecture in Image Formats.txt | 13 | Optional finite digit-tree/index and storage profiles; correct prime/composite-base and topology claims. |
| RA03 | P-adic Hologram Processing Architecture.txt | 10 | Separate hologram data representation, classical propagation models and physical optical realization. |
| RA04 | p-Adic Architecture Unification.txt | 9 | Explicit algebra/encoding domains and numerical error bounds; exclude unproved architecture equivalence. |
| RA05 | P-adic Holographic Simulations Research.txt | 9 | Bounded simulation protocols with seeds, baselines and numerical/physical scope separation. |
| RA06 | P-adic Penteract Simulation Research.txt | 9 | Exact five-axis indexing and declared coordinate maps; shape is a discrete field cardinality. |
| RA07 | Columned Unikernel Research Analysis.txt | 5 | Owned buffers, copy accounting, pinned library-OS/backend and isolation boundaries. |
| RA08 | IdeaPad 5i RAM Sampling.txt | 6 | Distinguish controlled allocation from host memory acquisition; unknown device capacity stays unknown. |
| RA09 | 1-Bit LAMB Unikernel Integration.txt | 6 | Optional optimizer integration with real warmup, residuals, variance and communication semantics. |
| RA10 | p-Adic 1-Bit LAMB Architecture.txt | 6 | Finite modular arithmetic may be studied; p-adic signs/square roots do not reproduce Euclidean LAMB. |
| RA11 | OAM Spatial Shifting Arithmetic.txt | 8 | OAM fixed-base shifting is a simulation result; quotient division discards remainders. |
| RA12 | Optogenetics, Connectivity, and Super-Resolution.txt | 7 | Modality-specific observation metadata, calibration, uncertainty and source dataset provenance. |
| RA13 | Quantization Trade-offs and Efficiency.txt | 11 | Separate storage/compute/accumulator/communication precision and include scale/buffer overhead. |
| RA14 | HRR in Cognitive Modeling.txt | 8 | Approximate HRR retrieval with role encoding, cleanup, abstention and exact symbolic source links. |
| RA15 | TIFF GIF Spatial-Temporal Encoding.txt | 8 | TIFF/GIF serializers need declared rank/axis metadata and round-trip contracts; format alone computes nothing. |
| RA16 | Microscopic Quantum Paradigm GIF Research.txt | 8 | Gaussian interaction frame quantum simulation is distinct from GIF image-file encoding. |
| RA17 | Holographic Logical Reasoning Research.txt | 8 | Optical full-adder design reports simulated inputs; symbolic proof/effect authority require exact validation. |
| RA18 | Holographic Computation via Image Formats.txt | 9 | Explicit encoding/operator/decoding experiment; no autonomous TIFF/GIF computation is established. |
| RA19 | Holographic Image-Based Computation.txt | 9 | Image-backed derived representations need fidelity, provenance and interoperability tests. |

Each accession includes exact original bytes and SHA-256, a delivered normalized text extract with its own digest, source-specific locators, review decisions and relevant external primary references. See [intake](research/ADDITIONAL_SOURCE_INTAKE.json), [mathematical and holographic review](research/ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md), [systems and optimization review](research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md), and the [1-bit LAMB paper audit](research/ONE_BIT_LAMB_PAPER_REVIEW.md). The two detailed claim registries provide the correction, proposed use and evidence boundary for every decision. Full reads apply to the uploaded sources; external checks are claim-directed, and identity/abstract-only checks remain labeled as such. External publication bytes were not deposited as licensed archival snapshots.

## Exact shape, indexing and compatible serialization

For c4,c5,c6 in 0…3 and c7,c8 in 0…15, the delivered layout uses c8 fastest:

    J = 4096*c4 + 1024*c5 + 256*c6 + 16*c7 + c8

Axis widths are (2,2,2,4,4), summing to fourteen address bits. [The layout profile](research/FIXED_SHAPE_INDEXING_PROFILE.md) distinguishes this address from sample precision, physical coordinate units and state-vector interpretation. All 16,384 valid tuples have exact ordinal/inverse fixture records. The helper rejects booleans, non-integers and out-of-range inputs. Endpoint-inclusive rational coordinates remain separate from digit reversal or an optional 2-adic address metric.

The field contains 128 KiB of scalar f64 payload, 64 KiB of f32, 32 KiB of u16, or 16 KiB of u8. A packed one-bit view would contain 2 KiB before scales, metadata, alignment and other state; this is a bit-count calculation, not a lossless encoding or measured memory footprint. A fourteen-bit address does not establish fourteen physical qubits or a quantum state. The optional address ultrametric groups low-order matching bits, so its neighbors do not automatically match Euclidean image neighbors.

The original active golden fixture had a material mismatch: its source declared this f64 shape, while its field descriptor declared u8 shape (1,1,3,64,64). Exact historical bytes are preserved in examples/legacy_golden/ and the original ZIP. The current fixture uses the declared scalar f64 shape and axes, with recomputed descriptor, tuple and container identities. Source programs, lowered IR objects/identifiers, four MSSL modules and master-law image remain byte-preserved. Verification now requires source/descriptor agreement and rejects the historical contradiction even when hashes are internally recomputed.

## Research corrections and admitted designs

**Optimizer and systems.** 1-bit LAMB compresses communicated momentum after warmup using signs and scales, with local and aggregate error residuals. It does not make weights, activations, variance or the whole model one bit. Its frozen variance snapshot and continuing fresh variance estimate have different roles; their bounded correction affects the adaptive factor. A packed bit majority is not a numeric allreduce mean. The paper review preserves algorithm details, model/batch/network/hardware context and the distinction between measured end-to-end time and throughput-derived estimates. The proposed optimizer adapter remains design-only. Buffer/precision accounting includes residuals, gradients, masks, padding, scales, temporary copies, runtime and backend state. A library-OS port or a consumer device's unknown RAM/controller configuration is not inferred from an address shape.

**Mathematical domains.** Prime-adic absolute values and ultrametric arguments require a prime. Composite-base digit trees and finite residue rings have their own algebra and cannot inherit field theorems by name. Continuous p-adic functions are not all locally constant. Norm is not a generic sparsity measure. Monna digit reversal is not a required global bijective/topological map to a real interval. A numerical floor does not prove singularities absent. Local/global arithmetic theorems cannot transfer arbitrary mechanics across domains. Modular sign and square-root counterexamples prevent assuming p-adic arithmetic is equivalent to the Euclidean LAMB optimizer. Optional finite encodings need explicit domains, precision, exceptions and reconstruction/error contracts.

**Holographic, quantum and optical scope.** HRR is an approximate compositional representation with retrieval noise and cleanup, not lossless compression of an arbitrary field or proof of logical truth. Role/permutation encoding, finite vocabulary, false-acceptance thresholds and abstention are needed; proposed advisory retrieval retains exact symbolic source links. Gaussian interaction frame quantum simulation is a change of quantum-state representation, distinct from a GIF image file. The OAM paper's fixed-base arithmetic is numerical simulation of mode shifts; division discards remainders and is not arbitrary real division. The reviewed optical full-adder article supplies a design/simulation result, not a measured fabricated processor. These components do not establish a self-executing image format or a unified physical architecture.

**Formats, imaging and quantization.** TIFF/GIF can carry declared representations; execution still requires an implementation and exact encoding/operator/decoding contracts. Metadata and round trips need to preserve axes, dtype, coordinate units, frame/time semantics, provenance and fidelity. Imaging claims distinguish photothermal modulation, optogenetics, labeling, connectivity inference and super-resolution, each with its own experimental scope and uncertainty. Quantization distinguishes storage, computation, accumulation and communication precision; calibration, sensitive exceptions, saturation, error units and task quality remain explicit. Performance/energy/quality numbers from unmatched hardware, models or tasks are not admitted as RUSSL guarantees.

## Applied corpus changes and remaining experiments

The reviews feed informative implementation sections in WP04, WP07, WP12, WP13, WP14, WP15, WP16, WP18, WP21 and WP26. The original 293 requirement IDs and normative requirement tables are retained exactly. The accession/source registers, claim records, indexing registry and scientific evidence boundaries make each admitted design reviewable. Core mechanics, runtime authorization and effect authority receive no scientific or operational extension from these notes.

The eleven profiles span finite digit indexing/diffusion, classical hologram propagation, quantum-state frame modeling, optical arithmetic, image encodings, optimizer communication, owned buffers, quantization, HRR advisory retrieval and imaging observation metadata. Their exact IDs and experiment plans are in the two detailed reviews. These are proposals, not registered institutional standards or implemented adapters. Experiment statuses are NOT_RUN/design-only; generated address records are mathematical fixtures, not experimental observations.

Before any comparative result is accepted, pin code/library/device/backend versions, dataset/model digests, axis/scalar/precision domains, seeds, sample budget, endpoints, tolerances, exclusion/failure rules and statistical method. Compare against an exact or full-precision reference at matched output quality, include complete persistent and temporary resource accounting, preserve raw measurements and report null/failed runs. Physical or biological implementations require a separate real study and its accountable approvals; this document creates no such study. Cross-domain equivalence requires a stated mapping and proof or controlled falsification test.

## Verification and release limits

The offline package verifier checks all nineteen source and extract digests, complete source/claim indexing, the fixed shape, fixture digest, structural parsing, schema profile, tuple bindings, provenance and review status. Concrete regressions include all 16,384 index/inverse pairs and hostile parser/container/schema/integrity cases. [Current verification results](evidence/CONFORMANCE_RESULTS.json) and [release integrity](evidence/RELEASE_INTEGRITY.json) record the executed scope; detached hashes establish byte consistency, not authorship, signatures, empirical correctness or institutional approval. Same-environment repeated packaging and extracted-archive verification are recorded with the delivered release.

Requirement coverage remains deliberately narrower than package verification: 34 obligations have scoped partial evidence and 259 are NOT_RUN; all 293 remain unverified as complete obligations. The 28 work-package completion records require accountable review. Full language/runtime implementation, adapter replication, scientific validation, authenticated trust roots, rights/licensing closure and institutional ratification remain open under [unresolved issues](UNRESOLVED_ISSUES.md). The result is a substantially expanded and auditable research corpus candidate with applied software fixes, explicit evidence limits and concrete next experiments.


---

Source: `institutional/ARCHITECTURE_DECISIONS.md`

# Architecture Decision Records — Corpus 2.0.0

These are documented design dispositions of the audited candidate, not fabricated historical committee votes. Institutional acceptance remains pending. Each decision is scoped to the corpus baseline and linked to its defeaters.

## ADR-01 — Preserve logical semantics independently of storage

**Problem:** the superseded prototype exposes storage-specific state types/paths as core operands. **Disposition:** logical field, source/IR/tuple and mathematical identities remain core; TIFF/OME-Zarr/object storage are explicit adapters. **Rationale:** physical reorganization should not redefine a logical computation. **Evidence:** architecture charter, WP04/WP13, prototype supersession, adapter contracts. **Consequences:** raw source/export identities differ from logical sample equivalence; adapter receipts record loss and permutation; deployment performance is separately tested. **Defeater:** hidden backend assumptions in future implementations need differential verification.

## ADR-02 — Preserve source bytes and classify claims

**Problem:** MSSL true assertions and missing PDF references can be mistaken for proven experiments. **Disposition:** preserve bytes and distinguish assertions, definitions, simulations, observations and replication. **Evidence:** source hashes, visual master-image review, research foundation and critical mechanics review. **Consequences:** no guessed equations or invented datasets/results; a corrected transcription is a new derivative. **Defeater:** authentic originals and independent experiments are still required.

## ADR-03 — Retain RUSSL/1.0 identity compatibility

**Problem:** stronger external canonicalization terminology could change hashes silently. **Disposition:** identify the legacy Python JSON profile accurately; retain existing language/domain meaning unless a separately versioned migration is adopted. **Evidence:** WP17, reference serialization helper, canonicalization note. **Consequences:** JCS is a comparison, not a replacement label; cross-runtime proof remains scoped to actual vectors. **Defeater:** serializer/numeric/Unicode behavior outside tested accepted inputs can disagree.

## ADR-04 — Fail closed on unavailable authorization

**Problem:** mathematical admission or schema-shaped signatures can masquerade as permission for external effects. **Disposition:** require actual deployed verification; unavailable verifier/trust keeps effects unavailable. **Evidence:** WP09–WP11 and limitations. **Consequences:** reference validation cannot promise a deployed execution engine, key ownership or institutional consent. **Defeater:** configuration of a production trust/revocation path requires independent security review.

## ADR-05 — Proposed governance without invented ratification

**Problem:** construction GO can be misread as institutional acceptance. **Disposition:** use a candidate status and proposed review roles/quorum; real records alone can elevate status. **Evidence:** governance charter, assurance and change-control policies. **Consequences:** independent review, rights/privacy/custody and deployment decisions remain explicit. **Defeater:** no appointed institution, quorum or external certificate is supplied.


---

Source: `institutional/ARCHIVAL_POLICY.md`

# Archival, Fixity and Custody Policy

**Baseline:** corpus 2.0.0. **Status:** proposed institutional policy; no repository or retention authority is appointed here.

## Objects and inventory

Separate supplied original sources, released derivatives and operational evidence. A release deposit preserves sources, specifications, schemas, registries, examples, tools/tests, actual results, limitations, citations, provenance, decisions and manifest. A derived export never replaces the source deposit. A file known only by digest is unavailable, not archived.

Record deposit ID, corpus/language/profile versions, origin archive hash, manifest hash, finished archive hash outside that archive, custodians, storage locations, access class and disposition. Avoid self-reference: the manifest does not hash itself; an external receipt binds the finished manifest. Checksums authenticate neither publisher nor rights without an independently verified trust process.

## Custody workflow

| Stage | Required record | Failure disposition |
|---|---|---|
| Accession | Original name/size/hash, time, supplied origin, safe inventory, rights/privacy status | Quarantine corruption/ambiguous paths; preserve source |
| Assembly | Change log, inventory, tools/runtime, current evidence and limits | Do not substitute stale results |
| Deposit | Two checked copies on separate failure domains plus one recoverable offline/immutable copy when available | Mark redundancy pending until established |
| Fixity | SHA-256 at accession/transfer/restore; quarterly complete scans after adoption | Preserve suspect copy; compare independent copy; open incident |
| Recovery | Annual clean restoration and declared verifier run, including failures/time | Downgrade recovery claim until repaired |
| Migration | New object/format ID, tools, before/after hashes, losses and decision | Preserve previous deposit |
| Disposal | Written retention authority, scope, reason and metadata tombstone | No deletion inferred from supersession |

Timing/copy counts above are proposed targets, not completed activities. Adoption requires accountable custodians and actual service targets.

## Correction and discovery

Released deposits are immutable snapshots. Issue a new version with erratum/withdrawal and predecessor link. Changed source bytes create a new accession; preserve the original four MSSL modules and image even if corrected transcriptions arrive later. Restrict sensitive data while keeping appropriate discovery/access metadata.

Goals of findability, governed access, interoperable description and reuse draw on the [FAIR Guiding Principles, 2016](https://pmc.ncbi.nlm.nih.gov/articles/PMC4792175/) (accessed 2026-10-09). This is not FAIR certification. DOI registration, indexing, persistent access and affirmative licensing require external custody decisions.

A proposed provenance crosswalk treats immutable files as entities, extraction/build/test/migration as activities, and accountable custodians/tools as agents, with usage/generation/derivation/association/invalidation relationships. This draws on [PROV-DM, W3C Recommendation 2013-04-30](https://www.w3.org/TR/2013/REC-prov-dm-20130430/) (accessed 2026-10-09). It does not assert that packaged receipts are valid PROV serializations or that unidentified agents have authenticated identities.


---

Source: `institutional/ASSURANCE_CASE.md`

# RUSSL Institutional Assurance Case

**Corpus release:** 2.0.0. **Language compatibility:** RUSSL/1.0. **Status:** research and institutional review candidate. **Assessment date:** 2026-10-09.

## Scope and decision

This is a structured argument for using the package as a bounded research specification and reference implementation baseline. It is not an institutional acceptance decision. A passing local verifier supports the exact checks it performed on the identified release; it does not establish completeness, correctness of every implementation, safe deployment, or scientific validity.

The top claim `AC-0` is: **the release is inspectable, reproducible to its declared extent, and suitable for independent technical review when residual limitations accompany downstream claims.** Acceptance conditions are a verified inventory, preserved inputs, explicit separation of experimental mechanics, software requirements, authorization and adapters, actual executable-check results, and an unresolved-evidence register. Its decision is `CANDIDATE`, not `RATIFIED`.

## Claim–argument–evidence–defeater register

| Claim | Argument and control | Evidence a reviewer should inspect | Defeater / residual limit | Acceptance scope |
|---|---|---|---|---|
| `AC-1` Source custody is reviewable | Preserve original MSSL/image/lineage bytes; distinguish commentary from sources | `SOURCE_AUTHORITY.md`; MSSL baseline registry; source image; manifest and checksum set | Digests prove byte identity, not authorship, ownership or accuracy. Missing PDF/parent sources remain absent | Supplied-byte preservation |
| `AC-2` Boundaries are explicit | Core language, field and tuple identity independent of physical formats; separate adapters | Architecture charter; WP04/WP13/WP16; adapter profiles; actual leakage checks | Lexical leakage tests cannot prove semantic independence; future backends can add hidden assumptions | Design plus tested fixtures |
| `AC-3` Identity paths are repeatable | Identified normalization, canonicalization profile, domains and module digests | WP17; reference tool; identity vectors; verified examples | Python JSON serialization is not automatically RFC 8785 JCS; alternate runtimes and numeric/Unicode edges require differential tests | Reference accepted-input domain |
| `AC-4` Evidence differs from authorization | Mathematical admission does not grant effects; missing deployment verification keeps effects unavailable | WP09–WP11; capability schema/fixtures; limitations statement | Schema validity/signature-shaped text is not verified signature; no deployed trust/revocation infrastructure supplied | Denial and structural validation |
| `AC-5` Conformance is auditable | Separate documentary coverage, fixture checking, behavioral tests and independent witness | Requirement/test registries; current conformance results; verifier code | Generic assertions, self-generated goldens and counts do not establish independent correctness | Check-specific actual outcomes |
| `AC-6` Research claims are bounded | Formalized inputs, falsifiable protocols, preregistration and explicit provenance gaps | Research foundation, experiment protocols and mechanics review | No numerical result/empirical dataset arises from writing protocols; undefined scores defeat study readiness | Study-design readiness |
| `AC-7` Adapters are reviewable | Versioned mappings, losses, rejections and test obligations | TIFF/OME-Zarr profiles; research source registry | No actual external-format adapter or certification is established by documentation | Proposed contracts |
| `AC-8` Operations are accountable | Proposed independent roles, gates, custody, response, rights and privacy | Governance charter and institutional policies | Roles unappointed; quorum, custody and signing have not occurred; policy is not operating evidence | Proposed adoption process |

## Evidence qualification

Each evidence entry needs path/ID, digest where material, producing tool/version, input scope, run time, result and review status. Absence is `NOT_SUPPLIED`; planned work is `PROPOSED`; `PASS` requires an actual recorded run. Do not aggregate these into a percentage implying scientific or production readiness.

Legacy completion `GO` is construction bookkeeping. It is not external ratification or institutional authorization. Current release evidence and limitations govern this package's status.

## Review procedure

1. Recompute inventory from clean extraction; compare preserved source digests with the original archive.
2. Review implemented boundaries and adversarial checks, including the test harness and oracle.
3. Challenge parser, identity and coordinate assumptions through independent reviewers/implementations.
4. Classify each claim `SUPPORTED_WITHIN_SCOPE`, `PARTIAL`, `UNSUPPORTED` or `WITHDRAWN`; append evidence and decisions.
5. Authorize an institutional use only through appointed human roles and an adopted decision record.

No external assessor, regulator, university, publisher or standards organization has attested to these claims in supplied evidence.


---

Source: `institutional/CHANGE_CONTROL_POLICY.md`

# Change Control and Release Policy

**Corpus:** 2.0.0. **Language/identity:** RUSSL/1.0 unless an explicit versioned change states otherwise. **Status:** proposed operating policy.

## Separate version axes

Bundle, language, tuple ABI, schema, adapter, identity domain and tool implementation have distinct versions. A corpus major release can improve documentation/evidence while retaining RUSSL/1.0 meaning. It cannot silently change accepted syntax, identity bytes or effects. Evaluate compatibility against artifacts and behavior, not filename/version alone.

Patch changes preserve conforming meaning; minor changes are additive within the declared profile; accepted-meaning/identity changes require migration analysis. A security fix may intentionally reject previously accepted unsafe inputs: record that compatibility effect.

## Proposal dossier

Record ID, sponsor, problem evidence, affected requirements/files, exact before/after behavior, version axes, compatibility matrix, security/privacy/research impact, migration/rollback, checks, reviewers/conflicts, dissent, decision and predecessor. Identity changes include raw hash-input vectors and old/new identity mapping; migration creates new objects without overwriting old evidence.

Grammar/lowering, Unicode/numbers, tuple order, coordinates, effects/grants, trust roots, bindings, adapters and resource limits need technical, security and reproducibility review. Mechanics changes also need source/provenance and domain review. Rights changes require actual rights-holder authority.

## Gates

| Gate | Review question | Evidence |
|---|---|---|
| `CC-1` Inventory | Are sources preserved and files intentional? | Safe inventory, hashes, explicit exclusions |
| `CC-2` Behavior | Which requirements are implemented versus documentary? | Current tests, adverse vectors, code/oracle review, gaps |
| `CC-3` Compatibility | Is promised RUSSL/1.0 meaning/identity retained? | Old/new fixture comparison, migrations, identity vectors |
| `CC-4` Research | Are assumptions and evidence grades honest? | Hypothesis register, provenance gaps, supplied results |
| `CC-5` Deployment | Are real effects/trust/backend/resource policies configured? | Deployment evidence; never inferred from corpus run |
| `CC-6` Institution | Have appointed reviewers accepted a concrete use? | Dated quorum/conflict record; otherwise candidate |
| `CC-7` Publication | Are custody, rights/privacy and destination authorized? | Custodian decision, rights inventory, access class |

Researchers may assemble/review a candidate without ratification. Institutional acceptance, deployment and public release are separate decisions. A gate failure affects the scope it covers.

Proposed security practices include protecting source/release artifacts, requirements review, boundary verification and vulnerability response. They are informed by [NIST SP 800-218, SSDF 1.1, February 2022](https://csrc.nist.gov/pubs/sp/800/218/final) (accessed 2026-10-09). Full SSDF implementation and NIST endorsement are not claimed.

## Emergency correction

Contain compromise or authorization bypass, preserve failing artifacts/environments, issue a scoped advisory, and create reviewed correction with regression checks. Emergency status does not bypass trust/identity review. Restore a known-good immutable release only after checking it will not reintroduce the defect. Keep withdrawn versions and permitted research-only uses explicit.


---

Source: `institutional/INCIDENT_RESPONSE_POLICY.md`

# Integrity and Security Incident Response Policy

**Status:** proposed custodian/implementer operating policy. No team, contact or response deadline is represented as established.

## Classification

`IR-1`: corruption, unauthorized mutation or release hash mismatch. `IR-2`: parser/schema/authorization bypass. `IR-3`: key, credential or publishing compromise. `IR-4`: restricted/personal material disclosure. `IR-5`: materially false provenance or scientific claim. Severity depends on boundary, exposure, reproducibility and consequence.

## Workflow

1. Assign ID, discovery time, affected versions/paths, hash-bound reproducer, observed/expected behavior, exposure and owner. Restrict secrets/personal evidence.
2. Quarantine suspect artifacts and suspend affected effects/publication. Revoke compromised authority through the actual deployment mechanism. Preserve original evidence.
3. Reconstruct source/build/release chain, defect scope and affected identities; retain tool/environment versions. Unexplained failures remain unresolved.
4. Produce a reviewed new release/configuration, meaningful regression vector, compatibility/identity explanation and relevant rerun evidence.
5. Recover from verified clean deposits and trust configuration; measure actual expected behavior.
6. Accountable institutions determine disclosure recipients/timing. Advisories state affected versions, scope, fix/workaround and uncertainty without secrets.
7. Record root cause, control gaps, retained evidence, owners and closure criteria; preserve predecessor/advisory records.

Urgent containment requires an adopted incident role; it is not retrospective ratification. This policy triggers no unsolicited third-party notification.

The proposed procedure is informed by [NIST SP 800-61 Rev. 3, April 2025](https://csrc.nist.gov/pubs/sp/800/61/r3/final) (accessed 2026-10-09), which integrates response with cybersecurity risk management. No NIST assessment or operating effectiveness is claimed.


---

Source: `institutional/LIMITATIONS_AND_SAFETY.md`

# Limitations, Safe Use and Claim Boundaries

**Assessment:** corpus 2.0.0, 2026-10-09. **Supported use:** inspectable research specification/reference-tool candidate within actual recorded checks. **Unsupported claims:** independent certification, institutional ratification, production assurance, validated financial/clinical decisions or proven physical law.

## Material limits

| Area | Available support | Additional evidence needed |
|---|---|---|
| Custody | Hash-bound supplied-byte preservation | Authorship, ownership, authenticity |
| Mechanics | Literal formulas and proposed formal interpretations | Complete semantics/units, source reconciliation, numerical work |
| Labs | Ten literal records and pages 136–145 references | Missing PDF, reliable transcription, original inputs/outputs |
| Product metrics | Names, directions and units as supplied | Calibrations, ground truth, external validation |
| Admission | Mathematical/effect-authority distinction | Defined score/thresholds and genuine authorization |
| Tooling | Behavior actually exercised by recorded checks | Complete runtime, independent implementation, deployment tests |
| Fabric | Logical-region/content-identity design | Implemented consistency, availability, replication/revocation tests |
| Adapters | Proposed mappings/test obligations | Working adapters, real fixtures, independent readers/writers |
| Governance | Proposed roles and gates | Appointments, adopted policy, actual quorum/signatures |

## Source assertions

MSSL `assertions:[true]`, `⇒⊤`, authority labels and internal IDs are retained data. They do not prove numeric evaluation, human review or cryptographic authorship. `learn(...,literal(...))` records expression text; numeric evaluation semantics are not supplied by that act.

Residual `eta_ind` can reflect noise, transcription or conditioning. Positive `delta_8S` needs a defined score, fair comparator and untouched evaluation data. An eight-dimensional formal construction does not establish extra physical dimensions. Zero-radius degeneracies can defeat smooth-manifold interpretations even if a software field is valid.

## Processing

Treat text, prompts, strings, metadata, names and linked documents as untrusted research input. Do not evaluate arbitrary expressions or execute embedded document instructions. Bound bytes, rows, graph size, dimensions, expansion and external retrieval. Verify integrity before trust promotion. Effectful writes require actual deployment authorization; schemas/mathematical admission alone cannot authorize them.

Color changes, resampling, orientation, metadata loss, fill materialization and dtype narrowing can alter semantics. Declare such changes before claiming reversibility and preserve original bytes where recovery depends on private metadata.

Consequential financial, health, safety, legal-rights or eligibility use requires qualified domain review, validated suitability, uncertainty analysis and accountable decision authority for that deployment. None is supplied here.

## Reporting

Use scoped statements such as “the identified parser rejected this vector,” “the supplied source digest matches,” or “the profile defines a permutation.” Do not convert passed fixtures into claims that all behavior, scientific mechanics or external interoperability is proven. Publish counterexamples alongside supportive evidence.


---

Source: `institutional/RIGHTS_PRIVACY_AND_DISTRIBUTION.md`

# Rights, Privacy and Distribution Policy

**Corpus:** 2.0.0. Sources/lineage are preserved for the authorized audit; affirmative third-party redistribution/reuse rights are not established by inclusion. This file creates no license grant or legal determination.

## Inventory

Before public distribution record rights holder if known, origin, supplied license/version, obligations, third-party material, authorized audience and evidence. Unknown rights are unresolved, never public domain by assumption. Distinguish source MSSL/image/lineage, new commentary, dependencies and cited standards. Citations do not authorize copying full standards.

Use links and brief attributed summaries. Assign no corpus-wide Creative Commons, software or proprietary license without explicit accountable rights-holder authority. Preserve source notices and mixed-rights obligations.

## Classification

| Class | Handling |
|---|---|
| Publicly authorized | Approved release/provenance only; preserve permission |
| Internal research | Approved research audience/access record |
| Confidential/personal | Restricted access; minimum copies; separate identifying evidence |
| Unknown | Review before external sharing; preserve accession |

MSSL names/authority strings are unverified provenance, not contacts or appointments. Image metadata may contain subjects, locations/devices or acquisition information; decide explicitly before external export. Security/access logs also need minimization, retention and restricted handling.

Publication records audience, rights/privacy review, redactions, omissions and link to retained full accession. Redacted derivatives receive new identities/loss statements. Institutions handle restriction/takedown requests with retained decisions; sources are not silently rewritten. Non-sensitive synthetic fixtures may accompany methods when observations remain restricted.

No rights-holder appointments, original PDF license, privacy review, public publication authorization or complete dependency-rights review is supplied. These are external decisions; private inspection and improvement within the authorized audit do not require inventing them.


---

Source: `governance/GOVERNANCE_CHARTER.md`

# RUSSL Governance Charter

**Corpus:** 2.0.0. **Language:** RUSSL/1.0. **Status:** proposed charter; adoption and appointments are not supplied.

## Authority

This defines review for language, implementation, research and releases. It establishes no existing committee or external endorsement. Legacy internal GO and named MSSL authority strings are neither votes nor appointments. Actual decisions identify body/persons/roles, scope, date, conflicts, evidence and effective version.

Requirement terms in adopted requirements use [RFC 2119, March 1997](https://www.rfc-editor.org/rfc/rfc2119.html) and the uppercase clarification [RFC 8174, May 2017](https://www.rfc-editor.org/rfc/rfc8174.html) when capitalized (accessed 2026-10-09). This does not make RUSSL an IETF standard.

## Proposed roles

| Role | Responsibilities | Safeguard |
|---|---|---|
| Language editor | Grammar/semantics, IDs, ABI, compatibility | Cannot alone accept own proposal |
| Implementation reviewer | Behavior, vectors, oracle quality | Code and oracle reviewed separately |
| Security reviewer | Effects/trust, integrity, resources, adverse inputs | Explicit objection disposition |
| Research/provenance reviewer | Custody, hypotheses, assumptions, experiments/grade | No empirical claim accepted solely by author |
| Interoperability reviewer | Standard pins, mappings/losses, external readers/writers | Actual external evidence required |
| Release custodian | Inventory, receipts, archive/notices | Independent final-byte check |
| Institutional sponsor | Approved use, rights/privacy audience, operating authority | Deployment distinct from admission |

Multiple roles held by one person reduce independence and are disclosed; they do not create independent votes.

## Proposed quorum

Adoption appoints at least three distinct voting reviewers. Ordinary normative proposals require three participating reviewers, at least two affirmative votes, language/implementation and security coverage plus research/provenance where relevant, and disposition of every substantive objection. High-impact identity, trust, effect or scientific-status changes require all three affirmative votes and relevant specialist concurrence. Ties/unresolved safety or authority objections yield HOLD; missing quorum yields CANDIDATE.

This is a proposed future quorum, not completed review. Invented names, signatures or retroactive approvals are prohibited. External certification requires the actual body's process.

## Lifecycle

`DRAFT → REVIEW → PROVISIONAL → RATIFIED`, with HOLD, REJECTED, WITHDRAWN and SUPERSEDED recorded outcomes. Provisional is bounded review status, never permission for effects. Ratified needs a real decision record. New contrary evidence can reopen a decision; retain the original.

Use the change-control dossier. Archive deltas, risks, dissent, evidence, migration and affected release identity. Appeals identify new evidence/procedural defects and receive separate review where available.

## Extensions and research

Extensions use namespace, scope, compatibility and rejection behavior; never silently redefine operators/coordinates. Research elevation needs a complete algorithm/domain/units, appropriate evidence, independent review and migration. Normative software use still does not prove a physical or economic interpretation.

## Adoption record

Supply appointments, conflicts/quorum policy, rights/access decisions, actual signer/trust policy, custody, incident owner and review cadence. Until then the package remains an institutional candidate. Corpus 2.0.0 does not claim completed adoption.


---

Source: `interoperability/OME_ZARR_PROFILE.md`

# OME-Zarr / NGFF Adapter Profile

**Profile ID:** `RUSSL-OME-ZARR/2.0.0`. **Status:** proposed external adapter; not implemented or certified by this corpus. **Core:** RUSSL/1.0.

## Versions and source contract

Pin [OME-Zarr / NGFF 0.5](https://ngff.openmicroscopy.org/0.5/) and [Zarr core specification 3.1 as observed 2026-10-09](https://zarr-specs.readthedocs.io/en/latest/v3/core/index.html). `zarr_format` remains 3; it is distinct from the core document minor version. NGFF 0.5 uses Zarr v3 with OME metadata under `attributes.ome` in `zarr.json`. Multiscale arrays have 2–5 axes, ordered time, channel/custom, then space; array `dimension_names` match declared axis names. Dataset transforms contain scale and optional following translation, with group transforms applied afterward. Labels use integer types. These facts define the external boundary; accessed 2026-10-09.

The Zarr latest URL is mutable: capture exact text/commit and codec specifications before deployment. This receipt pins the reviewed document version/date, not a future website state. Do not interpret 0.4/v2 `.zattrs`, `dtype`, `compressor` or `order` as 0.5/v3 metadata without an explicit migration profile. The minimum proposed writer uses the ordinary named codec-object form compatible with the reviewed v3.0 subset, with every codec/version separately pinned; unknown extensions are not executed.

## Exact RUSSL axis permutation

The RUSSL profile chooses core axis order `(t,z,c,y,x)` = `(n4,n5,n6,n7,n8)`. This is an adapter convention, not an alteration of WP04. Standard-name example `(t,c,z,y,x)` becomes `(t,z,c,y,x)` via permutation `(0,2,1,3,4)`. For dimensions `(T,C,Z,H,W)`, output shape is `(T,Z,C,H,W)` and `F[t,z,c,y,x]=A[t,c,z,y,x]`.

| Declared input axes | Core shape | Mapping |
|---|---|---|
| `(y,x)` | `(1,1,1,H,W)` | Singleton time/depth/channel anchors 0 |
| `(z,y,x)` | `(1,Z,1,H,W)` | Depth to n5 |
| `(c,y,x)` | `(1,1,C,H,W)` | Channel to n6 |
| `(t,y,x)` | `(T,1,1,H,W)` | Time to n4 |
| `(c,z,y,x)` | `(1,Z,C,H,W)` | Permute c/z and insert singleton time |
| `(t,c,z,y,x)` | `(T,Z,C,H,W)` | Permutation above |

Axis names in NGFF need not be these strings. The adapter requires a supplied map based on unique names, types and intended meaning; it never guesses from shape. Nonstandard/custom axes, missing spatial semantics, multiple multiscales and collections need explicit selected-image/profile records. More than five logical dimensions, zero-length dimensions or unsupported sample types cannot become a valid nonempty core field by dropping information; reject or archive opaquely.

## Coordinate and pyramid treatment

Preserve physical units/calibration independently of normalized coordinates. For a non-singleton core axis, `c=-1+2*i/(n-1)`; for singleton `c=anchor` (default 0). The physical map is retained as a distinct ordered transform expression. For explicit dataset scale/translation `p=s*i+b` followed by group `p'=g*p+h`, record composed `p'=(g*s)*i+(g*b+h)` with every vector permuted consistently. Negative/zero/nonfinite scales require explicit supported-domain review; never silently resample them.

Each level has its own samples, shape, declared physical transform and root relationship. Preserve the normalized root extent contract while recording physical center/edge extent differences. Odd sizes and cropping can make exact physical extents differ; this is not repaired by forcing the normalized endpoints to imply equal physical coverage. If no valid WP04 relationship is established, retain separate derived fields and mark pyramid association unresolved. Unknown downsampling method remains unknown; do not manufacture a reproducible reduction from a method label.

## Metadata and sample policy

Chunks, shards, storage transformers and keys remain physical placement, never logical core coordinates. Record supported codec chain, dtype, chunk grid/key encoding, fill policy and metadata snapshot. Decode supported samples exactly; missing chunks use a validated declared fill policy, while fetch failures/corruption remain errors. Do not collapse missing-data masks into numeric zero. A nonfinite float fill encoded as a string in Zarr metadata is not permission to emit invalid numeric NaN in identity-critical JSON; bitwise floating samples need a separate binary identity profile.

Labels become separate integer fields with image association, coordinate mapping, label properties and unknown metadata retained. Rendering windows/colors are display metadata and never modify canonical intensities. Plate/well/series organization stays provenance/collection metadata; flattening it into time/depth without an explicit map is prohibited. Preserve source `zarr.json` bytes and unknown attributes as opaque evidence with sensitivity review.

## Loss and proposed acceptance

Rechunking/recompression may preserve declared logical samples while changing bytes. Lossless field equivalence is different from complete source-store reconstruction. Declare lost labels, rendering metadata, units, collections, transforms, fill distinctions, dtype narrowing or resampling per property. `REVERSIBLE_WITH_METADATA` requires a tested inverse; unavailable codec/extension/transform yields `UNSUPPORTED` rather than a fabricated mapping.

Tests need genuine 0.5/v3 fixtures and independent tools: 2D through 5D, nonstandard axis names with explicit maps, all axis permutations, multiple levels with odd sizes, scale/group composition, integer labels, fill/missing chunks, codec allowlist, collection metadata and round trips. Adverse tests cover escaping paths, remote references, unknown required extensions, mixed metadata versions, mismatched dimensions, huge shapes, malformed codec chains, source changes during reads and corrupt chunks. Record exact fixture hashes, tools/spec snapshots and observed sample/metadata results.

No such external-format execution results are supplied by writing this profile. Current coordinate fixtures establish only their own core behavior. Adapter conformance and production availability remain unresolved.


---

Source: `interoperability/STORAGE_ADAPTER_CONTRACT.md`

# Storage Adapter Contract — Research Candidate

**Profile:** `RUSSL-ADAPTER/2.0.0`; core language compatibility RUSSL/1.0. This expands the WP13 design boundary. No backend, transaction engine or deployment implementation is established by this document.

## Semantics and identities

An adapter translates physical bytes/locations to logical immutable handles. Physical keys, TIFF offsets, Zarr paths, object-store ETags and filesystem names never become core field coordinates or authorization. Distinguish `source_blob_sha256` (exact imported bytes), core domain-separated identities (WP17), decoded logical-sample equivalence, and derived export bytes. Identical decoded fields can have different source/export hashes.

## Required abstract interface

| Operation | Precondition and result | Failure/limit |
|---|---|---|
| `put(bytes) → digest` | Accept bounded byte string; compute content digest; publish immutable content only after complete write and verification | Partial writes not discoverable as complete; caller receives a stable failure |
| `get(digest) → bytes` | Exact digest-bound object, verified before returning trusted bytes | Missing, denied and corrupt are distinct outcomes; no silent substitute |
| `has(digest) → bool` | Advisory availability at observation time | Not proof of integrity, durability, permission or future availability |
| `verify(digest, bytes)` | Recompute selected digest with explicit domain/algorithm | Fail on malformed digest or mismatch; never trust ETag as equivalent |
| `capabilities() → record` | Profile ID/version, size limits, integrity mode, consistency, atomicity, permitted methods, supported codecs | Unsupported capability remains absent; do not infer it from provider brand |

Logical WP13 methods are retained; this document specifies review obligations rather than adding core operators. A backend that only stores mutable paths needs an immutable object mapping before conforming.

Optional `get_range` uses checked half-open byte ranges and total-object identity. Range bytes alone cannot verify a whole-file digest: obtain complete object or a separately defined authenticated chunk/Merkle proof. Optional `get_region` returns requested logical intervals, sample/type metadata, membership evidence and declared missing samples. Optional pin/replication/listing methods record availability hints, never redefine core meaning. A promised compare-and-swap or transaction needs a precise deployment linearization point and fault tests; unsupported multi-object atomicity cannot be synthesized from `put`.

## Adapter receipt

A receipt identifies adapter/profile and implementation version, source and output identities, standards versions, input inventory, logical shape/type, axis permutation, coordinate transforms/units, codecs, metadata preservation map, output classification, observed losses, resource limits, runtime environment and actual test results. `LOSSLESS` refers to declared logical-sample/semantic equivalence; exact source-byte recovery is a separate property. `REVERSIBLE_WITH_METADATA` requires all inverse information preserved and exercised. `LOSSY` lists each changed/discarded property and error metric. `UNSUPPORTED` yields a rejection or explicitly separate opaque archival object; it is not a successful lossless field import.

## Hardening and trust

Treat headers, dimensions, strides, counts, ranges, codec names, nested metadata and referenced paths as untrusted. Before allocation, bound every dimension/product and decoded size, recursion/IFD count, path depth, codec expansion, CPU time and metadata bytes. Parse declaratively; use a supported-codec allowlist and isolated decoders. Reject path traversal, absolute/drive/network paths and references escaping an approved dataset root. Retrieval of remote linked content requires a deployment allowlist and authorization; importing a URI does not authorize its fetch.

An absent Zarr chunk, failed network request, corrupt object, transparent pixel and sparse undefined sample are distinct states. Capture snapshots/version IDs or complete digest inventories to prevent mixing source versions during partial reads. Enforce access independently of deduplication; content-addressed names can leak existence. Do not log credentials or personal metadata into unrestricted provenance.

## Proposed acceptance matrix

| Obligation | Positive test | Adverse test | Current evidence |
|---|---|---|---|
| Adapter substitution | Same declared field under two backends | Backend key leaks into core identity | Core design/fixtures only |
| Integrity | Complete verified put/get | Corruption/truncation/ETag substitution | Deployment test required |
| Resource limits | Bounded exact decoded size | Overflow, huge shape, expansion bomb | Adapter implementation required |
| Consistency | Immutable snapshot retrieval | Mutation during import | Backend evidence required |
| Loss accounting | Reversible import/export through independent reader | Dropped tag/axis/dtype/transform | External adapter evidence required |
| Authorization | Approved effect with real trust verification | Missing/expired/revoked/wrong-scope grant | Deployment evidence required |

Tests are proposed adapter acceptance obligations, not newly claimed executed results. A conformance report identifies implemented capabilities and unsupported cases explicitly.


---

Source: `interoperability/TIFF_PROFILE.md`

# TIFF, BigTIFF and Cloud Optimized GeoTIFF Adapter Profile

**Profile ID:** `RUSSL-TIFF/2.0.0`. **Status:** versioned design candidate; no implemented importer/exporter or external conformance claim. Core language remains RUSSL/1.0.

## External source pins

The source contract uses **TIFF Revision 6.0, final 1992-06-03**, authored by Aldus and available as an [ITU-hosted original specification](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf). Classic headers distinguish byte order and use version 42/32-bit offsets. **BigTIFF** is the [LibTIFF BigTIFF Design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html), observed in LibTIFF documentation 4.7.2: version 43, 8-byte offsets, reserved field zero, 16-byte header and 20-byte directory entries. **COG** is [OGC 21-026, version 1.0, 2023-07-14](https://docs.ogc.org/is/21-026/21-026.html), with tiled imagery, overviews, GeoTIFF keys and HTTP range conformance classes. Accessed 2026-10-09.

The TIFF mirror supplies the original text; BigTIFF documentation URL is mutable and has no separately asserted numbered design revision. A production profile must preserve a checked specification snapshot and independently pin decoder/codec versions. BigTIFF is not a compression codec. A tiled TIFF alone is insufficient evidence of COG conformance.

## Proposed RUSSL mapping

The initial review subset accepts supported grayscale or RGB samples with an exact decoded dtype and a rectangular plane. Other variants remain explicitly unsupported until tested. Map decoded input row/column `(y,x)` to core indices `(0,0,k,y,x)` of shape `(1,1,C,H,W)` for scalar channel planes; a packed pixel alternative requires a separately identified sample profile. `C=1` for scalar grayscale. Endianness belongs to byte decoding, not coordinates.

| Imported property | RUSSL-side rule |
|---|---|
| Image dimensions and sample descriptors | Preserve width/height, sample count, integer signedness/float width/bit depth and declared interpretation in receipt; reject inconsistent counts |
| Contiguous/planar storage | Decode same logical channel samples; physical organization does not change core axes |
| Orientation | Preserve raw decoded row/column order plus orientation metadata; a display-normalized derivative records explicit permutation/reflection and inverse |
| Photometric interpretation / palette / alpha | Preserve interpretation, color table and associated/unassociated-alpha meaning; do not convert colors or unpremultiply samples implicitly |
| Resolution and units | Preserve declared calibration separately from normalized Penteract coordinates; unspecified physical units remain unspecified |
| Multiple image directories | Each image is a separate field by default; page order is provenance, never inferred time/depth. Combining into axes requires explicit reviewed mapping |
| Reduced-resolution images | Separate derived levels with known parent/scale relation; do not mistake them for independent samples or invent reduction algorithm |
| Tags/private metadata | Preserve typed values and raw source reference; uninterpreted tags remain opaque rather than asserted semantic mappings |
| Strips/tiles/offsets/codecs | Adapter-only acquisition metadata, absent from core coordinates and source-program operands |
| Georeferencing | Preserve CRS/calibration/GeoTIFF metadata and unknown keys; normalized coordinates are not geographic coordinates |

Reject nonrectangular stacking, unsupported predictors/codecs, ambiguous sample widths, unsupported YCbCr/CMYK/CIELAB interpretation and transformations requiring unimplemented color semantics. Float nonfinite values, signed zero and NaN payloads require a declared binary-sample equivalence profile; JSON numeric serialization is insufficient to preserve them. The minimal finite-sample subset rejects unsupported representations explicitly.

## Equivalence, export and loss

Maintain original source bytes for archival exactness. Repacking tags, endianness or compression can preserve decoded samples while changing byte hash. A `LOSSLESS` logical export preserves exact sample bits/declared interpretation and calibration; it does not promise original byte layout. `REVERSIBLE_WITH_METADATA` requires an exercised inverse with all retained mapping/tag information. Quantization, color conversion, resampling, lost georeferencing/private metadata or alpha changes are `LOSSY`, each described. Unsupported variants are rejected, not relabeled lossless.

Export chooses classic TIFF only after proving every offset/count fits the chosen format and decoder capabilities; otherwise explicitly select BigTIFF. Overview generation records method, parameters and loss separately from full-resolution samples. COG export and hosting require the declared OGC conformance classes and their Annex A tests; HTTP range hosting is a deployment property that cannot be inferred from file layout.

## Proposed tests and abuse cases

Use genuine fixtures from an independently pinned writer and read the output through at least one independent decoder. Cover both byte orders, classic/BigTIFF, strips/tiles, supported planar modes, singleton/non-square dimensions, all supported orientation mappings, RGB/alpha metadata, multipage ambiguity, dtype boundaries and overviews. Check bitwise full-resolution samples and semantic metadata separately from byte equality.

Adverse fixtures cover cyclic/overlapping/out-of-bounds directory chains, enormous counts, truncated tiles, inconsistent channel descriptors, integer overflow in dimension products, unsupported codec/predictor, forged BigTIFF header fields, private metadata with executable-looking text, and concurrent source mutation. Set memory/CPU/expansion bounds before decoding.

The current corpus's field/coordinate vectors are not actual TIFF/BigTIFF/COG round trips. External acceptance remains open until real fixture hashes, tools/versions, reader outputs and class-specific results are recorded.
