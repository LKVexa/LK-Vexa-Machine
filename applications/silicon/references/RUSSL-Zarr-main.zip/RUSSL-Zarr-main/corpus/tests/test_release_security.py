from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import struct
import sys
import unittest
import tempfile
from contextlib import contextmanager

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tooling'))
import russ_container as rc
import russl_reference as rr
from schema_subset import validate_document, check_schema

@contextmanager
def scratch():
    base = Path.cwd().resolve()
    folder = Path(tempfile.mkdtemp(prefix='russl-test-', dir=base))
    if not folder.resolve().is_relative_to(base): raise ValueError('scratch escape')
    try:
        yield str(folder)
    finally:
        for path in sorted(folder.rglob('*'), key=lambda p: len(p.parts), reverse=True):
            if path.is_symlink(): path.unlink()
            elif not path.resolve().is_relative_to(folder.resolve()): raise ValueError('scratch cleanup escape')
            elif path.is_dir(): path.rmdir()
            else: path.unlink()
        folder.rmdir()


class ContainerSecurity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = (ROOT / 'examples/golden/RUSS_Penteract_RUSSL_1.0_golden.russ').read_bytes()
        cls.valid = rc.verify_bytes(cls.data, ROOT / 'machine/schemas')

    def assertRejected(self, data):
        with self.assertRaises((ValueError, UnicodeError, KeyError, TypeError)):
            rc.verify_bytes(data, ROOT / 'machine/schemas')

    def raw(self, manifest, payload=None):
        # Assemble hostile data independently of rebuild_bytes' safety checks.
        payload = self.valid['payload'] if payload is None else payload
        mb = rr.canonical_json_bytes(manifest)
        out = rc.HEADER.pack(rc.MAGIC, 1, 3, 1, len(mb)) + mb
        for e in manifest['payload']:
            path = e['path'].encode()
            body = payload[e['path']]
            out += rc.RECORD.pack(len(path), len(body), hashlib.sha256(body).digest()) + path + body
        return out

    def test_fixture_rebuild_is_identical(self):
        self.assertEqual(self.data, rc.rebuild_bytes(self.valid['manifest'], self.valid['payload']))

    def test_original_incoherent_fixture_rejected(self):
        path = ROOT / 'examples/legacy_golden/RUSS_Penteract_RUSSL_1.0_golden.russ'
        self.assertRejected(path.read_bytes())

    def test_field_shape_forgery_with_recomputed_roots(self):
        m = copy.deepcopy(self.valid['manifest'])
        payload = copy.deepcopy(self.valid['payload'])
        field_path = m['tuple'][2][1]['field_descriptor']
        field = rc.strict_json(payload[field_path])
        field['shape'][0] += 1
        payload[field_path] = json.dumps(field, indent=2).encode()
        for e in m['payload']:
            e['size'] = len(payload[e['path']])
            e['sha256'] = hashlib.sha256(payload[e['path']]).hexdigest()
        root = rr.domain_hash('RUSS-PAYLOAD/1.0', rr.canonical_json_bytes(m['payload']))
        m['payload_root_sha256'] = root
        m['tuple'][8][1]['payload_root_sha256'] = root
        m['tuple_id'] = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(m['tuple']))
        self.assertRejected(self.raw(m, payload))

    def test_payload_corruption(self):
        self.assertRejected(self.data[:-1] + bytes([self.data[-1] ^ 1]))

    def test_truncation_at_header_manifest_and_record(self):
        for length in (0, 1, 23, 24, 100, len(self.data) - 1):
            with self.subTest(length=length):
                self.assertRejected(self.data[:length])

    def test_trailing_bytes(self):
        self.assertRejected(self.data + b'extra')

    def test_unknown_flags(self):
        data = bytearray(self.data)
        struct.pack_into('>I', data, 12, 3)
        self.assertRejected(data)

    def test_manifest_length_resource_limit(self):
        data = bytearray(self.data)
        struct.pack_into('>Q', data, 16, rc.MAX_MANIFEST + 1)
        self.assertRejected(data)

    def test_declared_payload_size_mismatch(self):
        m = copy.deepcopy(self.valid['manifest'])
        m['payload'][0]['size'] += 1
        self.assertRejected(self.raw(m))

    def test_swapped_tuple_components(self):
        m = copy.deepcopy(self.valid['manifest'])
        m['tuple'][0], m['tuple'][1] = m['tuple'][1], m['tuple'][0]
        m['tuple_id'] = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(m['tuple']))
        self.assertRejected(self.raw(m))

    def test_missing_language_reference_with_recomputed_identity(self):
        m = copy.deepcopy(self.valid['manifest'])
        m['tuple'][1][1]['source'] = 'language/missing.russl'
        m['tuple_id'] = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(m['tuple']))
        self.assertRejected(self.raw(m))

    def test_fake_ir_reference_with_recomputed_identity(self):
        m = copy.deepcopy(self.valid['manifest'])
        m['tuple'][1][1]['ir_id'] = 'russir:sha256:' + '0' * 64
        m['tuple_id'] = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(m['tuple']))
        self.assertRejected(self.raw(m))

    def test_duplicate_payload_path(self):
        m = copy.deepcopy(self.valid['manifest'])
        m['payload'].insert(1, copy.deepcopy(m['payload'][0]))
        self.assertRejected(self.raw(m))

    def test_unsafe_payload_paths(self):
        for path in ('../evil', '/root', 'C:/evil', 'a\\evil', 'a//evil', 'a/CON.txt', 'a/aux', 'a/.', 'a/end.'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                rc.safe_member(path)

    def test_authorization_boundary_with_recomputed_identity(self):
        m = copy.deepcopy(self.valid['manifest'])
        m['tuple'][6][1]['commit_requires_independent_authorization'] = False
        m['tuple_id'] = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(m['tuple']))
        self.assertRejected(self.raw(m))

    def test_policy_role_and_profile_forgery_with_recomputed_identity(self):
        for component, key, value in [(6, 'policy', 'language/main.russl'),
                                      (0, 'format', 'ARBITRARY'), (0, 'version', '999.0.0'),
                                      (2, 'base', 'P7')]:
            with self.subTest(key=key):
                m = copy.deepcopy(self.valid['manifest'])
                m['tuple'][component][1][key] = value
                m['tuple_id'] = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(m['tuple']))
                self.assertRejected(self.raw(m))


class StructuralSecurity(unittest.TestCase):
    def schema(self, name):
        return rc.strict_json((ROOT / 'machine/schemas' / name).read_bytes())

    def sample(self, path):
        return rc.strict_json((ROOT / path).read_bytes())

    def test_all_schema_keywords_supported(self):
        for path in (ROOT / 'machine/schemas').glob('*.json'):
            check_schema(rc.strict_json(path.read_bytes()))

    def test_unknown_schema_keyword_and_remote_ref_rejected(self):
        for s in ({'format': 'unknown'}, {'$ref': 'https://example.org/schema'}, {'type': 'mystery'}):
            with self.assertRaises(ValueError):
                check_schema(s)

    def test_invalid_keyword_declarations_rejected(self):
        for s in ({'required': ''}, {'minLength': -1}, {'uniqueItems': 0},
                  {'properties': []}, {'type': ['integer', 'integer']},
                  {'$defs': []}, {'oneOf': []}):
            with self.subTest(schema=s), self.assertRaises(ValueError):
                check_schema(s)

    def test_cyclic_negation_does_not_swallow_resource_error(self):
        with self.assertRaises(ValueError):
            validate_document({}, {'$defs': {'loop': {'$ref': '#/$defs/loop'}},
                                   'not': {'$ref': '#/$defs/loop'}})

    def test_unique_work_limit_propagates_through_negation_and_disjunction(self):
        for keyword in ('not', 'anyOf', 'oneOf'):
            child = {'type': 'array', 'uniqueItems': True}
            schema = {keyword: child if keyword == 'not' else [child, True]}
            with self.subTest(keyword=keyword), self.assertRaises(ValueError):
                validate_document(list(range(1000)), schema)

    def test_json_depth_surrogate_and_byte_limits(self):
        for text in ('[' * 65 + '0' + ']' * 65, '"\\ud800"', ' ' * (rr.MAX_JSON_BYTES + 1)):
            with self.assertRaises(ValueError): rc.strict_json(text)

    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(ValueError):
            rc.strict_json('{"a":1,"a":2}')

    def test_nonfinite_and_overflow_json_rejected(self):
        for text in ('NaN', 'Infinity', '-Infinity', '1e999'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                rc.strict_json(text)

    def test_short_or_reordered_axes_rejected(self):
        s = self.schema('penteract_field.schema.json')
        d = self.sample('examples/golden/field_descriptor.json')
        for axes in ([], ['c4'], ['c5', 'c4', 'c6', 'c7', 'c8']):
            d['axes'] = axes
            with self.assertRaises(ValueError):
                validate_document(d, s)

    def test_bool_and_zero_shape_rejected(self):
        s = self.schema('penteract_field.schema.json')
        d = self.sample('examples/golden/field_descriptor.json')
        for value in (True, 0, -1, 1.5):
            d['shape'][0] = value
            with self.assertRaises(ValueError):
                validate_document(d, s)

    def test_numeric_digest_rejected(self):
        s = self.schema('capability_grant.schema.json')
        for key in ('tuple_id', 'arguments_sha256'):
            d = self.sample('machine/registries/sample_capability_grant.json')
            d[key] = 123
            with self.assertRaises(ValueError):
                validate_document(d, s)

    def test_unknown_field_rejected(self):
        s = self.schema('capability_grant.schema.json')
        d = self.sample('machine/registries/sample_capability_grant.json')
        d['admin_override'] = True
        with self.assertRaises(ValueError):
            validate_document(d, s)

    def test_duplicate_effects_rejected(self):
        s = self.schema('capability_grant.schema.json')
        d = self.sample('machine/registries/sample_capability_grant.json')
        d['planned_effects'] = ['commit', 'commit']
        with self.assertRaises(ValueError):
            validate_document(d, s)

    def test_boolean_not_equivalent_to_numeric_constant(self):
        for schema in ({'const': 1}, {'enum': [1]}):
            with self.assertRaises(ValueError):
                validate_document(True, schema)

    def test_release_manifest_claims_and_exclusions_cannot_override_policy(self):
        import verify_corpus as verifier
        manifest = verifier.load(ROOT / 'MANIFEST.json')
        for key, value, message in [('version', '999.0.0', 'manifest policy'),
                                    ('schema', 'UNSUPPORTED', 'manifest policy'),
                                    ('full_conformance', True, 'manifest policy'),
                                    ('external_certification', True, 'manifest policy'),
                                    ('status', 'APPROVED', 'manifest policy'),
                                    ('content_root_domain', 'ARBITRARY', 'manifest policy'),
                                    ('excluded_generated_files', ['everything'], 'exclusion policy'),
                                    ('entry_count', 0, 'entry count')]:
            with self.subTest(key=key), scratch() as folder:
                d = copy.deepcopy(manifest)
                # The source manifest might predate edits; only the policy
                # check under test should execute before inventory checks.
                d[key] = value
                Path(folder, 'MANIFEST.json').write_text(json.dumps(d), encoding='utf-8')
                with self.assertRaisesRegex(ValueError, message):
                    verifier.verify_integrity(Path(folder))

class IntegrityPolicy(unittest.TestCase):
    def fixture(self, folder, report_change=None, receipt_change=None):
        import verify_corpus as verifier
        root = Path(folder)
        def put(name, value):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
        golden = root / 'examples/golden/RUSS_Penteract_RUSSL_1.0_golden.russ'
        golden.parent.mkdir(parents=True)
        golden.write_bytes(b'isolated integrity policy fixture; not a runtime container')
        report = {'schema':'RUSSL.VerificationResult/2.0', 'corpus_version':'2.0.0',
                  'status':'PASS', 'full_conformance':False, 'external_certification':False,
                  'checks':[{'id':'ISOLATED-POLICY-FIXTURE','status':'PASS'}]}
        report.update(report_change or {})
        put('evidence/CONFORMANCE_RESULTS.json', report)
        put('machine/schemas/conformance_result.schema.json', verifier.load(ROOT / 'machine/schemas/conformance_result.schema.json'))
        entries = [{'path':p.relative_to(root).as_posix(), 'size':p.stat().st_size,
                    'sha256':verifier.sha(p)} for p in sorted(root.rglob('*')) if p.is_file()]
        content = rr.domain_hash('RUSSL-CORPUS-CONTENT/2.0', rr.canonical_json_bytes(entries))
        manifest = {'schema':'RUSSL.CorpusManifest/2.0','version':'2.0.0',
                    'release_date':'2026-10-09','status':'CANDIDATE_REVIEW_REQUIRED',
                    'full_conformance':False,'external_certification':False,
                    'content_root_domain':'RUSSL-CORPUS-CONTENT/2.0',
                    'content_root_sha256':content,'entry_count':len(entries),'files':entries,
                    'excluded_generated_files':['MANIFEST.json','BUILD_RECEIPT.json','SHA256SUMS.txt','evidence/RELEASE_INTEGRITY.json']}
        put('MANIFEST.json', manifest)
        receipt = {'schema':'RUSSL.CorpusBuildReceipt/2.0','corpus_version':'2.0.0',
                   'status':'SCOPED_VERIFICATION_PASS','signed':False,'review_approval':False,
                   'content_root_sha256':content,'golden_russ_sha256':verifier.sha(golden),
                   'manifest_sha256':verifier.sha(root/'MANIFEST.json'),
                   'verification_results_sha256':verifier.sha(root/'evidence/CONFORMANCE_RESULTS.json')}
        receipt.update(receipt_change or {})
        put('BUILD_RECEIPT.json', receipt)
        sums=[verifier.sha(p)+'  '+p.relative_to(root).as_posix() for p in sorted(root.rglob('*')) if p.is_file()]
        (root/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n', encoding='utf-8')
        return root

    def test_unsigned_byte_integrity_baseline(self):
        import verify_corpus as verifier
        with scratch() as folder:
            self.assertEqual(verifier.verify_integrity(self.fixture(folder))['status'], 'PASS')

    def test_receipt_claim_forgery_despite_valid_file_hashes(self):
        import verify_corpus as verifier
        for key,value in [('signed',True),('review_approval',True),('status','APPROVED'),
                          ('content_root_sha256','0'*64),('golden_russ_sha256','0'*64)]:
            with self.subTest(key=key), scratch() as folder:
                root=self.fixture(folder,receipt_change={key:value})
                with self.assertRaisesRegex(ValueError,'receipt policy'):
                    verifier.verify_integrity(root)

    def test_bound_failure_or_full_conformance_report_rejected(self):
        import verify_corpus as verifier
        for change in [{'status':'FAIL'},{'full_conformance':True},{'external_certification':True},
                       {'checks':[{'id':'FAILURE','status':'FAIL'}]}]:
            with self.subTest(change=change), scratch() as folder:
                root=self.fixture(folder,report_change=change)
                with self.assertRaisesRegex(ValueError,'bound report policy'):
                    verifier.verify_integrity(root)

if __name__ == '__main__':
    unittest.main()
