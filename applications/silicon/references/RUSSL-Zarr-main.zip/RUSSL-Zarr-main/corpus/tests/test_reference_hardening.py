"""Executable static-profile regressions; no claims of runtime conformance."""
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tooling'))
import russl_reference as rr

HEADER = 'RUSSL/1.0\n@unit id=test.unit version=1.0.0 fail=closed\n'
DEFAULTS = '@defaults mode=deterministic regime=exact effect=read scope=self\n'
BINDING = '@mssl alias=master module=master source_version=0.1 digest=sha256:' + 'a' * 64 + '\n'
FRAME = '@frame id=F0 parent=ROOT module=test.unit\n'
ROW = 'R1│control│N│out.one│_│_│_│_'

def source(*rows, preamble='', frame=FRAME):
    return HEADER + preamble + frame + rr.COLUMNS + '\n' + '\n'.join(rows or (ROW,)) + '\n@end\n'

def row(rid='R1', lane='control', op='N', out='out.one', ctrl='_', inp='_', arg='_', meta='_'):
    return '│'.join((rid, lane, op, out, ctrl, inp, arg, meta))

class ReferenceHardeningTests(unittest.TestCase):
    def reject(self, text, code=None, **kwargs):
        with self.assertRaises(rr.RUSSLValidationError) as ctx:
            rr.parse_russl(text, **kwargs)
        error = ctx.exception
        self.assertEqual(error.severity, 'error')
        if code: self.assertEqual(error.code, code)
        return error

    def test_original_example_identity_preserved(self):
        paths = sorted((ROOT / 'examples/source').glob('*.russl'))
        self.assertEqual(len(paths), 12)
        for path in paths:
            with self.subTest(path=path.name):
                expected = rr.strict_json_loads((ROOT / 'examples/lowered' / path.name.replace('.russl', '.russir.json')).read_bytes())
                observed = rr.lower_russl(path.read_text(encoding='utf-8'))
                self.assertEqual(expected, observed)
                ir_id = observed.pop('ir_id')
                self.assertEqual(ir_id, 'russir:sha256:' + rr.domain_hash('RUSSIR/1.0', rr.canonical_json_bytes(observed)))

    def test_original_valid_and_invalid_vectors(self):
        for path in sorted((ROOT / 'tests/vectors/syntax/valid').glob('*.russl')):
            with self.subTest(valid=path.name): rr.parse_russl(path.read_text(encoding='utf-8'))
        for path in sorted((ROOT / 'tests/vectors/syntax/invalid').glob('*.russl')):
            with self.subTest(invalid=path.name): self.reject(path.read_text(encoding='utf-8'))

    def test_directive_order_duplicate_and_scope(self):
        variants = (
            source().replace(HEADER, 'RUSSL/1.0\n' + DEFAULTS + HEADER.split('\n', 1)[1]),
            source(preamble=DEFAULTS + DEFAULTS),
            source(preamble=BINDING + DEFAULTS),
            source().replace(FRAME, HEADER.split('\n', 1)[1] + FRAME),
            source().replace(rr.COLUMNS, DEFAULTS + rr.COLUMNS),
            source().replace(rr.COLUMNS, BINDING + rr.COLUMNS),
            source().replace(rr.COLUMNS, FRAME + rr.COLUMNS),
            source() + DEFAULTS,
            source() + BINDING,
            source() + '@unknown mode=read\n',
            source().replace(HEADER, 'RUSSL/1.0\n'),
        )
        for text in variants:
            with self.subTest(text=text): self.reject(text, 'RUSSL-E-PARSE-001')

    def test_columns_and_frame_structure(self):
        for text in (
            source().replace(FRAME, ''),
            source().replace(rr.COLUMNS + '\n', ''),
            source().replace(rr.COLUMNS, rr.COLUMNS + '\n' + rr.COLUMNS),
            source().replace(ROW, ROW + '\n' + rr.COLUMNS),
            HEADER + FRAME + rr.COLUMNS + '\n@end\n',
            HEADER + '@end\n',
            source() + '@end\n',
        ):
            with self.subTest(text=text): self.reject(text, 'RUSSL-E-PARSE-002')
        self.reject(source().replace('@end\n', ''), 'RUSSL-E-PARSE-001')
        self.reject(source() + FRAME + rr.COLUMNS + '\n' + row(rid='R2', out='out.two') + '\n@end\n', 'RUSSL-E-PARSE-003')
        self.reject(source(frame=FRAME.replace('parent=ROOT', 'parent=F999')), 'RUSSL-E-DEP-001')
        self.reject(source(frame=FRAME.replace('id=F0', 'id=ROOT')), 'RUSSL-E-PARSE-003')

    def test_closed_directive_keys_and_required_fields(self):
        for original, changed in (
            ('fail=closed', 'fail=closed mystery=true'),
            ('fail=closed', 'fail=closed fail=open'),
            ('fail=closed', 'fail=closed fail=closed'),
            ('id=test.unit ', ''), ('version=1.0.0 ', ''),
            ('fail=closed', 'fail=open'),
            ('version=1.0.0', 'version=01.0.0'),
            ('fail=closed', 'fail=closed profile=russl.unknown'),
            ('fail=closed', 'fail=closed target=unsafe'),
            ('module=test.unit', 'module=test.unit unknown=value'),
            ('module=test.unit', 'module=test.unit id=F1'),
            ('parent=ROOT ', ''), ('module=test.unit', ''),
        ):
            with self.subTest(changed=changed): self.reject(source().replace(original, changed))
        for defaults in ('mode=random', 'regime=approximate', 'effect=commit', 'scope=global', 'unknown=read'):
            with self.subTest(defaults=defaults): self.reject(source(preamble='@defaults ' + defaults + '\n'))

    def test_mssl_binding_completeness_and_ambiguity(self):
        self.reject(source(preamble=BINDING + BINDING), 'RUSSL-E-MSSL-001')
        for old, new in (
            ('alias=master ', ''), ('module=master ', ''), ('source_version=0.1 ', ''),
            ('digest=sha256:', 'other=sha256:'), ('alias=master', 'alias=source.master'),
            ('source_version=0.1', 'source_version=nan'),
            ('digest=sha256:' + 'a' * 64, 'digest=sha256:' + 'A' * 64),
            ('alias=master', 'alias=master extraneous=true'),
        ):
            with self.subTest(new=new): self.reject(source(preamble=BINDING.replace(old, new)))

    def test_effect_cannot_be_lowered_or_broadened(self):
        effects = ('read', 'derive', 'project', 'write:evidence', 'write:state', 'commit', 'replicate', 'publish', 'arbitrary')
        for operation, (_, _, required) in rr.OPERATORS.items():
            for effect in effects:
                if effect == required: continue
                with self.subTest(op=operation, effect=effect):
                    inp = 'master›source.data' if operation in ('MSSL_EVAL', 'ADMISSION_EVAL') else '_'
                    self.reject(source(row(op=operation, inp=inp, meta='eff=' + effect), preamble=BINDING), 'RUSSL-E-EFFECT-001')
        self.reject(source(row(meta='eff=read;eff=commit')), 'RUSSL-E-PARSE-002')
        self.reject(source(row(meta='eff=read;opaque')), 'RUSSL-E-PARSE-002')
        self.reject(source(row(meta='eff=read;unknown=commit')), 'RUSSL-E-PARSE-002')
        self.reject(source(row(meta='scope=global')), 'RUSSL-E-EFFECT-001')

    def test_registered_effects_and_aliases_are_inferred(self):
        for operation, (face, result_type, required) in rr.OPERATORS.items():
            with self.subTest(operation=operation):
                inp = 'master›source.data' if operation in ('MSSL_EVAL', 'ADMISSION_EVAL') else '_'
                parsed = rr.parse_russl(source(row(op=operation, inp=inp, meta='eff=' + required), preamble=BINDING))
                observed = parsed['frames'][0]['rows'][0]
                self.assertEqual((observed['op'], observed['face'], observed['type'], observed['effect']), (operation, face, result_type, required))
                self.assertNotIn('authorized', observed)
        for alias, operation in rr.ALIASES.items():
            with self.subTest(alias=alias):
                inp = 'master›source.data' if operation in ('MSSL_EVAL', 'ADMISSION_EVAL') else '_'
                actual = rr.parse_russl(source(row(op=alias, inp=inp), preamble=BINDING))['frames'][0]['rows'][0]
                self.assertEqual(actual['op'], operation)

    def test_empty_and_malformed_cells(self):
        for column in range(8):
            cells = ROW.split('│'); cells[column] = ''
            with self.subTest(column=column): self.reject(source('│'.join(cells)), 'RUSSL-E-PARSE-002')
        for text in (ROW + '│_', ROW.replace('│_', '', 1)):
            with self.subTest(text=text): self.reject(source(text), 'RUSSL-E-PARSE-002')
        for bad in ('1bad', 'has space', 'a..b', 'a/b', 'а', 'a\u200b', '_'):
            with self.subTest(symbol=bad): self.reject(source(row(rid=bad)))
        self.reject(source(row(op='NOPP')), 'RUSSL-E-OP-001')
        self.reject(source(row(op='FD', out='_')), 'RUSSL-E-BIND-001')
        self.assertEqual(rr.parse_russl(source(row(out='_')))['frames'][0]['rows'][0]['out'], '_')

    def test_ids_outputs_and_shadowing(self):
        self.reject(source(ROW, row(rid='R1', out='out.two')), 'RUSSL-E-PARSE-003')
        self.reject(source(ROW, row(rid='R2')), 'RUSSL-E-BIND-001')
        self.reject(source(row(out='master'), preamble=BINDING), 'RUSSL-E-BIND-001')
        self.reject(source(row(out='source.data')), 'RUSSL-E-BIND-001')
        self.reject(source(row(op='SB', out='source.data', inp='source.data', arg='media=image/tiff')), 'RUSSL-E-BIND-001')
        self.reject(source(row(inp='source.data'), row(rid='R2', op='SB', out='source.data', arg='media=image/tiff')), 'RUSSL-E-BIND-001')

    def test_dependency_graph_and_data_availability(self):
        for dependency in ('R1', 'R999', 'R2', 'R1,', ',R1', 'R1,R1'):
            with self.subTest(dependency=dependency):
                candidate = source(ROW, row(rid='R2', out='out.two', ctrl=dependency))
                if dependency == 'R1': rr.parse_russl(candidate)
                else: self.reject(candidate)
        self.reject(source(row(ctrl='R1')), 'RUSSL-E-DEP-001')
        self.reject(source(ROW, row(rid='R2', out='out.two', inp='out.one')), 'RUSSL-E-DEP-001')
        self.reject(source(row(inp='out.later'), row(rid='R2', out='out.later')), 'RUSSL-E-BIND-001')
        self.reject(source(row(inp='unknown')), 'RUSSL-E-BIND-001')
        parsed = rr.parse_russl(source(ROW, row(rid='R2', out='out.two', ctrl='R1'), row(rid='R3', out='out.three', ctrl='R2', inp='out.one')))
        self.assertEqual(parsed['frames'][0]['rows'][2]['inputs'], ['out.one'])
        # Later frames may depend on prior rows; parent denotes only frame ancestry.
        second = '@frame id=F1 parent=F0 module=test.unit\n' + rr.COLUMNS + '\n' + row(rid='R2', out='out.two', ctrl='R1', inp='out.one') + '\n@end\n'
        self.assertEqual(len(rr.parse_russl(source() + second)['frames']), 2)

    def test_external_placeholders_and_bound_source(self):
        parsed = rr.parse_russl(source(row(inp='source.unresolved')))
        self.assertEqual(parsed['frames'][0]['rows'][0]['inputs'], ['source.unresolved'])
        self.assertNotIn('authorized', parsed)
        self.assertNotIn('source_resolved', parsed)
        a = row(op='SB', out='source.tiff', arg='media=image/tiff;profile=profile.tiff')
        b = row(rid='R2', op='FP', out='field.candidate', ctrl='R1', inp='source.tiff', arg='mapping=identity5')
        rr.parse_russl(source(a, b))
        self.reject(source(a, b.replace('│R1│', '│_│')), 'RUSSL-E-DEP-001')

    def test_input_packing_and_module_invocation(self):
        for inputs in ('source.a›', '›source.a', 'source.a›_'):
            with self.subTest(inputs=inputs): self.reject(source(row(inp=inputs)), 'RUSSL-E-PARSE-002')
        self.reject(source(row(inp='source.a›source.b›source.c')), 'RUSSL-E-PARSE-002')
        for inputs in ('_', 'master', 'master›master', 'source.a›master', 'master›source.a'):
            with self.subTest(inputs=inputs):
                text = source(row(op='ME', inp=inputs), preamble=BINDING)
                if inputs == 'master›source.a': rr.parse_russl(text)
                else: self.reject(text, 'RUSSL-E-MSSL-001')
        self.reject(source(row(inp='master'), preamble=BINDING), 'RUSSL-E-MSSL-001')
        self.reject(source(row(op='ME', inp='master›source.a')), 'RUSSL-E-BIND-001')

    def test_closed_argument_and_meta_keys(self):
        for cell in ('bogus=value', 'shape=1;shape=2', 'shape=1;opaque', 'shape=1;', ';shape=1', 'shape=', 'shape=""'):
            with self.subTest(cell=cell): self.reject(source(row(op='FD', arg=cell)), 'RUSSL-E-PARSE-002')
        self.reject(source(row(op='CONST', arg='value=1')), 'RUSSL-E-PARSE-002')
        self.reject(source(row(meta='proof=x;proof=y')), 'RUSSL-E-PARSE-002')

    def test_coupling_reference_requires_control_ancestry(self):
        a = row(op='CD', out='coupling.one', arg='radius=1')
        b = row(rid='R2', op='ME', out='mechanics.one', inp='master›source.a', arg='coupling=coupling.one')
        self.reject(source(a, b, preamble=BINDING), 'RUSSL-E-DEP-001')
        rr.parse_russl(source(a, b.replace('│_│master', '│R1│master'), preamble=BINDING))
        self.reject(source(b, preamble=BINDING), 'RUSSL-E-BIND-001')

    def test_quoted_values_and_escape_rules(self):
        parsed = rr.parse_russl(source(row(op='FP', arg='mapping="a;b=2 \\"q\\""')))
        self.assertEqual(parsed['frames'][0]['rows'][0]['arg'], {'mapping': 'a;b=2 "q"'})
        for arg in ('mapping="bad', 'mapping="bad\\"', 'mapping="a"junk', "mapping='x'", 'mapping=has space', 'mapping="\\q"', 'mapping="\\n"', 'mapping="\\u2502"', 'mapping="\\u203a"', 'mapping="\\ud800"', 'mapping="\\u200b"'):
            with self.subTest(arg=arg): self.reject(source(row(op='FP', arg=arg)))
        directive = source().replace('module=test.unit', 'module="test.unit" phase="two words"')
        self.assertEqual(rr.parse_russl(directive)['frames'][0]['phase'], 'two words')
        tabbed = source().replace('@unit ', '@unit\t').replace('@frame ', '@frame\t')
        rr.parse_russl(tabbed)

    def test_source_canonicalization_identity_and_controls(self):
        text = source()
        variant = '\ufeff' + text.replace('\n', '  \r\n') + '\r\n'
        self.assertEqual(rr.lower_russl(text), rr.lower_russl(variant))
        self.assertEqual(rr.canonical_source('e\u0301\r\n'), 'é\n')
        self.assertEqual(rr.canonical_source(''), '\n')
        for control in ('\0', '\x85', '\u2028', '\u2029', '\u200b', '\u202e', '\ufeff', '\ud800'):
            with self.subTest(control=repr(control)): self.reject(text + '#comment' + control + '\n')
        self.assertEqual(rr.canonical_source(rr.canonical_source(text)), rr.canonical_source(text))

    def test_storage_lexical_filter_and_explicit_bypass(self):
        for name in ('state.zarr', 'OME_ZARR', 'zarr-v3'):
            with self.subTest(name=name): self.reject(source() + '#' + name + '\n', 'RUSSL-E-STORAGE-001')
        rr.parse_russl(source() + '#state.zarr\n', reject_storage_leak=False)
        self.reject(source(), reject_storage_leak='false')

    def test_resource_limits(self):
        cases = (
            (source(), {'source_bytes': 20}),
            (source(), {'line_chars': 10}),
            (source(), {'cell_chars': 3}),
            (source(), {'symbol_chars': 3}),
            (source(ROW, row(rid='R2', out='out.two')), {'rows': 1}),
            (source(preamble=BINDING + BINDING.replace('alias=master', 'alias=other')), {'bindings': 1}),
            (source(), {'structured_fields': 1}),
            (source(ROW, row(rid='R2', out='out.two'), row(rid='R3', out='out.three', ctrl='R1,R2')), {'dependencies_per_row': 1}),
            (source(ROW, row(rid='R2', out='out.two', ctrl='R1'), row(rid='R3', out='out.three', ctrl='R2')), {'dependencies_total': 1}),
        )
        for text, changes in cases:
            with self.subTest(changes=changes):
                error = self.reject(text, limits=replace(rr.DEFAULT_LIMITS, **changes))
                self.assertIn(error.code, ('RUSSL-E-RESOURCE-001', 'RUSSL-E-PARSE-002'))
        second = source().split(FRAME, 1)[1].replace('R1', 'R2').replace('out.one', 'out.two')
        self.reject(source() + '@frame id=F1 parent=ROOT module=test.unit\n' + second, 'RUSSL-E-RESOURCE-001', limits=replace(rr.DEFAULT_LIMITS, frames=1))
        for changes in ({'rows': 0}, {'rows': True}, {'rows': 1.5}):
            with self.subTest(changes=changes), self.assertRaises(ValueError): replace(rr.DEFAULT_LIMITS, **changes)

    def test_diagnostic_codes_locations_and_redaction(self):
        error = self.reject(source(row(op='secret_token')), 'RUSSL-E-OP-001')
        self.assertEqual(error.source_line, 5)
        self.assertEqual(error.row_id, 'R1')
        self.assertEqual(error.cause_class, 'op')
        self.assertNotIn('secret_token', str(error))

    def test_phi_strict_domain_and_precision(self):
        for n in (1, 2, 3, 5, 1 << 53):
            self.assertEqual(rr.phi(0, n), 0.0 if n == 1 else -1.0)
            self.assertEqual(rr.phi(n - 1, n), 0.0 if n == 1 else 1.0)
        self.assertEqual(rr.phi(0, 1, -0.5), -0.5)
        for i, n in ((True, 2), (0, True), (0.0, 2), (0, 2.0), (-1, 2), (2, 2), (0, 0), (0, 1 << 54), ('0', 1), (0, math.inf)):
            with self.subTest(i=i, n=n), self.assertRaises(rr.RUSSLValidationError): rr.phi(i, n)
        for n in (1, 3):
            for anchor in (math.nan, math.inf, -math.inf, -2, 2, True, '0', 10 ** 1000):
                with self.subTest(n=n, anchor=anchor), self.assertRaises(rr.RUSSLValidationError): rr.phi(0, n, anchor)

    def test_strict_json_duplicate_nonfinite_and_syntax(self):
        for payload in ('{"x":1,"x":2}', '{"x":{"y":1,"y":2}}', '{"a":1,"\\u0061":2}', 'NaN', 'Infinity', '-Infinity', '1e999', '{"x":1e999}', '{"x":}', '{}{}', '\ufeff{}', '"\\ud800"'):
            with self.subTest(payload=payload), self.assertRaises(rr.RUSSLValidationError): rr.strict_json_loads(payload)
        self.assertEqual(rr.strict_json_loads(b'{"x":1,"u":"\xc3\xa9"}'), {'x': 1, 'u': 'é'})
        with self.assertRaises(rr.RUSSLValidationError): rr.strict_json_loads(b'"\xff"')
        with self.assertRaises(rr.RUSSLValidationError): rr.strict_json_loads('[]', max_bytes=1)
        with self.assertRaises(rr.RUSSLValidationError): rr.strict_json_loads('[' * 65 + '0' + ']' * 65)
        self.assertEqual(rr.strict_json_loads('"[[["', max_depth=1), '[[[')
        with self.assertRaises(rr.RUSSLValidationError): rr.strict_json_loads('1' * 4097)

    def test_canonical_json_rejects_ambiguous_objects(self):
        bad = (float('nan'), float('inf'), {1: 'int-key'}, ('tuple',), {'x': '\ud800'}, object(), 10 ** 5000)
        for value in bad:
            with self.subTest(type=type(value)), self.assertRaises(rr.RUSSLValidationError): rr.canonical_json_bytes(value)
        cycle = []; cycle.append(cycle)
        with self.assertRaises(rr.RUSSLValidationError): rr.canonical_json_bytes(cycle)
        nested = 0
        for _ in range(65): nested = [nested]
        with self.assertRaises(rr.RUSSLValidationError): rr.canonical_json_bytes(nested)
        shared = {'x': 1}
        self.assertEqual(rr.canonical_json_bytes([shared, shared]), b'[{"x":1},{"x":1}]')
        self.assertEqual(rr.canonical_json_bytes({'b': -0.0, 'a': 'é'}), '{"a":"é","b":-0.0}'.encode('utf-8'))

    def test_mssl_digest_bytes_and_resource_failures(self):
        path = ROOT / 'bindings/mssl/master_coupled_mechanics.mssl'
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        self.assertTrue(rr.verify_mssl(path, digest))
        self.assertTrue(rr.verify_mssl(path, 'sha256:' + digest))
        for value in ('g' * 64, digest.upper(), '', None, 'sha256:' + '0' * 64):
            with self.subTest(value=value), self.assertRaises(rr.RUSSLValidationError): rr.verify_mssl(path, value)
        with patch.object(rr, 'MAX_MSSL_BYTES', 3), self.assertRaises(rr.RUSSLValidationError): rr.verify_mssl(path, digest)
        with self.assertRaises(rr.RUSSLValidationError): rr.verify_mssl(path / 'missing', digest)

if __name__ == '__main__':
    unittest.main()
