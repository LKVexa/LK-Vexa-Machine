import json
from pathlib import Path
import sys
import unittest
from fractions import Fraction
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tooling'))
import field_layout as fl
import russl_reference as rr

class FixedShapeLayout(unittest.TestCase):
    def test_all_sites_bijective(self):
        observed = {fl.ordinal(fl.indices(k)) for k in range(fl.SITES)}
        self.assertEqual(observed, set(range(16384)))
        self.assertEqual(sum(fl.BITS), 14)

    def test_full_fixture_has_exact_domain(self):
        path = ROOT / 'tests/vectors/field/fixed_shape_index_vectors.jsonl'
        rows = [rr.strict_json_loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
        self.assertEqual(len(rows), 16384)
        self.assertEqual([x['ordinal'] for x in rows], list(range(16384)))
        for row in rows:
            self.assertEqual(tuple(row['indices']), fl.indices(row['ordinal']))
            self.assertEqual(fl.ordinal(row['indices']), row['ordinal'])

    def test_stride_boundary_examples(self):
        self.assertEqual(fl.ordinal((1, 0, 0, 0, 0)), 4096)
        self.assertEqual(fl.ordinal((0, 1, 0, 0, 0)), 1024)
        self.assertEqual(fl.ordinal((0, 0, 1, 0, 0)), 256)
        self.assertEqual(fl.ordinal((0, 0, 0, 1, 0)), 16)
        self.assertEqual(fl.ordinal((3, 3, 3, 15, 15)), 16383)

    def test_invalid_domains(self):
        for args in [(True, 0, 0, 0, 0), (4, 0, 0, 0, 0), (0, 0, 0, 0, 16), (0, 0, 0, 0), (0.5, 0, 0, 0, 0)]:
            with self.assertRaises(ValueError): fl.ordinal(args)
        for value in [-1, 16384, True, 1.0]:
            with self.assertRaises(ValueError): fl.indices(value)

    def test_exact_normalized_coordinates(self):
        self.assertEqual([fl.coordinate(i, 4) for i in range(4)], [Fraction(-1), Fraction(-1,3), Fraction(1,3), Fraction(1)])
        self.assertEqual(fl.coordinate(0, 1), 0)
        self.assertEqual(fl.coordinate(1,16), Fraction(-13,15))

    def test_two_adic_metric_is_not_euclidean_neighborhood(self):
        self.assertEqual(fl.p2_distance(0,1), 1)
        self.assertEqual(fl.p2_distance(0,4096), Fraction(1,4096))
        self.assertEqual(fl.p2_distance(123,123), 0)

    def test_two_adic_ultrametric_small_complete_domain(self):
        distances = {(a,b):fl.p2_distance(a,b) for a in range(16) for b in range(16)}
        for a in range(16):
            for b in range(16):
                self.assertEqual(distances[a,b], distances[b,a])
                for c in range(16):
                    self.assertLessEqual(distances[a,c], max(distances[a,b], distances[b,c]))

if __name__ == '__main__': unittest.main()
