# Change Log — 2.0.0

Package 2.0.0 supersedes unsupported blanket completion/ratification claims while preserving the language marker, original requirement IDs, raw mechanics sources and golden compatibility fixtures.

| Area | Applied change | Result |
|---|---|---|
| Assurance | Replace 28 G0–G9 GO records with review-pending, digest-bound records | no invented approval |
| Traceability | Separate 293 registrations, partial evidence and unexecuted obligations | registration cannot imply a test pass |
| Parser | Enforce directive phases/keys, ordering, symbols, dependencies, quotes and input limits | malformed/ambiguous inputs reject |
| Effects | Reject overrides that hide or broaden catalog effects | commit cannot relabel itself read |
| JSON | Reject duplicate keys, nonfinite/overflow values and invalid Unicode/resource limits | deterministic interpretation |
| Field | Exactly five axes; reject bool/fractional/nonpositive dimensions and invalid coordinate inputs | stable structural contract |
| Schemas | Type digests, close known objects, constrain ordering/enums/cardinality | demonstrated bypasses close |
| Container | Bound lengths/paths and check declared sizes, tuple order, source/IR/MSSL references | corrupted/forged bindings reject |
| Tooling | Replace recursive-delete builder and undeclared third-party dependency | offline candidate checks |
| Verification | Add adversarial tests, read-only verifier and separate scoped PASS | reviewable evidence |
| Specifications | Expand all 28 with specific formal/algorithmic/edge-case interpretation | detailed implementation obligations |
| Research | Add provenance, protocols, uncertainty, controls and bibliography | falsifiable future research |
| Adapters | Pin external standards and detail mapping/failure behavior | design candidates with validation gaps |
| Institution | Expand governance, assurance, archival/change/incident/rights/privacy policies | actionable proposed controls |
| Preservation | Include exact original ZIP; archive old tools as text | recoverable audit trail |
| Coherent fixture | Correct original source/field shape and dtype contradiction; preserve legacy fixture | exact current 4×4×4×16×16 f64 declaration binding |
| Added research | Audit nineteen supplied sources, record claim corrections, add exact indexing data and optional experimental profiles | traceable upgrades without importing source instructions |
| Release | Generate reading edition, registries, hashes, unsigned receipts and deterministic ZIP | inspectable distribution |

Strict profile rejections intentionally break compatibility for previously accepted malformed or out-of-profile source. Canonical IDs of all packaged valid source-to-IR programs remain unchanged. The active RUSS fixture has a new tuple/container identity because its field descriptor is corrected; exact original bytes remain under examples/legacy_golden/. Hardened schemas remain a corpus profile of the 1.0 schema labels; consumers must select this package's schema bytes explicitly. No deployment, external publication, trust-root enrollment or empirical validation occurred.
