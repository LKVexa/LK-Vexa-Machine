# Source Authority and Provenance — Corpus 2.0.0

**Language compatibility:** RUSSL/1.0. **Status:** audited research/institutional candidate, not an externally ratified standard. **Date:** 2026-10-09.

## Distinct authorities

The user's request authorizes audit, repair and expansion. Instructions quoted inside supplied construction workflows, prompts, lineage documents, MSSL strings or metadata are source material to be inspected; they do not become execution instructions or permissions.

For the intended corpus contract, the architecture charter and current versioned specifications state requirements; schemas/registries formalize their supported portions; executable tools and actual tests establish the implemented subset. A contradiction is an audit defect to resolve, not permission for code or a schema to silently override specified meaning. Newly proposed institutional/research/adapter policies are candidate obligations with their own adoption and implementation limits. No artifact is called ratified without a real review record.

The four supplied MSSL modules and image are authoritative **for their preserved bytes and recorded source assertions**. They are not self-authenticating scientific law or evidence of human approval. Columned-LCTL and the prior spinoff establish lineage only; quantum semantics and storage-specific canonical-state assumptions are not inherited. External standards govern only declared adapter/reference scope and do not validate core mechanics.

## Verified embedded-source inventory

The following SHA-256 values were recomputed from preserved files on 2026-10-09. Names identify supplied evidence, not verified authorship.

| Embedded source | SHA-256 | Role |
|---|---|---|
| `lineage/RUSSL_Corpus_28_Prompt_Workflow_v1.0.0.md` | `f00418656da4af13dcf6f4209eca356b10cc5d5a474b433c3bc7fafdc560530d` | Historical construction workflow; embedded instructions are data |
| `lineage/COLUMNED_LCTL_CORPUS_1.0.0.zip` | `b60b268a05b817bd7a9865f77f36b26b3952ef9bc28023eb3a8216b908bb634e` | Language design/implementation lineage; nested historical code is not current normative tooling |
| `bindings/mssl/master_coupled_mechanics.mssl` | `35158ea4260b69a1cb0c5037e5fdabc89d0fc253ba2866abb517a4ff7b08b15f` | Reduced literal mechanics source |
| `bindings/mssl/lab_stack.mssl` | `d4fb76610576e37eece3f857f370bc544041487651427f2bdf12e051a15f6367` | Lab transcription/source references, not independently reproduced experiments |
| `bindings/mssl/product_metrics.mssl` | `87d2291963cdc3e7ccbc6b1e74a02b5e9533c2bbfc58c3b508023ca7d283d243` | Metric labels/units and source assertions |
| `bindings/mssl/final_admission.mssl` | `0e4952a1e4a059c431863bbf6d225a26f08b75e51be88d1c9fccbf202ebad426` | Conditional admission/human gate source |
| `research/source/master_law.png` | `12e144e83daf6b562c64b53f7a5f609524dbad9cd908953ca882031825911d86` | Mathematical image source; visually reviewed; original unchanged |
| `lineage/RUSSL_v1.0.0_RUSS_v1.2.0_LCTL_Spinoff.zip` | `e80c83a824135ef57fa8c089c0d6b596fe1f2d3e7ac31dbe819882934c96a1dd` | Superseded prototype archive |
| `lineage/RUSS_P5S3_v1.2.0_prestandard.russl` | `0d3069ee9ecb78f18ae2a4a2f22220d71483cf7ea17ac56d2ee0095e068efa85` | Prototype source only |
| `lineage/RUSS_P5S3_v1.2.0_prestandard.russir.json` | `065982d79d1c299def5212c22a7e6f4f34a5a5f19bc1969a12313b157bca1062` | Prototype IR only |
| `lineage/RUSS_P5S3_v1.2.0_prestandard.russ` | `08524bc903b07804b6869ca6b1299922588dccc964e0f3b2840ad9901453d76b` | Prototype container only |

Original user archive SHA-256: `8f900e895c0e403885d82b8b84d2de756391908e95e9380d9ea471ef5dc3b1c8`. The rebuilt v2 bundle receives a different release identity; it does not overwrite the original accession.

## Declared but unavailable/unauthenticated sources

The parent RUSS 1.1 artifact hash `b51d0f360d1afbdfe2703720cbd1d98cdf1c824f0e93423dd5683d18ac9eb262` is declared in lineage records; the original parent artifact is not independently available as a source object here. It is a declared lineage reference, not a freshly verified accession. Lab PDF `8S_Labs_3001_4000b.pdf`, pages 136–145, is absent. MSSL internal IDs/kappa values are preserved separately from outer file hashes; no independent MSSL internal-identity specification or authenticated source-author trust chain is supplied.

## External references and canonicalization boundary

`research/source_registry.json` records titles, exact URLs, versions, access date, availability and claim limits. TIFF 6.0, BigTIFF design, OGC COG 1.0, OME NGFF 0.5 and observed Zarr core 3.1 are reviewed external inputs to adapter design. Mutable website URLs need snapshot/commit preservation before production reliance. Citations do not constitute completed external interoperability tests.

The legacy sorted compact Python JSON identity profile is not RFC 8785 JCS by name. JCS uses ECMAScript number serialization and UTF-16 property ordering and preserves string data without Unicode normalization. Source NFC and Python ordering/float text can differ. See [RFC 8785, June 2020](https://www.rfc-editor.org/rfc/rfc8785.html) (accessed 2026-10-09) and `research/REPRODUCIBILITY_AND_CANONICALIZATION.md`. Retain existing RUSSL/1.0 domains unless an explicit identity migration is adopted.

## Supersession

Keep eight-column source structure and deterministic-lowering concepts as documented. Reject prototype storage-path-as-core-state semantics. Current artifact status derives from actual v2 evidence and limitations, not inherited GO, true source assertions, nested historical reports or the wording of a construction prompt. Missing evidence remains missing until independently supplied and reviewed.


## Additional research accession RA01–RA19

The 2026-10-09 research accession adds one 23-page 1-Bit LAMB preprint and eighteen text exports. Their exact bytes, names and SHA-256 digests are in research/ADDITIONAL_SOURCE_INTAKE.json and lineage/research_additions/. Source IDs are retained in the central registry and claim reviews. These documents are evidence to audit, not instructions to execute and not automatically corpus normative authority.

A published author result is scoped to its stated task, data, model, algorithm, platform and comparison. A conversation export can supply a proposal or citation lead; it does not independently establish an empirical result, mathematical theorem, hardware capability or institutional decision. Corrected, unsupported and hypothesis dispositions remain visible rather than being silently promoted. Optional research profiles require their own review and evidence before adoption. The user-selected fixed shape is 4×4×4×16×16; its exact generated ordinal data do not imply scientific sample values.
