# Dependency Graph and Review Groups

machine/registries/work_package_dependencies.json preserves original edges and reciprocal groups WP03/WP04 and WP08/WP09. An edge means the source contract depends on the target contract. It does not establish implementation or review.

Collapse strongly connected components into supernodes, require an acyclic condensed graph and order review by incoming prerequisites. Review each reciprocal group jointly while retaining individual requirement identities. A held member holds dependent approval. See [errata](WORKFLOW_ERRATA.md).

WP01/WP02 define source and interpretation; WP03/WP04 types/field shape; WP05–WP07 modules/IR/tuple; WP08/WP09 execution/authorization; WP10–WP12 security/admission/fabric; WP13–WP16 storage/sample/projection; WP17–WP22 identity/reproducibility/errors/conformance/examples; WP23/WP24 external adapters; WP25–WP28 governance/research/institutional/schema support. Before a conformance claim, pin every dependency, resolve contradictions and retain accountable review evidence. Current records remain CANDIDATE_REVIEW_REQUIRED.
