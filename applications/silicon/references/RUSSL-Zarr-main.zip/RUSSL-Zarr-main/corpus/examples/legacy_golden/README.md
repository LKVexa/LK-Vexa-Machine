# Original 1.0.0 golden fixture — preserved, incoherent

The exact original fixture declares source shape 4,4,4,16,16 and f64, but its descriptor declares shape 1,1,3,64,64 and u8. Its self-consistent byte hashes do not establish source/field consistency. The hardened container verifier rejects it. The active coherent candidate fixture is under ../golden/. No numerical field payload or execution result is claimed for either fixture.
