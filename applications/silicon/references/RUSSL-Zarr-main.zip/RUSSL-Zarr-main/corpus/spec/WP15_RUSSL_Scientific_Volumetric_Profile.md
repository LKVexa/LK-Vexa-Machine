# WP15 — RUSSL Scientific/Volumetric Profile

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines calibrated 3D/4D/5D scientific data and interoperability axis mappings.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP14, WP03.

**Mandatory deliverables:**
- axes/units
- coordinate transforms
- volume semantics
- calibration
- TCZYX mapping
- datasets/tests

## 5. Normative model
### Calibrated axes
A scientific axis carries `(name,semantic,unit,index_to_physical_transform)`. The interoperability profile may map `t,c,z,y,x` onto `c4…c8`, but this is a declared mapping, not a universal meaning of the Penteract axes.

Physical coordinates are computed after logical index normalization and profile calibration. Ambiguous axis order or unit conversion is a validation error for calibrated operations.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP15-REQ-0001` | Scientific profiles MUST declare axis names, units, and coordinate transforms. | `WP15-TEST-0001` |
| `WP15-REQ-0002` | TCZYX interoperability MAY map to the five Penteract axes only through an explicit profile mapping. | `WP15-TEST-0002` |
| `WP15-REQ-0003` | Calibration metadata MUST be versioned and provenance-bound. | `WP15-TEST-0003` |
| `WP15-REQ-0004` | 3D, 4D, and 5D slicing MUST preserve declared physical coordinate transforms. | `WP15-TEST-0004` |
| `WP15-REQ-0005` | Unknown units or ambiguous axis order MUST fail closed for calibrated operations. | `WP15-TEST-0005` |
| `WP15-REQ-0006` | Scientific test datasets MUST include expected coordinate and slicing results. | `WP15-TEST-0006` |
| `WP15-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP15-TEST-0007` |
| `WP15-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP15-TEST-0008` |
| `WP15-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP15-TEST-0009` |
| `WP15-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP15-TEST-0010` |

## 7. Technical interpretation and algorithms

### Index, normalized, and physical coordinate spaces
Keep three spaces separate: integer indices i, normalized Penteract coordinates `φ(i)`, and calibrated physical coordinates p. A calibration can be specified as `p=A·i+b` or as a transform of normalized coordinates, but its declared input basis resolves which expression is intended. Applying both normalizations without checking the basis double-transforms the data.

Each axis descriptor binds name, semantic role, unit identifier, direction, transform basis, and provenance. TCZYX maps t,c,z,y,x to c4…c8 only when that mapping is declared. A channel index is usually categorical metadata in this profile, not a physical distance; nonscientific axes can retain logical semantics without a fabricated physical unit.

### Slicing and affine composition
For an affine transform `p=A i+b`, a slice fixing selected indices `i_f=k` retains free-index transform `p=A_free i_free+(b+A_fixed k)`. Retained axis order and output rank are explicit. If an output coordinate basis uses cropped indices `j=i−l`, the new offset becomes `b+A l`. Permutation composes the matrix with the declared axis permutation.

Time interpolation, anisotropic spatial resampling, and unit conversion bind their own kernels and conversion factors. Calibration uncertainty is recorded separately from numeric serialization precision. A deterministic float calculation can still have measurement uncertainty and model error.

### Validity and degeneracy
Transforms specify rank, matrix dimensions, invertibility, and finite coefficients. Singular transforms can be usable for a projection but not for an operation claiming an inverse. Unit conversion follows a registered unit system and exact/rational factors where applicable; unknown units remain unresolved. Unsupported curved/nonlinear transformations are preserved as provenance or rejected for calibrated operations.

## 8. Worked example

For a volume with z spacing 2 μm and z origin 10 μm, `p_z=2 i_z+10`. Fixing `i_z=3` yields a plane at 16 μm. Cropping y indices from 5 upward shifts the y origin by `5·spacing_y` when output indexing restarts at zero.

The normalized c6 value describes placement in the declared logical axis. It is not 16 μm. The profile links that logical index to the calibrated z coordinate explicitly.

## 9. Boundary and adversarial cases

| Defect | Scientific-coordinate failure |
|---|---|
| Array dimensions interpreted as TCZYX without mapping | Axis role/order is guessed. |
| Millimeters treated as micrometers | Scale differs by 1000. |
| Crop restarts index at zero without offset adjustment | Physical placement changes. |
| Inverse requested from a singular transform | Operation is undefined. |
| NaN calibration coefficient | Transform cannot be reliably evaluated. |
| Calibration provenance absent but precision claimed | Measurement evidence is missing. |

## 10. Security and failure considerations

A coordinate transform is a data-model contract, not validation of an instrument or a biological/physical conclusion. Measurement accuracy needs instrument evidence, uncertainty analysis, and external observation. No calibrated executor or empirical dataset is synthesized by this package.

## 11. Verification obligations and current evidence boundary

Planned vectors cover affine composition, axis permutation, cropping offsets, singleton axes, anisotropic volumes, unit conversion, singular matrices, and unknown units. Tests distinguish exact rational expectations from declared floating tolerances. These require a future profile implementation beyond parser lowering.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [systems review](../research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md) separates optogenetic, photothermal, barcode-connectomics and super-resolution techniques into distinct evidence domains. Such data can motivate sample/provenance profiles but cannot establish P5×S³ physical mechanics, experimental outcomes or device capabilities.

## 13. Cross-specification consistency

WP04 supplies index geometry; WP14 supplies sample/channel interpretation; WP16 supplies output transformations; WP24 supplies explicit external version mapping.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
