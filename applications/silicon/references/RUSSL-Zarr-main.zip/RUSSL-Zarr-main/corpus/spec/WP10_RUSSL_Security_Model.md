# WP10 — RUSSL Security Model

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines threats, trust boundaries, identities, integrity, replay protection, evidence, and supply-chain controls.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP09, WP07, WP08.

**Mandatory deliverables:**
- threat model
- trust boundaries
- authentication
- integrity
- replay
- rollback
- security profile

## 5. Normative model
### Trust boundaries
Trust boundaries exist at source ingestion, MSSL resolution, RUSSIR compilation, tuple packaging, fabric retrieval, actor/reviewer authentication, grant verification, effect execution, and evidence publication. Content identities protect integrity; they do not establish authorization or scientific validity.

The corpus threat model includes substitution, digest collision assumptions, path traversal, replay, confused deputy, privilege amplification, rollback mismatch, mutable-head races, dependency poisoning, and diagnostic leakage.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP10-REQ-0001` | Security verification MUST fail closed on source, MSSL, tuple, payload, or evidence digest mismatch. | `WP10-TEST-0001` |
| `WP10-REQ-0002` | Authenticated actor identity MUST be distinct from reviewer identity when a profile requires independent review. | `WP10-TEST-0002` |
| `WP10-REQ-0003` | Nonce and expiration MUST be enforced for commit-capable grants. | `WP10-TEST-0003` |
| `WP10-REQ-0004` | Evidence and rollback checkpoint references MUST be immutable content identities. | `WP10-TEST-0004` |
| `WP10-REQ-0005` | Supply-chain manifests MUST bind compiler/runtime identities and dependencies. | `WP10-TEST-0005` |
| `WP10-REQ-0006` | Security-sensitive diagnostics MUST support redaction without suppressing stable error codes. | `WP10-TEST-0006` |
| `WP10-REQ-0007` | The reference corpus MUST NOT claim independent attestation or production authorization. | `WP10-TEST-0007` |
| `WP10-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP10-TEST-0008` |
| `WP10-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP10-TEST-0009` |
| `WP10-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP10-TEST-0010` |
| `WP10-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP10-TEST-0011` |

## 7. Technical interpretation and algorithms

### Assets, actors, and trust boundaries
Assets are canonical bytes, module bindings, candidate/committed roots, grant keys, replay state, research provenance, and audit evidence. Actors include source producers, module providers, compiler operators, runtime operators, storage peers, grant issuers, reviewers, and external researchers. None is trusted solely because their object has a content digest.

Treat each boundary as a verification function producing a decision plus evidence: `ingest(bytes)`, `bind(module)`, `validate(ir)`, `verify(tuple)`, `resolve(root)`, `authenticate(principal)`, `authorize(plan)`, and `publish(receipt)`. Evidence references the exact checked object. A later mutation invalidates the relationship.

### Threat/control/evidence matrix
| Threat | Control design | Evidence needed |
|---|---|---|
| Duplicate-key or Unicode ambiguity | Strict parsing and explicit canonical profile | Differential malformed-input vectors |
| Module substitution | Verify exact bytes before interpretation | Digest negatives and check/use race test |
| Archive traversal | Safe relative namespace and bounded framing | Traversal, drive path, collision vectors |
| Confused deputy | Exact run/row/root/args/scope binding | Cross-target grant rejection |
| Replay or concurrent commit | Durable nonce and CAS transaction | Concurrent/crash injection tests |
| Supply-chain replacement | Compiler/runtime/dependency digests | Rebuild and dependency provenance |
| Diagnostic leakage | Stable codes and redacted restricted context | Sensitive-value redaction test |

### Assurance boundaries and recovery
Integrity protects equality to a stated digest under algorithm assumptions. Authentication binds a principal to a key under a trust policy. Authorization binds that principal to a permitted action. Scientific validity concerns claims and evidence. These four predicates remain independent; no checksum combines them.

Independent review compares authenticated principal identifiers under a declared separation policy, not free-text names. Quarantine preserves suspect bytes and hashes without executing or publishing them. Recovery from compromised keys records affected grants/runs, revocation scope, forensic evidence, and fresh authority. Recovery from content corruption retrieves another replica and verifies it; it never rewrites bytes under an old digest.

Security budgets bound parse size, graph fan-out, member counts, recursive validation, decompression, and external fetches. Each limit has a visible profile value and stable failure instead of silently producing partial success.

## 8. Worked example

A member with the correct checksum but an unexpected executable role is still unauthorized. A reviewed candidate root remains uncommitted until a grant binds the intended head transition. If a source path exposes private directory names, a public diagnostic can retain the source-ingestion error code and row location while replacing the path value with a redaction marker.

## 9. Boundary and adversarial cases

| Event | Fail-closed response |
|---|---|
| Trusted module name with wrong bytes | Reject binding. |
| Reviewer and actor use the same authenticated principal under independent-review policy | Review gate remains unsatisfied. |
| Payload path escapes extraction directory | Refuse extraction and preserve primary code. |
| Evidence references a mutable URL as its immutable identity | Require a content binding before reliance. |
| Exception prints a token or private signature material | Redact detail while retaining causal class. |

## 10. Security and failure considerations

The hardening performed in this package is local ingestion, structure, identity, framing, and evidence hygiene. It is not a penetration test of a deployed fabric or an independent security assessment. Secrets, valid grants, production keys, and institutional endorsement are not created by the corpus.

## 11. Verification obligations and current evidence boundary

Current bounded-parser and container/schema negatives provide concrete local evidence. A complete security profile still needs independent adversarial review, crypto implementation tests, runtime isolation, replay-store durability, recovery exercises, and measured resource-limit behavior.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP17 supplies canonical bytes; WP09 supplies capability semantics; WP19 supplies diagnostic redaction; WP27 supplies the assurance case and explicit limitations.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
