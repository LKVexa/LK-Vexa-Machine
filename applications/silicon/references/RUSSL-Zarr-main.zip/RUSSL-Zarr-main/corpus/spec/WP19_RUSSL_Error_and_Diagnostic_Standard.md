# WP19 — RUSSL Error and Diagnostic Standard

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines stable errors, severities, locations, causal chains, and redaction.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP03, WP08, WP11.

**Mandatory deliverables:**
- error namespace
- stable codes
- severity
- source locations
- causal chains
- redaction

## 5. Normative model
### Diagnostic model
A diagnostic is `(code,severity,class,message,location,cause_chain,redactions)`. Stable codes are authoritative for automation; message wording may improve in compatible releases. Security-sensitive values such as signatures, secret tokens, or private paths are redacted while the code and structural cause remain observable.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP19-REQ-0001` | Every normative failure class MUST have a stable machine-readable error code. | `WP19-TEST-0001` |
| `WP19-REQ-0002` | Diagnostics MUST include a severity and causal class. | `WP19-TEST-0002` |
| `WP19-REQ-0003` | Source diagnostics SHOULD include row ID and source line when available. | `WP19-TEST-0003` |
| `WP19-REQ-0004` | Security redaction MUST NOT change the stable code or conformance result. | `WP19-TEST-0004` |
| `WP19-REQ-0005` | Multiple causal failures MAY be chained but MUST preserve the primary fail-closed cause. | `WP19-TEST-0005` |
| `WP19-REQ-0006` | Unknown errors MUST map to a stable generic class rather than leaking implementation exceptions. | `WP19-TEST-0006` |
| `WP19-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP19-TEST-0007` |
| `WP19-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP19-TEST-0008` |
| `WP19-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP19-TEST-0009` |
| `WP19-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP19-TEST-0010` |

## 7. Technical interpretation and algorithms

### Structured failure contract
A diagnostic record includes stable code, severity, phase/class, human message, source location when available, bounded causal chain, affected row/path, and redaction descriptors. Machine decisions use code and result status; messages remain explanatory and can change in compatible revisions.

Source locations distinguish byte offset, Unicode scalar offset, and line/cell position. The reference profile can use line number and row ID; a richer editor integration states its offset basis. Normalized-source positions are not silently presented as original-file byte positions.

### Primary cause and deterministic ordering
The earliest causal precondition failure on a blocked path is primary. Derived failures such as missing downstream output link back to it instead of replacing it with generic noise. For multiple independent failures, a deterministic report orders by phase, source ordinal, then code, while retaining dependency causality. Exception text never determines the stable error code.

Unknown internal exceptions map to a stable generic failure class with a restricted incident reference; detailed stack/context belongs in restricted logs. Diagnostic generation itself is bounded so malformed inputs cannot recursively produce unbounded cause chains.

### Redaction and evidence
Redact private paths, tokens, secret keys, signature material where sensitive, and protected dataset values by structured field policy. Preserve code, severity, phase, and conformance result. The redaction descriptor says which class was hidden without reproducing the value. Error receipts bind the failed input identity if safely available; they do not mark partially parsed data as a verified artifact.

A diagnostic distinguishes syntax rejection, unresolved external input, integrity mismatch, type failure, authorization failure, unsupported profile, resource limit, and operational unavailability. Unsupported runtime functionality is reported as unimplemented/not-run evidence, not simulated success.

## 8. Worked example

A duplicate row ID can report a stable parse-family code, severity error, source line, and row ID. A module-digest mismatch uses the MSSL integrity family and cites the declared binding without printing private resolver credentials.

When R3 fails verification and R4 consumes its output, R4's blocked status references R3's primary diagnostic. A public report can retain those relationships while redacting a private source location.

## 9. Boundary and adversarial cases

| Diagnostic defect | Why it matters |
|---|---|
| Error message string used as test oracle | Compatible wording changes break automation. |
| Generic downstream error hides root cause | Remediation targets the wrong failure. |
| Redaction changes failure to success | Evidence loses integrity. |
| Host exception contains a secret | Ingestion failure becomes disclosure. |
| Byte and character offsets are conflated | Editors select the wrong location. |
| Unsupported functionality returns a success receipt | Test evidence is fabricated. |

## 10. Security and failure considerations

A corpus error registry records stable families, but robust diagnostic coverage needs deliberate mapping of every implemented failure path. Never attach executable remediation text from untrusted source comments as system instructions; comments remain diagnostic/source data.

## 11. Verification obligations and current evidence boundary

Relevant current tests assert code-prefix stability for negative parser/canonicalization/container/schema cases. Planned runtime tests cover primary-cause propagation, redaction, offset correctness, bounded chaining, and unknown exceptions. Human-readable wording is not treated as a normative identity.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 produces source locations; WP10 defines sensitive data; WP20 defines result states; WP21 binds negative-test oracles.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
