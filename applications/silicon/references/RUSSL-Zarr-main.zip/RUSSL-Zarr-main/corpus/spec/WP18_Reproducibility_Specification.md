# WP18 — Reproducibility Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines deterministic build, dependency, environment, replay, and reproducibility receipts.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP17, WP08, WP05.

**Mandatory deliverables:**
- build manifest
- compiler/runtime identity
- dependency lock
- replay envelope
- environment
- receipt

## 5. Normative model
### Reproducibility envelope
A reproducibility envelope binds source digests, corpus version, compiler/runtime identifiers, schemas, MSSL modules, deterministic mode, locale/encoding, environment constraints, and all explicit seeds. Identity-critical output must not depend on wall-clock time, filesystem metadata, unordered directory traversal, or implicit random state.

Receipts distinguish deterministic reproduction from external validation or authorization.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP18-REQ-0001` | A reproducible build MUST record corpus version, source digests, compiler/runtime identity, dependency lock, and environment constraints. | `WP18-TEST-0001` |
| `WP18-REQ-0002` | Rebuilds under the same declared deterministic profile MUST reproduce canonical artifacts byte-for-byte. | `WP18-TEST-0002` |
| `WP18-REQ-0003` | Non-deterministic inputs such as wall clock, random seed, locale, or filesystem order MUST be fixed or excluded from identity-critical outputs. | `WP18-TEST-0003` |
| `WP18-REQ-0004` | Replay receipts MUST distinguish observed external inputs from deterministic internal derivations. | `WP18-TEST-0004` |
| `WP18-REQ-0005` | Reproducibility success MUST NOT be represented as external scientific validation. | `WP18-TEST-0005` |
| `WP18-REQ-0006` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP18-TEST-0006` |
| `WP18-REQ-0007` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP18-TEST-0007` |
| `WP18-REQ-0008` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP18-TEST-0008` |
| `WP18-REQ-0009` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP18-TEST-0009` |

## 7. Technical interpretation and algorithms

### Reproduction targets
Declare what is reproduced: canonical source, IR bytes, tuple members, physical .russ bytes, pure evaluation outputs, or effect receipts. These are different targets. A container rebuild can be deterministic while its mechanics has never been evaluated. Historical grant timestamps and external observations remain recorded inputs rather than fresh values inserted during reproduction.

An envelope binds input digests, corpus package/language/profile versions, compiler and runtime bytes, dependency versions/hashes, platform, encoding, locale, numeric libraries, seeds, and selected resource limits. A tool name or version string is weaker than a verified executable/dependency identity.

### Hermetic procedure
1. Verify the release manifest and required inputs before construction.
2. Select the declared interpreter/compiler environment and serializer profile.
3. Enumerate sources and members in a fixed order; fix encoding, locale, and archive metadata.
4. Construct canonical artifacts without reading implicit clock/random/network state.
5. Compare every declared output to an independent expected digest/byte fixture.
6. Produce an execution receipt that identifies checks, failures, exclusions, and observed external inputs.

At least one rebuild uses a clean destination so stale generated files cannot supply apparent success. Comparing only final checksums can miss untracked extras; archive membership and manifest closure are checked too.

### Numeric and environmental reproducibility
Bit-identical numerical outputs require a declared arithmetic profile, library versions, hardware behavior where relevant, threading/reduction order, and rounding. Tolerance-based scientific comparisons are useful but do not satisfy the byte-for-byte obligation for a claimed deterministic artifact profile. A report states which domain used exact bytes and which used numeric tolerances.

External input snapshots bind their observed bytes and observation context. Reproducing that snapshot is computational reproducibility; it does not repeat the physical measurement or validate the original observation.

## 8. Worked example

A rebuild can verify that all twelve source examples lower to the same canonical IR and that the golden .russ fixture is byte-identical. This establishes those build targets only. It does not show that a full MSSL interpreter produced field values or that a distributed commit is replay-safe.

A performance experiment records hardware, data sizes, warm/cold cache state, thread count, and repeated-run samples in addition to input/module hashes. Those results remain separate from deterministic identity checks.

## 9. Boundary and adversarial cases

| Hidden input | Reproduction risk |
|---|---|
| Directory enumeration order | Member/program ordering can vary. |
| Current clock in identified manifest | Rebuild digest changes. |
| Unpinned dependency | Serializer/parser behavior can drift. |
| Cached output reused without rebuilding | Test does not demonstrate construction. |
| Network source re-fetched without digest | Observation can change. |
| Float tolerance called byte identity | Claimed target is misstated. |

## 10. Security and failure considerations

Self-reproduction by a single implementation can preserve a shared bug. Independent implementations, property checks, and externally reviewed expected vectors strengthen evidence. Reproduction never supplies missing institutional authorization or empirical science.

## 11. Verification obligations and current evidence boundary

Current package checks can demonstrate local canonical artifact/golden rebuild equality. Multi-platform/cross-language builds, interpreter replay, independent expected-vector derivation, and measured performance are outstanding. Reports preserve this scope instead of promoting build success to all-class GO.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

Nineteen added attachments have exact raw-byte preservation and source IDs RA01–RA19 in research/ADDITIONAL_SOURCE_INTAKE.json. Published-paper results, corrected conversation claims, prospective protocols and generated index vectors have distinct evidence types. Reproducing an index formula does not replicate an optimizer, optical simulation or laboratory experiment.

## 13. Cross-specification consistency

WP17 fixes bytes; WP06/WP07 define artifact construction; WP08 defines historical effects; WP26 defines experiment reporting.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
