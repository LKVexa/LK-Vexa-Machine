# WP03 — RUSSL Type System

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines static and runtime types for values, coordinates, fields, modules, evidence, grants, and tuple handles.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP02, WP04.

**Mandatory deliverables:**
- type grammar
- dimensional typing
- unit rules
- effect typing
- inference limits

## 5. Normative model
### Type judgments
Core judgments have the form `Γ;Ε ⊢ row : τ ! ε`, where `Γ` maps handles to value types and `Ε` maps the row to its declared effect. Representative types are `Digest`, `Coord5`, `Shape5`, `Region5`, `Field<T,5>`, `MSSL<Module>`, `Evidence`, `Grant<Scope>`, `Root`, and `RUSSTuple`. `Field<T,5>` is invariant in rank; projections explicitly change rank.

Units are carried as qualified metadata and may constrain arithmetic or projection profiles, but a numeric value without unit metadata is never silently promoted to a physical quantity.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP03-REQ-0001` | The type system MUST include scalar, digest, coordinate, shape, field, MSSL-module, evidence, grant, root, and tuple-handle types. | `WP03-TEST-0001` |
| `WP03-REQ-0002` | A `Field<T,5>` MUST have exactly five indexed domains. | `WP03-TEST-0002` |
| `WP03-REQ-0003` | Dimension-changing operations MUST state their output rank and axis mapping. | `WP03-TEST-0003` |
| `WP03-REQ-0004` | Physical units MUST be metadata with explicit unit identifiers and MUST NOT be inferred from raw magnitudes. | `WP03-TEST-0004` |
| `WP03-REQ-0005` | Unknown or conflicting types MUST fail closed before effectful execution. | `WP03-TEST-0005` |
| `WP03-REQ-0006` | Floating-point values used in identity-critical structures MUST follow WP17 canonical representation rules. | `WP03-TEST-0006` |
| `WP03-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP03-TEST-0007` |
| `WP03-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP03-TEST-0008` |
| `WP03-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP03-TEST-0009` |
| `WP03-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP03-TEST-0010` |

## 7. Technical interpretation and algorithms

### Type domains and environments
A proposed type grammar is `τ ::= Bool | Int<w,s> | Float<w> | Decimal<p,s> | Digest<domain,alg> | Coord<rank> | Shape<rank> | Region<rank> | Field<sample,rank,axes> | Module<contract,digest> | Evidence<claim> | Grant<scope> | Root<domain> | Tuple<abi>`. Width, signedness, rank, coordinate basis, and digest domain are refinements; their erasure into a display label is not a proof of compatibility.

Use `Γ;Δ;Π ⊢ r : τ ! ε`, with handle environment Γ, module contracts Δ, and feature/numeric profile Π. The catalog's result labels such as `field_descriptor` are lowering annotations; a complete checker would verify these judgments rather than copy a label.

### Representative typing rules
For field construction, `shape=(n4,…,n8)`, all dimensions are positive integers, axes are five distinct declared domains, and dtype is supported; then `FIELD_DEFINE : Field<T,5>`. Population additionally checks source cardinality and sample compatibility. For a region `[la,ua)`, require `0≤la≤ua≤na` on each axis. A slice over a rank-k output declares exactly k surviving axes in a unique order, with fixed indices in range.

For evaluation, a declared MSSL alias resolves to a module contract `(τ1,…,τm)→τo`; operand arity and refinements agree with the contract. For commit, the candidate has a sealed-root type, arguments bind the observed head, and the effect is `commit`; policy evidence has a distinct type and is not coercible to `Grant<commit>`.

Unit compatibility is a profile relation `compatible(u,v)` accompanied by a declared conversion. Raw magnitudes have no physical unit. Numeric widening, signed conversion, overflow, rounding, and nullable/missing samples require explicit profile policies; the checker never repairs an unknown type by guessing.

### Soundness obligations and inference limits
Progress means a well-typed ready pure row either returns a declared result or a declared bounded failure. Preservation means successful evaluation maintains all output refinements and existing handle types. These are intended proof obligations, not established theorems. Inference is limited to registered operator defaults and uniquely known handle information; it does not infer absent calibration, module contracts, or authority.

## 8. Worked example

A `u16` field of shape `(1,1,1,2,3)` requires six samples in the canonical index traversal. Population by six integers in `[0,65535]` can satisfy an exact-value contract. Population by six floats requires a declared conversion; population by five samples fails cardinality checking.

A slice fixing c4, c5, and c6 yields `Field<u16,2,[c7,c8]>`. Reversing the output axes yields a different descriptor. An evidence digest and payload-root digest are both hexadecimal strings but have different domain-refined types.

## 9. Boundary and adversarial cases

| Defect | Intended type failure |
|---|---|
| `shape=1,1,1,2,0` | Empty dense axis violates the field-domain refinement. |
| Boolean used as an integer index | Host-language subtype behavior is not the intended index type. |
| Rank-3 transform attached to rank-5 input | Matrix and axis domains disagree. |
| A meter value is added to an unlabelled scalar | Unit inference would fabricate physical meaning. |
| Admission disposition used in a grant position | Policy and authorization types are disjoint. |
| Digest from another identity domain is accepted by spelling alone | String shape does not establish domain validity. |

## 10. Security and failure considerations

Type labels do not establish trust. Even a well-typed input can carry malicious bytes, false provenance, or an expired grant. Runtime checks remain necessary for externally supplied handles, module contracts, and range-dependent refinements. Opaque `source.*` handles remain unresolved until a resolver supplies typed, digest-bound inputs.

## 11. Verification obligations and current evidence boundary

The delivered tooling performs selected structural, operator-effect, and field-coordinate checks; it is not a general dimensional type checker. Required future tests include each rule's positive and negative derivations, overflow boundaries, unit conversions, missing-value cases, and a proof or mechanized review of progress/preservation for the implemented operator subset.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP04 defines dimensions and coordinates; WP05 defines module byte and contract binding; WP17 defines canonical identity-critical numbers. Package version 2.0.0 does not introduce a new language type syntax into `RUSSL/1.0`.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
