# WP08 — RUSSL Execution Model

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines lifecycle, deterministic scheduling, replay, rollback, resource accounting, and evidence.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP07, WP02, WP09.

**Mandatory deliverables:**
- execution phases
- state machine
- replay
- checkpoint/rollback
- receipts
- effect application

## 5. Normative model
### Execution state machine
`LOAD → VERIFY → RESOLVE → EVALUATE → AUTHORIZE_EFFECTS → APPLY_EFFECTS → EVIDENCE → FINALIZE`; any fail-closed error transitions to `ERROR`, while an authorized rollback transitions through `ROLLBACK` to a bound checkpoint. Candidate data may be derived before commit, but sealed roots are immutable.

The runtime interprets an allow-listed declarative operator set. Source text does not grant arbitrary code-loading authority.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP08-REQ-0001` | The execution lifecycle MUST include verify, resolve, evaluate, authorize-effects, evidence, and finalize/rollback phases. | `WP08-TEST-0001` |
| `WP08-REQ-0002` | Effectful rows MUST NOT execute before applicable grants are verified. | `WP08-TEST-0002` |
| `WP08-REQ-0003` | Candidate roots MUST be immutable after sealing. | `WP08-TEST-0003` |
| `WP08-REQ-0004` | Replay MUST use the same canonical inputs, module digests, execution profile, and deterministic order. | `WP08-TEST-0004` |
| `WP08-REQ-0005` | Rollback MUST target a digest-bound checkpoint and itself require commit authority. | `WP08-TEST-0005` |
| `WP08-REQ-0006` | Execution receipts MUST record tuple ID, run ID, phase, effects, and authorization state. | `WP08-TEST-0006` |
| `WP08-REQ-0007` | Arbitrary native, shell, Python, or WebAssembly code MUST NOT execute merely because it is embedded in RUSSL source. | `WP08-TEST-0007` |
| `WP08-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP08-TEST-0008` |
| `WP08-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP08-TEST-0009` |
| `WP08-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP08-TEST-0010` |
| `WP08-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP08-TEST-0011` |

## 7. Technical interpretation and algorithms

### Phase state and evidence
Define `phase∈{load,verify,resolve,evaluate,authorize,apply,evidence,finalize,error,rollback}`. Each transition records run identity, tuple identity, inputs, planned or applied effects, and primary failure. Verification precedes resolving executable interpretation; evaluation can produce a sealed candidate before any mutable state changes.

The phase invariant is `Applied(effect) ⇒ VerifiedInputs ∧ VerifiedGrant ∧ PreconditionsHeld`. A receipt distinguishes `planned`, `attempted`, `applied`, and `durably_recorded`. Crashes between application and receipt persistence are explicitly uncertain until a durable transaction record reconciles them; a restarted runtime does not infer that missing evidence means no effect occurred.

### Commit, retry, and rollback
A deployment transaction binds request identity, current state tip, new candidate root, grant nonce, and idempotency key. Compare-and-swap (CAS) checks the observed tip before changing it. Repeating the same request returns the previously recorded result; reusing its nonce for a different request fails. Correctness requires an atomicity contract among mutable-head update, nonce consumption, and durable result recording. A reference design without such storage guarantees is only a design.

Rollback updates a mutable reference to a digest-bound checkpoint under a fresh authorized transaction. Immutable content is preserved. A rollback can compensate a logical head transition; it does not erase an already published file, external notification, or replicated byte copy. Any broader compensation belongs to the deployment profile.

### Resource and replay profile
Evaluation fixes operator implementations, module digests, numeric behavior, reduction order, seed, and externally observed inputs. A runtime can impose instruction, memory, deadline, and cancellation budgets, with stable failure receipts. Embedding Python, shell, native, or WebAssembly text does not register a new operator or provide a grant.

Replay has two modes: pure derivation replay, which checks content equality, and historical effect reconstruction, which consults immutable receipts. Replaying effects against a live head is a fresh authorization decision and never an automatic consequence of successful pure replay.

## 8. Worked example

A commit plan binds old head H0 and candidate root H1. The grant also binds H0. If another actor changes the head to H2 before application, CAS rejects the stale plan; the original grant is not broadened to authorize H2→H1.

If the process crashes after H0→H1 but before publishing a receipt, restart reads a durable transaction record and returns the recorded outcome. Without that record the state is indeterminate, and the runtime halts automatic retry until reconciliation.

## 9. Boundary and adversarial cases

| Event | Required treatment |
|---|---|
| Grant expires after evaluation but before apply | Revalidate at the application boundary. |
| Nonce reused with new arguments | Reject replay/substitution. |
| Rollback reference is a mutable alias | Resolve immutable checkpoint before authorization. |
| Cancellation occurs during effect application | Report durable outcome or explicit uncertainty. |
| Receipt says success before adapter durability | Evidence overstates completion. |
| Embedded script is automatically executed | Declarative language authority is bypassed. |

## 10. Security and failure considerations

Exactly-once effects, crash consistency, authentic grants, and safe sandboxing require runtime and storage implementation work. A lowerer does not establish any of them. Operational deployments need measured budgets and recovery exercises rather than solely favorable schema checks.

## 11. Verification obligations and current evidence boundary

A complete runtime claim needs phase-transition tests, expiration/replay negatives, stale-tip races, crash injection at each durability boundary, rollback tests, and deterministic replay traces. These are roadmap obligations; the package does not include a full runtime executing this state machine.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP02 owns graph eligibility; WP09/WP10 own grants and authentication; WP11 owns policy/authorization separation; WP12 owns mutable-head storage consistency; WP18 owns replay envelopes.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
