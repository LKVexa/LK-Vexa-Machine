# WP07 — RUSS Tuple ABI

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the ABI from RUSSIR and MSSL bindings into a versioned .russ tuple-executable.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP06, WP04, WP05.

**Mandatory deliverables:**
- tuple registry
- component order
- identity
- compatibility
- golden manifest
- container framing

## 5. Normative model
### Normative tuple
The corpus defines the ordered ABI tuple `T=(I,L,G,S,C,M,A,P,F,E,X)`: Identity, Language, Geometry, State, Coupling, Mechanics, Admission, Projection, Fabric, Evidence, Execution. Ordering is identity-significant.

The candidate RUSS 1.3 framing retains the existing RUSS magic/header/record concept but replaces backend-specific canonical state with a logical Penteract descriptor. `tuple_id = russ:sha256:SHA256("RUSS-TUPLE/1.0\0" || canonical_json(T))`. The golden fixture is conformance evidence, not a production authorization.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP07-REQ-0001` | The normative tuple order MUST be `(I,L,G,S,C,M,A,P,F,E,X)`. | `WP07-TEST-0001` |
| `WP07-REQ-0002` | The `L` component MUST bind RUSSL source and RUSSIR identity. | `WP07-TEST-0002` |
| `WP07-REQ-0003` | The `M` component MUST bind MSSL modules by digest. | `WP07-TEST-0003` |
| `WP07-REQ-0004` | The `S` component MUST describe logical Penteract state without requiring a physical backend. | `WP07-TEST-0004` |
| `WP07-REQ-0005` | The `A` component MUST state that commit authorization is independent of mathematical admission. | `WP07-TEST-0005` |
| `WP07-REQ-0006` | Tuple identity MUST be computed over the ordered tuple using a domain-separated digest. | `WP07-TEST-0006` |
| `WP07-REQ-0007` | Every embedded payload member MUST be individually content-addressed. | `WP07-TEST-0007` |
| `WP07-REQ-0008` | The corpus golden `.russ` fixture MUST rebuild byte-for-byte deterministically. | `WP07-TEST-0008` |
| `WP07-REQ-0009` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP07-TEST-0009` |
| `WP07-REQ-0010` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP07-TEST-0010` |
| `WP07-REQ-0011` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP07-TEST-0011` |
| `WP07-REQ-0012` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP07-TEST-0012` |

## 7. Technical interpretation and algorithms

### Ordered logical tuple and member binding
Represent the ABI as an ordered sequence of eleven component descriptors `[I,L,G,S,C,M,A,P,F,E,X]`. A JSON object with alphabetically sorted keys is not a substitute for the specified tuple order. Each component's internal object can use canonical JSON while the enclosing sequence preserves its order.

Identity is computed over the canonical ordered logical tuple in the `RUSS-TUPLE/1.0` domain. A container-file digest identifies physical bytes independently. Repacking the same tuple and members can retain logical identity while changing container bytes; the deterministic golden fixture imposes an additional byte-equality constraint for its particular build profile.

### Framing and bounded verification
The package's .russ framing is a candidate container profile, not a standardized universal RUSS runtime ABI. A verifier first establishes magic, supported version, declared header/record bounds, finite member count, and exact end-of-file consumption. Each offset/length is checked with overflow-safe arithmetic and lies within the container; overlaps and trailing undeclared bytes are rejected under the strict profile.

Logical member names are normalized safe relative paths. Absolute, drive-qualified, parent-traversing, separator-confused, duplicate, or platform-colliding member paths are not safe extraction targets. Validate the member table and payload digests before extraction; parsing never authorizes executing any embedded script. A member descriptor binds its name, logical role, exact size, and digest.

### Graph completeness
Component L binds source and IR; M binds exact mechanics files; S describes logical field state; A distinguishes policy disposition from commit authority. For every required reference `r`, either a verified embedded member supplies it or a declared external resolution contract identifies it. A bare filename, boolean verification flag, or fabricated successful receipt does not discharge reference integrity or authorization.

Dependency closure verification is separate from archive-byte validity. A small structurally valid fixture need not contain scientific payloads or prove a runnable MSSL stack.

## 8. Worked example

The logical tuple can bind `L.source_id` and `L.ir_id`, four MSSL digests in M, and a shape descriptor in S. The container stores source/IR/module members with raw byte digests. To verify it, recompute both member digests and the domain-separated tuple identity; comparing only the outer file checksum cannot establish that internal references match.

Two rebuilds of the golden fixture with the same framing and member order are expected to be byte-identical. This applies to the golden build profile, not every conceivable container encoding of the tuple.

## 9. Boundary and adversarial cases

| Attack or defect | Verifier obligation |
|---|---|
| Member named `../outside` or a drive path | Refuse unsafe namespace. |
| Declared size exceeds actual remaining bytes | Reject truncated/overflowing record. |
| Two members resolve to the same normalized path | Reject ambiguous extraction target. |
| Correct outer digest but L points to another IR | Reject broken internal binding. |
| Payload digest matches but tuple component order changes | Logical ABI identity changes. |
| An embedded receipt claims grants were verified | Treat assertion as untrusted data, not a signature check. |

## 10. Security and failure considerations

Compressed/external member resolution requires independent resource and decompression limits. Container parsing and deterministic construction are implemented support utilities; no production loader, arbitrary-code execution, or full tuple runtime is implied by a successful rebuild.

## 11. Verification obligations and current evidence boundary

Current evidence can establish deterministic fixture bytes, framing bounds, path safety, member digests, and cross-reference consistency. ABI compatibility across independent implementations, all component semantics, and execution behavior require separate runtime and interoperability evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The original golden source and field descriptor contradicted one another in shape and sample dtype. Exact original bytes are retained under examples/legacy_golden/ and rejected by the hardened binder. The active candidate fixture binds the source declaration 4×4×4×16×16/f64 to a coherent descriptor, with new payload/tuple/container identities. No source.state sample data or execution result is supplied.

## 13. Cross-specification consistency

WP17 separates logical identity from raw container/member hashes. WP12 binds graphs, WP10 treats packaging as a trust boundary, and WP20 scopes a tuple claim to the checks actually executed.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
