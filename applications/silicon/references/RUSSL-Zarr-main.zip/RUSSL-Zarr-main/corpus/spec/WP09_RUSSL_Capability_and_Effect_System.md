# WP09 — RUSSL Capability and Effect System

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines least-privilege effects and digest-bound grants.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP03, WP08.

**Mandatory deliverables:**
- capability vocabulary
- effect declarations
- scope attenuation
- grant fields
- enforcement
- negative tests

## 5. Normative model
### Grant model
A capability grant is a signed, digest-bound authorization object over `(run_id,tuple_id,row_id,sequence,input_root,planned_effects,args_sha256,scopes,state_tip,rollback_checkpoint,nonce,expires_at,actor,reviewers)`. Verification validates signature, time, nonce/replay state, scope, and exact effect/argument bindings.

Capabilities form no implicit hierarchy. In particular, `write:state` does not imply `commit`, and `commit` does not imply `publish`.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP09-REQ-0001` | The core capability vocabulary MUST include `read`, `derive`, `project`, `write:evidence`, `write:state`, `commit`, `replicate`, and `publish`. | `WP09-TEST-0001` |
| `WP09-REQ-0002` | No capability MUST imply another capability. | `WP09-TEST-0002` |
| `WP09-REQ-0003` | An effectful row MUST be authorized by a grant whose scope covers that row and effect. | `WP09-TEST-0003` |
| `WP09-REQ-0004` | A grant MUST bind run ID, tuple ID, row ID, sequence, input root, planned effects, arguments digest, scopes, state tip, rollback checkpoint, nonce, expiration, actor, and signature. | `WP09-TEST-0004` |
| `WP09-REQ-0005` | Commit-capable grants MUST be replay-resistant and expiration-checked. | `WP09-TEST-0005` |
| `WP09-REQ-0006` | Scope attenuation MAY reduce but MUST NOT widen an upstream grant. | `WP09-TEST-0006` |
| `WP09-REQ-0007` | Boolean flags such as `signature_verified:true` MUST NOT substitute for cryptographic verification. | `WP09-TEST-0007` |
| `WP09-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP09-TEST-0008` |
| `WP09-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP09-TEST-0009` |
| `WP09-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP09-TEST-0010` |
| `WP09-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP09-TEST-0011` |

## 7. Technical interpretation and algorithms

### Effect sets and non-amplification
Model authority as a set of explicit capabilities, each with a target scope. The vocabulary `read, derive, project, write:evidence, write:state, commit, replicate, publish` is flat: membership in one set does not imply another. A row's effect is derived from its canonical operator, so changing `META.eff` cannot hide a commit under a read label.

A proposed judgment is `grant ⊨ (run,tuple,row,input,args,effect,scope,tip)`. It holds only when all signed bindings match the planned operation, the cryptographic profile accepts the signature and signer, the key is authorized for that scope, the grant is live, and nonce/sequence policy permits its use. Parsing the grant object establishes none of these facts.

### Scope attenuation
Represent a scope as a predicate over targets and operations. Delegation from parent P to child C is valid only if `∀x,C(x)⇒P(x)`, and the child's expiration, effect set, target roots, and argument constraints are no broader. String prefix matching is not a general scope algebra: `dataset/a` and `dataset/ab` are different targets unless a declared hierarchical profile explicitly relates them.

Grant signing specifies a byte preimage, signature algorithm, key identifier, trust anchor, and canonicalization profile. The signed body excludes the signature itself and includes all fields that can change effect meaning. A signature-verified boolean is an observation supplied by an untrusted object, never the verifier's result.

### Application-time validation
Validate once to construct a plan, then revalidate expiry, revocation applicability, nonce availability, and state tip immediately before application. Atomically couple nonce consumption to the effect transaction or use a durable idempotency record; merely checking and later inserting a nonce admits races. Sequence numbers have an explicit monotonic scope and do not replace nonce binding.

A grants profile also specifies trusted time, maximum clock skew, unknown-key behavior, key rotation, revocation transport, and unavailable-revocation policy. These choices remain deployment controls pending implementation and review.

## 8. Worked example

A grant for `write:state` can authorize uploading candidate bytes to a CAS adapter. It does not authorize moving `heads/project-a` to that root. The latter operation requires a matching `commit` capability and current-head binding. Publishing the root to another audience requires a distinct `publish` capability.

A child grant limited to one immutable root, one row, and an earlier expiration is an attenuation if every requested operation already lies in the parent's scope. Changing only the actor's display name does not establish a new authenticated principal.

## 9. Boundary and adversarial cases

| Manipulation | Reason authority fails |
|---|---|
| Add publish to a derive-only grant | Capability set widens. |
| Reuse valid signature with another row or argument digest | Signed operation binding differs. |
| Set `signature_verified=true` without a signature verifier | Data asserts its own authority. |
| Check nonce and apply in separate non-atomic steps | Concurrent replay can pass twice. |
| Treat a policy ADMIT value as commit permission | Authority domains are conflated. |
| Allow an unknown key because the JSON schema validates | Key trust is unestablished. |

## 10. Security and failure considerations

The package defines grant data shapes and negative design obligations but does not ship a cryptographic grant service, trusted clock, revocation service, replay store, or transaction coordinator. Sample grants are fixtures. No fixture authorizes an operational effect.

## 11. Verification obligations and current evidence boundary

The executable parser can enforce registered operator effects; schema and cross-field checks can inspect grant shape. Authentic signature, expiry/skew, replay-race, attenuation, revocation, key rotation, and application-time tests are outstanding for a security/runtime claim.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP10 defines trust boundaries; WP08 couples authorization to application; WP11 separates policy disposition; WP12 scopes mutable-head targets.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
