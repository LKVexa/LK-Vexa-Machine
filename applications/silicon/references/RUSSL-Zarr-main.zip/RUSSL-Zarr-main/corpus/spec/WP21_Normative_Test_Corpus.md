# WP21 — Normative Test Corpus

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines and supplies positive, negative, golden, and security/conformance vectors.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP20, All normative specs.

**Mandatory deliverables:**
- syntax vectors
- semantic/type vectors
- field vectors
- MSSL vectors
- security negatives
- hash vectors
- golden artifacts

## 5. Normative model
### Test taxonomy
Tests are positive parse/lower vectors, negative fail-closed vectors, field coordinate vectors, canonicalization identities, MSSL byte bindings, JSON-schema validation, deterministic fixture rebuild, requirements traceability, and architectural leakage scans. Golden expected hashes are stored with the vectors.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP21-REQ-0001` | The test corpus MUST include valid and invalid syntax vectors. | `WP21-TEST-0001` |
| `WP21-REQ-0002` | The test corpus MUST include Penteract coordinate vectors. | `WP21-TEST-0002` |
| `WP21-REQ-0003` | The test corpus MUST verify all four baseline MSSL file digests. | `WP21-TEST-0003` |
| `WP21-REQ-0004` | The test corpus MUST include canonicalization/hash vectors. | `WP21-TEST-0004` |
| `WP21-REQ-0005` | The test corpus MUST include at least one deterministic golden `.russ` fixture. | `WP21-TEST-0005` |
| `WP21-REQ-0006` | Negative tests MUST include storage-semantic leakage, missing MSSL digest, duplicate row ID, and forward dependency. | `WP21-TEST-0006` |
| `WP21-REQ-0007` | Golden artifacts MUST record expected hashes. | `WP21-TEST-0007` |
| `WP21-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP21-TEST-0008` |
| `WP21-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP21-TEST-0009` |
| `WP21-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP21-TEST-0010` |
| `WP21-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP21-TEST-0011` |

## 7. Technical interpretation and algorithms

### A test is an oracle plus executable evidence
A test record identifies the target behavior, requirement links, setup/input digests, execution procedure, expected result, comparison domain, tool/profile, applicability, and output evidence. A title such as “verify WP03-REQ-0005” is a plan until a real test determines that unknown types are rejected before effects.

Golden values are reviewed inputs, not values regenerated and immediately declared expected by the same implementation. Updating goldens records the semantic reason and old/new identities. Identity vectors include the exact preimage bytes so another implementation can calculate expectations independently.

### Coverage dimensions
| Dimension | Positive evidence | Negative or boundary evidence |
|---|---|---|
| Syntax | Canonical source accepted | Ordering, delimiter, duplicate key/ID, incomplete frame |
| Data flow | Producer reachable through controls | Missing ancestor, future dependency, duplicate output |
| Identity | Exact known source/IR/tuple hash | Duplicate JSON keys, nonfinite values, wrong domain |
| Geometry | Endpoint/singleton/region expectations | Invalid indices, anchors, dimensions, overflow |
| Tuple | Deterministic verified fixture | Truncation, traversal, member mismatch, broken reference |
| Schemas | Declared samples valid | Wrong type, missing field, unknown property, cross-field conflict |
| Runtime/authority | Future transition/grant traces | Future replay, expiry, races, crash/recovery |

Metamorphic tests assert relationships rather than mirror code: source canonicalization idempotence, alias normalization equality for unchanged canonical content where applicable, adapter-independent coordinate mapping, and tampered-byte rejection. Property-based generation remains bounded and records seeds.

### Status and aggregation
Requirement coverage distinguishes `registered`, `implemented`, `executed`, and `passed`. Some shared architectural/governance requirements require review artifacts rather than code execution; their evidence is recorded as review, not numeric unit-test success. Full runtime/type/mechanics/adapter tests remain planned when no implementation exists.

A suite exits unsuccessfully on a mandatory applicable failure or not-run obligation for its declared claim. A bounded tooling suite can pass its own checks while broader corpus conformance remains NO_GO. Failure artifacts preserve reproducing inputs and stable diagnostic codes.

## 8. Worked example

For a forward-dependency negative, store a small source where R1 names R2 before R2 appears, identify its input bytes, execute the parser, and compare the dependency error family. “File exists” is not the oracle.

For a tuple traversal negative, alter a member path to `../escape` while keeping framing coherent, then establish that the verifier rejects it before extraction. An invalid outer checksum alone does not isolate traversal validation.

## 9. Boundary and adversarial cases

| Weak test design | Defect |
|---|---|
| Golden generated by the tested function during the test | Circular expectation. |
| Registry record without executed procedure | Planned, not passed. |
| All negatives rejected by one earlier failure | Later controls remain untested. |
| Runtime behavior inferred from a schema-valid receipt | Receipt data is not an execution trace. |
| Missing cases silently excluded after a failure | Applicability decision is biased. |

## 10. Security and failure considerations

Fuzzing can find failures but cannot prove absence of all failures. Store minimized cases without exposing confidential input material. Test scripts included in the corpus are inspected code; attachment presence alone does not authorize executing arbitrary scripts.

## 11. Verification obligations and current evidence boundary

The package adds meaningful local hardening tests and preserves broader test IDs for future work. Current aggregate checks do not establish all 293 original requirement obligations. Exact counts and statuses come from the final requirements/test registries and executed report.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The supplemental finite-layout tests enumerate all 16,384 sites and check exact ordinal/index consistency. Their data and scope are documented in the [fixed-shape profile](../research/FIXED_SHAPE_INDEXING_PROFILE.md). These tests add concrete mathematical evidence but do not close all original language/runtime/scientific requirements.

## 13. Cross-specification consistency

WP20 defines claims and GO; WP19 defines stable errors; WP18 defines repeatability; WP28 validates records without fabricating behavioral evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
