# WP06 — RUSSL Intermediate Representation

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines canonical RUSSIR and deterministic source-to-IR lowering.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP02, WP03, WP05.

**Mandatory deliverables:**
- IR schema
- normalized instruction graph
- resolved modules
- lowering
- canonical identity
- golden vectors

## 5. Normative model
### Lowering function
`lower : CanonicalRUSSL → RUSSIR` resolves operator aliases, infers registered face/type/default effect, expands dependencies and packed inputs, and copies unit/default/MSSL declarations. No storage adapter is selected during lowering.

`ir_id = russir:sha256:SHA256("RUSSIR/1.0\0" || canonical_json(IR_without_ir_id))`. Source identity uses the independent `RUSSL-SOURCE/1.0` domain.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP06-REQ-0001` | RUSSIR MUST contain explicit canonical operators, faces, effects, dependencies, inputs, arguments, and metadata. | `WP06-TEST-0001` |
| `WP06-REQ-0002` | RUSSIR MUST preserve source row IDs and source order. | `WP06-TEST-0002` |
| `WP06-REQ-0003` | MSSL aliases in RUSSIR MUST resolve to digest-bound declarations. | `WP06-TEST-0003` |
| `WP06-REQ-0004` | The source-to-IR transformation MUST be deterministic for identical canonical source and compiler profile. | `WP06-TEST-0004` |
| `WP06-REQ-0005` | RUSSIR identity MUST be domain-separated from source and tuple identities. | `WP06-TEST-0005` |
| `WP06-REQ-0006` | IR serialization MUST use WP17 canonical JSON rules. | `WP06-TEST-0006` |
| `WP06-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP06-TEST-0007` |
| `WP06-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP06-TEST-0008` |
| `WP06-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP06-TEST-0009` |
| `WP06-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP06-TEST-0010` |

## 7. Technical interpretation and algorithms

### Deterministic lowering pipeline
The profile pipeline is `canonicalize → parse → validate_structure → resolve_operator_aliases → annotate → serialize → identify`. Operator resolution is a finite catalog lookup. Annotation supplies the registered face, result label, and effect; explicit effects agree with the catalog. Lowering copies declared module descriptors, expands primary inputs, records control dependencies, and preserves frame and row order.

An implementation can check that `program = concat(frame.rows)` by value and order. The duplicated frame/program views are consistency-sensitive: a modified copy in one view is invalid even if the JSON shape remains acceptable. A supplied IR is untrusted until both schema shape and cross-field invariants are verified.

### Identity preimage
Let `J` be the IR object before `ir_id` is inserted. Compute `h=SHA256(ASCII("RUSSIR/1.0") || 0x00 || CJSON(J))`; represent identity as `russir:sha256:h`. Verification removes only the self-identifying `ir_id` field from the preimage and recomputes the digest; removing arbitrary other fields would weaken identity.

The IR schema tag remains `RUSSL.CanonicalIR/1.0` for this package. A compiler/profile identifier belongs in release and reproduction evidence unless a new IR contract explicitly adds it. Identical current IR bytes can retain their previous identities; package version 2.0.0 does not force the language/schema identity domain to change.

### Source positions and equivalence
This IR includes `source_line` annotations and a source digest. Thus adding a comment or blank line can change source identity and source-position fields even when operators behave the same. Semantic equivalence, canonical-source equality, and IR-byte equality are different relations. The lowerer provides deterministic structural translation, not proof that source and runtime semantics are equivalent.

The expected consistency properties are: row IDs preserved; all aliases canonicalized; all referenced aliases declared; no physical adapter chosen; graph order valid; no output produced twice; and the self-identity recomputes under the exact serializer profile.

## 8. Worked example

The source alias `FD` lowers to `FIELD_DEFINE`, with face `FIELD`, result label `field_descriptor`, and effect `derive`. A populated-field operand string `field.main›source.pixels` becomes two ordered inputs.

```json
{"op":"FIELD_DEFINE","face":"FIELD","type":"field_descriptor","effect":"derive"}
```

This fragment is illustrative and not a complete valid IR record. The type label reflects the catalog. It does not certify shape validity, sample cardinality, or the existence of the external input.

## 9. Boundary and adversarial cases

| Modification | Verification failure |
|---|---|
| `frames` row differs from its `program` copy | Cross-view consistency is broken. |
| Alias spelling remains in a canonical operator field | Lowering normalization is incomplete. |
| Module operand names an undeclared alias | Binding relation is unresolved. |
| `ir_id` is trusted without recomputation | Content substitution remains possible. |
| Hash preimage includes `ir_id` recursively | Identity construction is ill-founded. |
| Source-line annotations are discarded during verification | The stated identity no longer covers the supplied object. |

## 10. Security and failure considerations

An IR supplied by another compiler can contain contradictory effects or duplicated authority-bearing fields. Revalidation is independent of having a plausible source hash. A compiler's own digest is supply-chain provenance; it does not certify its correctness.

## 11. Verification obligations and current evidence boundary

Golden source-to-IR comparison, identity recomputation, flattened-view consistency, schema validation, and malformed structural cases are the appropriate current checks. Full semantic preservation and type-correct lowering await an implemented evaluator/checker and independent differential evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 fixes the surface profile; WP03 explains the difference between annotations and types; WP17 fixes exact bytes. WP18 binds compiler identity and profile in reproducibility evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
