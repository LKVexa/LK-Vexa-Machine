# WP28 — Machine-Readable Schemas

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines authoritative grammars, schemas, registries, and schema tests.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP06, WP07, WP20, WP25.

**Mandatory deliverables:**
- grammar artifact
- RUSSIR schema
- tuple schema
- MSSL binding schema
- receipts
- conformance schema
- extension registry

## 5. Normative model
### Schema authority
JSON schemas use Draft 2020-12 identifiers under `urn:russl:schema:*`. The EBNF grammar is the machine-readable source syntax artifact. Registries for operators, errors, capabilities, MSSL bindings, and extensions are versioned corpus resources. Schema conformance is tested by the packaged verifier.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP28-REQ-0001` | Machine-readable schemas MUST be versioned and carry stable identifiers. | `WP28-TEST-0001` |
| `WP28-REQ-0002` | The corpus MUST publish schemas for RUSSIR, Penteract field descriptors, MSSL bindings, tuple manifests, capability grants, evidence receipts, execution receipts, conformance results, and extension registries. | `WP28-TEST-0002` |
| `WP28-REQ-0003` | Schema samples MUST validate under the declared JSON Schema draft. | `WP28-TEST-0003` |
| `WP28-REQ-0004` | Schema changes that break previously valid normative artifacts MUST require a major schema version. | `WP28-TEST-0004` |
| `WP28-REQ-0005` | The grammar artifact MUST match the surface syntax described in WP01. | `WP28-TEST-0005` |
| `WP28-REQ-0006` | The extension registry schema MUST preserve explicit lifecycle status. | `WP28-TEST-0006` |
| `WP28-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP28-TEST-0007` |
| `WP28-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP28-TEST-0008` |
| `WP28-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP28-TEST-0009` |
| `WP28-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP28-TEST-0010` |

## 7. Technical interpretation and algorithms

### Schema dialect and implementation scope
The corpus publishes JSON schemas with stable identifiers and declared Draft 2020-12 dialects. Dialect identification is not proof that a validator implements every vocabulary. Draft 2020-12 separates format annotation from format assertion; a validator using annotation mode does not automatically reject an invalid timestamp solely because `format=date-time` appears. [JSON Schema Draft 2020-12](https://json-schema.org/draft/2020-12)

The package's local dependency-free validator has an explicitly bounded supported-keyword contract and fail-closed behavior for unsupported constructs. It is not advertised as a complete general Draft 2020-12 implementation. A future full validator is pinned and tested against the actual dialect/vocabularies.

### Structural and cross-field layers
Structural validation checks required keys, primitive types, arrays/tuples, allowed values, patterns, bounds, and closed-world property policy under supported keywords. A JSON integer is not a host boolean. Strict ingestion rejects duplicate keys and nonfinite numbers before schema validation; a schema cannot recover fields discarded by a permissive parser.

Cross-field validation checks relations that schemas alone may not express: unique row/output namespaces, consistent flattened program/frame rows, operator/effect agreement, declared alias usage, rank/axis/shape length, tuple member/reference binding, matching grant identifiers, and self-identity recomputation. Authentic signatures, actual module evaluation, and truth of conformance results lie beyond schema shape.

### Closed-world evolution
Authority-bearing records use explicit allowed properties; extensions enter designated namespaces with lifecycle and version rather than arbitrary unknown executable fields. Opaque provenance fields remain inert data. New fields are reviewed for validator compatibility and hash-preimage impact.

Schema resources resolve through a local, versioned allow-list. No automatic network `$ref` resolution occurs merely because a schema requests it. Reference depth and cyclic processing are bounded. Schema and EBNF edits are reviewed with example fixtures and parser behavior to prevent a prose/grammar/implementation split.

## 8. Worked example

A tuple schema can require eleven components and named identities. The semantic verifier still checks their order, referenced member digests, and actual content. A grant schema can require `signature`, `nonce`, and `expires_at`; only a cryptographic/runtime verifier can establish that the signature is trusted, the nonce unused, and expiry live.

A field schema checks five positive dimensions. A cross-field checker additionally relates axis names and sample-count expectations where supplied. Neither check loads or computes missing scientific pixels.

## 9. Boundary and adversarial cases

| Artifact | Validation boundary |
|---|---|
| Boolean where shape integer is expected | Reject type confusion. |
| Unknown property on a closed authority record | Reject undeclared semantics. |
| Duplicate JSON key | Reject during ingestion, before schema. |
| External `$ref` points to an arbitrary URL | Resolution authority absent. |
| Valid IR shape but inconsistent program/frame copies | Cross-field rejection. |
| Schema-valid receipt asserts runtime success | Truth/authenticity is not established. |

## 10. Security and failure considerations

Unbounded references and complex schema constructs can exhaust validation resources. A bounded internal validator needs a supported-keyword inventory and adversarial tests; silently ignoring an unknown validation keyword would create false assurance.

## 11. Verification obligations and current evidence boundary

Current checks establish schema/sample structure and selected cross-field rules under the bundled local profile. Full Draft 2020-12 metaschema/official-suite conformance, external-validator parity, exhaustive semantic validation, and authentic receipts remain outside that claim.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01 and grammar govern syntax; WP06/WP07 govern identity-sensitive records; WP09 governs grants; WP20 governs truthful result semantics; WP25 governs schema/version changes.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
