# WP20 — Conformance Standard

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines conformance classes, test declarations, compatibility, GO/NO_GO, and reports.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01–WP19.

**Mandatory deliverables:**
- classes
- feature levels
- test format
- result schema
- compatibility
- GO/NO_GO

## 5. Normative model
### Conformance classes
Classes are `P` parser, `C` compiler/lowerer, `R` runtime, `M` MSSL binding, `T` tuple/container, `F` fabric, `S` security, `D` determinism/reproducibility, and `I` interoperability. Claims name class set, corpus version, profile, test set digest, and result digest.

`GO` is a scoped result requiring every applicable mandatory check to execute and pass; no corpus-wide GO is inferred from aggregate static checks. External certification is always a separate artifact.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP20-REQ-0001` | Conformance classes MUST separately identify parser, compiler, runtime, MSSL binding, tuple, fabric, security, determinism, and interoperability claims. | `WP20-TEST-0001` |
| `WP20-REQ-0002` | A conformance claim MUST name the corpus version and feature profile. | `WP20-TEST-0002` |
| `WP20-REQ-0003` | A `GO` corpus result MUST require every mandatory check to PASS. | `WP20-TEST-0003` |
| `WP20-REQ-0004` | Skipped mandatory tests MUST produce `NO_GO`. | `WP20-TEST-0004` |
| `WP20-REQ-0005` | Conformance reports MUST state that they are not external certification unless independently certified. | `WP20-TEST-0005` |
| `WP20-REQ-0006` | Version compatibility MUST be explicit and MUST fail closed for unknown major versions. | `WP20-TEST-0006` |
| `WP20-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP20-TEST-0007` |
| `WP20-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP20-TEST-0008` |
| `WP20-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP20-TEST-0009` |
| `WP20-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP20-TEST-0010` |

## 7. Technical interpretation and algorithms

### Claims are sets of bounded assertions
A claim identifies implementation/tool bytes, class set, feature subset, language/profile version, corpus package version, requirements in scope, test-suite digest, environment, and result evidence. Classes are P parser, C compiler, R runtime, M MSSL binding, T tuple, F fabric, S security, D reproducibility/determinism, and I interoperability. Class labels alone are not executable evidence.

A result model separates per-check `PASS, FAIL, NOT_RUN, NOT_IMPLEMENTED, NOT_APPLICABLE` from release decisions. Applicability is decided from a documented profile before results are inspected. Unimplemented semantics remain visible; documentation completeness does not substitute for execution.

### Decision rule
For a declared scoped claim Q, let M(Q) be its mandatory applicable checks. A scoped GO requires every member of M(Q) to have executed and passed with valid evidence. A skipped, unimplemented, or not-run member fails the mandatory condition. An empty mandatory set cannot justify a substantive conformance claim; it signals an incomplete claim definition.

Corpus-wide GO quantifies over all applicable mandatory requirements across claimed classes. Fifteen aggregate verifier checks or hundreds of registry links are not hundreds of executed behavioral checks. A test ID proves traceability only after it resolves to a real oracle and evidence. Coverage is reported at requirement granularity with implementation, test, and evidence status separately.

### Document status versus operational status
This 2.0.0 package is a hardened research/institutional candidate. Its specs are proposed contracts with preserved IDs. A successful local artifact verifier reports the bounded checks it actually performed. It does not mark all work packages, runtime semantics, experimental mechanics, security controls, or adapter profiles GO.

A release decision is a human/institutional governance artifact with authentic decision authority. External certification is another artifact entirely. Unknown language/schema majors fail closed; package-major changes can correct assurance and structure without inventing a new `RUSSL/1.0` syntax.

## 8. Worked example

A precise current claim can read: “The identified Python tool passed the recorded syntax/structural-lowering vectors, source/IR hash checks, bounded tuple checks, and local schema/cross-field checks under the 2.0.0 hardened reference profile.” Its report lists exact checks.

A separate runtime claim lists scheduler, module evaluation, grant verification, state commit, and replay requirements. If these are unimplemented, their mandatory evidence is NOT_IMPLEMENTED/NOT_RUN and the runtime claim receives NO_GO.

## 9. Boundary and adversarial cases

| Overclaim | Correct assessment |
|---|---|
| Every registry row is counted as a test pass | Registry linkage is not execution. |
| Unknown or skipped mandatory check counted as pass | Scoped GO condition fails. |
| Text includes “MUST” so behavior is declared implemented | Specification and implementation status differ. |
| Local checksum success called external certification | No certifier evidence exists. |
| Empty feature profile used to claim all-class conformance | Claim scope is vacuous/invalid. |

## 10. Security and failure considerations

Conformance reports are security-relevant evidence. If tool output can mark unsupported tests passed or omit mandatory tests, downstream assurance becomes unreliable. The report schema and verifier need independent review and negative cases for missing/contradictory evidence.

## 11. Verification obligations and current evidence boundary

The revised package requires honest scoped reporting. The original blanket Internal GO and all-requirement conformance implications are superseded. Executed check evidence, not this prose, determines any local PASS. Full corpus semantics and external certification remain unestablished.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP21 owns actual oracles; WP27 owns assurance claims; WP25 owns authentic release decisions; WP28 validates report shape but not the truth of a pass assertion.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
