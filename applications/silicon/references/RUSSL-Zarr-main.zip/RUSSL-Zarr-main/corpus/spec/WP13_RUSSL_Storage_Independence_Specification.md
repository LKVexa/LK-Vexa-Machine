# WP13 — RUSSL Storage Independence Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the boundary and adapter contract between logical RUSS semantics and physical storage.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP12.

**Mandatory deliverables:**
- adapter interface
- canonical/derived distinction
- backend capabilities
- adapter profiles
- conformance

## 5. Normative model
### Adapter contract
A conforming adapter exports `put(bytes)->digest`, `get(digest)->bytes`, `has(digest)->bool`, `verify(digest,bytes)`, and `capabilities()`. Optional region/range methods may accelerate partial retrieval. Adapter choice is recorded in the fabric component or deployment profile, never in core field identity unless adapter-specific bytes themselves are being identified.

The profile catalog includes native CAS, filesystem/object-store, TIFF-family import/export, and OME-Zarr interoperability. They are subordinate representations.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP13-REQ-0001` | Core RUSSL semantics MUST be invariant under substitution of conforming physical storage adapters. | `WP13-TEST-0001` |
| `WP13-REQ-0002` | An adapter MUST implement logical `put`, `get`, `has`, integrity verification, and capability reporting. | `WP13-TEST-0002` |
| `WP13-REQ-0003` | Adapter metadata MUST identify whether an output is canonical, derived, or cache-only. | `WP13-TEST-0003` |
| `WP13-REQ-0004` | Zarr/OME-Zarr and TIFF-family behaviors MUST be confined to adapter/interoperability profiles. | `WP13-TEST-0004` |
| `WP13-REQ-0005` | A storage adapter MUST NOT redefine Penteract coordinates or MSSL semantics. | `WP13-TEST-0005` |
| `WP13-REQ-0006` | Lossy adapter behavior MUST be explicitly declared and provenance-bound. | `WP13-TEST-0006` |
| `WP13-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP13-TEST-0007` |
| `WP13-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP13-TEST-0008` |
| `WP13-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP13-TEST-0009` |
| `WP13-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP13-TEST-0010` |

## 7. Technical interpretation and algorithms

### Adapter operations and error contracts
The abstract adapter interface operates on bounded immutable byte objects and digest domains. `put` returns the calculated content identity after the declared durability level is achieved; `get` returns verified bytes or a typed missing/corrupt/unavailable error; `has` is only a hint unless the profile promises stronger consistency. Presence checks do not replace fetching and verifying.

Capabilities describe supported object sizes, digest algorithms, atomic put behavior, partial retrieval, conditional head updates, consistency, durability, and retention. Unsupported optional functions are discoverable and produce explicit failures. Retry policy distinguishes idempotent immutable writes from state-changing head transactions.

### Observational equivalence
For adapters A and B, storage independence is the relation `observe(exec(P,A)) ≃ observe(exec(P,B))` over canonical logical outputs for the same verified inputs and execution profile. Location, latency, retry counts, and availability receipts can differ. Semantic equality is not asserted when one adapter loses metadata, applies resampling, or returns different bytes.

Three output roles are distinct: canonical objects define the field contract; derived objects bind a transformation and source identity; cache-only objects are dispensable accelerators with verification and invalidation rules. A cache path or physical chunk key is not a canonical root.

### Representation levels
Raw encoding identity concerns the exact bytes of a payload/descriptor. Logical sample equivalence concerns decoded values, axis placement, and missingness. Profile equivalence concerns application meaning such as color or calibrated units. Two codecs can produce equal logical samples and different byte identities. The current package does not define a codec-independent semantic digest for all samples; such a digest would require its own numeric, ordering, coverage, and domain contract.

Import/export adapters register supported external versions, codecs, loss classes, metadata policies, and round-trip comparison domains. These properties belong to profile manifests and do not grant arbitrary filesystem or network authority.

## 8. Worked example

A filesystem CAS and an object-store CAS can both return the same digest-bound payload bytes. Their storage addresses differ while logical field coordinates remain unchanged. If one adapter transcodes a u16 payload to u8, it produces a derived lossy output with a new identity rather than an equivalent canonical object.

A decoded-sample comparison can demonstrate value preservation across compression changes. It cannot demonstrate byte-identity equality unless the encoded bytes also match.

## 9. Boundary and adversarial cases

| Behavior | Contract problem |
|---|---|
| `has=true` followed by unverified bytes accepted | Presence is mistaken for integrity. |
| Cache path determines field coordinates | Logical semantics depend on storage. |
| Transcoding is labeled canonical without provenance | Loss classification is concealed. |
| An adapter silently opens network paths from core ARG | Core text acquires undeclared effects. |
| Backend replacement changes dtype or sparse default | Observational equivalence fails. |

## 10. Security and failure considerations

Backend independence is an architecture property requiring evidence over concrete adapters. It is not proven by banning a format name with a regular expression. Loss reports and storage credentials remain deployment responsibilities.

## 11. Verification obligations and current evidence boundary

Adapter conformance awaits implementations of the abstract interface. Evidence includes put/get corruption tests, negative capability discovery, round-trip loss checks, canonical-output equality across two adapters, and separate performance/durability experiments. No TIFF/NGFF adapter execution is claimed.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [mathematical and image-computation review](../research/ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md) treats TIFF/GIF as encoded carriers. Metadata is declarative data unless an identified verified interpreter gives it meaning. Acquisition/codec transformations and arbitrary script execution are not inferred from file extension or chunk structure.

## 13. Cross-specification consistency

WP12 defines object graphs; WP17 defines byte identities; WP23/WP24 define external mappings. WP14/WP15 own semantic metadata, not the underlying object key layout.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
