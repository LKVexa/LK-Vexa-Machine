# WP25 — Language Governance

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines authority, RFCs, registries, versions, deprecation, errata, advisories, and release roles.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** All prior specs.

**Mandatory deliverables:**
- charter
- RFC lifecycle
- extensions
- versioning
- errata
- security advisories
- release authority

## 5. Normative model
### Governance process
Normative proposals use states `DRAFT → REVIEW → PROVISIONAL → RATIFIED`, with `REJECTED` and `SUPERSEDED` terminal alternatives. Each proposal records problem statement, specification delta, compatibility, security impact, research impact, migration, tests, reviewers, and release decision.

Semantic-breaking changes require a major version. Additive backward-compatible features require minor; clarifications/errata with no semantic change use patch.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP25-REQ-0001` | Specification authority and release roles MUST be documented and separable. | `WP25-TEST-0001` |
| `WP25-REQ-0002` | Normative changes MUST use an RFC/change proposal with impact and compatibility analysis. | `WP25-TEST-0002` |
| `WP25-REQ-0003` | Experimental extensions MUST use a registered namespace and MUST NOT silently become core semantics. | `WP25-TEST-0003` |
| `WP25-REQ-0004` | Major/minor/patch version rules MUST be defined. | `WP25-TEST-0004` |
| `WP25-REQ-0005` | Errata MUST preserve an immutable record of the superseded text. | `WP25-TEST-0005` |
| `WP25-REQ-0006` | Security advisories MUST support coordinated disclosure and version applicability. | `WP25-TEST-0006` |
| `WP25-REQ-0007` | No governance document MUST imply external institutional endorsement that has not been supplied. | `WP25-TEST-0007` |
| `WP25-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP25-TEST-0008` |
| `WP25-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP25-TEST-0009` |
| `WP25-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP25-TEST-0010` |
| `WP25-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP25-TEST-0011` |

## 7. Technical interpretation and algorithms

### Authorities and decision records
Proposed roles separate spec editing, technical review, security review, research-method review, release assembly, release approval, and external certification. The package does not assign authentic institutional persons or invent signatures. Role placeholders in templates remain unfilled until supplied by real participants.

A proposal record binds identifier, problem statement, affected requirements, old/new text, implementation impact, compatibility, numeric/identity effects, security/research consequences, migration, test plan, reviewer decisions, and release decision. A state change from DRAFT to REVIEW or RATIFIED requires an authentic recorded event; changing a status string in a generated document is not ratification.

### Version axes
Four version axes are independent: corpus package, source language, machine schema/identity profile, and external adapter profile. Package 2.0.0 corrects assurance claims and hardens tooling while the language header remains `RUSSL/1.0`. Program `@unit version` is program metadata, not language grammar authority.

A source-language semantic break requires its own major-version process. Schema changes invalidating formerly normative artifacts require a schema-major decision. Additive features are reviewed for closed-world validators and identity preimages; a superficially additive key can still break interoperability or change every hash.

### Extension and errata lifecycle
Extensions have a namespace, owner or explicitly vacant role, problem scope, security boundary, proposed tests, compatibility, status, and references. EXPERIMENTAL does not grant core semantics. Promotion records actual evidence and review. Unknown extensions fail closed where required for execution; safely preserved opaque metadata does not imply execution support.

Errata preserve the old text and reason, identify affected releases, and state whether semantics/identity changed. Security advisories record applicability, affected tools/profiles, exploit preconditions, mitigations, fixed artifact identities, disclosure handling, and unresolved risk without inventing incident history.

The original Internal GO wording is preserved only as historical audit evidence in the original release. It is not a current approval decision.

## 8. Worked example

A proposal to replace the current Python JSON profile with JCS would list numeric/Unicode differences, changed source/IR/tuple identity expectations, migration vectors, new domain/version choices, and dependent tool changes. It is not treated as a harmless serializer cleanup.

A documentation-only correction to remove an unsupported external-certification claim can be a package release change while preserving RUSSL/1.0 syntax and baseline module bytes.

## 9. Boundary and adversarial cases

| Governance defect | Consequence |
|---|---|
| Generated reviewer names/signatures | Institutional provenance is fabricated. |
| Status set to RATIFIED without a decision record | Lifecycle evidence is absent. |
| Identity-changing rule called editorial only | Migration impact is hidden. |
| Experimental extension appears in core silently | Semantics change without review. |
| Old erroneous text deleted without history | Audit trail is lost. |

## 10. Security and failure considerations

Governance quality depends on authentic participants and durable records. This package supplies processes and reviewable artifacts; it does not establish a standards body, regulator approval, committee ratification, or deployed release authority.

## 11. Verification obligations and current evidence boundary

Review checks establish document presence, proposed role separation, version distinctions, and truthful status wording. Actual governance conformance needs signed/authenticated proposal and decision records from responsible parties. Templates are not completed approvals.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP20 separates conformance from approval; WP27 archives decisions; WP17 exposes identity consequences; WP26 preserves research-grade evidence boundaries.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
