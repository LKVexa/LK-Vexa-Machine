# WP16 — RUSSL Projection Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines deterministic lower-dimensional slices and derived projections from Penteract/P5×S³ state.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP04, WP14, WP15, WP05.

**Mandatory deliverables:**
- projection model
- 2D/3D/4D/5D
- P5×S³ profile
- determinism
- provenance
- golden vectors

## 5. Normative model
### Projection function
A projection is `Π=(source_root,selector,transform,reducer,output_rank,parameters)`. Slice projections use selectors without reduction; aggregate projections declare a reducer. Output identity binds all six elements plus relevant MSSL module identities.

Projection provenance records whether the transformation is invertible, value-preserving, approximate, or lossy.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP16-REQ-0001` | A projection MUST identify source root, selector, transform/reducer, output rank, and provenance. | `WP16-TEST-0001` |
| `WP16-REQ-0002` | Projection outputs MUST be derived and MUST NOT silently replace canonical field state. | `WP16-TEST-0002` |
| `WP16-REQ-0003` | Identity/slice projections MUST preserve selected sample values exactly. | `WP16-TEST-0003` |
| `WP16-REQ-0004` | Non-invertible projections MUST be marked lossy. | `WP16-TEST-0004` |
| `WP16-REQ-0005` | P5×S³ derived projections MUST identify the MSSL mechanics module and parameters used. | `WP16-TEST-0005` |
| `WP16-REQ-0006` | Equivalent deterministic projection requests over the same root MUST yield the same projection identity. | `WP16-TEST-0006` |
| `WP16-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP16-TEST-0007` |
| `WP16-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP16-TEST-0008` |
| `WP16-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP16-TEST-0009` |
| `WP16-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP16-TEST-0010` |

## 7. Technical interpretation and algorithms

### Selector, transform, and reducer
Decompose a projection into a selector over source indices, an output-axis mapping, a transform, and an optional reducer. An identity selection preserves rank, order, values, and missingness. A slice fixes axes and records retained-axis order. A reduction combines values along named axes and records numeric regime, accumulation order, missing-value policy, and rounding.

A mean is undefined for an empty selected domain unless the profile provides an explicit missing result. A max projection declares ties and any associated location selection. Floating reductions use a fixed order or another documented reproducible algorithm; a mathematically commutative expression alone does not establish byte-identical results.

### Identity and provenance
Projection identity binds source root, canonical selector, transform/reducer version, parameters, output rank, numeric profile, and relevant module bindings. If two textual selectors describe the same region but serialize differently, their requests are not automatically byte-equivalent. Canonical selector normalization needs a published rule or the equivalence claim is limited to identical canonical requests.

Mark invertibility, sample preservation, approximation, and information loss independently. A slice preserves selected values yet discards unselected values; in the whole-source round-trip sense it is non-invertible and therefore lossy under WP16-REQ-0004. This resolves the original tension between exact slice values and non-invertible projection classification.

### Mechanics-derived projections
P5×S³ projection binds an experimental mechanics algorithm and parameters through MSSL. Its output is an identified derived dataset. The projection does not promote that mechanics algorithm to a validated physical law or alter canonical field state. Unsupported transforms remain explicit errors or separately preserved metadata.

## 8. Worked example

For a 2×2 plane `[[1,4],[3,2]]`, a max over y returns `[3,4]` in retained x order. A slice at y=0 returns `[1,4]` exactly, but is lossy with respect to reconstructing the original full plane.

A request changing reducer from max to mean has a different transform contract and identity even if a particular dataset happens to produce the same values.

## 9. Boundary and adversarial cases

| Defect | Projection failure |
|---|---|
| Reducer axes omitted | Aggregation domain is ambiguous. |
| Empty mean silently returns zero | Invented output value. |
| Slice called fully reversible without preserved complement | Round-trip classification is false. |
| Parameters or mechanics digest excluded from identity | Different algorithms can collide at the request level. |
| Derived output overwrites the canonical parent root | Source authority is replaced. |
| Parallel accumulation order varies across runs | Determinism claim lacks a numeric contract. |

## 10. Security and failure considerations

Projection can hide information or alter scientific interpretation despite deterministic output. Provenance exposes that transformation; it does not certify its appropriateness. Rendering/export can introduce additional color, dtype, or metadata losses beyond the logical projection.

## 11. Verification obligations and current evidence boundary

Planned evidence includes identity/slice exact-value tests, empty selections, reducer boundary cases, canonical-selector equivalence, deterministic floating reductions, and provenance/loss checks. No general projection evaluator is supplied in the structural lowerer.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

The [mathematical review](../research/ADDITIONAL_MATHEMATICAL_AND_HOLOGRAPHIC_REVIEW.md) and [systems review](../research/ADDITIONAL_SYSTEMS_AND_OPTIMIZATION_REVIEW.md) constrain HRR/holographic binding to defined approximate retrieval tasks. Cleanup, cross-talk, quantization and reconstruction errors require declared oracles. Their use as derived projections does not supply a general lossless field compressor.

## 13. Cross-specification consistency

WP04 owns selection geometry; WP03 owns output rank; WP14/WP15 own profile meaning; WP17 owns identity; WP26 owns the experimental mechanics boundary.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
