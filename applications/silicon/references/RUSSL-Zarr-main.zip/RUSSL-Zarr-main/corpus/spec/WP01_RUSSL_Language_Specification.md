# WP01 — RUSSL Language Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines the normative surface syntax and source canonical form.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** Columned-LCTL lineage, Architecture Charter.

**Mandatory deliverables:**
- lexical grammar
- eight-column syntax
- directives
- namespaces and versions
- canonical source form

## 5. Normative model
### Formal source model
The source unit is a sequence `U=(H,D,B*,F+)` consisting of a fixed header, unit/default directives, zero or more digest-bound MSSL declarations, and one or more frames. Each frame contains the fixed eight-column heading and an ordered list of rows. `ID` is syntactic identity; `CTRL` names dependency predecessors; `IN` carries zero, one, or two primary operands; `ARG` carries operator parameters; `META` carries effect/scope/proof overrides.

The language inherits the Columned-LCTL design law—write only what changes, infer what is stable, lower before authority—but not LCTL quantum operators or runtime semantics. Core semantics are defined by the RUSSL operator registry and RUSSIR, not by physical storage names.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP01-REQ-0001` | Source MUST begin with `RUSSL/1.0` and contain exactly one `@unit` directive. | `WP01-TEST-0001` |
| `WP01-REQ-0002` | Every instruction row MUST contain exactly eight cells in `ID│LANE│OP│OUT│CTRL│IN│ARG│META` order. | `WP01-TEST-0002` |
| `WP01-REQ-0003` | Row IDs MUST be unique within a unit and MUST NOT be inferred. | `WP01-TEST-0003` |
| `WP01-REQ-0004` | Operator aliases MUST lower to registered canonical operators without changing semantics. | `WP01-TEST-0004` |
| `WP01-REQ-0005` | Core RUSSL source MUST NOT name a physical storage backend as the canonical state substrate. | `WP01-TEST-0005` |
| `WP01-REQ-0006` | A conforming reference-profile unit MUST declare `fail=closed`. | `WP01-TEST-0006` |
| `WP01-REQ-0007` | At most two primary input operands MAY be packed in `IN` using U+203A `›`. | `WP01-TEST-0007` |
| `WP01-REQ-0008` | MSSL module declarations MUST carry a SHA-256 digest. | `WP01-TEST-0008` |
| `WP01-REQ-0009` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP01-TEST-0009` |
| `WP01-REQ-0010` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP01-TEST-0010` |
| `WP01-REQ-0011` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP01-TEST-0011` |
| `WP01-REQ-0012` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP01-TEST-0012` |

## 7. Technical interpretation and algorithms

### Parsing as a finite-state process
The hardened reference profile uses states `HEADER → UNIT → DEFAULTS? → BINDINGS* → FRAMES+ → END`. A frame has states `OPEN → COLUMNS → ROWS+ → CLOSED`. The columns heading appears once before rows; nested frames, late global directives, unmatched `@end`, repeated defaults, and an empty frame have no accepting transition. Comments and blank lines are lexical trivia, while source identity remains the identity of canonical text, including comments.

Each row separates on exactly seven literal U+2502 characters. There is no cell-level escape for that delimiter in this profile. `_` is the explicit absent-cell sentinel. ASCII identifier rules and reserved namespaces prevent invisible Unicode characters from being interpreted as distinct authority-bearing symbols. Quoted structured values use the profile's documented string escaping; quotes do not turn an instruction cell into executable code. U+203A separates at most two primary operands; it is distinct from ASCII `>`.

### Structural and data-flow checks
Maintain symbol tables for row IDs, frame IDs, output handles, and MSSL aliases. For a row at ordinal `k`, every control predecessor occurs at an ordinal less than `k`. Thus the accepted control graph is acyclic by construction. A produced handle consumed by row `r` is backed by a unique earlier producer reachable through the transitive closure of `CTRL(r)`. This is stronger than a textual earlier-definition check: unrelated branches do not automatically become dependencies.

The reserved `source.*` convention denotes unresolved external inputs in packaged examples. It is a syntactic interface convention, not evidence that bytes exist, have a particular dtype, or have been authorized. MSSL evaluation operands identify a declared alias. Operator aliases resolve through the catalog before effect checks, and a declared row effect agrees with that operator's registered effect.

### Complexity and limits
Single-pass lexical and namespace checks are linear in source size. Reachability can be computed by predecessor sets or graph traversal; a naive traversal per operand can approach quadratic work. Source bytes, line and cell lengths, frame counts, row counts, and dependency fan-out are bounded before untrusted expansion. Implementation limits are profile limits and produce diagnostics rather than truncated successful programs.

### Structured-key profile boundary
The hardened parser recognizes the current unit/default/frame/MSSL directive keys and `META={eff,scope,proof}`; ARG is `_` or structured key/value pairs. Repeated keys and opaque textual ARG/META fallback are rejected. The supported demonstrated ARG keys include field shape/sample/axes/sparse, population mapping, slice/region selector, pyramid levels/downsample/spatial_axes, mechanics mode/lab_ids/coupling, admission policy/authorization, projection selector/output, receipt content_bound/expected, shard partition/count, root hash, and commit grant. Other catalog operators can be recognized lexically with absent arguments; recognition is not a complete parameter, arity, type, or evaluation contract.

The exact implemented directive values, per-operator ARG key table, quoted-string exclusions, symbol grammar, and frozen default budgets are documented in [the reference profile](../technical/REFERENCE_PROFILE.md). Only `scope=self` and deterministic/exact/read/self defaults are accepted by the current parser. MSSL_EVAL and ADMISSION_EVAL require a declared alias plus one data handle. Nonempty ARG key recognition does not validate values or required parameters. Frame, row, and output names remain distinct namespaces.

## 8. Worked example

A minimal structural example, with language version independent of document version:

```text
RUSSL/1.0
@unit id=demo.syntax version=1.0.0 profile=russl.core target=russ fail=closed
@frame id=F0 parent=ROOT module=demo.syntax phase=construct-evaluate
ID│LANE│OP│OUT│CTRL│IN│ARG│META
F1│field│FD│field.main│_│_│shape=1,1,1,2,3;sample=u16;axes=c4,c5,c6,c7,c8│_
P1│field│FP│field.ready│F1│field.main›source.pixels│mapping=origin│eff=derive
@end
```

This shows syntax and structural lowering. `source.pixels` remains an external-input obligation. The field descriptor has six samples; this example does not prove their existence or evaluate them. The full packaged ladder is under `examples/source/`.

## 9. Boundary and adversarial cases

| Input defect | Failure rationale |
|---|---|
| `@defaults` after the first frame | Global environment is no longer unambiguously fixed. |
| Two directives assign the same key twice | Last-write-wins would make authority depend on parser behavior. |
| A row precedes the columns heading | Cell interpretation has no established frame heading. |
| `CTRL=R9` before row R9 | Forward dependency is outside this profile. |
| P1 consumes F1's handle but has no control ancestry to F1 | Evaluation readiness is not established by source order alone. |
| `eff=read` on `STATE_COMMIT` | A syntactic override would conceal the true effect. |
| An extra delimiter appears inside a quoted ARG value | Quoting does not escape the row delimiter. |

## 10. Security and failure considerations

Parsing is an ingestion boundary. Numeric-looking strings are not trusted scalar values until typed by a later phase. Filenames and module names are resolver data, not paths the parser is authorized to open. A storage-leakage scan is a useful architecture lint; it cannot prove that every backend dependency or malicious spelling has been removed.

## 11. Verification obligations and current evidence boundary

The reference parser and lowerer support a bounded, explicitly named profile. Positive examples, malformed ordering, duplicate symbols, ancestry failures, effect mismatches, and MSSL-alias negatives are the relevant executable checks. A parser pass establishes syntactic and structural acceptance only. General semantic validity, dimensional type soundness, external input availability, and execution authority remain separate obligations.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP06 records the explicit lowering result; WP03 owns type validity; WP05 owns byte-bound MSSL resolution; WP09 owns grants. The EBNF and Python profile are reviewed together. A prose example with a `source.*` input is not a self-contained dataset.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
