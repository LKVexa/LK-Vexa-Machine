# WP02 — RUSSL Semantic Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines deterministic meaning, dependency evaluation, state transitions, and failure behavior.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, MSSL binding model.

**Mandatory deliverables:**
- semantic domains
- dependency DAG
- evaluation order
- state transition semantics
- halt/failure semantics

## 5. Normative model
### Operational relation
Let `G=(V,E)` be the row dependency DAG after lowering. Configuration is `⟨G,σ,e,a⟩`, where `σ` is the immutable handle environment, `e` is the evidence log, and `a` is the authorization context. A row may step only when every predecessor is terminal-success and its input handles are available. A derive/project step extends `σ`; it does not mutate an existing handle. An effectful step additionally requires `authorize(a,row,effect)=true`.

Deterministic mode chooses the least source ordinal among eligible rows. Failure produces a terminal diagnostic and suppresses downstream effectful transitions.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP02-REQ-0001` | Program meaning MUST be defined over the lowered dependency graph, not source text alone. | `WP02-TEST-0001` |
| `WP02-REQ-0002` | A row MUST become eligible only after all declared control dependencies are satisfied. | `WP02-TEST-0002` |
| `WP02-REQ-0003` | Among simultaneously eligible rows, deterministic mode MUST use source ordinal as the tie-breaker unless a profile specifies an equivalent deterministic order. | `WP02-TEST-0003` |
| `WP02-REQ-0004` | A failed verification, binding, type, authorization, or canonicalization precondition MUST halt the affected commit path. | `WP02-TEST-0004` |
| `WP02-REQ-0005` | Derived operations MUST NOT mutate an admitted root. | `WP02-TEST-0005` |
| `WP02-REQ-0006` | Execution observations MUST distinguish candidate state from committed fabric state. | `WP02-TEST-0006` |
| `WP02-REQ-0007` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP02-TEST-0007` |
| `WP02-REQ-0008` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP02-TEST-0008` |
| `WP02-REQ-0009` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP02-TEST-0009` |
| `WP02-REQ-0010` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP02-TEST-0010` |

## 7. Technical interpretation and algorithms

### Configuration and eligible rows
Refine the operational configuration to `K=⟨G,σ,q,e,a,h⟩`, where `q:V→{pending,running,succeeded,failed,blocked}` records row state and `h` contains external mutable-head observations. Let `pred(r)` include declared control predecessors and validated data-flow obligations. The eligible set is `Ready(K)={r | q(r)=pending ∧ ∀p∈pred(r),q(p)=succeeded ∧ inputs(r)⊆dom(σ)}`.

In deterministic sequential mode select `argmin ordinal(r)` from `Ready(K)`. Evaluation produces either `Ok(values,receipts)` or `Err(diagnostic)`. Success extends the handle environment by fresh names and marks the row succeeded. Failure records a primary cause and blocks descendants on the affected effect path. An empty ready set with pending rows is a liveness failure or missing-input condition; it is not successful completion.

### Pure and effectful transition rules
For derivation, `eval(op,inputs,args,module_profile)=v` yields `σ'=σ[out↦v]` without modifying existing bindings. The preservation obligation is `∀x∈dom(σ), σ'(x)=σ(x)`. Projection obeys the same immutable-input rule even when values are reduced.

For an effectful row, successful evaluation constructs an effect plan first. Application is a separate transition guarded by verified identity, matching input root, matching argument digest, live grant, and deployment state preconditions. A plan records intended changes; it does not report those changes as already committed. Parallel schedulers may reorder independent pure rows only when their observations and canonical output identities match the declared deterministic profile.

### Safety and liveness claims
Candidate safety is the invariant that failed or unauthorized rows cannot advance a mutable head. Exactly-once application is not implied by a DAG or a deterministic tie-breaker: retries require WP08/WP12 transaction records. Liveness additionally depends on finite module evaluation, external input availability, and a progressing adapter. These assumptions are made explicit in a proof or test report rather than absorbed into a language-level success claim.

## 8. Worked example

Suppose R1 defines a field; R2 and R3 independently derive regions with `CTRL=R1`; R4 builds a candidate root with `CTRL=R2,R3`. After R1 succeeds the eligible set is `{R2,R3}`; sequential deterministic mode chooses R2 if its ordinal is smaller. R4 is blocked until both regions succeed.

If R3 fails integrity verification, R2's derived immutable value may remain observable as candidate data, but R4 cannot produce a valid commit path. A later independent read can be handled only under an explicitly chosen failure profile. No rollback is needed to erase immutable candidate bytes; rollback concerns mutable authority-bearing state.

## 9. Boundary and adversarial cases

| Scenario | Semantic consequence |
|---|---|
| A scheduler runs R4 after only R2 succeeds | Dependency readiness is violated. |
| Derivation updates an existing admitted root in place | Handle immutability is violated. |
| A missing external sample is treated as zero | Program meaning changes through an implicit input. |
| A receipt says committed when only a plan was produced | Candidate and committed observations are conflated. |
| Parallel reducers use nondeterministic accumulation order | The claimed numeric/determinism profile is not established. |

## 10. Security and failure considerations

Untrusted mechanics can fail to terminate or demand unbounded resources even when source syntax is declarative. A runtime therefore needs budgeted evaluation and a defined cancellation boundary. The parser's finite DAG checks establish ordering, but no interpreter, complete semantic evaluator, or liveness proof is supplied by that fact.

## 11. Verification obligations and current evidence boundary

Planned evidence includes transition-trace tests, differential schedulers, immutability assertions, injected module failures, and a model checker for the commit-path invariant. Structural dependency tests are partial evidence only. No full operational-semantics conformance is claimed for the packaged lowerer.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01's source-order restriction is a profile choice; WP02 defines meaning over the lowered graph. WP08 supplies lifecycle transitions, WP09 supplies authorization, and WP12 supplies mutable-head consistency.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
