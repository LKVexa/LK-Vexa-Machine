# WP11 — RUSSL Admission Model

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Separates MSSL mathematical/policy disposition from authorization, commit, and publication.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP05, WP10, WP08.

**Mandatory deliverables:**
- admission state model
- baseline MSSL states
- authorization separation
- evidence
- fail-closed behavior

## 5. Normative model
### Two-layer admission model
The supplied `final_admission.mssl` declares policy dispositions `ADMIT`, `CONDITIONAL`, `REVIEW`, and `HOLD`, and explicitly requires a human authorization reference. RUSSL execution uses separate authorization progression `OBSERVE → REVIEW → ADMIT → COMMIT`.

A policy disposition may inform the authorization state but can never skip capability/grant verification. With the supplied baseline module and no external authorization artifact, the safe corpus outcome is no commit authority.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP11-REQ-0001` | The baseline MSSL policy dispositions `ADMIT`, `CONDITIONAL`, `REVIEW`, and `HOLD` MUST be represented without silently redefining them. | `WP11-TEST-0001` |
| `WP11-REQ-0002` | The execution authorization states `OBSERVE`, `REVIEW`, `ADMIT`, and `COMMIT` MUST be distinct from MSSL policy dispositions. | `WP11-TEST-0002` |
| `WP11-REQ-0003` | An MSSL mathematical `ADMIT` result MUST NOT by itself authorize `COMMIT`. | `WP11-TEST-0003` |
| `WP11-REQ-0004` | A human authorization requirement declared by the baseline admission module MUST remain unsatisfied when no authorization artifact is supplied. | `WP11-TEST-0004` |
| `WP11-REQ-0005` | Policy `CONDITIONAL`, `REVIEW`, or `HOLD` MUST NOT advance to commit without an authorized transition. | `WP11-TEST-0005` |
| `WP11-REQ-0006` | Admission evidence MUST record the evaluated MSSL module digest and inputs digest. | `WP11-TEST-0006` |
| `WP11-REQ-0007` | Unknown policy state or missing required gate MUST fail closed. | `WP11-TEST-0007` |
| `WP11-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP11-TEST-0008` |
| `WP11-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP11-TEST-0009` |
| `WP11-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP11-TEST-0010` |
| `WP11-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP11-TEST-0011` |

## 7. Technical interpretation and algorithms

### Product state, not a shared ADMIT enum
Define state `A=(policy,authority)`, where `policy∈{ADMIT,CONDITIONAL,REVIEW,HOLD,unknown}` and `authority∈{OBSERVE,REVIEW,ADMIT,COMMIT}`. The coincident spelling ADMIT does not equate the two domains. Every policy result binds evaluated module digest, exact inputs, numerical profile, thresholds, and result evidence.

A transition relation `A —event→ A'` records who or what supplied the event, gate evaluation, input root, and immutable authorization reference. Positive mathematical disposition can satisfy a policy gate; human authorization, verified grants, independent review, and state-tip checks remain separate gates.

### Commit predicate
A useful design predicate is `CanCommit = PolicyGate ∧ RequiredHumanAuthorization ∧ VerifiedGrant ∧ CurrentTipMatches ∧ EvidenceComplete`. Each conjunct cites its evidence. Unknown states and absent required evidence evaluate to false rather than inheriting a favorable default. The predicate is explanatory; the package does not include an executable authentic authorization service.

CONDITIONAL records explicit unresolved conditions and the authority allowed while they remain unresolved. REVIEW requests an authenticated review decision. HOLD inhibits progress until a new authorized event changes applicable conditions. A transition logs the superseded disposition instead of overwriting provenance.

### Policy evolution and re-evaluation
A result computed against module M and root R cannot be reused as a result for M' or R'. Changed mechanics bytes, thresholds, input population, or calibrated transform trigger re-evaluation under a new evidence binding. A grant can authorize an action only within its signed bindings; it does not repair missing policy evidence or retroactively convert an experimental model into validated science.

The baseline human-authorization requirement remains unresolved if no authentic artifact is supplied. A local example can demonstrate the required reference position without supplying a real authorizer.

## 8. Worked example

Suppose `final_admission.mssl` produces policy ADMIT for root R. The authorization state can remain OBSERVE because the required human authorization reference is absent. The output receipt records policy ADMIT and `commit_authorized=false`; it does not print a blanket admission success for the state-changing path.

If a reviewed grant later authorizes a different root R2, the grant does not apply to R. Both policy and authority bindings are checked for the same intended candidate.

## 9. Boundary and adversarial cases

| Defect | Admission interpretation |
|---|---|
| Unknown disposition treated as ADMIT | Unsafe default. |
| Policy ADMIT auto-advances to COMMIT | Mathematical decision is mistaken for authority. |
| Required human reference is an empty string or placeholder | Required gate is unresolved. |
| Old policy result reused after module replacement | Evaluation identity no longer matches. |
| A condition disappears from a revised receipt without evidence | Conditional policy history is falsified. |

## 10. Security and failure considerations

Research thresholds and mechanics may be incomplete or scientifically unvalidated. A perfectly reproduced admission calculation proves only that the declared calculation was repeated. Organizational permission additionally depends on authentic institutional roles and signed authorization, which are not supplied.

## 11. Verification obligations and current evidence boundary

Static checks can verify baseline module bytes and the presence of stated gate vocabulary. Full claim evidence needs interpreter result vectors, transition traces, authentic authorization negatives, unknown-state failures, and policy/module/input substitution tests. The package cannot assert operational admission conformance from text inspection.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP05 governs mechanics binding, WP09 governs grants, WP08 governs effects, and WP26 governs scientific evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
