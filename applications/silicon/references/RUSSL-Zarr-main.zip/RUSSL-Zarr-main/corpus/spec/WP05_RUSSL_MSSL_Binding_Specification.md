# WP05 — RUSSL–MSSL Binding Specification

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Core  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Defines digest-bound discovery, import, parameterization, invocation, and result binding for MSSL.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01, WP02, Baseline MSSL family.

**Mandatory deliverables:**
- module reference
- digest/version binding
- parameter binding
- result binding
- capability boundary
- failure behavior

## 5. Normative model
### Binding function
A binding record is `B=(alias,module,source_version,file_digest,capabilities,metadata)`. Resolution returns module bytes only if `SHA256(bytes)=file_digest`; otherwise resolution fails. The MSSL internal identity and κ value may be recorded as additional provenance, but the file digest is the corpus byte-binding authority.

The supplied baseline modules are mechanics (`master_coupled_mechanics`), laboratory stack (`lab_stack`), product metrics (`product_metrics`), and final admission (`final_admission`). Evaluation is performed by an MSSL interpreter under the invoking row's effect/capability envelope.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP05-REQ-0001` | Each MSSL binding MUST identify module name, source version, alias, and file digest. | `WP05-TEST-0001` |
| `WP05-REQ-0002` | The bound module bytes MUST be verified against the declared digest before evaluation. | `WP05-TEST-0002` |
| `WP05-REQ-0003` | RUSSL MUST treat MSSL as the mechanics/policy authority and MUST NOT substitute a storage adapter for an MSSL module. | `WP05-TEST-0003` |
| `WP05-REQ-0004` | Module inputs and outputs MUST be explicitly bound by symbolic handles. | `WP05-TEST-0004` |
| `WP05-REQ-0005` | An MSSL module MUST NOT acquire effects beyond the invoking row grant. | `WP05-TEST-0005` |
| `WP05-REQ-0006` | The baseline registry MUST include the four supplied MSSL modules by exact file digest. | `WP05-TEST-0006` |
| `WP05-REQ-0007` | Unresolved or digest-mismatched MSSL bindings MUST fail closed. | `WP05-TEST-0007` |
| `WP05-REQ-0008` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP05-TEST-0008` |
| `WP05-REQ-0009` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP05-TEST-0009` |
| `WP05-REQ-0010` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP05-TEST-0010` |
| `WP05-REQ-0011` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP05-TEST-0011` |

## 7. Technical interpretation and algorithms

### Resolution protocol
Treat a binding as both a lookup descriptor and a byte-integrity obligation. Resolve a module name and source version through an explicit allow-listed registry. Read the candidate bytes once into a bounded immutable buffer, calculate SHA-256 over those exact bytes, compare with the declared digest, and pass that verified buffer to the interpreter. Reopening a mutable path after verification creates a check/use race.

The baseline digest is a raw-file digest, separate from any MSSL internal identity or mathematical κ expression. Different newline normalization changes raw-file identity. The caller records both identities if both are meaningful, rather than substituting one for the other.

### Contract and authority boundaries
A module interface describes named parameters, their types/units, allowed modes, result fields, numerical regime, failure dispositions, and imported dependencies. Binding verifies that an invoking row supplies compatible symbolic handles and named arguments. Evaluation sees only the capability envelope explicitly delegated to it; filesystem, network, clock, and publication access are not implicit consequences of a module's text.

The effective effect set is the intersection of the row's permitted effects, authenticated grant scopes, and the interpreter sandbox profile. A missing grant does not become valid because mechanics produced a favorable result. Module output is candidate data plus evidence until a separate authorization path establishes a state-changing effect.

### Dependencies and determinism
The closure of transitive module imports is digest-bound and acyclic under the chosen interpreter profile, or explicitly treated as an unsupported recursive contract. Evaluation budgets bound steps, recursion, memory, and wall-time as deployment controls. Deterministic evaluation fixes numeric routines, reduction order, seeds, and external observations. The corpus ships four preserved baseline files; preserving and hashing them is distinct from implementing their full language semantics.

## 8. Worked example

The packaged `master_coupled_mechanics` alias can be resolved only to the exact bytes registered under that name and source version. If a space or comment is edited, the raw file digest changes, even if a human considers the mechanics expression equivalent.

An `MSSL_EVAL` row consuming `master›field.populated` first establishes that `master` is a declared alias. Lowering records the binding. Only a later interpreter can establish that `field.populated` satisfies the module's actual input contract and compute a result.

## 9. Boundary and adversarial cases

| Defect | Binding consequence |
|---|---|
| Alias resolves to an unregistered local filename | Resolution authority is missing. |
| Correct module name but altered bytes | Declared file digest does not match. |
| Verified bytes are then replaced before execution | The execution object is no longer bound to the check. |
| Module requests publication while row permits derivation | Capability amplification attempt. |
| Missing referenced research PDF is fabricated | Research provenance is corrupted. |
| κ is substituted for the SHA-256 file digest | Mathematical/internal identity is confused with byte binding. |

## 10. Security and failure considerations

Digest verification establishes consistency with the declared bytes, not author legitimacy or scientific truth. A malicious but digest-matching module remains untrusted code/data. The baseline files are immutable source inputs to this package; changes require new bindings and review rather than silent repair.

## 11. Verification obligations and current evidence boundary

Raw-byte digest checks for all four baseline modules are executable. Alias declaration checks are structural. General module parsing, parameter/result contracts, sandbox enforcement, numerical mechanics, dependency closure, and termination are unimplemented obligations unless a separately identified interpreter supplies evidence.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP06 carries binding descriptors into IR; WP07 binds modules in tuple component M; WP09 caps delegated authority; WP11 keeps policy result separate from authorization.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
