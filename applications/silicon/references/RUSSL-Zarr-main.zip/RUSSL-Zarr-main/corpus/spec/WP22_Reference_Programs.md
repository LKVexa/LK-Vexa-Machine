# WP22 — Reference Programs

**Version:** 2.0.0  
**Status:** Hardened Research / Institutional Candidate — unratified  
**Normative class:** Profile / Governance / Research  
**Corpus:** RUSSL Research & Institutional Corpus 2.0.0  
**Language/profile:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)

## 1. Scope
Supplies canonical RUSSL examples from a single sample through distributed candidate publication.

This 2.0.0 specification supersedes the unsupported blanket Internal GO implication of the original package. It is a proposed technical contract with scoped implementation evidence, not ratification or external certification. The language header remains RUSSL/1.0. Section 6 preserves the original requirement IDs and normative statements for traceability. Sections 7–13 add technical interpretation, design obligations, examples, and verification boundaries; they introduce no new normative requirement IDs.

Dependencies below are architectural relationships, not an instruction to execute attached content or proof that those dependencies have been implemented. Baseline mechanics remain experimental; absent external authorization and research source material remain absent.

## 2. Non-goals
- It does not make a storage backend the semantic definition of RUSSL.
- It does not treat mathematical admission as cryptographic or organizational authorization.
- It does not invent missing external attestations, source documents, or scientific validation.

## 3. Normative terminology
`MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT`, and `MAY` are requirement terms. "Core" means language/IR/tuple/field semantics independent of physical storage. "Profile" means a scoped interoperability or deployment contract.

## 4. Definitions and dependencies
**Dependencies:** WP01–WP11.

**Mandatory deliverables:**
- single sample
- 2D image
- RGB/pyramid
- 3D/5D
- sparse field
- MSSL stack
- distributed examples

## 5. Normative model
### Reference-program ladder
The program suite grows from one sample to raster, RGB pyramid, 3D volume, native 5D, sparse coupling, full MSSL stack, distributed candidate root, guarded commit, and projection. A TIFF migration profile example is included without making TIFF a core data model. Each source has canonical RUSSIR output.

## 6. Normative requirements
| Requirement | Normative statement | Conformance mapping |
|---|---|---|
| `WP22-REQ-0001` | Reference programs MUST cover a single sample, 2D image, RGB/pyramid, 3D volume, native 5D field, sparse field, MSSL stack, distributed candidate, guarded commit, and projection. | `WP22-TEST-0001` |
| `WP22-REQ-0002` | Reference RUSSL programs MUST lower successfully with the corpus reference lowerer. | `WP22-TEST-0002` |
| `WP22-REQ-0003` | Core reference programs MUST NOT contain a storage-backend path as canonical state. | `WP22-TEST-0003` |
| `WP22-REQ-0004` | Commit examples MUST show an external grant requirement rather than self-authorizing. | `WP22-TEST-0004` |
| `WP22-REQ-0005` | Reference outputs MUST include canonical RUSSIR artifacts. | `WP22-TEST-0005` |
| `WP22-REQ-0006` | The specification MUST preserve the architecture boundary `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. | `WP22-TEST-0006` |
| `WP22-REQ-0007` | Normative requirements MUST distinguish core semantics from adapter/profile behavior. | `WP22-TEST-0007` |
| `WP22-REQ-0008` | Unresolved required references, ambiguous authority, or incompatible major versions MUST fail closed. | `WP22-TEST-0008` |
| `WP22-REQ-0009` | Every testable MUST in this specification MUST be traceable to a conformance test or validation rule. | `WP22-TEST-0009` |

## 7. Technical interpretation and algorithms

### Pedagogic progression and evidence grade
The reference-program ladder separates syntax demonstrations from executed scientific workloads. Each program records its objective, required inputs, module aliases, expected lowering features, and unsupported runtime obligations. The existing corpus covers single sample, plane, RGB/pyramid, volume, native 5D, sparse coupling, MSSL stack, distributed candidate, guarded commit, projection, and migration profile examples.

A program is self-contained only if every external handle resolves to supplied digest-bound data with a declared type. `source.*` names are unresolved interface placeholders in the current examples. They allow structural lowering but do not supply pixels, calibrated datasets, network nodes, or authorizers.

### Review protocol
For each example: canonicalize and parse; compare source/IR identities; verify all module descriptors against preserved baseline files; inspect control ancestry and effect annotations; classify external dependencies; and list expected evaluator/adapter behavior separately. A reference output can be canonical IR without being a calculated image, mechanics result, or state commit.

The guarded-commit example explicitly demonstrates that the language has a commit operator and grant argument position. It remains non-authorizing unless authentic external grant evidence is supplied. Distributed examples can describe shard/root plans without constructing a live fabric.

### Expansion policy
New runnable examples need a small supplied dataset, a declared numeric/axis profile, an independently reviewed expected result, reproducible execution procedure, and negative sibling cases. Benchmark-scale data belongs in separately digest-bound packages with acquisition provenance; generating arbitrary pixels is suitable for synthetic correctness tests, not empirical validation.

Reference examples do not become normative syntax by accidental parser permissiveness. Closed operator-argument keys in the hardened profile are based on documented demonstrated contracts; recognition of other operators does not imply their parameter or runtime semantics are implemented.

## 8. Worked example

The single-sample source declares field population and mechanics/admission evaluation, but its `source.sample` operand is an external placeholder. Its canonical IR is a valid lowering fixture. A runnable variant would supply one u16 sample, bind its digest/type, and evaluate under a separately implemented MSSL contract.

The 2D program demonstrates shape `(1,1,1,H,W)`; its expected coordinates can be computed from WP04. The compiler fixture does not prove any image decoder ran.

## 9. Boundary and adversarial cases

| Example misuse | Why it is unsupported |
|---|---|
| Program filename says “scientific” so output is empirical | Names do not supply observations. |
| Source input is replaced silently with random data | Program input contract changes. |
| Grant placeholder is treated as a real capability | Example self-authorizes. |
| IR fixture is called an execution receipt | Lowering and evaluation are different stages. |
| Adapter name is used as canonical field substrate | Architecture boundary is crossed. |

## 10. Security and failure considerations

Examples are strong teaching artifacts but weak assurance if their external assumptions are hidden. The hardened profile records structural acceptance while the package's limitations keep runtime and empirical obligations explicit.

## 11. Verification obligations and current evidence boundary

All supplied source examples are intended to parse/lower under the bounded profile and compare against canonical IR fixtures. Full end-to-end execution, synthetic dataset result vectors, distributed behavior, and real adapter round trips remain separate work.

The requirement-to-test mapping in Section 6 is a traceability plan. A registered test identifier is not an executed pass. The final machine registries and verification report identify actual evidence; mandatory unexecuted obligations prevent GO for a claim that includes them.

## 12. Research and institutional boundary

P5×S³/8S mechanics are experimental inputs. Mathematical definitions, preserved bytes, deterministic computation, simulation, empirical observation, and external replication have separate evidence grades. Institutional approval, authentic grants, independent certification, and empirical validation are claimed only when separately supplied and verified. This package does not fabricate those artifacts.

## 13. Cross-specification consistency

WP01/WP06 govern source and IR; WP03/WP05 govern runtime inputs; WP09 governs grant authenticity; WP26 governs empirical versus synthetic evidence.

## 14. Change history

- **2.0.0:** Replaced generic repeated algorithm/example text with work-package-specific technical detail, formal invariants, boundary cases, and explicit implementation/verification limits. Preserved the original normative requirement table and language version; superseded blanket Internal GO and placeholder-test conformance implications.
- **1.0.0:** Initial corpus candidate generated from the serialized 28-work-package construction workflow; retained as original audit evidence.
