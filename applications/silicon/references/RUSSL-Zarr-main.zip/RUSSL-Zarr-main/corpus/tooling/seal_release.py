"""Seal the existing candidate tree. No recursive deletion or external sources.

The release date is fixed by package policy; receipts are unsigned. This seals
the supplied specifications, not regeneration of their intellectual content.
"""
from __future__ import annotations
import hashlib, json, re, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tooling'))
from verify_corpus import verify, verify_integrity, load, sha
import russl_reference as rr

VERSION='2.0.0'
DATE='2026-10-09'
EXCLUDED={'MANIFEST.json','BUILD_RECEIPT.json','SHA256SUMS.txt','evidence/RELEASE_INTEGRITY.json'}
SCOPED={
 'WP01':{1,2,3,4,6,7,8}, 'WP03':{2}, 'WP04':{1,2,3}, 'WP05':{1,2,3},
 'WP06':{1,2,3}, 'WP07':{1,2,3,4,5,6,7,8}, 'WP17':{1,2,4,5,6},
 'WP18':{1}, 'WP19':{1}, 'WP28':{1,2}}
EVIDENCE={'WP01':['V03-SOURCE-IR','V09-ADVERSARIAL'],'WP03':['V04-SCHEMAS'],'WP04':['V04-SCHEMAS','V06-COORDINATES'],'WP05':['V05-MSSL-PROVENANCE','V08-RUSS-CONTAINER'],'WP06':['V03-SOURCE-IR','V04-SCHEMAS'],'WP07':['V08-RUSS-CONTAINER','V09-ADVERSARIAL'],'WP17':['V07-SOURCE-CANON','V08-RUSS-CONTAINER','V09-ADVERSARIAL'],'WP18':['V08-RUSS-CONTAINER'],'WP19':['V09-ADVERSARIAL'],'WP28':['V04-SCHEMAS','V09-ADVERSARIAL']}
METHODS={'WP01':'Mutate lexical, directive, row, and handle forms and require bounded parse rejection plus exact lowering of accepted fixtures.',
'WP02':'Specify an evaluator and compare small-step traces, blocked dependencies and terminal states against an independently reviewed oracle.',
'WP03':'Implement type judgments and exercise valid and invalid dimensional/unit/effect derivations; shape validation alone is insufficient.',
'WP04':'Check rank, axis permutation, bounds, singleton coordinates, sparse missingness, sample layout and region membership.',
'WP05':'Change raw MSSL bytes, identity declarations and capability claims independently; compare each rejection boundary.',
'WP06':'Lower source, recompute identity, compare frame flattening and catalog attributes, and reject unresolved/mismatched references.',
'WP07':'Rebuild containers, corrupt each binding independently, and validate component order, resource bounds and cross-payload identities.',
'WP08':'Build runtime state-transition tests with crash injection around authorization, evidence persistence and commit.',
'WP09':'Use a real trust profile to test nonce replay, expiration, actor/scope/row/root binding, revocation and independent authorization.',
'WP10':'Threat-model adversarial entry points and independently test trust, isolation, resource bounds, secrets and recovery.',
'WP11':'Compare admission boundary inputs with declared mathematical predicates; separately require authorization for commit.',
'WP12':'Simulate partitions, stale tips, unavailable content, concurrent proposals and Byzantine data; define the chosen consistency model.',
'WP13':'Use two independent adapters for the same logical field, then compare sample/metadata equivalence separately from byte identity.',
'WP14':'Exercise channel, orientation, color, alpha, bit-depth and missingness fixtures against explicit axis and sample contracts.',
'WP15':'Exercise physical calibration, units, irregular sampling, uncertainty, coordinate transforms and volume provenance.',
'WP16':'Check selector, transform, reducer, rank, provenance and lossiness with exact identity/slice fixtures and numerical tolerances.',
'WP17':'Check source canonicalization and domain hashes with Unicode/numeric/ordering edge cases; do not substitute RFC8785.',
'WP18':'Repeat transformations from archived pinned inputs; compare both semantic observables and exact artifact digests.',
'WP19':'Enumerate malformed inputs and compare stable diagnostic codes, bounded context and secret redaction.',
'WP20':'Define each conformance class, its required evidence and its complete oracle set; report unexecuted obligations.',
'WP21':'Provide concrete fixture, precondition, command, oracle and result for each planned test; registration is not execution.',
'WP22':'Run reference programs against an implementation with bound sample inputs and verify outputs, not only source parsing.',
'WP23':'Read TIFF/BigTIFF/COG fixtures with independent decoders and validate metadata, sample, layout, loss and export restrictions.',
'WP24':'Pin NGFF/Zarr versions and exercise multiscales, axis types, transforms, units, chunks, codecs and hierarchy rejection.',
'WP25':'Obtain actual review appointments, conflict disclosures, signed votes, quorum and appeal records before ratification.',
'WP26':'Preregister falsifiable hypotheses, controls, uncertainty model, data, code and independent replication before empirical claims.',
'WP27':'Review provenance, approvals, archival recoverability, rights, incidents, accessibility and documented limitations.',
'WP28':'Validate all schema samples and negative type/key/bounds cases, then check semantic invariants beyond schema shape.'}

def write(path,obj):
    path=Path(path)
    if not path.resolve().is_relative_to(ROOT.resolve()):raise ValueError('write outside corpus')
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def preflight():
    for path in ROOT.rglob('*'):
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('symlink/path escape rejected before sealing')
        if '__pycache__' in path.parts or path.suffix=='.pyc':
            raise ValueError('remove bytecode caches before sealing; use python -B')

def update_records():
    req=[load_line(x) for x in (ROOT/'machine/requirements_registry.jsonl').read_text(encoding='utf-8').splitlines() if x]
    tests=[];results=[];counts={'SCOPED_EVIDENCE':0,'NOT_RUN':0};packages={}
    for r in req:
        wp=r['work_package'];number=int(r['requirement_id'].rsplit('-',1)[1]);scoped=number in SCOPED.get(wp,set())
        status='SCOPED_EVIDENCE' if scoped else 'NOT_RUN';counts[status]+=1
        tests.append({'test_id':r['test_id'],'work_package':wp,'type':'scoped_validation' if scoped else 'planned_review_or_runtime_test','legacy_test_type':r['test_type'],'procedure':METHODS[wp],'requirement_under_test':r['text'],'acceptance_oracle':'A reviewer verifies every clause of this exact requirement against recorded inputs and independently specified expected outcomes. Aggregate check PASS does not establish the whole requirement.','executable_checks':EVIDENCE.get(wp,[]) if scoped else [],'status':status})
        results.append({'requirement_id':r['requirement_id'],'test_id':r['test_id'],'work_package':wp,'status':status,'full_requirement_verified':False,'evidence':EVIDENCE.get(wp,[]) if scoped else [],'scope_limit':'Evidence is limited to packaged fixtures and structural checks; complete requirement proof/review has not occurred.' if scoped else 'No requirement-specific execution or independent review is claimed.'})
        packages.setdefault(wp,{'requirements':0,'scoped_evidence':0,'not_run':0,'fully_verified':0});packages[wp]['requirements']+=1;packages[wp]['scoped_evidence' if scoped else 'not_run']+=1
    (ROOT/'machine/tests_registry.jsonl').write_text(''.join(json.dumps(x,sort_keys=True,ensure_ascii=False)+'\n' for x in tests),encoding='utf-8')
    write(ROOT/'machine/registries/requirement_results.json',{'schema':'RUSSL.RequirementEvidence/2.0','corpus_version':VERSION,'results':results})
    write(ROOT/'machine/registries/requirements_coverage.json',{'schema':'RUSSL.RequirementsCoverage/2.0','total_requirements':len(req),'total_registered_tests_or_validations':len(tests),'fully_verified_requirements':0,'full_conformance':False,'status_counts':counts,'work_packages':packages})
    deps=load(ROOT/'machine/registries/work_package_dependencies.json')
    for p in (ROOT/'spec').glob('WP*.md'):
        wp=p.name[:4];old=load(ROOT/'lineage/prior_release/completion'/(wp+'_completion.json'))
        record={'schema':'RUSSL.WorkPackageCandidate/2.0','work_package':wp,'version':VERSION,'status':'CANDIDATE_REVIEW_REQUIRED','satisfied_gates':[],'blocked_gates':['G0-G9 require explicit evidence and accountable review; prior GO assertions are superseded'],'normative_requirement_count':packages[wp]['requirements'],'test_count':packages[wp]['requirements'],'evidence_summary':packages[wp],'reviewer_roles_required':old['reviewer_roles_required'],'reviewers_appointed':[],'review_signatures':[],'declared_dependencies':old.get('declared_dependencies',[]),'input_versions_and_digests':{'original_archive_sha256':'8f900e895c0e403885d82b8b84d2de756391908e95e9380d9ea471ef5dc3b1c8','corpus_version':VERSION},'output_files_and_digests':{p.relative_to(ROOT).as_posix():sha(p)}}
        if old.get('ratification_group'):record['proposed_review_group']=old['ratification_group']
        write(ROOT/'completion'/(wp+'_completion.json'),record)
    docs=[]
    for p in sorted(ROOT.rglob('*.md')):
        rel=p.relative_to(ROOT).as_posix()
        if rel.startswith('lineage/'):continue
        docs.append({'path':rel,'title':next((x.lstrip('# ').strip() for x in p.read_text(encoding='utf-8').splitlines() if x.startswith('# ')),p.stem),'kind':'work-package-specification' if rel.startswith('spec/') else 'supporting-document','normativity':'normative-candidate' if rel.startswith('spec/') else 'informative-or-proposed-policy','review_status':'not-institutionally-ratified'})
    write(ROOT/'machine/registries/document_registry.json',{'schema':'RUSSL.DocumentRegistry/2.0','documents':docs})

def load_line(line):
    from russ_container import strict_json
    return strict_json(line)

def compile_full():
    files=[ROOT/x for x in ['README_START_HERE.md','ARCHITECTURE_CHARTER.md','SOURCE_AUTHORITY.md','AUDIT_REPORT.md','CHANGELOG.md','UNRESOLVED_ISSUES.md'] if (ROOT/x).exists()]
    for directory in ['spec','technical','research','institutional','governance','interoperability']:
        files+=sorted((ROOT/directory).glob('*.md'))
    chunks=['# RUSSL Research and Institutional Corpus 2.0.0\n\nDerived reading edition. Individual files and MANIFEST.json are authoritative for this candidate package. Review status: CANDIDATE_REVIEW_REQUIRED.\n']
    for p in files:
        text=p.read_text(encoding='utf-8')
        def replace(m):
            url=m.group(2)
            if re.match(r'[A-Za-z][A-Za-z0-9+.-]*:',url) or url.startswith('#'):return m.group(0)
            target,sep,fragment=url.partition('#');resolved=(p.parent/target).resolve()
            if resolved.is_relative_to(ROOT.resolve()):return m.group(1)+'('+resolved.relative_to(ROOT.resolve()).as_posix()+(sep+fragment if sep else '')+')'
            return m.group(0)
        text=re.sub(r'(\[[^\]]*\])\(([^\s)]+)\)',replace,text)
        chunks.append('\n\n---\n\nSource: `'+p.relative_to(ROOT).as_posix()+'`\n\n'+text)
    (ROOT/'RUSSL_FULL_CORPUS.md').write_text(''.join(chunks),encoding='utf-8')

def make_archive(destination):
    destination=Path(destination)
    if destination.resolve().is_relative_to(ROOT.resolve()):raise ValueError('archive cannot be inside sealed tree')
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file():
                i=zipfile.ZipInfo(ROOT.name+'/'+p.relative_to(ROOT).as_posix(),date_time=(1980,1,1,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.create_system=0;i.external_attr=0x20
                z.writestr(i,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)

def main():
    preflight()
    update_records();compile_full();update_records()
    result=verify();write(ROOT/'evidence/CONFORMANCE_RESULTS.json',result)
    if result['status']!='PASS':
        print(json.dumps(result,indent=2));raise SystemExit('candidate verification failed; sealing stopped')
    entries=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.relative_to(ROOT).as_posix() not in EXCLUDED:entries.append({'path':p.relative_to(ROOT).as_posix(),'size':p.stat().st_size,'sha256':sha(p)})
    domain='RUSSL-CORPUS-CONTENT/2.0';content=rr.domain_hash(domain,rr.canonical_json_bytes(entries))
    write(ROOT/'MANIFEST.json',{'schema':'RUSSL.CorpusManifest/2.0','corpus':'RUSSL Research and Institutional Corpus','version':VERSION,'release_date':DATE,'status':'CANDIDATE_REVIEW_REQUIRED','external_certification':False,'full_conformance':False,'entry_count':len(entries),'content_root_sha256':content,'content_root_domain':domain,'excluded_generated_files':sorted(EXCLUDED),'files':entries})
    write(ROOT/'BUILD_RECEIPT.json',{'schema':'RUSSL.CorpusBuildReceipt/2.0','corpus_version':VERSION,'release_date':DATE,'status':'SCOPED_VERIFICATION_PASS','manifest_sha256':sha(ROOT/'MANIFEST.json'),'content_root_sha256':content,'verification_results_sha256':sha(ROOT/'evidence/CONFORMANCE_RESULTS.json'),'golden_russ_sha256':sha(ROOT/'examples/golden/RUSS_Penteract_RUSSL_1.0_golden.russ'),'review_approval':False,'signed':False,'builder':'tooling/seal_release.py','boundary':'Seals current candidate source tree; does not regenerate intellectual content from unavailable original authorities.'})
    sums=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.relative_to(ROOT).as_posix() not in {'SHA256SUMS.txt','evidence/RELEASE_INTEGRITY.json'}:sums.append(sha(p)+'  '+p.relative_to(ROOT).as_posix())
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n',encoding='utf-8')
    integrity=verify_integrity();write(ROOT/'evidence/RELEASE_INTEGRITY.json',integrity)
    destination=ROOT.parent/(ROOT.name+'.zip');make_archive(destination)
    print(json.dumps({'verification':result['status'],'integrity':integrity['status'],'files':len(entries)+len(EXCLUDED),'archive':str(destination),'archive_sha256':sha(destination),'coverage':result['requirement_coverage']['status_counts']},indent=2))

if __name__=='__main__':main()
