"""Bounded, read-only RUSS 1.3 golden-profile verification and rebuilding."""
from __future__ import annotations
import hashlib
import json
import math
import re
import struct
from pathlib import Path
import russl_reference as rr
from schema_subset import validate_document

HEADER = struct.Struct('>8sHHIQ')
RECORD = struct.Struct('>IQ32s')
MAGIC = b'RUSS\r\n\x1a\n'
COMPONENTS = ['identity', 'language', 'geometry', 'state', 'coupling', 'mechanics',
              'admission', 'projection', 'fabric', 'evidence', 'execution']
MAX_BYTES = 64 * 1024 * 1024
MAX_MANIFEST = 1024 * 1024
MAX_RECORDS = 1024


def strict_json(raw):
    return rr.strict_json_loads(raw)


def safe_member(path):
    if not isinstance(path, str) or len(path) > 1024 or not re.fullmatch(r'[A-Za-z0-9_.\-/]+', path):
        raise ValueError('unsafe payload path')
    parts = path.split('/')
    if any(p in ('', '.', '..') or p.endswith(('.', ' ')) for p in parts):
        raise ValueError('unsafe payload path')
    if any(re.fullmatch(r'(?i)(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\..*)?', p) for p in parts):
        raise ValueError('Windows reserved payload path')
    return path


def verify_bytes(data, schema_root=None):
    if len(data) > MAX_BYTES or len(data) < HEADER.size:
        raise ValueError('container size')
    magic, major, minor, flags, length = HEADER.unpack_from(data)
    if magic != MAGIC or (major, minor) != (1, 3) or flags != 1:
        raise ValueError('unsupported header/version/flags')
    if not 0 < length <= MAX_MANIFEST or HEADER.size + length > len(data):
        raise ValueError('manifest bounds')
    offset = HEADER.size
    raw_manifest = data[offset:offset + length]
    offset += length
    manifest = strict_json(raw_manifest)
    if not isinstance(manifest, dict) or rr.canonical_json_bytes(manifest) != raw_manifest:
        raise ValueError('manifest is not corpus canonical JSON')
    if manifest.get('format') != 'RUSS.TupleExecutable' or manifest.get('version') != '1.3.0':
        raise ValueError('manifest version')
    entries = manifest.get('payload')
    if not isinstance(entries, list) or not 1 <= len(entries) <= MAX_RECORDS:
        raise ValueError('payload cardinality')
    payload = {}
    observed = []
    cases = set()
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {'path', 'sha256', 'size'}:
            raise ValueError('payload entry keys')
        path = safe_member(entry['path'])
        if path.casefold() in cases:
            raise ValueError('duplicate/case-colliding payload path')
        cases.add(path.casefold())
        if type(entry['size']) is not int or not 0 <= entry['size'] <= MAX_BYTES:
            raise ValueError('declared payload size')
        if not isinstance(entry['sha256'], str) or not re.fullmatch('[0-9a-f]{64}', entry['sha256']):
            raise ValueError('declared payload digest')
        if offset + RECORD.size > len(data):
            raise ValueError('truncated record header')
        path_len, data_len, digest = RECORD.unpack_from(data, offset)
        offset += RECORD.size
        if not 0 < path_len <= 1024 or data_len != entry['size'] or offset + path_len + data_len > len(data):
            raise ValueError('record bounds/declared size mismatch')
        record_path = data[offset:offset + path_len].decode('utf-8', errors='strict')
        offset += path_len
        content = data[offset:offset + data_len]
        offset += data_len
        actual = hashlib.sha256(content).hexdigest()
        if record_path != path or actual != entry['sha256'] or digest.hex() != actual:
            raise ValueError('record path/digest mismatch')
        payload[path] = content
        observed.append({'path': path, 'sha256': actual, 'size': len(content)})
    if offset != len(data) or list(payload) != sorted(payload):
        raise ValueError('trailing data or unsorted payload')
    root = rr.domain_hash('RUSS-PAYLOAD/1.0', rr.canonical_json_bytes(observed))
    if manifest.get('payload_root_sha256') != root:
        raise ValueError('payload root mismatch')
    tuples = manifest.get('tuple')
    if not isinstance(tuples, list) or len(tuples) != 11:
        raise ValueError('tuple arity')
    for name, component in zip(COMPONENTS, tuples):
        if not isinstance(component, list) or len(component) != 2 or component[0] != name or not isinstance(component[1], dict):
            raise ValueError('tuple component ordering/type')
    parts = dict(tuples)
    identity = parts['identity']
    if (identity.get('format') != 'RUSS' or identity.get('version') != '1.3.0'
        or identity.get('profile') != 'russl.penteract.corpus'
        or identity.get('media_type') != 'application/vnd.russ.tuple-executable'
        or parts['geometry'].get('base') != 'P5'
        or parts['state'].get('model') != 'RUSS.PenteractField/1.0'):
        raise ValueError('unsupported golden identity/geometry/state profile')
    tid = 'russ:sha256:' + rr.domain_hash('RUSS-TUPLE/1.0', rr.canonical_json_bytes(tuples))
    if manifest.get('tuple_id') != tid or parts['fabric'].get('payload_root_sha256') != root:
        raise ValueError('tuple identity/fabric root mismatch')
    if parts['state'].get('physical_backend') is not None or parts['admission'].get('commit_requires_independent_authorization') is not True:
        raise ValueError('state/authorization boundary')
    if parts['execution'].get('arbitrary_code') is not False:
        raise ValueError('execution allowlist boundary')
    def member(path):
        safe_member(path)
        if path not in payload:
            raise ValueError('missing referenced payload: ' + path)
        return payload[path]
    lang = parts['language']
    ir = strict_json(member(lang['ir']))
    source = member(lang['source']).decode('utf-8', errors='strict')
    lowered = rr.lower_russl(source)
    if ir != lowered or lang.get('ir_id') != lowered['ir_id']:
        raise ValueError('source/IR/language binding mismatch')
    modules = parts['mechanics'].get('modules')
    if not isinstance(modules, list) or len(modules) != len(set(modules)):
        raise ValueError('mechanics module list')
    declared = set()
    for binding in ir['mssl_bindings']:
        path = 'mssl/' + binding['module'] + '.mssl'
        if path not in modules or hashlib.sha256(member(path)).hexdigest() != binding['digest'][7:]:
            raise ValueError('MSSL digest/module binding mismatch')
        declared.add(path)
    if declared != set(modules):
        raise ValueError('unbound mechanics module')
    policy = parts['admission']['policy']
    aliases = {b['alias']: 'mssl/' + b['module'] + '.mssl' for b in ir['mssl_bindings']}
    admission_modules = {aliases[row['inputs'][0]] for row in ir['program']
                         if row['op'] == 'ADMISSION_EVAL' and row['inputs'] and row['inputs'][0] in aliases}
    if policy not in modules or policy not in admission_modules:
        raise ValueError('policy does not bind an ADMISSION_EVAL module')
    member(policy)
    provenance = strict_json(member(parts['evidence']['provenance']))
    field = strict_json(member(parts['geometry']['field_descriptor']))
    if parts['geometry'].get('axes') != field.get('axes') or field.get('rank') != 5:
        raise ValueError('geometry/field mismatch')
    definitions = [r for r in ir['program'] if r['op'] == 'FIELD_DEFINE']
    if len(definitions) != 1 or not isinstance(definitions[0]['arg'], dict):
        raise ValueError('golden field binding requires exactly one FIELD_DEFINE')
    declared_field = definitions[0]['arg']
    if (field.get('shape') != [int(x) for x in declared_field.get('shape', '').split(',')]
        or field.get('axes') != declared_field.get('axes', '').split(',')
        or field.get('sample', {}).get('dtype') != declared_field.get('sample')):
        raise ValueError('source/field shape, axes or dtype binding mismatch')
    if schema_root is not None:
        schemas = Path(schema_root)
        for value, filename in [(manifest, 'russ_tuple_manifest.schema.json'),
                                (ir, 'russir.schema.json'), (field, 'penteract_field.schema.json')]:
            validate_document(value, strict_json((schemas / filename).read_bytes()))
    return {'tuple_id': tid, 'payload_root_sha256': root, 'records': len(payload),
            'container_sha256': hashlib.sha256(data).hexdigest(), 'manifest': manifest, 'payload': payload}


def verify_file(path, schema_root=None):
    path = Path(path)
    with path.open('rb') as stream:
        raw = stream.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError('container resource limit')
    return verify_bytes(raw, schema_root)


def rebuild_bytes(manifest, payload):
    raw = rr.canonical_json_bytes(manifest)
    if len(raw) > MAX_MANIFEST:
        raise ValueError('manifest resource limit')
    chunks = [HEADER.pack(MAGIC, 1, 3, 1, len(raw)), raw]
    for entry in manifest['payload']:
        path = safe_member(entry['path'])
        content = payload[path]
        encoded = path.encode('utf-8')
        chunks.extend([RECORD.pack(len(encoded), len(content), hashlib.sha256(content).digest()), encoded, content])
    result = b''.join(chunks)
    verify_bytes(result)
    return result
