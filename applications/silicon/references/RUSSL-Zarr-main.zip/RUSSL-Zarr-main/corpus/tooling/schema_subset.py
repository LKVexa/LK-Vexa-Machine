"""Offline validator for the explicitly supported JSON Schema keyword subset.

This is not a general Draft 2020-12 implementation. Unsupported keywords and
remote references are errors; it never silently skips a validation keyword.
"""
from __future__ import annotations
import math
import re

ANNOTATIONS = {'$schema', '$id', 'title', 'description', '$comment', 'default', 'examples'}
KEYWORDS = {'type', 'const', 'enum', 'required', 'properties', 'additionalProperties',
            'items', 'prefixItems', 'minItems', 'maxItems', 'uniqueItems',
            'minLength', 'maxLength', 'pattern', 'minimum', 'maximum',
            'minProperties', 'maxProperties', '$defs', '$ref', 'allOf', 'anyOf', 'oneOf', 'not'}

class ValidationMismatch(ValueError):
    """An instance does not match; distinct from invalid schema/resource errors."""


class ResourceLimit(ValueError):
    pass


def _type(value, name):
    return {'null': value is None, 'boolean': isinstance(value, bool),
            'integer': isinstance(value, int) and not isinstance(value, bool),
            'number': isinstance(value, (int, float)) and not isinstance(value, bool)
                      and (not isinstance(value, float) or math.isfinite(value)),
            'string': isinstance(value, str), 'array': isinstance(value, list),
            'object': isinstance(value, dict)}.get(name, False)


def _equal(a, b, budget=None):
    if budget is not None:
        budget['comparisons'] -= 1
        if budget['comparisons'] < 0:
            raise ResourceLimit('schema comparison work limit')
    if isinstance(a, bool) != isinstance(b, bool):
        return False
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(_equal(x, y, budget) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(_equal(a[k], b[k], budget) for k in a)
    return a == b


def check_schema(schema, root=None, depth=0, ref_stack=(), budget=None):
    if budget is None: budget = {'nodes': 100_000}
    budget['nodes'] -= 1
    if budget['nodes'] < 0: raise ResourceLimit('schema work limit')
    if depth > 64:
        raise ValueError('schema nesting limit')
    if isinstance(schema, bool):
        return
    if not isinstance(schema, dict):
        raise ValueError('schema must be object or boolean')
    root = schema if root is None else root
    if not isinstance(root.get('$defs', {}), dict):
        raise ValueError('invalid root definitions')
    unknown = set(schema) - ANNOTATIONS - KEYWORDS
    if unknown:
        raise ValueError('unsupported schema keywords: ' + ','.join(sorted(unknown)))
    if '$ref' in schema:
        ref = schema['$ref']
        if not isinstance(ref, str) or not ref.startswith('#/$defs/') or ref[8:] not in root.get('$defs', {}):
            raise ValueError('only local $defs references supported')
        if ref in ref_stack:
            raise ValueError('cyclic schema references unsupported')
        check_schema(root['$defs'][ref[8:]], root, depth + 1, ref_stack + (ref,), budget)
    for k in ('properties', '$defs'):
        if k in schema and (not isinstance(schema[k], dict) or any(type(x) is not str for x in schema[k])):
            raise ValueError('invalid schema object keyword: ' + k)
    if 'required' in schema:
        v = schema['required']
        if not isinstance(v, list) or any(type(x) is not str for x in v) or len(v) != len(set(v)):
            raise ValueError('invalid required keyword')
    for k in ('minItems', 'maxItems', 'minLength', 'maxLength', 'minProperties', 'maxProperties'):
        if k in schema and (type(schema[k]) is not int or schema[k] < 0):
            raise ValueError('invalid nonnegative integer keyword: ' + k)
    for k in ('minimum', 'maximum'):
        if k in schema and not _type(schema[k], 'number'):
            raise ValueError('invalid finite numeric keyword: ' + k)
    if 'uniqueItems' in schema and type(schema['uniqueItems']) is not bool:
        raise ValueError('invalid uniqueItems keyword')
    if 'enum' in schema and (not isinstance(schema['enum'], list) or not schema['enum']):
        raise ValueError('invalid enum keyword')
    for k in ('prefixItems', 'allOf', 'anyOf', 'oneOf'):
        if k in schema and (not isinstance(schema[k], list) or (k != 'prefixItems' and not schema[k])):
            raise ValueError('invalid schema list keyword: ' + k)
    if 'type' in schema:
        types = schema['type'] if isinstance(schema['type'], list) else [schema['type']]
        if not types or any(type(t) is not str or t not in ('null', 'boolean', 'integer', 'number', 'string', 'array', 'object') for t in types) or len(types) != len(set(types)):
            raise ValueError('invalid schema type')
    if 'pattern' in schema:
        if type(schema['pattern']) is not str:
            raise ValueError('invalid pattern keyword')
        re.compile(schema['pattern'])
    for k in ('properties', '$defs'):
        for child in schema.get(k, {}).values():
            check_schema(child, root, depth + 1, ref_stack, budget)
    for k in ('items', 'additionalProperties', 'not'):
        if k in schema:
            check_schema(schema[k], root, depth + 1, ref_stack, budget)
    for k in ('prefixItems', 'allOf', 'anyOf', 'oneOf'):
        for child in schema.get(k, []):
            check_schema(child, root, depth + 1, ref_stack, budget)


def validate(value, schema, root=None, path='$', depth=0, budget=None):
    if budget is None:
        budget = {'nodes': 100_000, 'comparisons': 100_000}
    budget['nodes'] -= 1
    if budget['nodes'] < 0:
        raise ResourceLimit('instance validation work limit')
    if depth > 64:
        raise ResourceLimit(path + ': instance/schema nesting limit')
    root = schema if root is None else root
    if schema is False:
        raise ValidationMismatch(path + ': forbidden')
    if schema is True:
        return
    def fail(message):
        raise ValidationMismatch(path + ': ' + message)
    if '$ref' in schema:
        validate(value, root['$defs'][schema['$ref'][8:]], root, path, depth + 1, budget)
    if 'type' in schema:
        types = schema['type'] if isinstance(schema['type'], list) else [schema['type']]
        if not any(_type(value, t) for t in types):
            fail('type ' + repr(types))
    if 'const' in schema and not _equal(value, schema['const'], budget):
        fail('const mismatch')
    if 'enum' in schema and not any(_equal(value, x, budget) for x in schema['enum']):
        fail('enum mismatch')
    if isinstance(value, dict):
        missing = set(schema.get('required', [])) - set(value)
        if missing:
            fail('missing keys ' + ','.join(sorted(missing)))
        for k, v in value.items():
            child = schema.get('properties', {}).get(k, schema.get('additionalProperties', True))
            validate(v, child, root, path + '.' + k, depth + 1, budget)
        if len(value) < schema.get('minProperties', 0) or len(value) > schema.get('maxProperties', float('inf')):
            fail('object size')
    if isinstance(value, list):
        if len(value) < schema.get('minItems', 0) or len(value) > schema.get('maxItems', float('inf')):
            fail('array size')
        if schema.get('uniqueItems'):
            comparisons = len(value) * (len(value) - 1) // 2
            if comparisons > budget['comparisons']:
                raise ResourceLimit('uniqueItems comparison work limit')
            if any(_equal(value[i], value[j], budget) for i in range(len(value)) for j in range(i)):
                fail('duplicate array item')
        prefixes = schema.get('prefixItems', [])
        for i, v in enumerate(value):
            validate(v, prefixes[i] if i < len(prefixes) else schema.get('items', True), root, path + '[' + str(i) + ']', depth + 1, budget)
    if isinstance(value, str):
        if len(value) < schema.get('minLength', 0) or len(value) > schema.get('maxLength', float('inf')):
            fail('string size')
        if 'pattern' in schema and not re.search(schema['pattern'], value):
            fail('pattern mismatch')
    if _type(value, 'number'):
        if value < schema.get('minimum', -float('inf')) or value > schema.get('maximum', float('inf')):
            fail('number bounds')
    for child in schema.get('allOf', []):
        validate(value, child, root, path, depth + 1, budget)
    for keyword in ('anyOf', 'oneOf'):
        if keyword in schema:
            count = 0
            for child in schema[keyword]:
                try:
                    validate(value, child, root, path, depth + 1, budget)
                    count += 1
                except ValidationMismatch:
                    pass
            if (keyword == 'anyOf' and count == 0) or (keyword == 'oneOf' and count != 1):
                fail(keyword + ' mismatch')
    if 'not' in schema:
        try:
            validate(value, schema['not'], root, path, depth + 1, budget)
        except ValidationMismatch:
            pass
        else:
            fail('not mismatch')


def validate_document(value, schema):
    from russl_reference import canonical_json_bytes
    canonical_json_bytes(value)
    canonical_json_bytes(schema)
    check_schema(schema)
    validate(value, schema)
