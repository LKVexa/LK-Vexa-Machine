"""Offline verification. Read-only unless --write-report is set."""
from __future__ import annotations
import argparse, collections, hashlib, io, json, platform, re, sys, unittest
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tooling'))
import russl_reference as rr
import russ_container as rc
from schema_subset import check_schema, validate_document

def load(path):
    with Path(path).open('rb') as stream: raw = stream.read(rr.MAX_JSON_BYTES + 1)
    return rc.strict_json(raw)
def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''): digest.update(chunk)
    return digest.hexdigest()
def require(value, message):
    if not value: raise ValueError(message)
def jsonl(path):
    total = count = 0
    with Path(path).open('rb') as stream:
        while True:
            line = stream.readline(rr.MAX_JSON_BYTES + 1)
            if not line: break
            total += len(line)
            if total > 64 * 1024 * 1024: raise ValueError('JSONL file resource limit')
            if line.strip():
                count += 1
                if count > 100_000: raise ValueError('JSONL record resource limit')
                yield rc.strict_json(line)

def verify(root=ROOT):
    root = Path(root); checks = []
    def check(cid, fn):
        try: checks.append({'id': cid, 'status': 'PASS', 'detail': str(fn())})
        except Exception as exc: checks.append({'id': cid, 'status': 'FAIL', 'detail': type(exc).__name__ + ': ' + str(exc)})
    def strict_records():
        count = 0
        for path in sorted(root.rglob('*')):
            if not path.is_file() or 'lineage' in path.relative_to(root).parts: continue
            if path.suffix.lower() == '.json':
                load(path)
                if path.relative_to(root).as_posix() not in {'MANIFEST.json','BUILD_RECEIPT.json','evidence/CONFORMANCE_RESULTS.json','evidence/RELEASE_INTEGRITY.json'}: count += 1
            if path.suffix.lower() == '.jsonl':
                for _ in jsonl(path): count += 1
        return f'{count} current JSON/JSONL records; duplicate keys/nonfinite numbers rejected'
    def traceability():
        req = list(jsonl(root/'machine/requirements_registry.jsonl'))
        tests = list(jsonl(root/'machine/tests_registry.jsonl'))
        require(len(req)==len({r['requirement_id'] for r in req}), 'duplicate requirement')
        require(len(tests)==len({t['test_id'] for t in tests}), 'duplicate test')
        expected={(r['requirement_id'],r['test_id']) for r in req}; observed=set()
        for p in (root/'spec').glob('WP*.md'):
            observed.update(re.findall(r'\| `?(WP\d+-REQ-\d+)`? \|.*?\| `?(WP\d+-TEST-\d+)`? \|',p.read_text(encoding='utf-8')))
        require(expected==observed,'registry/spec table mismatch')
        require(all(r['test_id'] in {t['test_id'] for t in tests} for r in req),'missing registered test')
        cov=load(root/'machine/registries/requirements_coverage.json')
        require(cov['total_requirements']==len(req) and cov['full_conformance'] is False,'coverage overclaim')
        require(sum(cov['status_counts'].values())==len(req),'coverage count')
        return f'{len(req)} requirement IDs and mappings; registration is separate from execution'
    def syntax():
        paths=list((root/'examples/source').glob('*.russl')); require(len(paths)==12,'example count')
        for p in paths:
            require(rr.lower_russl(p.read_text(encoding='utf-8'))==load(root/'examples/lowered'/(p.stem+'.russir.json')),p.name+': IR drift')
        valid = list((root/'tests/vectors/syntax/valid').glob('*.russl'))
        invalid = list((root/'tests/vectors/syntax/invalid').glob('*.russl'))
        require(len(valid) == 4 and len(invalid) == 5, 'syntax vector inventory')
        for p in valid:
            require(p.read_bytes() == (root/'examples/source'/p.name).read_bytes(), 'positive vector drift')
            rr.lower_russl(p.read_text(encoding='utf-8'))
        for p in invalid:
            try: rr.lower_russl(p.read_text(encoding='utf-8'))
            except ValueError: continue
            raise ValueError('invalid accepted: '+p.name)
        return '12 exact legacy source-IR pairs; 5 invalid fixtures rejected'
    def schemas():
        for p in (root/'machine/schemas').glob('*.json'): check_schema(load(p))
        pairs=[('penteract_field.schema.json','examples/golden/field_descriptor.json'),('mssl_binding.schema.json','machine/registries/sample_mssl_binding.json'),('russ_tuple_manifest.schema.json','examples/golden/RUSS_Penteract_RUSSL_1.0_golden.manifest.json'),('evidence_receipt.schema.json','machine/registries/sample_evidence_receipt.json'),('execution_receipt.schema.json','machine/registries/sample_execution_receipt.json'),('capability_grant.schema.json','machine/registries/sample_capability_grant.json'),('extension_registry.schema.json','machine/registries/extension_registry.json')]
        pairs += [('russir.schema.json',p.relative_to(root).as_posix()) for p in (root/'examples/lowered').glob('*.json')]
        for s,p in pairs: validate_document(load(root/p),load(root/'machine/schemas'/s))
        return f'{len(pairs)} samples; closed supported-keyword subset, not a full Draft implementation'
    def bindings():
        modules=load(root/'machine/registries/mssl_baseline_registry.json')['modules'];require(len(modules)==4,'MSSL count')
        for m in modules: rr.verify_mssl(root/'bindings/mssl'/m['file'],m['file_sha256'])
        m=re.search(r'master_law\.sha256.*?([0-9a-f]{64})',(root/'bindings/mssl/master_coupled_mechanics.mssl').read_text(encoding='utf-8'))
        require(m is not None and m.group(1)==sha(root/'research/source/master_law.png'),'image digest binding')
        return 'four MSSL byte digests and master-law image; scientific evaluation remains absent'
    def coordinates():
        d=load(root/'tests/vectors/field/coordinate_vectors.json')
        for v in d['vectors']:
            got=[rr.phi(i,v['n'],v['anchor']) for i in v['indices']]
            require(len(got)==len(v['expected']) and all(abs(a-b)<1e-12 for a,b in zip(got,v['expected'])),'coordinate mismatch')
        return f"{len(d['vectors'])} coordinate vectors"
    def canonicalization():
        d=load(root/'tests/vectors/canonicalization/source_vectors.json')
        for v in d['vectors']:
            c=rr.canonical_source(bytes(v['input_escaped'],'utf-8').decode('unicode_escape'))
            require(c.encode('unicode_escape').decode()==v['canonical_escaped'],'canonical mismatch')
            require(hashlib.sha256(c.encode()).hexdigest()==v['sha256'],'canonical digest mismatch')
        return f"{len(d['vectors'])} source vectors; corpus JSON is distinct from RFC8785"
    def container():
        p=root/'examples/golden/RUSS_Penteract_RUSSL_1.0_golden.russ';d=rc.verify_file(p,root/'machine/schemas')
        require(d['manifest']==load(p.with_suffix('.manifest.json')),'sidecar drift')
        payload={e['path']:(root/'examples/golden/fixture_payload'/e['path']).read_bytes() for e in d['manifest']['payload']}
        require(payload==d['payload'],'fixture tree drift');require(rc.rebuild_bytes(d['manifest'],payload)==p.read_bytes(),'fixture rebuild drift')
        return 'bounded framing, references/digests/source-IR/MSSL bindings and exact rebuild: '+d['tuple_id']
    def adversarial():
        require(all((root/'tests'/n).is_file() for n in ['test_reference_hardening.py','test_release_security.py']), 'required regression file absent')
        stream=io.StringIO();suite=unittest.defaultTestLoader.discover(str(root/'tests'),pattern='test_*.py')
        result=unittest.TextTestRunner(stream=stream,verbosity=1).run(suite)
        require(result.wasSuccessful() and result.testsRun>=23,stream.getvalue())
        return f'{result.testsRun} regression tests; {len(result.skipped)} skipped'
    def operators():
        cat=load(root/'machine/registries/operator_catalog.json')['operators'];require(len(cat)==len(rr.OPERATORS),'operator count drift')
        for e in cat:
            require(rr.OPERATORS[e['operation']]==(e['face'],e['type'],e['default_effect']),'operator drift')
            if e.get('alias'):require(rr.ALIASES.get(e['alias'])==e['operation'],'alias drift')
        return f'{len(cat)} operation identities; runtime semantics remain unimplemented'
    def completion():
        ps=list((root/'completion').glob('WP*_completion.json'));require(len(ps)==28,'completion count')
        for p in ps:
            d=load(p);require(d['status']=='CANDIDATE_REVIEW_REQUIRED' and not d['satisfied_gates'],'unsupported gate approval')
            for n,h in d['output_files_and_digests'].items():require(sha(root/n)==h,'completion digest drift')
        return '28 review-pending records with actual specification hashes'
    def links():
        count=0
        for p in root.rglob('*.md'):
            if 'lineage' in p.relative_to(root).parts:continue
            for link in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)\)',p.read_text(encoding='utf-8')):
                if re.match(r'[A-Za-z][A-Za-z0-9+.-]*:',link) or link.startswith('#'):continue
                target=link.split('#')[0]
                if target:require((p.parent/target).exists(),'broken link '+p.relative_to(root).as_posix()+': '+link);count+=1
        return f'{count} local Markdown links resolve; remote sources have a separate dated review'
    def inventory():
        for p in root.rglob('*'):
            require(not p.is_symlink(),'symlink in corpus');require('__pycache__' not in p.parts and p.suffix!='.pyc','bytecode cache in release')
        require('rmtree' not in (root/'tooling/build_corpus.py').read_text(encoding='utf-8'),'destructive builder')
        return 'no symlinks/caches or recursive-delete active builder'
    def added_research():
        intake=load(root/'research/ADDITIONAL_SOURCE_INTAKE.json')
        require(intake['source_count']==19 and len(intake['records'])==19 and intake['field_shape']==[4,4,4,16,16],'research intake count/shape')
        ids={x['source_id'] for x in intake['records']};require(ids=={f'RA{i:02d}' for i in range(1,20)},'intake IDs')
        for source in intake['records']:
            rc.safe_member(source['archive_path']);p=root/source['archive_path']
            require(p.stat().st_size==source['bytes'] and sha(p)==source['sha256'],'added source byte preservation')
            rc.safe_member(source['extracted_text_path'])
            require(sha(root/source['extracted_text_path'])==source['extracted_text_sha256'],'source extraction digest')
        reports=[load(root/'research'/n) for n in ['additional_math_claims.json','additional_systems_claims.json']]
        require(set().union(*(set(d['source_ids']) for d in reports))==ids,'research review coverage')
        normalization={'SUPPORTED_PRIMARY':'SUPPORTED_PRIMARY','CORRECTED':'CORRECTED',
                       'UNSUPPORTED':'UNSUPPORTED','HYPOTHESIS':'HYPOTHESIS',
                       'retain_with_scope':'SUPPORTED_PRIMARY','correct':'CORRECTED',
                       'reject':'REJECTED','reject_extrapolation':'UNSUPPORTED','unsupported':'UNSUPPORTED'}
        review_paths=['research/additional_math_claims.json','research/additional_systems_claims.json']
        claim_index=[];by_source=collections.defaultdict(list);seen=set()
        for d,review_path in zip(reports,review_paths):
            require(d['claims'] and all(c['source_id'] in ids for c in d['claims']),'untraceable additional claim')
            require(len(d['source_ids'])==len(set(d['source_ids']))
                    and {c['source_id'] for c in d['claims']}==set(d['source_ids']),'actual source claim coverage')
            require(d['field_shape']==[4,4,4,16,16],'review shape drift')
            for c in d['claims']:
                require(isinstance(c['claim_id'],str) and c['claim_id'] and c['claim_id'] not in seen,'duplicate/invalid claim ID')
                require(c['disposition'] in normalization,'unknown claim disposition')
                seen.add(c['claim_id'])
                entry={'claim_id':c['claim_id'],'source_id':c['source_id'],'review_registry':review_path,
                       'original_disposition':c['disposition'],'normalized_disposition':normalization[c['disposition']]}
                claim_index.append(entry);by_source[c['source_id']].append(entry)
            if 'claim_count' in d:require(d['claim_count']==len(d['claims']),'review claim count drift')
            if 'counts' in d:require(d['counts']==dict(collections.Counter(c['disposition'] for c in d['claims'])),'review disposition count drift')
        source_index=[]
        for s in intake['records']:
            cs=by_source[s['source_id']]
            source_index.append({'source_id':s['source_id'],'original_filename':s['original_filename'],
                'archive_path':s['archive_path'],'sha256':s['sha256'],
                'extracted_text_path':s['extracted_text_path'],'extracted_text_sha256':s['extracted_text_sha256'],
                'claim_count':len(cs),'claim_ids':[c['claim_id'] for c in cs],
                'disposition_counts':dict(collections.Counter(c['normalized_disposition'] for c in cs))})
        index=load(root/'machine/registries/research_evidence_index.json')
        require(index.get('schema')=='RUSSL.AdditionalResearchEvidenceIndex/2.0'
                and index.get('corpus_version')=='2.0.0' and index.get('status')=='SCOPED_RESEARCH_REVIEW', 'research index identity')
        require(index['field_shape']==[4,4,4,16,16] and index['scalar_sites']==16384,'research index shape')
        require(index['source_count']==19 and index['claim_count']==len(claim_index)
                and index['normalization']==normalization and index['claims']==claim_index
                and index['sources']==source_index,'research index/claim/source drift')
        require(index['normalized_disposition_counts']==dict(collections.Counter(c['normalized_disposition'] for c in claim_index)),
                'normalized claim counts')
        require(index['experimental_profiles_implemented'] is False and index['empirical_measurements_added'] is False
                and index['core_requirement_ids_added']==0 and index['effect_authority_expanded'] is False,'research scope claims')
        renders=reports[1]['inspection']['pdf']['delivered_render_records']
        require([r['page'] for r in renders]==[5,6,9],'paper visual inspection inventory')
        for render in renders:
            rc.safe_member(render['path'])
            require(render['source_id']=='RA01' and render['source_sha256']==intake['records'][0]['sha256']
                    and sha(root/render['path'])==render['sha256'],'paper render provenance')
        layout=load(root/'machine/registries/fixed_shape_layout.json')
        require(layout['shape']==[4,4,4,16,16] and layout['sites']==16384 and layout['total_index_bits']==14,'layout metadata')
        require(sha(root/layout['fixture'])==layout['fixture_sha256'],'index fixture digest')
        return f'19 original sources/extracts and three inspected page renders; {len(claim_index)} unique indexed claims with exact coverage/counts; 16384 exact fixed-shape index records; scientific claims remain disposition-scoped'
    for cid,fn in [('V01-STRICT-JSON',strict_records),('V02-TRACEABILITY',traceability),('V03-SOURCE-IR',syntax),('V04-SCHEMAS',schemas),('V05-MSSL-PROVENANCE',bindings),('V06-COORDINATES',coordinates),('V07-SOURCE-CANON',canonicalization),('V08-RUSS-CONTAINER',container),('V09-ADVERSARIAL',adversarial),('V10-OPERATOR-REGISTRY',operators),('V11-REVIEW-STATUS',completion),('V12-LOCAL-LINKS',links),('V13-RELEASE-INVENTORY',inventory),('V14-ADDED-RESEARCH',added_research)]:check(cid,fn)
    result={'schema':'RUSSL.VerificationResult/2.0','corpus_version':'2.0.0','status':'PASS' if all(c['status']=='PASS' for c in checks) else 'FAIL','scope':'offline candidate package/reference structural profile/golden compatibility/adversarial regression','full_conformance':False,'external_certification':False,'checks':checks,'requirement_coverage':load(root/'machine/registries/requirements_coverage.json'),'environment':{'python':platform.python_version(),'implementation':platform.python_implementation(),'dependencies':'Python standard library only'}}
    validate_document(result,load(root/'machine/schemas/conformance_result.schema.json'))
    return result

def verify_integrity(root=ROOT):
    root=Path(root);m=load(root/'MANIFEST.json');excluded=set(m['excluded_generated_files'])
    require(m.get('schema')=='RUSSL.CorpusManifest/2.0' and m.get('version')=='2.0.0'
            and m.get('release_date')=='2026-10-09' and m.get('status')=='CANDIDATE_REVIEW_REQUIRED'
            and m.get('full_conformance') is False and m.get('external_certification') is False
            and m.get('content_root_domain')=='RUSSL-CORPUS-CONTENT/2.0', 'manifest policy metadata')
    require(excluded=={'MANIFEST.json','BUILD_RECEIPT.json','SHA256SUMS.txt','evidence/RELEASE_INTEGRITY.json'}
            and len(m['excluded_generated_files'])==4, 'manifest exclusion policy')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};expected={e['path'] for e in m['files']}
    require(m.get('entry_count')==len(m['files']), 'manifest entry count')
    require(actual-excluded==expected and len(expected)==len(m['files']),'manifest inventory drift')
    for e in m['files']:
        rc.safe_member(e['path']);p=root/e['path'];require(p.stat().st_size==e['size'] and sha(p)==e['sha256'],'manifest mismatch: '+e['path'])
    require(rr.domain_hash(m['content_root_domain'],rr.canonical_json_bytes(m['files']))==m['content_root_sha256'],'content root mismatch')
    observed=set()
    for line in (root/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        h,n=line.split('  ',1);rc.safe_member(n);require(n not in observed and sha(root/n)==h,'checksum mismatch: '+n);observed.add(n)
    require(observed==actual-{'SHA256SUMS.txt','evidence/RELEASE_INTEGRITY.json'},'checksum inventory drift')
    b=load(root/'BUILD_RECEIPT.json');report=load(root/'evidence/CONFORMANCE_RESULTS.json')
    require(b.get('schema')=='RUSSL.CorpusBuildReceipt/2.0' and b.get('corpus_version')=='2.0.0'
            and b.get('status')=='SCOPED_VERIFICATION_PASS' and b.get('signed') is False
            and b.get('review_approval') is False and b.get('content_root_sha256')==m['content_root_sha256']
            and b.get('golden_russ_sha256')==sha(root/'examples/golden/RUSS_Penteract_RUSSL_1.0_golden.russ'), 'receipt policy metadata')
    require(report.get('schema')=='RUSSL.VerificationResult/2.0' and report.get('corpus_version')=='2.0.0'
            and report.get('status')=='PASS' and report.get('full_conformance') is False
            and report.get('external_certification') is False and report.get('checks')
            and all(c.get('status')=='PASS' for c in report['checks']), 'bound report policy metadata')
    validate_document(report,load(root/'machine/schemas/conformance_result.schema.json'))
    require(b['manifest_sha256']==sha(root/'MANIFEST.json') and b['verification_results_sha256']==sha(root/'evidence/CONFORMANCE_RESULTS.json'),'build receipt drift')
    return {'schema':'RUSSL.ReleaseIntegrity/2.0','status':'PASS','checked_entries':len(expected),'checksum_entries':len(observed),'manifest_sha256':sha(root/'MANIFEST.json'),'content_root_sha256':m['content_root_sha256'],'authentication':False,'scope':'byte integrity, not authorship or approval'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--write-report',action='store_true');p.add_argument('--integrity',action='store_true');args=p.parse_args()
    result=verify_integrity() if args.integrity else verify()
    if args.write_report:(ROOT/'evidence'/('RELEASE_INTEGRITY.json' if args.integrity else 'CONFORMANCE_RESULTS.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2,ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 1)

if __name__=='__main__':main()
