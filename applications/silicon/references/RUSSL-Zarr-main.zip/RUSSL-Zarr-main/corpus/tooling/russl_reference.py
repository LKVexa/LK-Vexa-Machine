"""Bounded RUSSL/1.0 reference-profile validator; never executes or authorizes rows."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import re
import unicodedata

OPERATORS = {'SOURCE_BIND': ('DECL', 'source_binding', 'read'), 'CONST': ('DECL', 'constant', 'read'), 'FIELD_DEFINE': ('FIELD', 'field_descriptor', 'derive'), 'FIELD_POPULATE': ('FIELD', 'field_candidate', 'derive'), 'FIELD_SLICE': ('FIELD', 'field_slice', 'derive'), 'FIELD_REGION': ('FIELD', 'field_region', 'derive'), 'PYRAMID_DEFINE': ('FIELD', 'multiresolution_descriptor', 'derive'), 'COUPLING_DEFINE': ('MECHANICS', 'coupling_descriptor', 'derive'), 'MSSL_EVAL': ('MECHANICS', 'mssl_result', 'derive'), 'MECHANICS_STEP': ('MECHANICS', 'mechanics_state', 'derive'), 'ADMISSION_EVAL': ('ADMISSION', 'admission_disposition', 'derive'), 'PROJECT': ('PROJECTION', 'projection', 'project'), 'VERIFY_SOURCE': ('VERIFY', 'verification', 'read'), 'VERIFY_MSSL': ('VERIFY', 'verification', 'read'), 'VERIFY_TUPLE': ('VERIFY', 'verification', 'read'), 'VERIFY_EVIDENCE': ('VERIFY', 'verification', 'read'), 'HASH': ('EVIDENCE', 'digest', 'read'), 'EMIT_RECEIPT': ('EVIDENCE', 'receipt', 'write:evidence'), 'NODE': ('DISTRIBUTED', 'node_descriptor', 'read'), 'SHARD': ('DISTRIBUTED', 'shard_descriptor', 'derive'), 'ROUTE': ('DISTRIBUTED', 'route_descriptor', 'derive'), 'CHECKPOINT': ('FABRIC', 'checkpoint', 'derive'), 'CAS_GET': ('FABRIC', 'content_fetch', 'read'), 'CAS_PUT': ('FABRIC', 'content_put', 'write:state'), 'ROOT_BUILD': ('FABRIC', 'root_descriptor', 'derive'), 'STATE_COMMIT': ('FABRIC', 'commit', 'commit'), 'ROLLBACK': ('FABRIC', 'rollback', 'commit'), 'REPLICATE': ('FABRIC', 'replication', 'replicate'), 'PUBLISH': ('FABRIC', 'publication', 'publish'), 'ASSERT': ('CONTROL', 'assertion', 'read'), 'BARRIER': ('CONTROL', 'barrier', 'read'), 'NOP': ('CONTROL', 'nop', 'read')}
ALIASES = {'SB': 'SOURCE_BIND', 'FD': 'FIELD_DEFINE', 'FP': 'FIELD_POPULATE', 'FS': 'FIELD_SLICE', 'FR': 'FIELD_REGION', 'PY': 'PYRAMID_DEFINE', 'CD': 'COUPLING_DEFINE', 'ME': 'MSSL_EVAL', 'MS': 'MECHANICS_STEP', 'AE': 'ADMISSION_EVAL', 'PJ': 'PROJECT', 'VS': 'VERIFY_SOURCE', 'VM': 'VERIFY_MSSL', 'VT': 'VERIFY_TUPLE', 'VE': 'VERIFY_EVIDENCE', 'H': 'HASH', 'ER': 'EMIT_RECEIPT', 'CP': 'CHECKPOINT', 'CG': 'CAS_GET', 'CT': 'CAS_PUT', 'RB': 'ROOT_BUILD', 'SC': 'STATE_COMMIT', 'RO': 'ROLLBACK', 'RP': 'REPLICATE', 'PB': 'PUBLISH', 'A': 'ASSERT', 'B': 'BARRIER', 'N': 'NOP'}
STORAGE_LEAK = re.compile(r"(?i)(?:\.zarr(?:\b|/)|ome[-_.]?zarr|zarr[-_]?v[0-9]|logical/state\.russ\.zarr)")
COLUMNS = 'ID│LANE│OP│OUT│CTRL│IN│ARG│META'
SYMBOL = re.compile(r'[A-Za-z_][A-Za-z0-9_-]*(?:\.[A-Za-z_][A-Za-z0-9_-]*)*\Z')
KEY = re.compile(r'[A-Za-z_][A-Za-z0-9_.-]*\Z')
VERSION = re.compile(r'(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*))?\Z')
DIGEST = re.compile(r'sha256:[0-9a-f]{64}\Z')
ARG_KEYS = {
    'SOURCE_BIND': ('media', 'profile'),
    'FIELD_DEFINE': ('shape', 'sample', 'axes', 'sparse'),
    'FIELD_POPULATE': ('mapping',), 'FIELD_SLICE': ('selector',),
    'FIELD_REGION': ('selector',),
    'PYRAMID_DEFINE': ('levels', 'downsample', 'spatial_axes'),
    'COUPLING_DEFINE': ('neighborhood', 'radius', 'representation'),
    'MSSL_EVAL': ('mode', 'lab_ids', 'coupling'),
    'ADMISSION_EVAL': ('policy', 'authorization'),
    'PROJECT': ('selector', 'output'), 'EMIT_RECEIPT': ('content_bound', 'expected'),
    'SHARD': ('partition', 'count'), 'ROOT_BUILD': ('hash',),
    'STATE_COMMIT': ('grant',),
}

@dataclass(frozen=True)
class ReferenceLimits:
    """Resource policy is independent of language identity and authority."""
    source_bytes: int = 1_048_576
    line_chars: int = 65_536
    cell_chars: int = 16_384
    symbol_chars: int = 256
    rows: int = 10_000
    frames: int = 1_024
    bindings: int = 256
    dependencies_per_row: int = 128
    dependencies_total: int = 100_000
    structured_fields: int = 64

    def __post_init__(self):
        if any(type(v) is not int or v < 1 for v in self.__dict__.values()):
            raise ValueError('reference limits must be positive integers')

DEFAULT_LIMITS = ReferenceLimits()
MAX_JSON_BYTES = 4_194_304
MAX_JSON_DEPTH = 64
MAX_JSON_NODES = 100_000
MAX_INTEGER_DIGITS = 4_096
MAX_INTEGER_ABS = 10 ** MAX_INTEGER_DIGITS
MAX_MSSL_BYTES = 67_108_864

class RUSSLValidationError(ValueError):
    """Stable diagnostic; source values and private paths are not copied."""
    def __init__(self, code, message, *, source_line=None, row_id=None):
        self.code, self.severity = code, 'error'
        self.cause_class = code.split('-')[2].lower()
        self.source_line, self.row_id = source_line, row_id
        where = f' at line {source_line}' if source_line is not None else ''
        super().__init__(f'{code}: {message}{where}')

def _fail(code, message, **location):
    raise RUSSLValidationError(code, message, **location)

def _utf8(text, label, *, code='RUSSL-E-PARSE-001'):
    if not isinstance(text, str):
        _fail(code, f'{label} must be text')
    try:
        return text.encode('utf-8', errors='strict')
    except UnicodeError:
        _fail(code, f'{label} contains invalid Unicode')

def _json_object_valid(obj, *, max_depth=MAX_JSON_DEPTH):
    pending, active, nodes = [(obj, 0, False)], set(), 0
    while pending:
        value, depth, leaving = pending.pop()
        if leaving:
            active.remove(id(value))
            continue
        nodes += 1
        if nodes > MAX_JSON_NODES or depth > max_depth:
            _fail('RUSSL-E-RESOURCE-001', 'JSON object resource limit')
        if isinstance(value, (dict, list)):
            if type(value) not in (dict, list):
                _fail('RUSSL-E-CANON-001', 'JSON containers must be plain dict/list')
            if id(value) in active:
                _fail('RUSSL-E-CANON-001', 'cyclic JSON object')
            if len(value) + nodes > MAX_JSON_NODES:
                _fail('RUSSL-E-RESOURCE-001', 'JSON container resource limit')
            active.add(id(value))
            pending.append((value, depth, True))
            if type(value) is dict:
                for key in value:
                    if type(key) is not str:
                        _fail('RUSSL-E-CANON-001', 'JSON object keys must be strings')
                    if len(key) > MAX_JSON_BYTES or len(_utf8(key, 'JSON key', code='RUSSL-E-CANON-001')) > MAX_JSON_BYTES:
                        _fail('RUSSL-E-RESOURCE-001', 'JSON key resource limit')
                pending.extend((item, depth + 1, False) for item in value.values())
            else:
                pending.extend((item, depth + 1, False) for item in value)
        elif type(value) is str:
            if len(value) > MAX_JSON_BYTES or len(_utf8(value, 'JSON string', code='RUSSL-E-CANON-001')) > MAX_JSON_BYTES:
                _fail('RUSSL-E-RESOURCE-001', 'JSON string resource limit')
        elif type(value) is float:
            if not math.isfinite(value):
                _fail('RUSSL-E-CANON-001', 'nonfinite JSON number')
        elif type(value) is int:
            if abs(value) >= MAX_INTEGER_ABS:
                _fail('RUSSL-E-RESOURCE-001', 'JSON integer resource limit')
        elif value is not None and type(value) is not bool:
            _fail('RUSSL-E-CANON-001', 'unsupported JSON value')

def canonical_json_bytes(obj):
    """Legacy sorted compact Python JSON, not RFC 8785/JCS serialization."""
    _json_object_valid(obj)
    try:
        payload = json.dumps(obj, sort_keys=True, separators=(',', ':'),
                             ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, UnicodeError, RecursionError):
        _fail('RUSSL-E-CANON-001', 'JSON serialization failed')
    if len(payload) > MAX_JSON_BYTES:
        _fail('RUSSL-E-RESOURCE-001', 'canonical JSON byte limit')
    return payload

def strict_json_loads(data, *, max_bytes=MAX_JSON_BYTES, max_depth=MAX_JSON_DEPTH):
    """UTF-8 JSON with duplicate, nonfinite and resource protection."""
    if type(max_bytes) is not int or max_bytes < 1 or type(max_depth) is not int or max_depth < 1:
        _fail('RUSSL-E-RESOURCE-001', 'invalid JSON resource policy')
    if isinstance(data, bytes):
        if len(data) > max_bytes:
            _fail('RUSSL-E-RESOURCE-001', 'JSON byte limit')
        try:
            data = data.decode('utf-8', errors='strict')
        except UnicodeError:
            _fail('RUSSL-E-CANON-001', 'JSON must be UTF-8')
    elif not isinstance(data, str):
        _fail('RUSSL-E-CANON-001', 'JSON input must be text or bytes')
    if len(data) > max_bytes or len(_utf8(data, 'JSON input', code='RUSSL-E-CANON-001')) > max_bytes:
        _fail('RUSSL-E-RESOURCE-001', 'JSON byte limit')
    depth, quoted, escaped = 0, False, False
    for char in data:
        if quoted:
            if escaped: escaped = False
            elif char == '\\': escaped = True
            elif char == '"': quoted = False
        elif char == '"': quoted = True
        elif char in '[{':
            depth += 1
            if depth > max_depth:
                _fail('RUSSL-E-RESOURCE-001', 'JSON nesting limit')
        elif char in ']}': depth -= 1

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                _fail('RUSSL-E-CANON-001', 'duplicate JSON object key')
            result[key] = value
        return result
    def integer(token):
        if len(token.lstrip('-')) > MAX_INTEGER_DIGITS:
            _fail('RUSSL-E-RESOURCE-001', 'JSON integer digit limit')
        return int(token)
    def number(token):
        result = float(token)
        if not math.isfinite(result):
            _fail('RUSSL-E-CANON-001', 'nonfinite JSON number')
        return result
    def constant(_token):
        _fail('RUSSL-E-CANON-001', 'nonfinite JSON constant')
    try:
        result = json.loads(data, object_pairs_hook=pairs, parse_int=integer,
                            parse_float=number, parse_constant=constant)
    except RUSSLValidationError: raise
    except (ValueError, UnicodeError, RecursionError):
        _fail('RUSSL-E-CANON-001', 'invalid JSON syntax')
    _json_object_valid(result, max_depth=max_depth)
    return result

def canonical_source(text, *, max_bytes=DEFAULT_LIMITS.source_bytes):
    if type(max_bytes) is not int or max_bytes < 1:
        _fail('RUSSL-E-RESOURCE-001', 'invalid source resource policy')
    if not isinstance(text, str):
        _fail('RUSSL-E-PARSE-001', 'source must be text')
    if len(text) > max_bytes or len(_utf8(text, 'source')) > max_bytes:
        _fail('RUSSL-E-RESOURCE-001', 'source byte limit')
    if text.startswith('\ufeff'): text = text[1:]
    text = unicodedata.normalize('NFC', text.replace('\r\n', '\n').replace('\r', '\n'))
    if any((unicodedata.category(ch) in ('Cc', 'Cf') and ch not in '\n\t')
           or ch in '\u2028\u2029' for ch in text):
        _fail('RUSSL-E-PARSE-001', 'forbidden source controls or line separators')
    lines = [line.rstrip(' \t') for line in text.split('\n')]
    while lines and lines[-1] == '': lines.pop()
    result = '\n'.join(lines) + '\n'
    if len(_utf8(result, 'canonical source')) > max_bytes:
        _fail('RUSSL-E-RESOURCE-001', 'canonical source byte limit')
    return result

def domain_hash(domain, payload):
    if not isinstance(domain, str) or not domain or '\0' in domain or not isinstance(payload, bytes):
        _fail('RUSSL-E-CANON-001', 'invalid digest domain or payload')
    try: tag = domain.encode('ascii')
    except UnicodeError: _fail('RUSSL-E-CANON-001', 'digest domain must be ASCII')
    return hashlib.sha256(tag + b'\0' + payload).hexdigest()

def _split_fields(text, separator):
    fields, start, quoted, escaped = [], 0, False, False
    for index, char in enumerate(text):
        if quoted:
            if escaped: escaped = False
            elif char == '\\': escaped = True
            elif char == '"': quoted = False
        elif char == '"': quoted = True
        elif (separator is None and char in ' \t') or char == separator:
            if separator is not None or index > start:
                fields.append(text[start:index])
            start = index + 1
    if quoted or escaped:
        _fail('RUSSL-E-PARSE-002', 'unterminated quoted value')
    if start < len(text) or separator is not None: fields.append(text[start:])
    return fields

def _field_value(raw):
    if not raw: _fail('RUSSL-E-PARSE-002', 'empty field value')
    if raw.startswith('"'):
        try: value = json.loads(raw)
        except (ValueError, RecursionError):
            _fail('RUSSL-E-PARSE-002', 'invalid quoted value')
        if not isinstance(value, str):
            _fail('RUSSL-E-PARSE-002', 'quoted value must be a string')
    else:
        if any(char in raw for char in "'\"\\ \t"):
            _fail('RUSSL-E-PARSE-002', 'unquoted quote, escape or whitespace')
        value = raw
    _utf8(value, 'field value')
    if not value or any(unicodedata.category(ch) in ('Cc', 'Cf')
                        or ch in '│›\u2028\u2029' for ch in value):
        _fail('RUSSL-E-PARSE-002', 'forbidden structural characters in field value')
    return value

def _parse_fields(text, separator, *, max_fields=DEFAULT_LIMITS.structured_fields):
    parts = _split_fields(text, separator)
    if not parts or len(parts) > max_fields:
        _fail('RUSSL-E-RESOURCE-001', 'structured field count')
    result = {}
    for part in parts:
        if not part or '=' not in part:
            _fail('RUSSL-E-PARSE-002', 'structured field lacks key=value')
        key, raw = part.split('=', 1)
        if not KEY.fullmatch(key):
            _fail('RUSSL-E-PARSE-002', 'invalid field key')
        if key in result: _fail('RUSSL-E-PARSE-002', 'duplicate field key')
        result[key] = _field_value(raw)
    return result

def parse_kvs(text): return _parse_fields(text, None)
def parse_structured(cell): return {} if cell == '_' else _parse_fields(cell, ';')

def _keys(record, allowed, required=()):
    if set(record) - set(allowed):
        _fail('RUSSL-E-PARSE-002', 'unknown profile field key')
    if set(required) - set(record):
        _fail('RUSSL-E-PARSE-002', 'missing required profile field')

def _symbol(value, limits, label='symbol'):
    if value == '_' or len(value) > limits.symbol_chars or not SYMBOL.fullmatch(value):
        _fail('RUSSL-E-PARSE-002', f'invalid {label}')

def parse_russl(text, reject_storage_leak=True, *, limits=DEFAULT_LIMITS):
    """Validate a closed static profile and return the legacy parse structure."""
    if not isinstance(limits, ReferenceLimits):
        _fail('RUSSL-E-RESOURCE-001', 'invalid reference resource policy')
    if type(reject_storage_leak) is not bool:
        _fail('RUSSL-E-PARSE-001', 'storage lexical policy must be boolean')
    text = canonical_source(text, max_bytes=limits.source_bytes)
    if reject_storage_leak and STORAGE_LEAK.search(text):
        _fail('RUSSL-E-STORAGE-001', 'storage-specific lexical leakage in core source')
    lines = text.split('\n')
    if lines[0] != 'RUSSL/1.0':
        _fail('RUSSL-E-PARSE-001', 'RUSSL/1.0 header required', source_line=1)
    unit, defaults, defaults_seen, mssl, bindings = None, {}, False, [], {}
    frames, frame_ids, frame, saw_columns = [], set(), None, False
    rows, outputs, ancestors, external_consumed = {}, {}, {}, set()
    dependency_count = 0

    def required_input(handle, ancestor_bits):
        if handle in outputs:
            if not (ancestor_bits & (1 << outputs[handle])):
                _fail('RUSSL-E-DEP-001', 'input producer absent from control ancestry')
        elif handle in bindings: return
        elif handle.startswith('source.'): external_consumed.add(handle)
        else: _fail('RUSSL-E-BIND-001', 'unresolved input symbol')

    for index, line in enumerate(lines[1:], start=2):
        if len(line) > limits.line_chars:
            _fail('RUSSL-E-RESOURCE-001', 'line character limit', source_line=index)
        if not line or line.startswith('#'): continue
        directive_match = re.fullmatch(r'@(unit|defaults|mssl|frame)[ \t]+(.*)', line)
        directive, directive_body = directive_match.groups() if directive_match else (None, None)
        current_row_id = None
        try:
            if directive == 'unit':
                if unit is not None or mssl or frame is not None or frames:
                    _fail('RUSSL-E-PARSE-001', 'unit directive order or duplication')
                unit = _parse_fields(directive_body, None, max_fields=limits.structured_fields)
                _keys(unit, ('id', 'version', 'profile', 'target', 'fail'), ('id', 'version', 'fail'))
                _symbol(unit['id'], limits, 'unit ID')
                if not re.fullmatch(r'(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)', unit['version']):
                    _fail('RUSSL-E-PARSE-001', 'unit version requires three decimal components')
                if unit['fail'] != 'closed' or unit.get('profile', 'russl.core') != 'russl.core' or unit.get('target', 'russ') != 'russ':
                    _fail('RUSSL-E-PARSE-001', 'unsupported profile, target or failure policy')
            elif directive == 'defaults':
                if unit is None or defaults_seen or mssl or frame is not None or frames:
                    _fail('RUSSL-E-PARSE-001', 'defaults directive order or duplication')
                defaults = _parse_fields(directive_body, None, max_fields=limits.structured_fields)
                _keys(defaults, ('mode', 'regime', 'effect', 'scope'))
                if defaults.get('mode', 'deterministic') != 'deterministic' or defaults.get('regime', 'exact') != 'exact':
                    _fail('RUSSL-E-PARSE-001', 'unsupported reference execution annotation')
                if defaults.get('effect', 'read') != 'read' or defaults.get('scope', 'self') != 'self':
                    _fail('RUSSL-E-EFFECT-001', 'unsupported reference default effect or scope')
                defaults_seen = True
            elif directive == 'mssl':
                if unit is None or frame is not None or frames:
                    _fail('RUSSL-E-PARSE-001', 'MSSL directive outside binding preamble')
                binding = _parse_fields(directive_body, None, max_fields=limits.structured_fields)
                if not DIGEST.fullmatch(binding.get('digest', '')):
                    _fail('RUSSL-E-MSSL-001', 'missing or invalid SHA-256 module digest')
                _keys(binding, ('alias', 'module', 'source_version', 'digest'), ('alias', 'module', 'source_version', 'digest'))
                for key in ('alias', 'module'): _symbol(binding[key], limits, f'MSSL {key}')
                if binding['alias'].startswith('source.') or binding['alias'] in bindings:
                    _fail('RUSSL-E-MSSL-001', 'duplicate or reserved MSSL alias')
                if not VERSION.fullmatch(binding['source_version']):
                    _fail('RUSSL-E-MSSL-001', 'invalid module source version')
                if len(mssl) >= limits.bindings:
                    _fail('RUSSL-E-RESOURCE-001', 'MSSL binding count')
                mssl.append(binding)
                bindings[binding['alias']] = binding
            elif directive == 'frame':
                if unit is None or frame is not None:
                    _fail('RUSSL-E-PARSE-001', 'frame directive order or nesting')
                if len(frames) >= limits.frames:
                    _fail('RUSSL-E-RESOURCE-001', 'frame count')
                frame = _parse_fields(directive_body, None, max_fields=limits.structured_fields)
                _keys(frame, ('id', 'parent', 'module', 'phase'), ('id', 'parent', 'module'))
                for key in ('id', 'parent', 'module'): _symbol(frame[key], limits, f'frame {key}')
                if frame['id'] == 'ROOT' or frame['id'] in frame_ids:
                    _fail('RUSSL-E-PARSE-003', 'duplicate or reserved frame ID')
                if frame['parent'] != 'ROOT' and frame['parent'] not in frame_ids:
                    _fail('RUSSL-E-DEP-001', 'unresolved frame parent')
                frame['rows'], saw_columns = [], False
            elif line == COLUMNS:
                if frame is None or saw_columns or frame['rows']:
                    _fail('RUSSL-E-PARSE-002', 'columns must occur once before frame rows')
                saw_columns = True
            elif line == '@end':
                if frame is None or not saw_columns or not frame['rows']:
                    _fail('RUSSL-E-PARSE-002', 'empty or malformed frame terminator')
                frames.append(frame)
                frame_ids.add(frame['id'])
                frame = None
            elif line.startswith('@'):
                _fail('RUSSL-E-PARSE-001', 'unknown directive')
            elif frame is not None:
                if not saw_columns: _fail('RUSSL-E-PARSE-002', 'row before columns')
                cells = line.split('│')
                if len(cells) != 8 or any(not cell for cell in cells):
                    _fail('RUSSL-E-PARSE-002', 'eight nonempty cells required')
                if any(len(cell) > limits.cell_chars for cell in cells):
                    _fail('RUSSL-E-RESOURCE-001', 'cell character limit')
                rid, lane, op, out, ctrl, inp, arg, meta = cells
                _symbol(rid, limits, 'row ID')
                current_row_id = rid
                _symbol(lane, limits, 'lane')
                if rid in rows: _fail('RUSSL-E-PARSE-003', 'duplicate row ID')
                if len(rows) >= limits.rows: _fail('RUSSL-E-RESOURCE-001', 'row count')
                norm = ALIASES.get(op, op)
                if norm not in OPERATORS: _fail('RUSSL-E-OP-001', 'unregistered operator')
                face, typ, effect = OPERATORS[norm]
                if out == '_':
                    if face != 'CONTROL': _fail('RUSSL-E-BIND-001', 'output required')
                else:
                    _symbol(out, limits, 'output handle')
                    if out in outputs or out in bindings or out in external_consumed:
                        _fail('RUSSL-E-BIND-001', 'duplicate or shadowed output handle')
                    if out.startswith('source.') and norm != 'SOURCE_BIND':
                        _fail('RUSSL-E-BIND-001', 'source namespace requires SOURCE_BIND')
                deps = [] if ctrl == '_' else ctrl.split(',')
                if len(deps) > limits.dependencies_per_row:
                    _fail('RUSSL-E-RESOURCE-001', 'per-row dependency count')
                dependency_count += len(deps)
                if dependency_count > limits.dependencies_total:
                    _fail('RUSSL-E-RESOURCE-001', 'total dependency count')
                if len(set(deps)) != len(deps): _fail('RUSSL-E-DEP-001', 'duplicate predecessor')
                ancestor_bits = 0
                for dep in deps:
                    _symbol(dep, limits, 'control predecessor')
                    if dep not in rows: _fail('RUSSL-E-DEP-001', 'predecessor must be prior row')
                    ancestor_bits |= ancestors[dep] | (1 << rows[dep])
                inputs = [] if inp == '_' else inp.split('›')
                if len(inputs) > 2: _fail('RUSSL-E-PARSE-002', 'at most two primary operands')
                for handle in inputs:
                    _symbol(handle, limits, 'input handle')
                    if handle == out:
                        _fail('RUSSL-E-BIND-001', 'row cannot consume its own output')
                    required_input(handle, ancestor_bits)
                if norm in ('MSSL_EVAL', 'ADMISSION_EVAL') and (len(inputs) != 2 or inputs[0] not in bindings or inputs[1] in bindings):
                    _fail('RUSSL-E-MSSL-001', 'invocation requires bound alias and data handle')
                if norm not in ('MSSL_EVAL', 'ADMISSION_EVAL', 'VERIFY_MSSL') and any(handle in bindings for handle in inputs):
                    _fail('RUSSL-E-MSSL-001', 'module alias outside module operation')
                args = {} if arg == '_' else _parse_fields(arg, ';', max_fields=limits.structured_fields)
                meta_obj = {} if meta == '_' else _parse_fields(meta, ';', max_fields=limits.structured_fields)
                _keys(args, ARG_KEYS.get(norm, ()))
                _keys(meta_obj, ('eff', 'scope', 'proof'))
                if 'eff' in meta_obj and meta_obj['eff'] != effect:
                    _fail('RUSSL-E-EFFECT-001', 'effect differs from operator effect')
                if 'scope' in meta_obj and meta_obj['scope'] != 'self':
                    _fail('RUSSL-E-EFFECT-001', 'unsupported reference scope')
                if 'coupling' in args:
                    _symbol(args['coupling'], limits, 'coupling handle')
                    if args['coupling'] not in outputs: _fail('RUSSL-E-BIND-001', 'unresolved coupling')
                    required_input(args['coupling'], ancestor_bits)
                row = {'id': rid, 'lane': lane, 'op': norm, 'face': face, 'type': typ,
                       'effect': effect, 'out': out, 'ctrl': deps, 'inputs': inputs,
                       'arg': args, 'meta': meta_obj, 'source_line': index}
                frame['rows'].append(row)
                rows[rid] = len(rows)
                ancestors[rid] = ancestor_bits
                if out != '_': outputs[out] = rows[rid]
            else: _fail('RUSSL-E-PARSE-001', 'content outside frame')
        except RUSSLValidationError as error:
            error.row_id = current_row_id
            if error.source_line is None:
                error.source_line = index
                error.args = (f'{error.args[0]} at line {index}',)
            raise
    if unit is None or frame is not None or not frames:
        _fail('RUSSL-E-PARSE-001', 'incomplete unit')
    return {'unit': unit, 'defaults': defaults, 'mssl_bindings': mssl,
            'frames': frames, 'source': text}

def lower_russl(text, *, limits=DEFAULT_LIMITS):
    parsed = parse_russl(text, limits=limits)
    source = parsed.pop('source')
    obj = {'schema': 'RUSSL.CanonicalIR/1.0',
           'source_sha256': domain_hash('RUSSL-SOURCE/1.0', source.encode('utf-8')),
           'unit': parsed['unit'], 'defaults': parsed['defaults'],
           'mssl_bindings': parsed['mssl_bindings'], 'frames': parsed['frames'],
           'program': [row for frame in parsed['frames'] for row in frame['rows']]}
    obj['ir_id'] = 'russir:sha256:' + domain_hash('RUSSIR/1.0', canonical_json_bytes(obj))
    return obj

def phi(i, n, anchor=0.0):
    """Integer binary64 reference coordinate mapping with finite anchor."""
    if type(i) is not int or type(n) is not int or n < 1 or i < 0 or i >= n:
        _fail('RUSSL-E-FIELD-001', 'index and extent require valid integers')
    if n > (1 << 53) or type(anchor) not in (int, float):
        _fail('RUSSL-E-FIELD-001', 'coordinate precision profile or anchor type')
    try: anchor = float(anchor)
    except (ValueError, OverflowError): _fail('RUSSL-E-FIELD-001', 'invalid anchor')
    if not math.isfinite(anchor) or not -1.0 <= anchor <= 1.0:
        _fail('RUSSL-E-FIELD-001', 'anchor must be finite and in [-1,1]')
    return anchor if n == 1 else -1.0 + 2.0 * float(i) / float(n - 1)

def verify_mssl(path, digest):
    """Bounded byte equality only; caller selects path and expected digest."""
    if not isinstance(digest, str): _fail('RUSSL-E-MSSL-001', 'digest must be text')
    digest = digest[7:] if digest.startswith('sha256:') else digest
    if not re.fullmatch(r'[0-9a-f]{64}', digest):
        _fail('RUSSL-E-MSSL-001', 'invalid SHA-256 digest')
    hasher, count = hashlib.sha256(), 0
    try:
        with Path(path).open('rb') as stream:
            while True:
                chunk = stream.read(65_536)
                if not chunk: break
                count += len(chunk)
                if count > MAX_MSSL_BYTES: _fail('RUSSL-E-RESOURCE-001', 'MSSL byte limit')
                hasher.update(chunk)
    except (OSError, TypeError, ValueError) as error:
        if isinstance(error, RUSSLValidationError): raise
        _fail('RUSSL-E-MSSL-002', 'module bytes unavailable')
    if hasher.hexdigest() != digest: _fail('RUSSL-E-MSSL-002', 'module byte digest mismatch')
    return True
