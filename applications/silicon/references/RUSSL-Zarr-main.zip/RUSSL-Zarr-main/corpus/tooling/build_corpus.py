"""Safe entry point: seal this existing candidate corpus without deletion."""
from seal_release import main
if __name__ == '__main__':
    main()
