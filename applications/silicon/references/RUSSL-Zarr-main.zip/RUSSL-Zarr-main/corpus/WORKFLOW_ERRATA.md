# Workflow Errata — 2.0.0

RUSSL-WF-ERRATA-0001 records reciprocal design dependencies WP03↔WP04 and WP08↔WP09. The graph preserves both strongly connected groups. They can undergo atomic co-ratification: approve every member only when the entire group and incoming prerequisites satisfy the selected review gates. Construction order cannot itself ratify a cycle.

Earlier records asserted completed internal ratification and G0–G9 GO without identifiable reviewers, votes or independent gate evidence. This assertion is superseded. Candidate records identify proposed review groups and leave every gate unapproved. Original records remain under lineage/prior_release/ and in the exact original ZIP.

This local clarification describes future review; it does not amend external sources or certify the corpus. The graph describes dependency, not design consistency. Reviews retain incoming edges, conflicting interpretations, agreed invariants and evidence for each member's obligations.
