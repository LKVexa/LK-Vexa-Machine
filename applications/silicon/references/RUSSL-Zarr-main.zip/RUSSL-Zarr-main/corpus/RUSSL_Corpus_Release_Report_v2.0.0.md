# RUSSL Corpus Release Report — 2.0.0

Release date 2026-10-09. Status CANDIDATE_REVIEW_REQUIRED. This distribution applies the end-to-end audit's structural/software fixes and expands technical, institutional and research content. It preserves the exact original ZIP and selected compatibility artifacts.

The 28 work packages and 293 original requirements remain addressable. Verification establishes candidate package consistency, strict profile parsing/lowering, structural schema checks, bounded golden tuple binding/rebuilding and concrete regression behavior. The authoritative result and test count are in `evidence/CONFORMANCE_RESULTS.json`; requirement coverage is separately recorded and does not claim all requirements passed. Completion gates await accountable review.

The release contains expanded formal/algorithmic commentary, conformance limits, research protocols, version-pinned adapter designs, primary-source bibliography and proposed assurance/governance/change/archive/incident/rights/privacy policies. These are specification and research designs, not empirical findings or external institutional approvals.

Use [start here](README_START_HERE.md), [audit report](AUDIT_REPORT.md) and [change log](CHANGELOG.md). Verify the extracted package with offline and integrity commands. MSSL evaluation, full type/effect semantics, runtime authorization/distributed execution, independent adapter tests, scientific replication and institutional ratification remain open before stronger claims.

The added research stage audits all nineteen supplied files and records 159 claim decisions, with eleven optional research designs and 16,384 exact address/inverse fixture rows for 4×4×4×16×16. [Research integration](research/RESEARCH_INTEGRATION_REPORT.md) explains source-by-source use, corrections, implemented helpers, unexecuted experiments and provenance. The central registry includes 100 source records across standards, preserved sources and unavailable/limited references; this count is not a claim of 100 fully verified scientific publications.
