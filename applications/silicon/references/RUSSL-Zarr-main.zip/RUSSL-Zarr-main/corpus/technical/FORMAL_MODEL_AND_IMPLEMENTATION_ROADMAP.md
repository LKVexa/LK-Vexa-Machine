# Formal model and implementation roadmap

**Package:** RUSSL Research & Institutional Corpus 2.0.0  
**Language:** RUSSL/1.0 hardened reference profile (corpus 2.0.0)  
**Status:** Informative technical design and verification plan; unratified  
**Evidence basis:** Supplied archive and local audit; external primary sources where cited  
**Scope:** Language/compiler/tuple/field/runtime/fabric contracts and their implementation boundaries

This document converts the corpus architecture into a checkable engineering program. It does not claim that a full type checker, MSSL interpreter, runtime, distributed fabric, or TIFF/NGFF adapter exists. The final verification report is authoritative about which local checks executed. The original 293 requirement IDs remain the normative traceability anchors; this roadmap introduces no new requirements.

## 1. Entities, identities, and authority

Define a source unit U, canonical source C(U), lowered IR J, ordered logical tuple T, logical field F, mechanics binding B, candidate root R, grant G, receipt E, and mutable head H. Keep the following relations separate:

| Relation | Meaning | What it cannot establish alone |
|---|---|---|
| Raw file digest equality | Exact supplied file bytes match | Authorship, permission, scientific truth |
| Domain-separated object identity | Canonical object bytes match under a named profile | Semantic equivalence of different representations |
| Type compatibility | Values obey a declared structural/numeric contract | Input authenticity or operational permission |
| Policy disposition | A mechanics/policy evaluation produced a result | A verified grant or human authorization |
| Authentic authorization | A trusted principal permitted a bound action | Scientific validity of mechanics |
| Reproduction | Declared outputs repeat under fixed inputs/profile | Independent empirical validation |

The architecture is `RUSSL → MSSL → RUSS tuple-executable → Penteract field → distributed fabric`. This is a separation of contracts. It is not a claim that every stage has an executing implementation. Backend paths and external container layouts live in adapter profiles; they do not define the core field.

## 2. Current implementation boundary

| Layer | Delivered or intended bounded support | Outstanding implementation/evidence |
|---|---|---|
| Source ingestion | Strict canonical text and finite-state parsing; bounded input | Independent parser differential review; broader language profiles |
| Structural compiler | Alias resolution, graph/order/handle/effect checks, canonical IR | General arity/parameter contracts, type soundness, semantic preservation |
| JSON ingestion/identity | Strict duplicate/nonfinite handling and compact corpus serializer | Independent cross-language numeric/Unicode equivalence |
| Geometry helper | Finite index/anchor checks and normalized-coordinate vectors | Complete dense/sparse/pyramid evaluator |
| Module binding | Four preserved files and exact digest checking | Complete MSSL parsing/evaluation, contracts, sandbox budgets |
| Tuple tools | Deterministic golden construction and bounded verification | Full loader/ABI runtime, independent compatibility implementations |
| Schema checks | Bounded supported-keyword validation plus selected cross-field checks | Complete Draft 2020-12 suite/validator parity and semantic coverage |
| Runtime/grants/fabric | Detailed contracts and examples | Authentic signature/grant service, replay store, transactions, distributed operations |
| TIFF/NGFF profiles | Versioned mappings, loss and round-trip plans | Actual import/export adapters and fixture round trips |
| Research/institutional | Evidence taxonomy, limitations, proposed assurance/governance | Authentic review/approval, empirical observations, external replication |

Recognition of an operator catalog entry is not evaluation support. Result labels attached during lowering are not a complete type judgment. Sample grant/receipt JSON objects are inert fixtures, not authentic operational evidence. Reserved `source.*` handles in existing examples designate unresolved external inputs.

## 3. Structural compiler invariants

Let `ord(r)` be source ordinal. A parsed row is
`r=(id,lane,op,out,ctrl,inputs,arg,meta)`, with a registered canonical operator and eight explicit source cells.

The hardened source profile admits a finite-state parse: header, one unit, optional defaults, zero or more module declarations, and one or more nonempty closed frames. Each frame establishes its columns exactly once before rows. Global declarations do not occur within a frame. Authority-bearing identifiers use a constrained lexical profile; duplicate keys are rejected rather than overwritten.

For every row r:

1. Row identity and produced output are unique within the applicable unit namespace.
2. Every p in ctrl(r) has ord(p) < ord(r).
3. Every produced input consumed by r has a unique producer p in the transitive control ancestry of r.
4. Module operands identify a declared digest-bound alias.
5. The explicit effect, if present, agrees with the registered operator effect.
6. Primary input count is at most two under this surface profile.

Property 2 proves the accepted control graph acyclic: a cycle would imply a strict ordinal inequality back to the same row. Property 3 establishes structural readiness rather than mere earlier textual definition. It does not prove that external inputs exist or that module results have the right type.

The grammar remains RUSSL/1.0. Package version 2.0.0 hardens the recognized reference profile and assurance discipline. Program `@unit version`, corpus version, schema version, and external adapter version are independent axes.

## 4. Operational semantics proposal

Use configuration `K=⟨G,σ,q,e,a,h⟩`. G is the lowered DAG, σ the immutable handle environment, q row status, e evidence, a authorization context, and h observed mutable-head state.

`Ready(K)={r | q(r)=pending ∧ ∀p∈pred(r),q(p)=succeeded ∧ inputs(r)⊆dom(σ)}`.

Sequential deterministic evaluation selects the smallest ordinal in Ready(K). A pure transition returns fresh output values and extends σ. Its preservation invariant is `∀x∈dom(σ),σ'(x)=σ(x)`. A failed precondition emits a stable primary cause and blocks descendants on the affected effect path.

An effectful row first produces a plan. Its application guard is the conjunction of verified content, compatible input contracts, live exact-bound grant, unused nonce/idempotency record, and unchanged state preconditions. An evaluation success is a candidate result until this guarded transition succeeds.

Safety statement: an unauthorized or failed commit path does not advance a mutable head. Liveness additionally assumes available inputs, finite/budgeted module evaluation, and a progressing adapter. Neither property is proved merely by a deterministic DAG scheduler.

## 5. Type-system proposal

A proposed judgment is `Γ;Δ;Π ⊢ r:τ!ε`, where Γ maps handles to refined types, Δ contains digest-bound module contracts, and Π specifies numeric/profile behavior.

Representative refinements include `Digest<domain,algorithm>`, `Coord<rank,basis>`, `Shape<rank>`, `Region<rank>`, `Field<sample,rank,axes>`, `Module<contract,digest>`, `Evidence<claim>`, `Grant<scope>`, and `Root<domain>`.

Field construction requires five positive integer dimensions, five distinct axes, and a supported sample contract. Population additionally relates cardinality, dtype, packing, coverage, and missingness to the source values. Slicing names fixed indices and output-axis order. Module evaluation requires an actual module contract rather than an alias name alone. Policy dispositions and grants are disjoint types.

Unit identifiers are explicit metadata. Physical arithmetic verifies compatibility and declared conversion; it does not infer units from magnitudes. Unknown external handle types remain unresolved. Overflow, clipping, signed conversion, null/missing values, binary sample NaN behavior, and rounding are declared profile choices.

Future soundness work has two obligations: progress for supported ready pure rows, and preservation of all handle/result refinements under successful evaluation. These are proposed theorem statements, not established corpus results.

## 6. Field, calibration, and sample equality

For positive integer shape `(n4,…,n8)`, domain `D=∏{0,…,na−1}` has size `N=∏na`, checked before allocation. Normalization is `φa(i)=(2i−(na−1))/(na−1)` for na>1, with finite declared singleton anchor otherwise.

The three coordinate spaces are integer index, normalized logical coordinate, and calibrated physical coordinate. If calibration is `p=A i+b`, a slice fixing indices k yields `p=A_free i_free+b+A_fixed k`. A crop starting at l yields an offset b+A l in rebased indices. A transform's input basis prevents double normalization.

A sparse absent sample is different from stored zero or null. Dense/sparse equivalence requires the same declared domain and presence/default policy. Logical regions use half-open bounds. Pyramid extent preservation and sample-value preservation are different obligations.

Equality also has several domains: encoded bytes, decoded samples, axis placement, calibrated coordinates, color/channel meaning, and scientific observations. The current digest model is byte/domain identity; it does not specify a universal codec-independent semantic sample hash. A change in compression can preserve samples and change payload bytes.

## 7. Canonicalization and identity

For canonical bytes B in domain D,
`H(D,B)=SHA256(ASCII(D)||0x00||B)`.
Raw module/member digests hash exact file bytes instead.

Source canonicalization is UTF-8/NFC/LF/no-BOM, trailing SP/TAB removal, and one final LF. It is idempotent and retains comments. Source identity is therefore not semantic-equivalence identity.

The corpus JSON profile is compact Python serialization with recursively sorted string keys and preserved array order. It is explicitly distinct from RFC 8785/JCS: numeric serialization and Unicode property ordering can differ; JCS preserves JSON string data without normalization. [RFC 8785](https://www.rfc-editor.org/rfc/rfc8785.html)

The IR preimage excludes only its self-identifying ir_id. It includes source identity and source_line annotations. Tuple identity covers the ordered eleven-component logical tuple. A container-file digest covers framing/physical bytes. Version migration reviews all affected preimages and keeps old vectors; switching serializers is a semantic identity change, not formatting.

## 8. Commit transaction and crash states

A transaction record binds run, tuple, row, sequence, input root, arguments digest, head scope, observed tip/revision, candidate root, grant, nonce, and idempotency key.

The abstract application operation is
`CAS(head,expected_revision,expected_root,new_root,grant)`.
Success atomically establishes the new head, consumes authority according to nonce policy, and stores a durable result. If the adapter cannot provide that atomicity, the deployment declares its weaker contract and recovery procedure.

Crash analysis distinguishes: before effect, during effect, after effect before receipt, and after durable result. A missing receipt is not proof no effect occurred. Retry reads durable idempotency state; it does not reapply arbitrary actions. Rollback is a new authorized head update to an immutable checkpoint, preserving history. It does not erase publication or replication.

Exactly-once behavior is a transaction/storage property. DAG ordering, schema validation, and a nonce field alone do not supply it.

## 9. Interoperability contracts

TIFF migration separates safe container inspection, decode, explicit axis placement, metadata retention, and round-trip classification. Original byte recovery, exact sample recovery, and metadata reconstruction are distinct targets. The maintained official libtiff documentation provides format/library context; an adapter still pins its supported decoder/version/codecs. [libtiff documentation](https://libtiff.gitlab.io/libtiff/)

NGFF mapping pins external and Zarr versions. The informative 0.5 target uses Zarr v3 and explicit ordered axis/multiscale metadata. Scale/translation composition, dtype, labels, and unsupported metadata are preserved or classified; newer versions are not inferred compatible. [NGFF 0.5 specification](https://ngff.openmicroscopy.org/0.5/)

Schema dialect declarations identify the intended JSON Schema contract. A local bounded validator is not a complete general dialect implementation. Format annotation versus assertion and unsupported keywords are handled explicitly. Cross-field validators check semantic relationships and identity; no schema proves grant authenticity or scientific truth. [Draft 2020-12](https://json-schema.org/draft/2020-12)

## 10. Verification and release gates

Each evidence obligation records requirement ID, implementation status, applicability rationale, actual test procedure, expected oracle, input/suite/tool identities, environment, result, and evidence digest. Planned registry entries remain NOT_RUN. Review artifacts are labelled review evidence rather than invented unit-test passes.

A scoped GO requires every applicable mandatory check in the declared claim to execute and pass. An empty mandatory set is not a substantive claim. Whole-corpus GO is unestablished when mandatory runtime, mechanics, security, adapter, or institutional obligations remain unimplemented. A successful local hardening verifier is reported as such.

The next engineering milestones are:

| Milestone | Concrete deliverable | Exit evidence |
|---|---|---|
| M1. Independent grammar/profile review | Grammar, parser contracts, closed keys/limits | Differential valid/invalid vectors; ambiguity review |
| M2. Refined type checker | Supported operator/module signatures and numeric rules | Positive/negative judgments; preservation review |
| M3. Pure evaluator | Field population, slicing, projection subset | Analytic exact cases; invariant/metamorphic tests |
| M4. MSSL interpreter | Bounded verified-buffer evaluation | Baseline contract vectors; sandbox/termination negatives |
| M5. Grant verifier | Pinned signature/preimage/trust profile | Invalid key/signature/scope/expiry/replay tests |
| M6. Transaction runtime | Durable CAS/idempotency/recovery | Races and crash injection at all boundaries |
| M7. Two CAS adapters | Identical verified immutable object behavior | Corruption/availability/substitution vectors |
| M8. TIFF/NGFF adapters | Version-pinned import/export implementations | Sample/metadata/calibration round trips |
| M9. Independent reproducibility | Another environment or implementation | Byte/numeric-profile parity and source lineage |
| M10. Scientific/institutional review | Actual reviewer/observation artifacts | Evidence-grade assessment and authentic decisions |

No calendar date or completion status is invented for these milestones. Readiness depends on the stated evidence, not document volume.

## 11. Research evaluation protocol

A research claim states exact assumptions, mathematical/data-model definitions, algorithm/module identities, parameter domain, expected invariants, falsification criteria, analysis method, and evidence grade. Computational studies fix seeds, boundary/initial conditions, precision, convergence criteria, solver versions, and environment. Empirical studies add real observation acquisition, sampling, calibration, controls, uncertainty, and exclusions.

Start with transcription/dimensional review, small analytic cases, limiting cases and invariants, independent implementation, sensitivity/convergence studies, then external observations where appropriate. Report null/failed results and separate numerical error, measurement error, model discrepancy, and bias.

P5×S³/8S mechanics remains experimental. A five-index field, a preserved MSSL hash, or deterministic simulation does not establish a physical law. Missing PDFs and authentic external authorization remain unresolved provenance/authority obligations. The package's technical detail supports honest research; it cannot manufacture the missing science or institutional decisions.
