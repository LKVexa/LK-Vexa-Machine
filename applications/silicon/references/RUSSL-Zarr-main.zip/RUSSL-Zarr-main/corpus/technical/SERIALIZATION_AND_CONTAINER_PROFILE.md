# Serialization and RUSS 1.3 Golden Verification Profile

## Identity

Canonical source removes one leading BOM, maps CRLF/CR to LF, normalizes NFC, removes trailing spaces/tabs per line and terminal blank lines, and appends one LF. Retained comments affect the source digest. `source_line` means line changes can affect IR identity. Equal computation need not imply equal source or IR digest.

Corpus JSON uses Python `json.dumps(sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False)` with UTF-8. This preserves supplied corpus compatibility; it does not implement RFC8785/JCS ordering/number rules. Exact decimal extensions need an explicit constrained string representation. Changing serializer requires a new identity profile and fixtures.

For preserved identities, `H(D,x)=SHA256(ASCII(D)||NUL||x)`. Domains are RUSSL-SOURCE/1.0, RUSSIR/1.0 (IR excluding ir_id), RUSS-TUPLE/1.0 (ordered tuple) and RUSS-PAYLOAD/1.0 (sorted path/digest/size entries). Payload/MSSL digests are raw SHA-256. The new corpus manifest uses RUSSL-CORPUS-CONTENT/2.0. Digests are identifiers, not signatures.

## Wire layout

| Structure | Big-endian fields | Bytes |
|---|---|---|
| Header | 8-byte magic RUSS CR LF 1A LF; u16 major=1; u16 minor=3; u32 flags=1; u64 manifest length | 24 |
| Record header | u32 path byte length; u64 payload byte length; 32-byte SHA-256 | 44 |
| Manifest | corpus-canonical UTF-8 JSON | declared length |
| Record body | relative path bytes followed by exact payload bytes | declared sizes |

Only portable embedded payload flag 1 is supported. Other flags/versions reject. The verifier limits containers to 64 MiB, manifests to 1 MiB, records to 1,024 and ASCII paths to 1,024 characters. These are local limits, not universal ABI maxima.

Components appear exactly in identity, language, geometry, state, coupling, mechanics, admission, projection, fabric, evidence, execution order. Each is a name/object pair. Payload descriptors contain path, lowercase 64-hex digest and nonnegative integer size. Records match order, lengths, names and both digest forms. Paths are relative, sorted, case-fold unique, and exclude traversal, drives, backslashes, empty/dot segments, trailing dots and Windows device names. Verification never extracts payloads.

## Binding checks

1. Validate fixed header and every length before slicing. Reject unsupported flags, truncated records and trailing bytes.
2. Strictly load manifest JSON and compare with canonical bytes. Validate each record/digest and recompute payload root.
3. Check tuple order and recompute identity; require fabric root equality.
4. Resolve source/IR references within verified members. Lower source and require exact IR and language ir_id agreement.
5. Bind every IR MSSL module to declared bytes/digest. Reject missing or unbound modules and missing policy/provenance/field references.
6. Check field rank/geometry axes, source FIELD_DEFINE shape/dtype correspondence, policy module role, known identity/geometry profile and structural schemas. Preserve independent authorization and no-arbitrary-code boundaries.
7. Return structural evidence. Evaluate no mechanics and grant no effect permission.

Rebuilding uses the sidecar manifest and fixture payload tree, then verifies the result. Exact active coherent fixture equality is the rebuild oracle. The original inconsistent fixture remains in examples/legacy_golden/ and is rejected. It does not regenerate scientific content. Production profiles require complete tuple-subobject semantics, trust/signatures, capability context and independent security review.
