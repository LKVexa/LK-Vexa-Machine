# RUSSL/1.0 hardened reference profile

**Profile status:** implemented static validation and deterministic lowering subset.  
**Corpus package:** 2.0.0.  
**Source header and IR schema:** `RUSSL/1.0` and `RUSSL.CanonicalIR/1.0`.  
**Implementation:** `tooling/russl_reference.py`.  
**Executable regressions:** `tests/test_reference_hardening.py`.

## 1. Authority and compatibility boundary

This profile defines the exact acceptance behavior of the packaged reference validator. Package version 2.0.0 records a corpus and assurance upgrade; it does not introduce a RUSSL/2.0 language, alter the RUSSL/1.0 digest domains, or declare an external language standard. Acceptance establishes bounded syntax, selected name-binding rules, selected dependency rules and effect-label consistency. It does not establish complete language conformance, scientific validation, runtime authorization or institutional approval.

The original implementation accepted malformed directive order, repeated defaults, rows before the column declaration, duplicate structured keys, unstructured META that bypassed effect checks, arbitrary effect annotations, unresolved data symbols and repeated output handles. Those acceptance behaviors were defects. They are explicitly removed by this closed profile. Extensions need an approved contract and separate profile identifier before they can change this parser's accepted key sets or effect rules.

All twelve supplied source examples produce exactly their original canonical IR objects and IDs under the hardened implementation. Their source header, program metadata version, source digest domain and IR digest domain remain unchanged. The regression compares full objects, not only selected fields. Syntax is narrower outside those examples: single-quoted values, opaque ARG/META text, unknown keys and unregistered effect substitutions are rejected. This is a declared reference-profile restriction, not evidence that every such input is invalid in every possible future RUSSL profile.

## 2. Source processing pipeline

The static pipeline is:

1. Accept a Python text string with valid Unicode scalar values and enforce the UTF-8 byte budget before normalization.
2. Remove one initial U+FEFF byte-order mark if present; convert CRLF and CR to LF; normalize Unicode to NFC.
3. Reject embedded U+FEFF, other Unicode format controls (`Cf`), control characters (`Cc`) except LF/TAB, U+2028/U+2029 and surrogate code points.
4. Remove trailing SP/TAB from each physical line, discard empty terminal lines and append exactly one LF.
5. Apply the optional storage-name lexical filter, validate source structure, normalize operator aliases and perform the profile's static checks.
6. Construct the legacy IR, serialize its identity preimage and calculate the domain-separated SHA-256 identifier.

The source canonicalizer is idempotent for accepted text. It preserves comments, internal empty lines, case, field order, significant quoted whitespace and source ordinals. Two semantically similar programs with different comments or source spellings can therefore have different source-bound IR identities. Alias normalization preserves the operator's lowered descriptor; it does not make different source spellings share one source digest.

The default storage filter searches the entire canonical text, including comments, for the packaged `STORAGE_LEAK` expression. This is a conservative lexical guard, not a proof of storage independence and not a storage-adapter implementation. `parse_russl(..., reject_storage_leak=False)` explicitly disables that guard. The flag must be an actual boolean. `lower_russl` always uses the default guard.

## 3. Structural state machine

The accepted order is a header, exactly one unit directive, at most one defaults directive, zero or more MSSL bindings, and one or more nonempty frames. Blank lines and full-line comments beginning with `#` may appear between complete lines after the header. Leading whitespace before a comment or directive is not ignored. Inline comments are not a syntax feature.

Each frame contains one frame directive, exactly one fixed `ID│LANE│OP│OUT│CTRL│IN│ARG│META` heading, one or more rows, and exactly one `@end`. Rows before the heading, duplicate headings, headings after rows, empty frames, nested frames and any unit/default/MSSL directive inside a frame fail. Once any frame has been completed, the preamble cannot reopen. Unknown directives fail.

Directive separators accept SP or TAB. Directive values are either bare values or double-quoted JSON strings. There is no shell interpretation, command expansion, filesystem resolution, networking or execution during parsing.

| Directive | Required keys | Optional keys | Additional checks |
|---|---|---|---|
| `@unit` | `id`, `version`, `fail` | `profile`, `target` | `fail=closed`; optional `profile=russl.core`; optional `target=russ`; version is exactly three nonnegative decimal components with no leading zeros |
| `@defaults` | none, but at least one field is required | `mode`, `regime`, `effect`, `scope` | Accepted supplied values are `deterministic`, `exact`, `read`, `self`, respectively |
| `@mssl` | `alias`, `module`, `source_version`, `digest` | none | SHA-256 digest is `sha256:` plus 64 lowercase hexadecimal digits; source version has two or three nonnegative decimal components |
| `@frame` | `id`, `parent`, `module` | `phase` | Parent is `ROOT` or a previously completed frame ID; frame ID is unique and cannot be `ROOT` |

Omitted optional keys are not inserted into the IR. Unit `version` is program metadata, not the source language version. Module source versions are parsed as metadata; parser acceptance does not verify compatibility between MSSL interpreter versions and module contents.

## 4. Lexical and structured-field contract

Each row has exactly eight nonempty cells separated by U+2502 `│`. Empty cells fail; `_` is the absence sentinel where the relevant field permits absence. Input packing uses U+203A `›` and permits zero, one or two nonempty operands. Empty packed operands, `_` inside a packed pair, repeated separators and more than two operands fail.

Identity-bearing symbols are ASCII segments separated by a dot. Each segment starts with a letter or underscore and continues with letters, digits, underscores or hyphens. The standalone `_` is reserved. These rules apply to unit IDs, frame IDs/parents/modules, MSSL aliases/modules, row IDs, lane annotations, outputs, inputs and control predecessors. Operator names and aliases are matched exactly and case-sensitively against the packaged registry. Lane names are descriptive annotations; the parser does not enforce a lane-to-face typing relation.

ARG and META are either `_` or semicolon-separated `key=value` fields. Keys start with an ASCII letter or underscore and continue with ASCII letters, digits, `_`, `-` or `.`. Duplicate keys fail in every directive and structured cell, even when both values are identical. Empty fields, missing equals signs, empty values, leading/trailing semicolons, mixtures of key-value fields and opaque text, and malformed quoting fail. There is no fallback from an unsuccessful structured parse to an opaque string.

Double-quoted values use JSON string escaping: for example `mapping="a;b=2 \"quoted\""`. A semicolon inside a quoted value is data. JSON escapes decode before further checks; decoded empty strings, controls, format controls, surrogates, U+2502, U+203A and Unicode line separators fail. U+2502 and U+203A cannot be smuggled through escaped text. Bare values cannot contain SP/TAB, apostrophes, double quotes or backslashes. The validator does not interpret text values as executable code or mathematical expressions.

META permits only `eff`, `scope` and `proof`. `proof` is retained as text and is not verified. The only accepted explicit `scope` is `self`; that annotation is not a runtime grant. `eff`, when supplied, must equal the operator catalog's effect exactly. Capabilities have no implicit hierarchy, so neither `commit→read` nor `derive→publish` nor any other substitution is accepted. Unit defaults do not replace operator-inferred effects. Omitting `eff` cannot turn an effectful operator into a read operation.

## 5. Operator parameter acceptance and implementation limits

The full operator catalog is recognized for descriptors, types-as-labels and default effects. Parameter contracts are implemented only as the following closed lexical key sets. Values remain strings. Recognition is not operator execution or complete type checking.

| Canonical operator | Accepted ARG keys |
|---|---|
| `SOURCE_BIND` | `media`, `profile` |
| `FIELD_DEFINE` | `shape`, `sample`, `axes`, `sparse` |
| `FIELD_POPULATE` | `mapping` |
| `FIELD_SLICE`, `FIELD_REGION` | `selector` |
| `PYRAMID_DEFINE` | `levels`, `downsample`, `spatial_axes` |
| `COUPLING_DEFINE` | `neighborhood`, `radius`, `representation` |
| `MSSL_EVAL` | `mode`, `lab_ids`, `coupling` |
| `ADMISSION_EVAL` | `policy`, `authorization` |
| `PROJECT` | `selector`, `output` |
| `EMIT_RECEIPT` | `content_bound`, `expected` |
| `SHARD` | `partition`, `count` |
| `ROOT_BUILD` | `hash` |
| `STATE_COMMIT` | `grant` |
| Every other registered operator | none; ARG must be `_` |

The table derives from the supplied example vocabulary, with `FIELD_REGION` sharing the selector vocabulary. It is deliberately incomplete. In particular, `CONST` is registered but has no implemented nonempty parameter contract. An ARG of `_` is permitted for any registered operator; parser acceptance therefore does not establish required argument presence. Shape rank, dimension positivity, sample type, axis compatibility, selector syntax, mapping semantics, coupling types, neighborhood definitions, module parameter types, effect scopes and full operator arities are outside this module's checks. They remain execution or specialized validation prerequisites. An accepted `authorization=absent` or `grant=external:required` is documentary data, never authorization.

## 6. Binding and dependency rules

Row IDs are unique unit-wide, including across frames. Output handles are immutable names and unique unit-wide. Outputs cannot shadow a declared MSSL alias or an external-input placeholder already consumed; a row cannot consume its own output. Non-control operators require a named output; control operators may use `_`. A named output under `source.*` can be produced only by `SOURCE_BIND`. Frame IDs, row IDs and output handles are distinct namespaces; frame parenthood does not replace row control edges.

Every CTRL predecessor must name a prior row; duplicate predecessors, self references, unknown names and forward references fail. Thus source order is a topological ordering of the checked control graph. The implementation represents each row's transitive ancestry as a bounded bitset, avoiding a recursive graph walk. For every consumed produced handle, the producing row must be a member of the consumer's CTRL ancestry. A merely earlier producer without a control path is insufficient. A referenced `coupling` ARG handle receives the same availability check, but its producer's result type is not validated.

MSSL aliases are unique preamble declarations. `MSSL_EVAL` and `ADMISSION_EVAL` require exactly two inputs: a declared alias followed by a data handle. A second module alias is not a data handle. Module aliases cannot appear in other operators except `VERIFY_MSSL`. The parser validates the digest token's syntax but does not read module files. Byte verification is a separate caller-selected `verify_mssl` operation; neither operation interprets MSSL.

### Reserved external-input convention

To preserve the twelve original examples, an unproduced input named `source.<symbol>` is accepted as a reserved external-input placeholder. This records an unresolved external requirement, not a successful binding. The parser's return object intentionally preserves the original IR shape and does not append `resolved` or `authorized` flags. Any execution environment must independently bind every consumed placeholder to immutable, typed, digest-identified data and fail if it cannot. Unresolved symbols outside this reserved namespace fail during static validation. A `SOURCE_BIND` row declaring a source handle is also a declaration only; its media/profile annotations do not prove the bytes exist or satisfy an adapter contract.

## 7. Canonical JSON and identity contract

`canonical_json_bytes` keeps the RUSSL/1.0 Python serialization profile: sort string keys, use compact separators, retain Unicode as UTF-8, and disallow NaN and infinities. Input must comprise plain dictionaries with string keys, plain lists, valid strings, finite Python floats, bounded Python integers, booleans and null. Cycles, unsupported containers/objects, invalid Unicode, excessive nesting and oversized output fail.

This is not RFC 8785/JCS. Python float spellings and negative zero are preserved; numbers are not normalized into a cross-language canonical mathematical form. Object keys are not NFC-normalized by the JSON helper. Consumers in other languages must reproduce this profile exactly or negotiate a separately versioned identity profile with migration evidence.

`strict_json_loads` accepts UTF-8 bytes or text and rejects duplicate keys at every object depth, including escape-equivalent keys such as `"a"` and `"\u0061"`; invalid syntax; extra trailing content; byte-order marks; invalid Unicode; `NaN`, `Infinity`, `-Infinity`; and exponent overflow such as `1e999`. It scans nesting outside JSON strings before recursive decoding, then validates the decoded object. JSON control characters expressed through valid string escapes are ordinary JSON data; RUSSL field validation imposes its additional control prohibition separately.

The identity equations remain:

```text
source_sha256 = SHA256(ASCII("RUSSL-SOURCE/1.0") || 0x00 || UTF8(canonical_source))
ir_id = "russir:sha256:" || SHA256(ASCII("RUSSIR/1.0") || 0x00 || canonical_json(IR_without_ir_id))
```

The canonical IR still includes frame rows, a flattened program array, source-line ordinals and the original directive records. `domain_hash` requires a nonempty ASCII domain without embedded NUL and a byte payload. SHA-256 equality proves byte equality subject to the hash assumption; it does not authenticate origin, correctness or authority.

## 8. Numeric coordinate helper

`phi(i,n,anchor=0.0)` implements `-1 + 2*i/(n-1)` for `n>1`, and the specified anchor for `n=1`. Indices and extents must be actual Python integers, excluding booleans, with `n≥1` and `0≤i<n`. The binary64 reference profile limits `n≤2^53`. The anchor is always validated, even when `n>1`: it must be an integer or float excluding booleans, must convert to a finite binary64 value, and must lie in `[-1,1]`.

Coordinates are approximate binary64 values. The extent limit prevents integers outside the reference conversion range; it does not guarantee unique floating coordinates at every index or correctly rounded exact rational results. Applications needing exact rational coordinates or stronger numerical guarantees require a separate implementation and explicit conformance evidence.

## 9. Resource policy

| Resource | Default bound |
|---|---:|
| Input and canonical source | 1,048,576 UTF-8 bytes |
| Physical line | 65,536 Unicode characters |
| Row cell | 16,384 Unicode characters |
| Identity symbol | 256 ASCII characters |
| Rows per unit | 10,000 |
| Completed frames per unit | 1,024 |
| MSSL binding declarations | 256 |
| Control predecessors per row / total | 128 / 100,000 |
| Fields per directive or ARG/META cell | 64 |
| JSON input / canonical JSON output | 4,194,304 bytes |
| JSON nesting / traversed value-node budget | 64 / 100,000 |
| Integer magnitude | fewer than 4,097 decimal digits |
| MSSL bytes read by one verification | 67,108,864 bytes |

`ReferenceLimits` is a frozen policy object with positive integer fields; `parse_russl` and `lower_russl` accept it through a keyword-only `limits` parameter. Invalid policy values fail. JSON decode budgets can be adjusted with `max_bytes` and `max_depth`; object validation still applies the module's global JSON size/node safeguards. Custom budgets are caller policy, not encoded language semantics or granted capabilities. Python process memory, host filesystem policy, interpreter isolation, input read limits before this API and wall-clock limits remain the caller's responsibility. MSSL verification reads 65,536-byte chunks, bounds total bytes and reports unavailable bytes without copying private paths into its diagnostic.

## 10. API and diagnostic contract

Existing public functions remain: `canonical_json_bytes`, `canonical_source`, `domain_hash`, `parse_kvs`, `parse_structured`, `parse_russl`, `lower_russl`, `phi` and `verify_mssl`. The required parse/lower return shape and verified-file boolean return are retained. `parse_kvs` and `parse_structured` are lexical helpers; only `parse_russl` applies directive/operator key sets, source budgets and binding checks. Helpers do not constitute a safe untrusted-input processing entry point by themselves.

New interfaces are `strict_json_loads`, `ReferenceLimits`, `DEFAULT_LIMITS` and `RUSSLValidationError`. The exception subclasses `ValueError` and carries `code`, `severity`, `cause_class`, optional `source_line` and optional `row_id`. Where a valid row ID has already been parsed, a subsequent failure records it. Messages describe structural causes without echoing source values or caller file paths. This is a local exception contract; it does not implement the full WP19 causal-chain, redaction audit and multi-error reporting model.

| Diagnostic | Implemented cause family |
|---|---|
| `RUSSL-E-PARSE-001` | header, directive order, unsupported reference annotations, incomplete source, invalid source Unicode/control policy |
| `RUSSL-E-PARSE-002` | columns/cells, structured syntax, unknown/duplicate keys, required fields, symbols and packed operands |
| `RUSSL-E-PARSE-003` | duplicate row/frame IDs or reserved frame identity |
| `RUSSL-E-OP-001` | operator is not registered |
| `RUSSL-E-DEP-001` | missing/forward/duplicate predecessor, frame parent or unavailable producer ancestry |
| `RUSSL-E-BIND-001` | unresolved input/output/coupling or output shadowing |
| `RUSSL-E-MSSL-001` | declaration/digest syntax, alias or invocation role |
| `RUSSL-E-MSSL-002` | unavailable module bytes or byte digest mismatch |
| `RUSSL-E-EFFECT-001` | effect substitution or unsupported scope/default effect |
| `RUSSL-E-STORAGE-001` | lexical storage-name guard |
| `RUSSL-E-CANON-001` | invalid JSON, identity input or noncanonical value domain |
| `RUSSL-E-FIELD-001` | coordinate helper domain, precision or anchor |
| `RUSSL-E-RESOURCE-001` | bounded input, container, record-count or verification-resource policy |

Error selection is first-failure validation order, not an exhaustive error inventory for one source. The exception wording can evolve while the documented cause code remains stable.

## 11. Verification and remaining proof obligations

Run the dependency-free regression suite from the corpus root with `python -m unittest discover -s tests -p test_reference_hardening.py -v`. The suite covers complete original IR identity preservation, original positive/negative vectors, directive ordering, column placement, closed keys, duplicate fields, all registered effect substitutions, all registered aliases, name shadowing, data/control ancestry, module operand roles, external-input boundaries, quoted and escaped payloads, resource boundaries, Unicode controls, strict JSON failures, coordinate failures and streamed MSSL byte verification.

Passing these tests establishes the specific static acceptance behavior above. It does not demonstrate MSSL interpretation, complete type checking, field construction, imaging conversion, runtime scheduling, cryptographic signatures, grant evaluation, nonce replay defense, commit atomicity, rollback correctness, CAS durability, replicated consensus, scientific mechanics correctness or production readiness. Those require independently implemented modules, threat-specific tests, numerical/experimental evidence and institutional decisions. The parser never consumes instructions embedded in source text as instructions to the host agent or operating system.
