# Verification, Coverage and Evidence Guide

## Scope

The offline verifier checks candidate package consistency, the documented structural reference profile, source-to-IR compatibility, bounded container binding, and adversarial regressions. It reports `full_conformance=false`. None of the 293 requirements is labeled fully verified. SCOPED_EVIDENCE identifies applicable check families; NOT_RUN identifies obligations without an executed requirement-specific test or accountable review.

A check's PASS means its declared observations matched its oracle for packaged inputs. It does not generalize to every implementation/input, runtime semantics, signatures, real data, platforms or empirical validity. The complete requirement text remains the review target. Tests sharing an implementation/oracle are useful regressions but weaker evidence than independent implementation comparison.

| Check | Observable | Limit |
|---|---|---|
| V01 | strict current JSON/JSONL parsing | historical content separately audited |
| V02 | exact specification-to-registry ID mapping | text consistency is not behavior correctness |
| V03 | 12 sources equal golden IR; 5 original bad sources rejected | external source placeholders remain unbound |
| V04 | schema keywords supported; selected samples validate | closed subset, not full Draft 2020-12 |
| V05 | four MSSL digests and image digest agree | no module evaluation or scientific validation |
| V06 | coordinate results match vectors | not physical calibration |
| V07 | canonical source/vector digests agree | corpus JSON differs from RFC8785 |
| V08 | bounded container, cross-bindings and exact rebuild | no tuple execution |
| V09 | adversarial/compatibility unittest suite | regression sampling, not formal proof |
| V10 | catalog and aliases agree with tooling | registered operators are not implemented runtime semantics |
| V11 | 28 review-pending records bind current specs | no independent review/ratification |
| V12 | local Markdown links resolve | remote sources can change |
| V13 | active tree excludes symlinks/caches/old destructive builder | not production penetration testing |
| V14 | 19 new source digests/review coverage and exact shape/index fixtures | no empirical research result implied |

## Evidence lifecycle

From the corpus, run `python -B tooling/verify_corpus.py` and `python -B tooling/verify_corpus.py --integrity`. Exit zero accompanies scoped PASS. Explicit conditions rather than Python assertions enforce release gates. `--write-report` changes evidence and can break a seal. The builder regenerates candidate records, coverage, reading edition, report, manifest, receipt, checksums, integrity report and sorted ZIP; a failing verification stops sealing. No network installation is needed.

The manifest excludes itself, build receipt, checksums and detached integrity report. Everything else, including the scoped report, is content-bound. SHA256SUMS additionally covers the manifest/build receipt, excluding only itself and detached integrity. The detached report is unsigned. Hashes protect byte integrity under SHA-256 assumptions; authenticity needs a separately governed signature profile.

## Schema-engine contract

`schema_subset.py` supports type, enum/const, required/properties/additionalProperties, local `$defs` references, prefixItems/items/cardinality/uniqueness, length/pattern/bounds and allOf/anyOf/oneOf/not. Unsupported schema keywords and remote references fail. Annotation keywords are allowlisted. This is not a JSON Schema meta-schema validator or an implementation of formats, dynamic references, unevaluated properties, dependent schemas, patternProperties or vocabulary negotiation. Additions require tests and a compatibility decision.

Strict JSON loading rejects duplicate object keys and nonfinite/overflow literals. Structural schemas reject numeric digests, short/reordered axes, invalid shapes, unknown known-object fields, duplicate effects and invalid enumerations. Date validity, grant internals, cryptographic signatures and runtime context still require semantic/trust validation. Opaque provenance or operator parameters are not automatically security decisions.

## Advancing requirements

Assign every partial/unexecuted obligation an owner, fixtures, preconditions, independent acceptance oracle, runnable command or named review procedure, expected positive/negative results, versions and retained evidence. Record scope and defeaters. Upgrade status only after every clause is checked and required accountable review occurs. Institutional ratification remains separate from test execution.

The schema engine separately propagates resource/schema errors through negation/disjunction, rejects recursive definitions and malformed keyword declarations, and bounds node/comparison work. JSON/JSONL/container ingress is bounded and hashes stream. Tests write and remove controlled temporary fixture folders in the current writable directory; maintained corpus artifacts are unchanged by default verification.
