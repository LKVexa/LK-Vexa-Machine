# Glossary and Distinctions

| Term | Candidate-corpus meaning |
|---|---|
| RUSSL | Eight-column RUSSL/1.0 source; a program description does not execute itself. |
| RUSSIR | Intermediate rows, catalog attributes, bindings and source identity. |
| MSSL | Preserved mechanics/policy source bound by raw SHA-256; evaluation/science remain separate. |
| RUSS tuple | Eleven ordered components I,L,G,S,C,M,A,P,F,E,X. |
| Penteract/P5 | Normalized five-dimensional base; not physical calibration. |
| S³ | Unit three-sphere in R⁴, scaled as a research fiber. |
| Sparse absence | Unrepresented location, distinct from zero, unknown, masked and missing. |
| Candidate root | Immutable derived state before independently authorized head update. |
| Admission | Mechanics/policy disposition, distinct from capability authorization. |
| Grant | Authenticated context-bound permission; schema validity is insufficient. |
| Effect | Catalog consequence: read, derive, project, write evidence/state, commit, replicate, publish. |
| Projection | Derived selector/transform/reduction; local exactness can still lose global information. |
| Byte identity | Equality of defined serializations under the digest construction. |
| Semantic equivalence | Equality of declared observable values/contracts, independent of encoding. |
| Source identity | Digest of canonical source including retained comments. |
| Canonical JSON | Corpus Python sorted-key compact representation, distinct from RFC8785/JCS. |
| Domain separation | ASCII domain plus NUL prefix before hashing to separate artifact classes. |
| CAS | Content-addressed fetch or, explicitly, compare-and-swap; context must disambiguate. |
| SCOPED_EVIDENCE | Applicable partial evidence, not every clause of a requirement. |
| NOT_RUN | No requirement-specific execution or accountable review is claimed. |
| Candidate | Proposed specification/policy awaiting identified evidence and review. |
| Assurance case | Claims, arguments, evidence and defeaters with explicit scope. |
| Preregistration | Hypotheses, methods, exclusions and outcomes recorded before confirmatory observations. |
| Lineage | Historical sources, not automatically current normative authority. |
