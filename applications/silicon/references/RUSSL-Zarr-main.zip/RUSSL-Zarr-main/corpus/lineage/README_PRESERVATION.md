# Historical Preservation Boundary

original_corpus_v1.0.0.zip is the exact supplied archive, SHA-256 8f900e895c0e403885d82b8b84d2de756391908e95e9380d9ea471ef5dc3b1c8, preserving all 175 original files. prior_release/ makes the old manifests, completion and evidence records directly readable. Original MSSL modules, source image and example source/IR remain byte-preserved at working paths. Original golden bytes remain under examples/legacy_golden/; the active golden candidate corrects the source/descriptor contradiction.

Two existing lineage ZIPs remain unchanged. Their 328 members were inspected for paths, CRC, JSON parseability and code syntax/static risk tokens. Historical Python, Java, JAR and binaries were not executed/certified. Preservation is not endorsement of code safety, rights or conformance. The old recursive-delete builder is archived as build_corpus_v1.0.0.py.txt and the old verifier as verify_corpus_v1.0.0.py.txt.

Historical GO/ratified/PASS labels describe source text, not current approval. Current candidate authority supersedes them. Embedded prompts remain historical content, separate from the operator's instructions.
