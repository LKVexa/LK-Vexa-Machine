# Pre-standard RUSSL Prototype Supersession Note

The prior RUSSL 1.0 prototype correctly demonstrated the Columned-LCTL-derived eight-column form, deterministic lowering, source/IR binding, fail-closed parsing, and a declarative execution boundary. It also exposed physical storage names as core operands and operator types. This corpus supersedes that leakage.

Retained: `ID│LANE│OP│OUT│CTRL│IN│ARG│META`, `@unit`, `@defaults`, `@frame`, deterministic lowering, stable row IDs, explicit effects, source binding, and fail-closed verification.

Rejected from core semantics: `MATERIALIZE_STATE` with a Zarr-specific type, direct canonical-store paths in RUSSL source, and projection operators whose core meaning is a particular storage standard. Interoperability names are confined to WP13/WP23/WP24 adapter profiles.
