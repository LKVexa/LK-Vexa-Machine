# RUSSL Research & Institutional Corpus v1.0.0
## Master Corpus Construction Prompt and Workflow

### Mission
Create a comprehensive, institutional, research-grade RUSSL corpus covering all 28 normative and supporting work packages in this repository. The resulting corpus must be internally consistent, testable, versioned, reproducible, fail-closed, and explicit about the boundary between normative language engineering and experimental research claims.

### Canonical architecture
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Source authority hierarchy
1. Ratified RUSSL corpus specifications produced by this workflow.
2. Versioned RUSSL/RUSS machine-readable schemas and conformance vectors.
3. Bound MSSL modules and their declared digests/versions.
4. Columned-LCTL corpus only as language-lineage and design input, never as silent normative authority over RUSSL.
5. Storage formats/adapters only as profile-level interoperability mechanisms.

### Global construction rules
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

### Required document anatomy
Every normative specification MUST contain:
1. Status and version.
2. Scope and non-goals.
3. Normative terminology.
4. Definitions and notation.
5. Normative requirements.
6. Algorithms or state machines where applicable.
7. Security and failure considerations.
8. Canonical examples.
9. Negative examples.
10. Conformance requirements.
11. Cross-specification dependencies.
12. Change history.

### Common workflow gates
- **G0 — Inputs established:** required upstream specifications and source authorities are identified.
- **G1 — Scope frozen:** purpose, exclusions, terminology, and architecture boundary are explicit.
- **G2 — Normative model complete:** requirements and definitions are internally complete.
- **G3 — Formalization complete:** grammar, algorithms, types, schemas, equations, or state machines exist where applicable.
- **G4 — Examples complete:** canonical positive examples are included.
- **G5 — Negative/failure coverage complete:** invalid, ambiguous, unauthorized, corrupted, or non-deterministic cases are covered.
- **G6 — Cross-document consistency:** identifiers, terms, versions, and dependencies match the rest of the corpus.
- **G7 — Security/research boundary review:** security claims and experimental claims are properly scoped.
- **G8 — Conformance traceability:** every testable MUST has a test/validator mapping.
- **G9 — Reproducibility/release:** canonicalization, version, digest, changelog, and release manifest are produced.
A work package receives **GO** only after all applicable gates pass. Otherwise record **NO_GO** with explicit blockers and remediation.

### Serialization
The canonical build order is WP01 → WP02 → … → WP28. A later package MAY be drafted early, but it MUST NOT be ratified until its declared dependencies have reached GO. Every ratified package increments the corpus manifest and records its content digest.

### Final corpus release
The final release MUST include:
- the 28 completed work-package specifications;
- a corpus index and dependency graph;
- a normative/informative document registry;
- machine-readable schemas and registries;
- the normative test corpus;
- reference programs;
- conformance results;
- provenance and reproducibility receipts;
- a release manifest with content digests;
- an unresolved-issues register.


---

# RUSSL Corpus Serialization Plan v1.0.0

The canonical release pipeline is sequential from WP01 through WP28. Drafting can overlap, but ratification cannot violate dependencies.

## Phase A — Language and formal foundation
WP01, WP02, WP03, WP04, WP05, WP06, WP17

## Phase B — Executable and assurance core
WP07, WP08, WP09, WP10, WP11, WP18, WP19

## Phase C — Distributed field and interoperability
WP12, WP13, WP14, WP15, WP16, WP23, WP24

## Phase D — Conformance, research, governance, and publication
WP20, WP21, WP22, WP25, WP26, WP27, WP28

A package is ratifiable only when every prerequisite named in its own file is at GO.


---


---

# WP01 — RUSSL Language Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define the normative surface language, syntax, grammar, directives, column model, namespaces, module declarations, canonical source form, and version negotiation.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP01 — RUSSL Language Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Columned-LCTL corpus as language-lineage input
- Current RUSSL prototype syntax
- RUSSL architectural charter

### Mandatory deliverables
- Normative lexical grammar and tokenization rules
- Eight-column instruction grammar and directive grammar
- Namespace/module/version rules
- Canonical source normalization rules
- ABNF or EBNF grammar
- Positive and negative syntax examples

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP01-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP01-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP01`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP02 — RUSSL Semantic Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define formal meaning for valid RUSSL programs, including evaluation order, dependency resolution, state transitions, observability, determinism, and failure behavior.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP02 — RUSSL Semantic Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- RUSSL Language Specification
- RUSSL architectural charter
- MSSL binding requirements

### Mandatory deliverables
- Semantic domains
- Operational semantics
- Dependency graph semantics
- State-transition rules
- Failure and halt semantics
- Normative examples and semantic traces

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP02-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP02-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP02`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP03 — RUSSL Type System
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Create the static and runtime type system for scalars, vectors, tensors, fields, Penteract coordinates, MSSL modules, evidence, capabilities, and tuple handles.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP03 — RUSSL Type System**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language Specification
- Semantic Specification
- Penteract field requirements

### Mandatory deliverables
- Type grammar
- Static typing rules
- Dimension/unit rules
- Effect and capability typing hooks
- Type inference limits
- Type-error catalog and test vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP03-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP03-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP03`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP04 — Penteract Field Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Specify the canonical five-dimensional sample field that replaces a TIFF-like raster as the native RUSS population space while remaining storage-independent.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP04 — Penteract Field Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Type System
- Imaging requirements
- P5×S³ research mechanics as informative/mechanics input

### Mandatory deliverables
- Formal field model F: D1×…×D5→S
- Normalized coordinate mapping to [-1,1]^5
- Dense/sparse realization rules
- Neighborhoods, regions, tiling/chunk abstraction
- Multiresolution Penteract pyramids
- 2D/3D/4D/5D slicing and population rules

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP04-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP04-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP04`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP05 — RUSSL–MSSL Binding Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define how RUSSL discovers, versions, authenticates, imports, parameterizes, invokes, and binds MSSL mechanics and policy modules.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP05 — RUSSL–MSSL Binding Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language Specification
- Semantic Specification
- Authoritative MSSL module family

### Mandatory deliverables
- MSSL module reference syntax
- Digest/version binding
- Parameter/result binding
- Mechanics and policy invocation contract
- Module capability boundaries
- Binding failure rules and conformance vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP05-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP05-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP05`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP06 — RUSSL Intermediate Representation
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define canonical RUSSIR as the deterministic, type-resolved, dependency-explicit lowering target for RUSSL source.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP06 — RUSSL Intermediate Representation**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language Specification
- Semantic Specification
- Type System
- MSSL Binding Specification

### Mandatory deliverables
- Canonical IR schema
- Normalized instruction graph
- Resolved identifiers and module digests
- Source→IR lowering algorithm
- IR canonicalization and hashing
- Golden source/IR vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP06-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP06-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP06`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP07 — RUSS Tuple ABI
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Specify the exact ABI mapping from canonical RUSSIR and bound MSSL modules into a versioned .russ tuple-executable.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP07 — RUSS Tuple ABI**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- RUSSIR Specification
- Penteract Field Specification
- MSSL Binding Specification

### Mandatory deliverables
- Tuple component registry
- Language/geometry/state/mechanics/admission/projection/fabric/evidence/execution sections
- ABI version rules
- Tuple identity construction
- Compatibility matrix
- Golden tuple manifests

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP07-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP07-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP07`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP08 — RUSSL Execution Model
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define the reference execution lifecycle from verification through state materialization, mechanics evaluation, admission, evidence emission, rollback, and replay.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP08 — RUSSL Execution Model**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- RUSS Tuple ABI
- Semantic Specification
- Capability/Effect System

### Mandatory deliverables
- Execution phases
- Reference state machine
- Deterministic replay rules
- Resource accounting hooks
- Rollback/checkpoint semantics
- Execution receipt requirements

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP08-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP08-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP08`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP09 — RUSSL Capability and Effect System
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define least-privilege capabilities and effects for read, derive, project, evidence write, state write, commit, replicate, and publish operations.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP09 — RUSSL Capability and Effect System**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Type System
- Execution Model

### Mandatory deliverables
- Capability vocabulary
- Effect declarations
- Scope attenuation
- Grant binding fields
- Static/dynamic enforcement rules
- Unauthorized-effect negative tests

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP09-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP09-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP09`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP10 — RUSSL Security Model
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Establish the security model for source, module, tuple, actor, reviewer, grant, evidence, rollback, replay, supply-chain, and distributed execution integrity.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP10 — RUSSL Security Model**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Capability/Effect System
- RUSS Tuple ABI
- Execution Model

### Mandatory deliverables
- Threat model
- Trust boundaries
- Identity/authentication requirements
- Digest/signature requirements
- Replay and nonce controls
- Immutable evidence and rollback binding
- Security conformance profile

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP10-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP10-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP10`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP11 — RUSSL Admission Model
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Formalize the difference between mathematical admissibility, policy evaluation, authorization, review, commit permission, and publication.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP11 — RUSSL Admission Model**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- MSSL Binding Specification
- Security Model
- Execution Model

### Mandatory deliverables
- Admission state machine
- OBSERVE/REVIEW/ADMIT/COMMIT semantics
- MSSL predicate binding
- Authorization separation
- Evidence requirements
- Fail-closed admission tests

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP11-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP11-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP11`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP12 — RUSSL Distributed-Fabric Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define distributed storage/execution behavior for content-addressed RUSS objects and Penteract field materialization without tying RUSSL semantics to one network.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP12 — RUSSL Distributed-Fabric Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- RUSS Tuple ABI
- Security Model
- Penteract Field Specification

### Mandatory deliverables
- Content-addressing model
- Merkle/DAG object relationships
- Replication and retrieval
- Deduplication
- Partial region retrieval
- Consistency and integrity rules
- Fabric conformance tests

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP12-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP12-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP12`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP13 — RUSSL Storage Independence Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define the abstraction boundary between RUSSL/RUSS semantics and physical storage adapters.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP13 — RUSSL Storage Independence Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Penteract Field Specification
- Distributed-Fabric Specification

### Mandatory deliverables
- Storage adapter interface
- Canonical-vs-derived data rules
- Backend capability matrix
- Zarr/OME-Zarr adapter profile
- TIFF/COG adapter profile
- CAS/filesystem/object-store profiles

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP13-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP13-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP13`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP14 — RUSSL Imaging Profile
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define a professional imaging profile for pixels/samples, channels, color, bit depth, masks, metadata, regions, pyramids, and TIFF-like behavior in the Penteract field.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP14 — RUSSL Imaging Profile**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Penteract Field Specification
- Type System
- Storage Independence Specification

### Mandatory deliverables
- Pixel/sample model
- Color/channel metadata
- Bit-depth and numeric rules
- Pyramid and tile semantics
- Masks/regions
- Metadata and profile conformance vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP14-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP14-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP14`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP15 — RUSSL Scientific/Volumetric Profile
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define scientific multidimensional imaging, volumetric coordinates, physical units, calibration, TCZYX interoperability, and native 5D Penteract population.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP15 — RUSSL Scientific/Volumetric Profile**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Penteract Field Specification
- Imaging Profile
- Type System

### Mandatory deliverables
- Axis and unit model
- Coordinate transformations
- 3D/4D/5D volume semantics
- Calibration metadata
- OME-compatible mappings
- Scientific reference datasets and tests

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP15-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP15-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP15`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP16 — RUSSL Projection Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Specify deterministic projections and slices from native Penteract/P5×S³ state to lower-dimensional views and interoperable outputs.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP16 — RUSSL Projection Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Penteract Field Specification
- Imaging Profile
- Scientific/Volumetric Profile
- MSSL Binding Specification

### Mandatory deliverables
- Projection function model
- 2D/3D/4D/5D projection rules
- P5×S³ derived projection profile
- Determinism requirements
- Projection provenance
- Golden projection vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP16-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP16-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP16`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP17 — Canonicalization and Cryptographic Identity
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define canonical representation and cryptographic identity rules for RUSSL source, RUSSIR, MSSL bindings, tuple manifests, field objects, evidence, and roots.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP17 — Canonicalization and Cryptographic Identity**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language Specification
- RUSSIR Specification
- RUSS Tuple ABI

### Mandatory deliverables
- Unicode/whitespace canonicalization
- Numeric/float canonicalization
- Map/list ordering
- Canonical JSON/CBOR rules where used
- Digest domains and identity URIs
- Cross-version identity rules
- Hash test vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP17-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP17-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP17`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP18 — Reproducibility Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define deterministic build, execution, dependency, environment, replay, and evidence requirements for reproducible RUSSL/RUSS research and production artifacts.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP18 — Reproducibility Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Canonicalization Specification
- Execution Model
- MSSL Binding Specification

### Mandatory deliverables
- Build manifest
- Compiler/runtime identity
- Dependency lock requirements
- Deterministic replay envelope
- Environment constraints
- Reproducibility receipt
- Rebuild test suite

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP18-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP18-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP18`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP19 — RUSSL Error and Diagnostic Standard
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define stable machine-readable and human-readable diagnostics across parsing, typing, semantics, MSSL binding, execution, integrity, admission, and authorization.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP19 — RUSSL Error and Diagnostic Standard**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language Specification
- Type System
- Execution Model
- Admission Model

### Mandatory deliverables
- Error namespace
- Stable codes
- Severity model
- Source locations
- Causal chains
- Redaction/security rules
- Diagnostic conformance vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP19-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP19-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP19`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP20 — Conformance Standard
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Create the normative conformance framework for parsers, compilers, runtimes, MSSL bindings, RUSS output, distributed fabric, security, and reproducibility.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP20 — Conformance Standard**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- All normative specifications 1–19 as available

### Mandatory deliverables
- Conformance classes
- Required/optional features
- Test declaration format
- Certification result schema
- Version compatibility rules
- GO/NO_GO criteria
- Conformance report template

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP20-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP20-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP20`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP21 — Normative Test Corpus
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Build a comprehensive positive/negative and golden-vector corpus that makes the specifications executable and falsifiable.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP21 — Normative Test Corpus**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Conformance Standard
- All normative specs

### Mandatory deliverables
- Valid/invalid syntax cases
- Semantic/type vectors
- Penteract address vectors
- MSSL binding vectors
- Admission/security negative tests
- Canonicalization/hash vectors
- Golden RUSSIR and .russ artifacts

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP21-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP21-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP21`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP22 — Reference Programs
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Create small-to-large canonical RUSSL programs demonstrating the language and validating end-to-end behavior.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP22 — Reference Programs**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language/Semantic/Type specs
- MSSL Binding
- Penteract Field
- Execution Model

### Mandatory deliverables
- Single-sample program
- 2D image program
- RGB/tiled/pyramid programs
- 3D voxel and 5D field programs
- Sparse coupled field
- MSSL mechanics/admission example
- Distributed publication/reconstruction examples

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP22-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP22-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP22`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP23 — TIFF→RUSS Migration Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define deterministic, loss-aware migration from TIFF/BigTIFF/COG structures into the RUSS Penteract field and back where reversible.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP23 — TIFF→RUSS Migration Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Imaging Profile
- Penteract Field Specification
- Storage Independence Specification

### Mandatory deliverables
- IFD/tag mapping
- Strips/tiles/pyramids
- ICC/EXIF/XMP handling
- BigTIFF considerations
- Sample-preservation rules
- Penteract placement mapping
- Round-trip classification and tests

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP23-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP23-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP23`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP24 — OME-Zarr→RUSS Interoperability Specification
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define interoperability mappings between OME-Zarr/NGFF-style multidimensional datasets and RUSS without making OME-Zarr the canonical RUSSL data model.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP24 — OME-Zarr→RUSS Interoperability Specification**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Scientific/Volumetric Profile
- Storage Independence Specification
- Projection Specification

### Mandatory deliverables
- Axis mapping
- Multiscale mapping
- Chunk and metadata mapping
- Labels/coordinate transforms
- Reversible vs lossy mapping classification
- Adapter requirements
- Interoperability test vectors

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP24-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP24-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP24`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP25 — Language Governance
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Define institutional governance for specification authority, versions, RFCs, registries, experimental extensions, deprecation, compatibility, errata, and security advisories.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP25 — Language Governance**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- All prior specifications as governance inputs

### Mandatory deliverables
- Governance charter
- RFC lifecycle
- Extension registry policy
- Versioning/deprecation rules
- Errata process
- Security advisory process
- Release authority matrix

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP25-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP25-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP25`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP26 — Research Foundation
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Separate normative language engineering from experimental theory and create a reproducible research framework for Penteract/P5×S³ mechanics and related hypotheses.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP26 — Research Foundation**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Penteract Field Specification
- MSSL Binding Specification
- Research equations and MSSL corpus

### Mandatory deliverables
- Mathematical glossary
- Assumptions/invariants
- Hypothesis registry
- Reference algorithms
- Experiment protocol
- Evidence grading
- Citation/bibliography policy
- Reproducibility requirements

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP26-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP26-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP26`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP27 — Institutional Documentation
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Create the assurance, architecture, provenance, release, interoperability, archival, safety, and change-control documentation expected for institutional adoption.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP27 — Institutional Documentation**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Security Model
- Governance
- Conformance
- Research Foundation

### Mandatory deliverables
- Architecture decision records
- Threat model and assurance case
- Safety/limitations statement
- Interoperability policy
- Change-control and release policy
- Provenance policy
- Long-term archival policy

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP27-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP27-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP27`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.


---

# WP28 — Machine-Readable Schemas
Version: 1.0.0  
Status: Construction Prompt / Workflow  
Corpus: RUSSL Research & Institutional Corpus

## Objective
Publish authoritative schemas and registries enabling automated validation of RUSSL/RUSS artifacts and corpus outputs.

## Dedicated construction prompt
You are the lead specification editor, formal-methods reviewer, language engineer, security reviewer, and research reproducibility editor for **WP28 — Machine-Readable Schemas**.

Produce an institutional-quality specification package that fulfills the objective above and integrates cleanly into the RUSSL corpus.

### Architecture constraint
RUSSL → MSSL semantic/mechanics modules → RUSS tuple-executable → Penteract field → distributed fabric.
Storage implementations and projections (including Zarr/OME-Zarr, TIFF/BigTIFF, COG, CAS, object stores, and filesystem layouts) are subordinate adapters/profiles. They MUST NOT become first-class RUSSL semantic dependencies unless a profile explicitly declares them.
The canonical Penteract field is storage-independent and is conceptually modeled as F: D1×D2×D3×D4×D5 → S with normalized coordinate mappings into [-1,1]^5.


### Inputs
- Language Specification
- RUSSIR
- RUSS Tuple ABI
- Conformance Standard
- Governance

### Mandatory deliverables
- RUSSL grammar artifact
- RUSSIR schema
- Tuple manifest schema
- MSSL binding schema
- Evidence/execution receipt schemas
- Conformance-result schema
- Extension registry schema
- Schema test suite

### Global rules inherited from the master corpus
- Use normative terms MUST, MUST NOT, SHOULD, SHOULD NOT, and MAY consistently; distinguish normative requirements from informative explanation.
- Preserve the architecture boundary: RUSSL orchestrates and binds MSSL; MSSL defines mechanics/policy; RUSS carries tuple-execution; storage backends remain subordinate.
- Do not make .zarr, .ome.zarr, TIFF, COG, filesystem paths, or a specific object store part of core RUSSL semantics.
- Bind the authoritative MSSL module family explicitly: master_coupled_mechanics.mssl, lab_stack.mssl, product_metrics.mssl, and final_admission.mssl, while allowing future versioned module registries.
- Keep mathematical admissibility separate from cryptographic authorization, human/organizational approval, and distributed commit authority.
- Mark hypotheses, experimental mechanics, empirical claims, and proposed physical interpretations as research or informative material unless formally elevated to a normative profile.
- Require deterministic canonicalization, explicit versioning, stable identifiers, provenance, reproducible test vectors, and content digests for normative machine-readable artifacts.
- Fail closed on unresolved references, type ambiguity, missing required digests, incompatible versions, unauthorized effects, or non-deterministic canonicalization.
- Every normative requirement must be traceable to at least one conformance test, validation rule, or declared rationale for why executable testing is not applicable.
- Do not manufacture external attestations, independent authorization, production approval, or empirical validation. Record these as absent/pending when not supplied.

## Workflow

### Step 1 — Establish authority and dependency state
Identify the exact upstream documents, source files, schemas, MSSL modules, and prior decisions this package depends on. Record versions and digests when available. If a required normative dependency is unresolved, continue only as a draft and mark ratification blocked.

### Step 2 — Freeze scope and terminology
Write the scope, non-goals, definitions, notation, and architecture-boundary statement. Eliminate ambiguous terminology and identify any term requiring registration in the corpus glossary.

### Step 3 — Build the normative model
Translate the objective into explicit normative requirements. Number requirements using `WP28-REQ-####`. Separate MUST-level behavior from recommendations and informative rationale.

### Step 4 — Formalize executable meaning
Where applicable, provide grammar, typing judgments, state machines, pseudocode, equations, canonical serialization rules, schemas, or validation algorithms. Every formal element must have a stable identifier.

### Step 5 — Construct canonical examples
Create minimal, representative, boundary, and end-to-end examples. Examples must use RUSSL/MSSL/RUSS abstractions correctly and must not leak a physical storage backend into core language semantics.

### Step 6 — Construct negative and adversarial cases
Cover malformed syntax, invalid types, unresolved MSSL bindings, digest mismatch, version mismatch, unauthorized effects, replay, corruption, ambiguous canonicalization, non-determinism, and any package-specific failure cases.

### Step 7 — Security, governance, and research review
State the trust boundary, fail-closed behavior, and any security-sensitive assumptions. Mark all experimental or empirical claims as research/informative unless supported by an approved normative profile.

### Step 8 — Conformance mapping
For every testable MUST, map the requirement to one or more tests using `WP28-TEST-####`. Where direct testing is impossible, specify a reviewable validation procedure and rationale.

### Step 9 — Cross-corpus consistency review
Check terminology, identifiers, module names, tuple fields, error codes, capability names, coordinate notation, version rules, and references against all upstream packages. No duplicated term may have conflicting meanings.

### Step 10 — Reproducibility and release preparation
Canonicalize the document and machine-readable outputs, compute content digests, update the corpus manifest, add a change record, and produce a reproducibility note identifying the exact inputs used.

## Acceptance gates
- G0 Inputs established
- G1 Scope frozen
- G2 Normative model complete
- G3 Formalization complete
- G4 Examples complete
- G5 Negative/failure coverage complete
- G6 Cross-document consistency complete
- G7 Security/research boundary review complete
- G8 Conformance traceability complete
- G9 Reproducibility/release metadata complete

## Required completion record
Produce a machine-readable and human-readable completion record containing:
- work_package: `WP28`
- version
- status: `GO` or `NO_GO`
- satisfied_gates
- blocked_gates
- normative_requirement_count
- test_count
- unresolved_issues
- input_versions_and_digests
- output_files_and_digests
- reviewer_roles_required
- next_work_package

A `GO` decision means the package is internally complete enough for its downstream dependents. It does **not** claim external certification, independent validation, production authorization, or empirical truth unless those artifacts are actually supplied.
