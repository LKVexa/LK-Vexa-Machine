# RUSSL Governance Charter

**Corpus:** 2.0.0. **Language:** RUSSL/1.0. **Status:** proposed charter; adoption and appointments are not supplied.

## Authority

This defines review for language, implementation, research and releases. It establishes no existing committee or external endorsement. Legacy internal GO and named MSSL authority strings are neither votes nor appointments. Actual decisions identify body/persons/roles, scope, date, conflicts, evidence and effective version.

Requirement terms in adopted requirements use [RFC 2119, March 1997](https://www.rfc-editor.org/rfc/rfc2119.html) and the uppercase clarification [RFC 8174, May 2017](https://www.rfc-editor.org/rfc/rfc8174.html) when capitalized (accessed 2026-10-09). This does not make RUSSL an IETF standard.

## Proposed roles

| Role | Responsibilities | Safeguard |
|---|---|---|
| Language editor | Grammar/semantics, IDs, ABI, compatibility | Cannot alone accept own proposal |
| Implementation reviewer | Behavior, vectors, oracle quality | Code and oracle reviewed separately |
| Security reviewer | Effects/trust, integrity, resources, adverse inputs | Explicit objection disposition |
| Research/provenance reviewer | Custody, hypotheses, assumptions, experiments/grade | No empirical claim accepted solely by author |
| Interoperability reviewer | Standard pins, mappings/losses, external readers/writers | Actual external evidence required |
| Release custodian | Inventory, receipts, archive/notices | Independent final-byte check |
| Institutional sponsor | Approved use, rights/privacy audience, operating authority | Deployment distinct from admission |

Multiple roles held by one person reduce independence and are disclosed; they do not create independent votes.

## Proposed quorum

Adoption appoints at least three distinct voting reviewers. Ordinary normative proposals require three participating reviewers, at least two affirmative votes, language/implementation and security coverage plus research/provenance where relevant, and disposition of every substantive objection. High-impact identity, trust, effect or scientific-status changes require all three affirmative votes and relevant specialist concurrence. Ties/unresolved safety or authority objections yield HOLD; missing quorum yields CANDIDATE.

This is a proposed future quorum, not completed review. Invented names, signatures or retroactive approvals are prohibited. External certification requires the actual body's process.

## Lifecycle

`DRAFT → REVIEW → PROVISIONAL → RATIFIED`, with HOLD, REJECTED, WITHDRAWN and SUPERSEDED recorded outcomes. Provisional is bounded review status, never permission for effects. Ratified needs a real decision record. New contrary evidence can reopen a decision; retain the original.

Use the change-control dossier. Archive deltas, risks, dissent, evidence, migration and affected release identity. Appeals identify new evidence/procedural defects and receive separate review where available.

## Extensions and research

Extensions use namespace, scope, compatibility and rejection behavior; never silently redefine operators/coordinates. Research elevation needs a complete algorithm/domain/units, appropriate evidence, independent review and migration. Normative software use still does not prove a physical or economic interpretation.

## Adoption record

Supply appointments, conflicts/quorum policy, rights/access decisions, actual signer/trust policy, custody, incident owner and review cadence. Until then the package remains an institutional candidate. Corpus 2.0.0 does not claim completed adoption.
