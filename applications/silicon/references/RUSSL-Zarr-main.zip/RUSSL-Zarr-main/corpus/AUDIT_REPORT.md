# End-to-End Corpus Audit — 2026-10-09

## Conclusion and disposition

The supplied package is byte-consistent and contains a useful architecture/specification scaffold. Its original completion/conformance claims exceed the supporting executable evidence, and its parser, schema and builder controls contain concrete defects. This audit applies structural hardening, expands every work-package specification and institutional/research support document, preserves original evidence, and produces a versioned candidate with transparent residual obligations. Disposition: **CANDIDATE_REVIEW_REQUIRED; scoped offline verification can PASS; full conformance and institutional approval are not established.**

## Scope, intake and method

The attached `RUSSL_Research_Institutional_Corpus_v1.0.0.zip` has SHA-256 `8f900e895c0e403885d82b8b84d2de756391908e95e9380d9ea471ef5dc3b1c8`. Intake read all 175 outer members (3,428,467 uncompressed bytes), checked CRC readability, bounded size/count, duplicate/case-fold paths, traversal/drive syntax and symlink metadata before extraction. Two nested lineage ZIPs contain another 328 members; both were read and inspected without executing their historical Python/Java/JAR code. An exact original ZIP is retained in the new corpus.

The audit covers package integrity, metadata, all 28 specifications, 293 requirement/test mappings, 9 schemas, 12 source/IR programs, 4 MSSL modules, the master-law source image, golden RUSS container, positive/negative vectors, active tool source, lineage authority and institutional/research/interoperability claims. Methods include file/digest comparison, text/AST/static code review, targeted original-parser mutation experiments, closed schema checks, bounded container checks, executable regression testing and dated official-source research. It is an artifact/software/design audit; no production service, real institutional identity, private laboratory source, scientific dataset or live distributed deployment was supplied.

Original manifest verification checked 171 content entries with zero mismatches. Original SHA256SUMS checked 174 entries with zero mismatches. All 28 original completion output hashes agree with their files. These correct hashes establish preservation consistency, not the correctness of the assertions inside those files.

The original verifier could not run unchanged in the observed clean bundled Python environment because `jsonschema` was absent and its dependency was undeclared. Its source and recorded 15 aggregate check results were reviewed; the historical recorded GO was not reclassified as a newly reproduced whole-suite result. Targeted controls and all candidate tooling were executed separately. The new verifier uses only the standard library and has an explicit supported-schema subset.

## Findings and applied remediation

Severity is qualitative relative to use of this candidate tooling, not a deployment vulnerability score. High means the issue can misstate authority or invalidate a safety boundary if treated as authoritative. Medium means ambiguity, inadequate verification or reproducibility. No exploit of a production system is alleged.

| ID | Severity | Finding and evidence | Applied disposition |
|---|---|---|---|
| A01 | High | 293 test registrations contain only two unique generic procedures; 70 are labeled executable without fixture/command/oracle results per requirement | preserve IDs; rewrite methods/oracles; record partial evidence/NOT_RUN; full conformance false |
| A02 | High | 28 records assert GO/G0–G9 without identifiable review signatures or actual review decisions | candidate records replace blanket approvals; history retained |
| A03 | High | original parser accepts STATE_COMMIT with `eff=read` | require catalog effect agreement; negative regression |
| A04 | Medium | rows before columns, duplicate column headings and a defaults directive inside a frame are accepted | explicit parse phases and structural rejection |
| A05 | Medium | duplicate unit/ARG keys overwrite earlier values | reject duplicates; reject unknown directive/structured-profile fields |
| A06 | Medium | original phi accepts NaN anchor, fractional and boolean indices/domain sizes | finite, integer and bounded coordinate profile |
| A07 | High | original schemas accept `axes=[]` and numeric tuple/digest values because prefixItems lacked minItems and pattern lacked type | exact rank/axis cardinality and explicit digest string types |
| A08 | Medium | broad additionalProperties and unspecified operator/tuple shapes weaken known contracts | close known schema objects; constrain enum/order/bounds and add semantic cross-checks |
| A09 | High | original builder recursively deletes an environment-selected output path at startup | preserve as historical text; new active builder never recursively deletes |
| A10 | Medium | original verifier depends on undeclared jsonschema, uses assertions for gates and writes evidence on every run | offline stdlib verifier, explicit conditions and optional writes |
| A11 | Medium | golden container verifier omits important flags, declared-size, path, component/reference and cross-binding defenses | bounded verifier and hostile mutations, including recomputed tuple IDs |
| A12 | Medium | algorithm sections duplicate high-level prose and examples are frequently generic/empty | package-specific formal rules, algorithms, edge cases and implementation roadmap |
| A13 | High | authority/ratification and coverage language can be read as more assurance than exists | candidate authority and assurance defeaters; distinguish review/test/science/authentication |
| A14 | Medium | external TIFF/NGFF standards were unpinned/unverified in original adapter notes | dated primary sources and version-specific mapping/negative obligations; no adapter certification |
| A15 | Medium | research mechanics, external laboratory pages and scientific validity lack supplied empirical evidence | preserved source digests, provenance gap register and preregistered experiment designs |
| A16 | Medium | archival/change/governance policies are short statements without accountable operational process | expanded proposed roles, review/quorum, archival fixity/recovery, incident and change workflows |
| A17 | Medium | rights/privacy/trust-root/runtime obligations are unresolved | explicitly documented residual work; no invented permissions, signatures or results |

The original mutation observations are retained in `evidence/ORIGINAL_ADVERSARIAL_OBSERVATIONS.JSON`; all eleven selected malformed/numeric/schema cases were accepted by the original control. Candidate regression tests cover the corrected boundaries. Tests demonstrate observed behavior for selected inputs rather than exhaustive absence of defects.

## Compatibility and changes

All 293 requirement identifiers and normative requirement tables are retained. The package's editorial and assurance version is 2.0.0; RUSSL/1.0, CanonicalIR/1.0 and the golden RUSS 1.3 framing remain the selected compatibility profile. All 12 valid program IR objects/IDs remain exact. Four MSSL modules, master-law image and example sources/lowered IR remain unchanged. Exact original tuple bytes are preserved under examples/legacy_golden/. The active coherent fixture has new identities after correcting its descriptor to the declared 4×4×4×16×16 f64 field. Historical prompts inside lineage remain data. The new parser intentionally rejects previously accepted ambiguous or out-of-profile forms. A complete language implementation must make its own declared conformance claim with further tests.

## Evidence and release decision

Current executable results are `evidence/CONFORMANCE_RESULTS.json`, with separate byte integrity in `evidence/RELEASE_INTEGRITY.json`. Requirement-level evidence and scope limits are in `machine/registries/requirement_results.json`. Content hashes, build receipt and checksums are regenerated after reviewable edits. The ZIP is sorted with fixed member timestamps and standard compression; repeated same-environment sealing is checked for identical archive bytes. This is deterministic packaging of the current edited tree, not independent reconstruction of the corpus from the original unavailable external sources.

Remaining scientific, implementation, trust, rights and institutional questions have named closure criteria in [unresolved issues](UNRESOLVED_ISSUES.md), the implementation roadmap and proposed policies. A lack of external evidence is retained as an open issue rather than filled with model-generated approval. The intended next research stage is reviewed implementation and controlled experiments, followed by independent replication and accountable institutional decisions.

## Audit limits

No formal proof, general JSON Schema conformance, independent cryptographic review, exhaustive fuzz campaign, cross-platform runtime matrix, production penetration test, JAR execution, full historical compiler validation or empirical mechanics replication was performed. Remote standards were reviewed through their primary publisher pages at the stated access date; immutable copies/licensing are future archival obligations. These limits permit release of a documented candidate but prevent calling it certified, production authorized or scientifically validated.


## Independent tooling review and final corrections

A separate read-only review challenged the first candidate using hostile schemas, rebuilt tuple hashes and contradictory integrity metadata. The original probes are retained in evidence/INDEPENDENT_TOOLING_REVIEW.json, with final disposition in evidence/TOOLING_REVIEW_RESOLUTION.json.

| Additional finding | Applied change |
|---|---|
| Original golden source f64 shape 4,4,4,16,16 conflicts with u8 descriptor shape 1,1,3,64,64 | Preserve legacy fixture, reject its binding, construct a coherent current fixture and test shape forgery despite recomputed roots |
| Recursive schema negation swallowed resource failures | Reject cyclic references; separate instance mismatch from schema/resource failure |
| Malformed keyword declarations accepted | Validate supported keyword value types/cardinalities and reject invalid declarations |
| Tuple metadata and policy role could be replaced after rehashing | Pin known golden identity/geometry profile; policy must bind a declared ADMISSION_EVAL module |
| Integrity metadata could contradict bound reports | Pin version/domain/exclusion/count policies; verify receipt/report status and digest consistency |
| First-seal count changed on second seal | Validate generated JSON but exclude its volatile presence from stable input-record counts |
| Missing vector/test inventories could pass vacuously | Require four positive/five negative source vectors and required regression files |
| Seal writes preceded symlink checks | Reject path escapes/symlinks/caches before generated writes |
| Whole-file reads and schema comparison work lacked early bounds | Stream hashes, bound JSON/container reads, enforce schema-node/comparison budgets |

Additional user-supplied research intake comprises one 23-page paper preprint and eighteen text exports. Their exact bytes/hashes are retained under lineage/research_additions/ with research/ADDITIONAL_SOURCE_INTAKE.json. The new research reviews distinguish publication evidence, corrected conversation claims, hypotheses and rejected connections. The 4×4×4×16×16 indexing fixture enumerates all 16,384 sites; it is generated mathematical data, not measured mechanics, optical or optimizer output. The final integration report records relevance and source-by-source dispositions.

## Final additional-research review

The final synthesis includes 159 unique source-linked decisions: 24 supported primary component claims, 64 corrections, 53 unsupported claims or extrapolations, seven explicit rejections and eleven hypotheses. The registers retain each reviewer's original terminology and the normalization map. Eleven broader research profiles remain proposed; finite address/inverse and optional metric helpers are implemented separately. Three visually inspected paper pages are delivered with exact source/render digests. No empirical observations or benchmarks were generated.

A final read-only consistency review corrected the LAMB estimate/measured-runtime distinction, paragraph ranges and intermediate-path portability. V14 now cross-checks actual per-source claim coverage, unique IDs, original/normalized counts, the exact evidence index, source/extract hashes, rendered-page provenance and fixed-shape data. Six targeted negative mutations are rejected against a passing unchanged control, recorded in [research-index mutation results](evidence/RESEARCH_INDEX_MUTATION_RESULTS.json). This evidence is limited to the declared indexing and verification behavior.
