# Architecture Charter — Candidate 2.0.0

The proposed architecture is `RUSSL source → canonical RUSSIR → digest-bound MSSL mechanics/policy → ordered RUSS tuple → logical Penteract field → distributed fabric`. Binding a module is distinct from evaluating it. Artifact identity, mathematical admission, authenticated authorization and mutable-head publication each require independent evidence.

| Boundary | Contract | Current evidence | Remaining obligation |
|---|---|---|---|
| Source → IR | marker, directives, rows, predecessors, catalog, bindings | strict parser and exact golden lowering | full static type/effect semantics |
| IR → mechanics | module alias, raw digest, inputs | byte verification/cross-binding | evaluator, units, numeric tolerances |
| Mechanics → admission | policy and evidence | preserved candidate MSSL | decision oracle and empirical validation |
| Admission → effects | run/row/root/arguments and authenticated grant | shapes; effect downgrade rejection | trust roots, signatures, replay/revocation, runtime |
| Tuple → payload | ordered components, per-member digest, root | bounded verifier/exact rebuild | production ABI/extension implementation |
| Field → storage | five axes, sample, mapping, snapshot | schema/profile documents | independent adapters/equivalence tests |
| Roots → fabric | content verification, head CAS, receipts, recovery | proposed protocol | implementation, consistency and failure evidence |

P5 is the normalized five-axis base with positive integer sizes and axes c4–c8. It does not supply physical calibration, a codec, trust roots or verified mechanics. The S³ fiber/8S model remains a separate experimental research object.

A digest protects byte equality under the algorithm assumption. A signature authenticates a statement only through a validated trust profile. Neither establishes scientific correctness. Mathematical admission does not authorize a mutable head update. Storage offsets, chunk paths and codecs belong to adapters. Projections and observations remain derived artifacts.

Stages expose validation result, evidence locator, scope and stable failure classification. Missing evidence remains unresolved. Source placeholders are not asserted to exist because a parser accepted their names. A tuple can pass structural/byte verification while being unexecutable because inputs, evaluators or grants are missing.

This charter is a corpus-local candidate contract. Proposed working groups and institutional roles remain unappointed absent explicit evidence. No external body endorsement is asserted.
