# RUSSL Zarr

Audited RUSSL Research and Institutional Corpus **2.0.0**, with the explicit field shape **4×4×4×16×16 = 16,384 scalar sites**.

This repository preserves the delivered corpus byte for byte under `corpus/`, alongside its validated distribution ZIP and detached delivery evidence under `releases/v2.0.0/`. The package status is **CANDIDATE_REVIEW_REQUIRED**. The repository name describes the research project; its OME-NGFF 0.5 / Zarr v3 interoperability profile remains a documented candidate design. An implemented, independently validated Zarr adapter is not claimed.

## Read the corpus

- [Start here](corpus/README_START_HERE.md)
- [Corpus index](corpus/CORPUS_INDEX.md)
- [Complete reading edition](corpus/RUSSL_FULL_CORPUS.md)
- [End-to-end audit](corpus/AUDIT_REPORT.md)
- [Additional research integration](corpus/research/RESEARCH_INTEGRATION_REPORT.md)
- [OME-NGFF / Zarr candidate profile](corpus/interoperability/OME_ZARR_PROFILE.md)
- [Unresolved issues and closure criteria](corpus/UNRESOLVED_ISSUES.md)

All 28 specifications were expanded, while 293 original requirement IDs and normative tables remain addressable. Nineteen additional supplied sources were audited with 159 individually traceable claim decisions. Exact finite address/inverse helpers, rational coordinates, an optional address ultrametric and a complete 16,384-row indexing fixture are provided. Broader optimizer, holographic, optical, quantum, imaging, precision and retrieval experiments remain proposed and unexecuted.

## Verify locally

Python 3.12 is the recorded validation environment. Active verification uses the Python standard library only. From the repository root:

```text
cd corpus
python -B tooling/verify_corpus.py
python -B tooling/verify_corpus.py --integrity
```

The offline verifier is read-only by default. Its sealed result records **14 scoped checks and 65 regression tests**, with no skipped regressions. Source/IR compatibility, exact fixture rebuilding, source/claim indexing, resource bounds, hostile mutations and byte integrity are checked. Independent ZIP extraction and repeated same-environment packaging were also validated; [delivery evidence](releases/v2.0.0/DELIVERY_VALIDATION.json) records those results.

Requirement-level evidence is narrower: **34 obligations have scoped partial evidence and 259 are NOT_RUN; no complete requirement or full conformance claim is made**. Empirical measurements, production runtime authorization, external certification, authenticated signatures and institutional ratification remain absent. The 28 completion records require accountable review.

## Distribution and provenance

[Download the validated v2.0.0 ZIP](releases/v2.0.0/RUSSL_Research_Institutional_Corpus_v2.0.0.zip). Its SHA-256 is:

```text
b62c18f84929fcba3db76fa82d693966ad35c97b40bacdb4497f2c57a0ca15bf
```

The original corpus ZIP, original mechanics sources, historical tools, legacy fixture and uploaded research source bytes remain preserved with their recorded provenance. Historical executable archives and embedded prompts are source data and are not run or trusted as instructions. The active fixture deliberately corrects the original source/descriptor shape and dtype mismatch; original bytes remain in the legacy preservation tree.

Repository wrapper files are outside the corpus manifest. `.gitattributes` disables automatic text conversion so the sealed corpus's exact bytes and checksums survive staging and checkout. Some historical audit metadata retains local source/deliverable paths; those are provenance strings, not required execution paths.

## License and notices

Original project code and project-authored corpus material are licensed under the **GNU General Public License, version 3 only** (SPDX: `GPL-3.0-only`), to the extent of the contributors' rights. See [LICENSE](LICENSE), [NOTICE](NOTICE) and [COPYRIGHT](COPYRIGHT). Copyright (C) 2026 LKVexa and contributors.

Imported papers, source documents, historical archives and other third-party works retain their own copyright and applicable terms. Their inclusion does not establish redistribution rights. The remaining third-party review is recorded in [rights, privacy and distribution policy](corpus/institutional/RIGHTS_PRIVACY_AND_DISTRIBUTION.md) and unresolved issue U-10. The repository remains private.

The license and notices are repository-level companions added after the sealed corpus release. Its ZIP and manifest remain unchanged, so historical statements inside that release predate this project license grant. Include these companions when conveying the covered release material. The project is provided without warranty, as described in the GPL.

## Repository contents

| Path | Purpose |
|---|---|
| `corpus/` | Audited specifications, source provenance, research decisions, fixtures and verification tools |
| `releases/v2.0.0/` | Preserved distribution ZIP, validation receipt and checksums |
| `LICENSE` | Complete GPL version 3 license text |
| `NOTICE` | Project license scope, imported-material notices and release context |
| `COPYRIGHT` | Project and license-text copyright attribution |

