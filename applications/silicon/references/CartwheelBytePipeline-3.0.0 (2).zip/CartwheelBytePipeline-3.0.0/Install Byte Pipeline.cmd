@echo off
setlocal
set "PIPELINE_TARGET=D:\Codex\CartwheelConsole"
if not "%~1"=="" set "PIPELINE_TARGET=%~1"
"%PIPELINE_TARGET%\portable\python\python.exe" -S -B "%~dp0install_upgrade.py" --root "%PIPELINE_TARGET%"
if errorlevel 1 pause
