"""Apply this reviewed update to an existing portable Cartwheel installation.

Only paths and hashes in upgrade-manifest.json are admitted. Existing source
changes reject before writes. Backups retain every replaced file and seal.
"""
from pathlib import Path
from hashlib import sha256
import argparse
import datetime
import json
import os
import shutil
import tempfile


def digest(path):
    with path.open('rb') as stream:
        return sha256(stream.read()).hexdigest()


def safe_file(root, relative):
    if not isinstance(relative,str) or '\\' in relative or ':' in relative or relative.startswith('/'):
        raise ValueError('Invalid relative update path')
    parts=relative.split('/')
    if any(part in ('','.','..') for part in parts):
        raise ValueError('Invalid update component')
    path=root.joinpath(*parts)
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Update path leaves selected installation')
    current=path
    while current != root.parent:
        if current.is_symlink() or (current.exists() and getattr(current.stat(),'st_file_attributes',0)&1024):
            raise ValueError('Linked update paths are not admitted')
        current=current.parent
    return path


def atomic_bytes(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.byte-upgrade-',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as handle:
            handle.write(data);handle.flush();os.fsync(handle.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def encoded(value):
    return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode('utf-8')


def apply_update(package,root):
    package=package.resolve();root=root.resolve()
    if not (root/'portable-console.json').is_file():
        raise ValueError('Choose an existing portable Cartwheel console folder')
    manifest=json.loads((package/'upgrade-manifest.json').read_text(encoding='utf-8'))
    rows=manifest['files'];seen=set();operations=[]
    for row in rows:
        relative=row['path']
        if relative.casefold() in seen:raise ValueError('Duplicate update path')
        seen.add(relative.casefold())
        target=safe_file(root,relative);source=safe_file(package/'payload',relative)
        if digest(source)!=row['sha256']:raise ValueError('Update source hash mismatch: '+relative)
        current=digest(target) if target.is_file() else None
        if current not in (row['previousSha256'],row['sha256']):
            raise ValueError('Existing source differs; no files were changed: '+relative)
        if current!=row['sha256']:operations.append((relative,source,target))
    runtime_path=safe_file(root,'engine/ja21/runtime.integrity.json')
    package_path=safe_file(root,'package.integrity.json')
    runtime=json.loads(runtime_path.read_text(encoding='utf-8'))
    package_seal=json.loads(package_path.read_text(encoding='utf-8'))
    # Startup's existing immutable closure must be valid before it is extended.
    for row in runtime['files']:
        if digest(safe_file(root,row['path']))!=row['sha256']:
            raise ValueError('Current startup integrity mismatch: '+row['path'])
    if not operations:
        runtime_rows={row['path']:row for row in runtime['files']}
        package_rows={row['path']:row for row in package_seal['files']}
        for relative in manifest['runtimePaths']:
            target=safe_file(root,relative)
            expected={'path':relative,'bytes':target.stat().st_size,'sha256':digest(target)}
            if runtime_rows.get(relative)!=expected:
                raise ValueError('Installed update is missing its startup seal: '+relative)
        for relative in [row['path'] for row in rows]+['engine/ja21/runtime.integrity.json']:
            target=safe_file(root,relative)
            expected={'path':relative,'bytes':target.stat().st_size,'sha256':digest(target)}
            if package_rows.get(relative)!=expected:
                raise ValueError('Installed update is missing its package seal: '+relative)
        print('Byte pipeline 3.0.0 is already installed and its update seals pass.');return
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
    backup=safe_file(root,'work/upgrade-backups/byte-pipeline-3.0.0-'+stamp)
    backup.mkdir(parents=True,exist_ok=False)
    originals={}
    replaced=[]
    try:
        for relative,_,target in operations:
            originals[relative]=target.read_bytes() if target.exists() else None
            if originals[relative] is not None:atomic_bytes(backup/relative,originals[relative])
        for relative in ('engine/ja21/runtime.integrity.json','package.integrity.json'):
            originals[relative]=safe_file(root,relative).read_bytes();atomic_bytes(backup/relative,originals[relative])
        atomic_bytes(backup/'update-record.json',encoded({'version':'3.0.0','replaced':[r for r,_,_ in operations],'created':[r for r,b in originals.items() if b is None]}))
        for relative,source,target in operations:
            replaced.append(relative);atomic_bytes(target,source.read_bytes())
        runtime_rows={row['path']:row for row in runtime['files']}
        for relative in manifest['runtimePaths']:
            target=safe_file(root,relative)
            runtime_rows[relative]={'path':relative,'bytes':target.stat().st_size,'sha256':digest(target)}
        for relative in list(runtime_rows):
            if relative.casefold() in seen:
                target=safe_file(root,relative)
                runtime_rows[relative]={'path':relative,'bytes':target.stat().st_size,'sha256':digest(target)}
        runtime['files']=[runtime_rows[key] for key in sorted(runtime_rows)]
        replaced.append('engine/ja21/runtime.integrity.json');atomic_bytes(runtime_path,encoded(runtime))
        package_rows={row['path']:row for row in package_seal['files']}
        for relative in [r['path'] for r in rows]+['engine/ja21/runtime.integrity.json']:
            target=safe_file(root,relative)
            package_rows[relative]={'path':relative,'bytes':target.stat().st_size,'sha256':digest(target)}
        package_seal['files']=[package_rows[key] for key in sorted(package_rows)]
        replaced.append('package.integrity.json');atomic_bytes(package_path,encoded(package_seal))
    except BaseException:
        for relative in reversed(replaced):
            target=safe_file(root,relative);original=originals[relative]
            if original is None:target.unlink(missing_ok=True)
            else:atomic_bytes(target,original)
        raise
    print('Installed byte pipeline 3.0.0 into '+str(root))
    print('Preserved original files and seals in '+str(backup))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Install the byte pipeline replacement with checked backups')
    parser.add_argument('--root',type=Path,default=Path('D:/Codex/CartwheelConsole'))
    parser.add_argument('--package',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    apply_update(args.package,args.root)
