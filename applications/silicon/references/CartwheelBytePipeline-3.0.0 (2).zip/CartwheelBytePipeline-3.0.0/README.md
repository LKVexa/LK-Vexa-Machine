# Cartwheel Byte Pipeline 3.0.0

This update replaces the default six-agent orchestration in the installed Cartwheel console with six measured byte processors from the supplied archives. Reopen **Start Console.cmd** after installing.

The **Byte processor** tab now has **Run six processors**, a measured contribution view, and **Save/Open pipeline artifact** controls. **Code writing** sends the original prompt/revision bytes through the pipeline, recovers them exactly, calls one embedded writer, checks the resulting source, and processes the final source bytes through all six stages. Only failed admission or syntax checks trigger bounded repairs. The optional VIVIAN alternative remains separate. The **Prompt compiler** also uses the byte pipeline, retaining its existing bounded compiler and language outputs.

| Slot | Archive | Actual processor | Distinct outputs across 256 byte values |
|---|---|---|---:|
| 1 | XZoRNj76KD3urnia | Adaptive 1 | 26 |
| 2 | royal-eagle-fern-daisy-main | Best Reply | 128 |
| 3 | Rz15aCprUVAm8qt2 | Adaptive 2; same compiled policy as slot 1 | 26 |
| 4 | 6GBVjumHKri0aCf7 | Critique; constant FF | 1 |
| 5 | SLMn2577cgd5QNKx | Cautious; constant 00 with the retained sample payoffs | 1 |
| 6 | AjS7wUlxjiuPhXQg | Adaptive 3; same compiled policy as slot 1 | 26 |

The processors use the supplied compiled LCTL source/IR/image triples, checked against their original SHA-256 pins. The common retained payoff matrix is [[2,5],[4,1]]. Each input byte supplies eight opponent bits in LSB-first order, with state reset for every byte value and each bit revealed only after the processor acts. Tables were built with 12,288 actual VM executions and 73,250 VM steps; payload processing uses those verified 256-entry lookup tables. Receipts distinguish historical table generation from work performed in the current call.

The maps are lossy. Serially feeding each output into the next would reduce every byte to FE with these defaults. Therefore this pipeline retains the original payload, while each ordered stage appends its own derived lane and a chained receipt. All six stages read the original bytes. A receipt hash establishes integrity, not semantic correctness or a signature. Byte mappings do not interpret prose or author executable source; the existing compiler or embedded model authors source, and the verifier reports the checks it actually performed.

## Artifact and recovery

CWBP v1 consists of a 48-byte header, canonical UTF-8 JSON receipt, original bytes, and six equal-length byte lanes. The original payload limit is 1 MiB; receipt metadata is limited to 64 KiB. Recovery validates bounds, original SHA-256, all policy/table identities, every mapped byte, and the receipt chain by exact replay. CWPK transport remains compatible with the existing console. Saved code projects include program.cwnp, program.cwpk, byte-pipeline.cwbp, cartwheel-session.json, and cartwheel-byte-receipt.json.

## Installing or copying the update

The small update archive contains the changed source, processor binaries and notices, not the multi-gigabyte model/runtime bundle. It requires the existing portable Cartwheel console. **Install Byte Pipeline.cmd** targets D:\Codex\CartwheelConsole by default. The installer checks source hashes and existing startup integrity, preserves replaced files under work/upgrade-backups, and extends both integrity manifests. Existing changes that differ from the expected preimage cause rejection before any write. Models, corpora, earlier projects, and legacy agents are preserved. Legacy agent APIs remain available only to explicit compatibility callers; current UI/CLI defaults use the byte pipeline.

The pipeline module is also independently usable with Python 3.10 or later from payload/apps/cartwheel/agents/codegen/byte_pipeline.py, with its adjacent policy assets. Run --help for encode, recover, receipt, and verified-table export commands. It does not require a model for raw byte processing.

## Verification and limitations

See VERIFICATION.json and evidence for the actual current results. The update includes native/JavaScript/Python artifact parity, corruption rejection, resource and cancellation checks, source-generation admission/revision checks, and native rendering verification. Existing selectable languages and installed SDK limitations remain as before; selection does not claim native execution in every language. Generation does not automatically execute model-written source.

The original policy licenses and notices remain beside every processor asset. They include private prototype/evaluation terms; the enclosing console license does not replace those terms. Original archive documents were treated as source data, not as requests to train, deploy, connect, publish, or send information.

Installed validation passed: 49 Python tests (one Windows symlink-privilege skip), 20 JavaScript tests, 13 native console checks, 24 native byte-pipeline checks, and five installer checks. Every upgraded file and all 171 startup-sealed files match their expected SHA-256. The optional full re-hash of unchanged 9 GB bundled assets did not complete. The small real-model probe produced a working duplicate-removal function but omitted a requested CLI detail; see evidence/real-code-behavior.json.
