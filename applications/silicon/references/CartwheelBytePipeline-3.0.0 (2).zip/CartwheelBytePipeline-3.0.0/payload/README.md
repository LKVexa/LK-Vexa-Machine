# Cartwheel Byte Pipeline 3.0.0

The default workflow now uses six measured byte processors from the supplied archives. See [BYTE_PIPELINE.md](BYTE_PIPELINE.md) for controls, exact recovery, source generation, and current verification. Reopen **Start Console.cmd**. Original models, corpora, saved projects and legacy compatibility APIs are preserved.

The existing console background and portable setup follow. References below to the older six-agent workflow describe earlier versions.

# JA21 Cartwheel Virtual Console

Console integration **2.1.0** · Cartwheel **2.0.0** · Windows x64

Extract the complete portable package into a short, writable local folder with
an ASCII path (spaces are supported), and double-click
**Start Console.cmd**. The application opens inside the console with three tabs:

- **Code writing:** the six direct model agents generate and revise new source
  from prose, with files and contribution receipts in the same hosted workbench.
- **Byte workbench:** the offline Cartwheel compiler, cartwheel fields, packets,
  source inspector and bounded calculations/tensor/page composition.
- **Files & readiness:** access projects, complete system files, model files,
  reports and component readiness.

The full system is under `apps/cartwheel`; bundled interpreters, syntax checkers,
models and offline renderer are inside `portable` and `models`. Generated projects
are saved under `outputs/generated`; logs/state and byte-workbench downloads stay
under `workspace`. No coding-model server or inference bridge is used. The WPF
console and the hosted Python UI are separate native UI processes; all six agents
and all model inference run directly in the Python UI process.

The primary workbench uses the embedded Qwen coding model and offers the supplied
VIVIAN weights as an experimental alternative. All 70 language profiles remain
available. Native execution with missing framework SDKs and custom JA/DeepML
runtimes remains unverified; model-generated source is not automatically executed.

Read `START_HERE.txt` and `PORTABILITY_REPORT.txt` for the current installation,
packaging and validation details. See
[console integration](docs/CARTWHEEL_CONSOLE_INTEGRATION.md) for implementation and
verification details. The original empty console remains available through
**Start Blank Console.cmd**; its historical documentation is preserved in
[the original README](docs/LEGACY_BLANK_CONSOLE_README.md).

Windows PowerShell 5.1 and .NET Framework WPF are operating-system prerequisites.
The bundled fixed WebView2 runtime renders the offline tab. Keep the package
writable and copy the entire folder when moving it to another Windows x64 machine.

The original GPL-3.0-only console attribution, source and notices are preserved in
`LICENSE`, `COPYRIGHT`, `NOTICE`, `LICENSING.md`, and `THIRD-PARTY-NOTICES.md`.
Cartwheel, coding-model, Python, llama.cpp, Node, compiler and Microsoft components
retain their separate licenses and notices. VIVIAN's supplied checkpoint is retained
as local research material; its donor lineage is not a verified redistribution grant.
