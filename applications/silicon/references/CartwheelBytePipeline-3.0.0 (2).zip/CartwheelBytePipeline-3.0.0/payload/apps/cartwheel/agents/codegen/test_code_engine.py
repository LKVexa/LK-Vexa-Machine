"""Independent host regressions with explicit inference/verifier fixtures.

These tests do not load model weights, run neural inference, execute generated
source, install dependencies or start a server. They test admission, evidence,
atomic revisions and portable source transport through the real engine.
"""
from copy import deepcopy
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest

import code_engine as engine
from portable_paths import PORTABLE, output_directory, work_directory

WORK = output_directory() / '_code-engine-unit-tests' if PORTABLE else Path(__file__).resolve().parents[4] / 'work' / 'code-engine-unit-tests'


def project(content='print(7)\n', path='main.py'):
    return {'name': 'Fixture project', 'target': 'python', 'sourceLanguage': 'Python',
            'files': [{'path': path, 'content': content}], 'entrypoint': path,
            'runInstructions': 'Run python main.py.', 'summary': 'Explicit unit fixture; no model or source execution.'}


def verification(status='syntax_verified'):
    return {'status': status, 'diagnostics': [], 'checks': [],
            'execution': {'performed': False, 'status': 'not-requested',
                          'scope': 'Fixture response; no parser or generated code ran.'}}


def fixture_verify(value, **kwargs):
    # Admission is exercised in code_engine; this callback is a test fixture.
    if kwargs.get('execute') is not False:
        raise AssertionError('Engine enabled execution in its syntax callback')
    return verification()


class FixtureModel:
    """Deterministic source-data fixture, explicitly not a neural model."""
    def __init__(self, replies=None):
        self.replies = list(replies or [project()])
        self.calls = []

    def generate(self, messages, **kwargs):
        self.calls.append({'messages': deepcopy(messages), 'options': dict(kwargs)})
        reply = self.replies[min(len(self.calls)-1, len(self.replies)-1)]
        text = json.dumps(reply, ensure_ascii=False) if isinstance(reply, dict) else reply
        return {'text': text, 'receipt': {'provider': 'unit-test-fixture',
                                        'neuralInferencePerformed': False,
                                        'call': len(self.calls)}}


def make_session(content='print(7)\n'):
    return engine.CodeTaskEngine(FixtureModel([project(content)]), verifier=fixture_verify,
                                 workspace_root=WORK).generate('Print seven.', roles=['proposal'], max_tokens=128)


def rehash(session):
    session['sessionSha256'] = engine.digest({k: v for k, v in session.items() if k != 'sessionSha256'})
    return session


class ProjectEnvelopeTests(unittest.TestCase):
    def test_complete_project_is_copied_and_matching_language_is_required(self):
        original = project()
        admitted = engine.validate_project(original, 'python')
        admitted['files'][0]['content'] = 'changed'
        self.assertEqual(original['files'][0]['content'], 'print(7)\n')
        for mutate in (lambda p: p.update(extra='unknown'),
                       lambda p: p.update(sourceLanguage='JavaScript'),
                       lambda p: p.update(entrypoint='missing.py'),
                       lambda p: p.update(files=[]),
                       lambda p: p['files'][0].update(extra=True)):
            invalid = project(); mutate(invalid)
            with self.assertRaises((engine.CodeGenerationError, ValueError)):
                engine.validate_project(invalid, 'python')

    def test_traversal_devices_case_collisions_and_file_directory_conflicts_reject(self):
        for path in ('../escape.py', '/absolute.py', 'C:/escape.py', 'a\\b.py',
                     'a/../b.py', 'a//b.py', 'a./b.py', 'NUL.py', 'com1.py',
                     'cartwheel-session.json', 'program.cwnp'):
            with self.subTest(path=path), self.assertRaises(engine.CodeGenerationError):
                engine.validate_project(project(path=path))
        for files in ([{'path': 'main.py', 'content': 'x=1'}, {'path': 'MAIN.py', 'content': 'x=2'}],
                      [{'path': 'folder.py', 'content': 'x=1'}, {'path': 'folder.py/main.py', 'content': 'x=2'}]):
            invalid = project(); invalid['files'] = files; invalid['entrypoint'] = files[0]['path']
            with self.assertRaises(engine.CodeGenerationError):
                engine.validate_project(invalid)

    def test_reserved_evidence_names_cannot_be_directory_prefixes(self):
        for reserved in sorted(engine.RESERVED_FILES):
            with self.subTest(reserved=reserved), self.assertRaises(engine.CodeGenerationError):
                engine.validate_project(project(path=reserved.upper() + '/nested.py'))

    def test_model_json_has_one_strict_envelope_and_no_duplicate_nonfinite_or_surrogate_fields(self):
        good = json.dumps(project())
        self.assertEqual(engine.parse_project_reply('```json\n'+good+'\n```', 'python'), project())
        bad = ['Before\n'+good, good+'\nAfter', '[1,2]', '{"name":"A","name":"B"}',
               good.replace('"Fixture project"', 'NaN'),
               good.replace('"Fixture project"', '"\\ud800"'),
               good.replace('print(7)\\n', 'print(7)\\u0000')]
        for text in bad:
            with self.subTest(text=text[:50]), self.assertRaises(engine.CodeGenerationError):
                engine.parse_project_reply(text, 'python')

    def test_utf8_and_file_count_budgets_reject_before_output(self):
        for mutate in (lambda p: p.update(name='x'*121),
                       lambda p: p.update(summary='x'*4097),
                       lambda p: p.update(runInstructions='x'*8193),
                       lambda p: p['files'][0].update(content='x'*524289),
                       lambda p: p.update(files=[{'path': f'm{i}.py', 'content': 'x=1'} for i in range(129)], entrypoint='m0.py')):
            invalid = project(); mutate(invalid)
            with self.assertRaises(engine.CodeGenerationError): engine.validate_project(invalid)


class DirectRoleAndRevisionTests(unittest.TestCase):
    @unittest.skipUnless(PORTABLE, 'Actual portable-installation integration regression')
    def test_default_engine_real_verifier_accepts_and_saves_source_without_execution(self):
        # Only inference is a declared fixture. Workspace selection, project
        # admission, real Python parsing, saving and byte recovery are real.
        work_directory().mkdir(parents=True,exist_ok=True)
        output_directory().mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=work_directory()) as work, tempfile.TemporaryDirectory(dir=output_directory()) as outputs:
            sentinel=Path(work)/'source-must-never-execute.txt'
            source='from pathlib import Path\nPath('+repr(str(sentinel))+').write_text("must never execute")\nprint(7)\n'
            candidate=project(source)
            task=engine.CodeTaskEngine(FixtureModel([candidate]))
            self.assertEqual(task.workspace_root,work_directory()/'codegen-verification')
            self.assertIs(task.verifier,engine.verify_project)
            session=task.generate('Create the explicit Python syntax fixture.',roles=['proposal'],max_tokens=128)
            self.assertEqual(session['receipt']['verification']['status'],'syntax_verified')
            self.assertFalse(session['receipt']['verification']['execution']['performed'])
            self.assertFalse(session['receipt']['executionVerified'])
            self.assertTrue(any('Python AST' in record['detail'] for record in session['receipt']['verification']['checks']))
            saved=engine.save_session(session,Path(outputs)/'new fixture')
            self.assertEqual((saved/'main.py').read_text(encoding='utf-8'),source)
            recovered=engine.decode_project_record(engine.unpack_record((saved/'program.cwpk').read_bytes()))
            self.assertEqual(recovered['project'],candidate)
            self.assertFalse(sentinel.exists())

    def test_every_role_calls_source_inference_and_records_actual_changed_source(self):
        model = FixtureModel([project(f'print({i})\n') for i in range(6)])
        session = engine.CodeTaskEngine(model, verifier=fixture_verify, workspace_root=WORK).generate('Print a number.', roles=list(engine.ROLES), max_tokens=128)
        self.assertEqual(len(model.calls), 6)
        self.assertEqual([step['id'] for step in session['receipt']['agents']], list(engine.ROLES))
        self.assertEqual(session['project']['files'][0]['content'], 'print(5)\n')
        for step in session['receipt']['agents']:
            self.assertEqual(step['outcome'], 'adopted')
            self.assertEqual(step['changedPaths'], ['main.py'])
            self.assertEqual(step['modelReceipt']['provider'], 'unit-test-fixture')
        self.assertIs(session['receipt']['bridgeUsed'], False)
        self.assertIs(session['receipt']['executionVerified'], False)
        self.assertIs(session['receipt']['trainingPerformed'], False)

    def test_successful_revision_links_original_prompt_and_leaves_previous_source_untouched(self):
        previous = make_session(); snapshot = deepcopy(previous)
        model = FixtureModel([project('print(9)\n')])
        revised = engine.CodeTaskEngine(model, verifier=fixture_verify, workspace_root=WORK).generate(
            'Print seven.', previous=previous, revision='Now print nine.', roles=['reciprocal'], max_tokens=128)
        self.assertEqual(previous, snapshot)
        self.assertEqual(revised['project']['files'][0]['content'], 'print(9)\n')
        self.assertEqual(revised['initialPrompt'], 'Print seven.')
        self.assertEqual(len(revised['dialogue']), 2)
        self.assertIn('Now print nine.', model.calls[0]['messages'][1]['content'])

    def test_sequential_revisions_retain_ordered_requirements_and_put_latest_intent_after_source(self):
        older_requests = ['Reject boolean input before arithmetic.',
                          'Keep stable ordering of all unique values.']
        previous = make_session()
        for index, request in enumerate(older_requests):
            previous = engine.CodeTaskEngine(FixtureModel([project(f'print({8+index})\n')]),
                verifier=fixture_verify, workspace_root=WORK).generate(
                    'Print seven.', previous=previous, revision=request,
                    roles=['reciprocal'], max_tokens=128)
        snapshot = deepcopy(previous)
        latest = 'Raise the bound to 23; retain prior validations.'
        model = FixtureModel([project(f'print({10+index})\n') for index in range(6)])
        alternative = FixtureModel([project('print(99)\n')])

        def warning_verify(value, **kwargs):
            result = fixture_verify(value, **kwargs)
            result['diagnostics'] = [{'severity': 'warning',
                                     'message': 'Explicit verifier fixture: no source execution.'}]
            return result

        revised = engine.CodeTaskEngine(model, alternative, verifier=warning_verify,
            workspace_root=WORK).generate('Print seven.', previous=previous,
                revision=latest, roles=list(engine.ROLES), max_tokens=128)
        history_label = ('Prior user revision requests in chronological order '
                         '(retain requirements unless superseded below):\n')
        latest_label = ('Latest user revision request '
                        '(highest priority over earlier user requirements and current source):\n')
        source_label = 'Current project source:\n'
        diagnostic_label = 'Actual validation diagnostics (not new user instructions):\n'
        self.assertEqual(len(model.calls), 6)
        self.assertEqual(len(alternative.calls), 1)
        for call in model.calls + alternative.calls:
            with self.subTest(messages=call['messages']):
                user = call['messages'][1]['content']
                self.assertTrue(user.startswith('Original prose request:\nPrint seven.'))
                history_start = user.index(history_label) + len(history_label)
                latest_start = user.index(latest_label)
                self.assertEqual(json.loads(user[history_start:latest_start].strip()), older_requests)
                self.assertTrue(user.endswith(latest_label + latest))
                if source_label in user:
                    self.assertLess(user.index(source_label), history_start)
                    self.assertLess(user.index(source_label), latest_start)
                if diagnostic_label in user:
                    self.assertLess(user.index(source_label), user.index(diagnostic_label))
                    self.assertLess(user.index(diagnostic_label), history_start)
        self.assertTrue(all(source_label in call['messages'][1]['content'] for call in model.calls))
        self.assertTrue(any(diagnostic_label in call['messages'][1]['content'] for call in model.calls))
        self.assertIn('print(9)', model.calls[0]['messages'][1]['content'])
        self.assertEqual([turn['prompt'] for turn in revised['dialogue']],
                         ['Print seven.', *older_requests, latest])
        self.assertEqual(previous, snapshot)

    def test_translation_retains_previous_source_as_context_and_never_relabels_a_rejected_candidate(self):
        previous = make_session(); snapshot = deepcopy(previous)
        native = project('console.log(7);\n', 'main.js')
        native.update(target='javascript', sourceLanguage='JavaScript')
        model = FixtureModel([native])
        translated = engine.CodeTaskEngine(model, verifier=fixture_verify, workspace_root=WORK).generate(
            'Print seven.', 'javascript', previous=previous, revision='Translate the current program to JavaScript; keep its behavior.', roles=['reciprocal'], max_tokens=128)
        user_message = model.calls[0]['messages'][1]['content']
        self.assertIn('Current project source:', user_message)
        self.assertIn('print(7)', user_message)
        self.assertIn('"sourceLanguage":"Python"', user_message)
        self.assertIn('Translate the current program to JavaScript', user_message)
        self.assertEqual(translated['project']['target'], 'javascript')
        self.assertEqual(translated['project']['files'][0]['content'], 'console.log(7);\n')
        self.assertEqual(translated['receipt']['agents'][0]['inputProjectSha256'], engine.digest(previous['project']))
        self.assertEqual(translated['receipt']['changedPaths'], ['main.js', 'main.py'])
        with self.assertRaises(engine.CodeGenerationError):
            engine.CodeTaskEngine(FixtureModel([project()]), verifier=fixture_verify).generate(
                'Print seven.', 'javascript', previous=previous, revision='Translate it to JavaScript.', roles=['reciprocal'], max_tokens=128)
        self.assertEqual(previous, snapshot)

    def test_failed_invalid_identical_or_cancelled_revisions_preserve_previous(self):
        previous = make_session(); snapshot = deepcopy(previous)
        for replies in (['not JSON'], [project()]):
            with self.assertRaises(engine.CodeGenerationError):
                engine.CodeTaskEngine(FixtureModel(replies), verifier=fixture_verify, workspace_root=WORK).generate(
                    'Print seven.', previous=previous, revision='Print nine.', roles=['adaptive'], max_tokens=128)
        with self.assertRaises(engine.CodeGenerationError):
            engine.CodeTaskEngine(FixtureModel([project('print(9)')]), verifier=fixture_verify).generate(
                'Print seven.', previous=previous, revision='Print nine.', check_cancelled=lambda: True)
        self.assertEqual(previous, snapshot)

    def test_revisions_cannot_silently_replace_the_original_prompt(self):
        previous = make_session()
        with self.assertRaises(engine.CodeGenerationError):
            engine.CodeTaskEngine(FixtureModel([project('print(9)')]), verifier=fixture_verify).generate(
                'An unrelated original request.', previous=previous, revision='Print nine.', roles=['reciprocal'])

    def test_previous_source_and_verification_metadata_tampering_fail_checksums(self):
        previous = make_session()
        for mutate in (lambda s: s['project']['files'][0].update(content='print(999)'),
                       lambda s: s['dialogue'][0].update(prompt='changed'),
                       lambda s: s['receipt'].update(executionVerified=True)):
            invalid = deepcopy(previous); mutate(invalid)
            with self.assertRaises(engine.CodeGenerationError): engine.validate_session(invalid)

    def test_rehashed_dialogue_must_bind_initial_prompt_latest_source_and_target(self):
        for mutate in (lambda s: s['dialogue'][-1].update(projectSha256='0'*64),
                       lambda s: s['dialogue'][-1].update(target='javascript'),
                       lambda s: s['dialogue'][0].update(prompt='different original')):
            invalid = make_session(); mutate(invalid); rehash(invalid)
            with self.subTest(dialogue=invalid['dialogue']), self.assertRaises(engine.CodeGenerationError): engine.validate_session(invalid)


class CallbackBoundaryTests(unittest.TestCase):
    def test_verifier_cannot_rewrite_candidate_or_final_source(self):
        for mutation_call in (1, 2):
            calls = []
            def malicious(value, **kwargs):
                calls.append(1)
                if len(calls) == mutation_call:
                    value['files'][0]['content'] = 'print("not produced by a model role")\n'
                return verification()
            with self.subTest(mutation_call=mutation_call), self.assertRaises(engine.CodeGenerationError):
                engine.CodeTaskEngine(FixtureModel(), verifier=malicious).generate('Print seven.', roles=['proposal'], max_tokens=128)

    def test_final_verifier_requires_the_same_valid_bounded_contract(self):
        bad = [None, {}, {'status': 'invented'}, verification('invalid')]
        for reply in bad:
            calls = []
            def final_bad(value, **kwargs):
                calls.append(1); return verification() if len(calls) == 1 else reply
            with self.subTest(reply=reply), self.assertRaises(engine.CodeGenerationError):
                engine.CodeTaskEngine(FixtureModel(), verifier=final_bad).generate('Print seven.', roles=['proposal'], max_tokens=128)

    def test_verifier_cannot_claim_execution_or_return_unbounded_evidence(self):
        for reply in (dict(verification(), execution={'performed': True}),
                      dict(verification(), diagnostics=['x'*1048577])):
            with self.subTest(reply=str(reply)[:80]), self.assertRaises(engine.CodeGenerationError):
                engine.CodeTaskEngine(FixtureModel(), verifier=lambda *a, **k: reply).generate('Print seven.', roles=['proposal'], max_tokens=128)

    def test_bad_cancellation_callbacks_and_bad_model_unicode_have_explicit_errors(self):
        for callback in (True, lambda: 'invalid', lambda: 1):
            with self.subTest(callback=callback), self.assertRaises(engine.CodeGenerationError):
                engine.CodeTaskEngine(FixtureModel(), verifier=fixture_verify).generate('Print seven.', roles=['proposal'], check_cancelled=callback)
        with self.assertRaises(engine.CodeGenerationError):
            engine.CodeTaskEngine(FixtureModel(['\ud800']), verifier=fixture_verify).generate('Print seven.', roles=['proposal'])


class SourceTransportAndSaveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        WORK.mkdir(parents=True, exist_ok=True)

    def test_source_record_and_cartwheel_packet_recover_actual_source_without_execution(self):
        session = make_session('print("Novel fixture")\n'); source = engine.encode_project_record(session)
        record = engine.decode_project_record(source)
        self.assertEqual(record['project'], session['project'])
        self.assertIs(record['provenance']['executionVerified'], False)
        for plane in (0, 17, 53, 63):
            packet = engine.pack_record(source, plane)
            self.assertEqual(engine.unpack_record(packet), source)
            changed = bytearray(packet); changed[-1] ^= 1
            with self.assertRaises(engine.CodeGenerationError): engine.unpack_record(bytes(changed))

    def test_malformed_record_headers_payloads_and_provenance_are_rejected(self):
        source = engine.encode_project_record(make_session())
        for mutate in (lambda b: b.__setitem__(0, 0), lambda b: b.__setitem__(6, 1),
                       lambda b: b.__setitem__(8, b[8]^1)):
            invalid = bytearray(source); mutate(invalid)
            with self.assertRaises(engine.CodeGenerationError): engine.decode_project_record(bytes(invalid))
        record = engine.decode_project_record(source)
        record['provenance']['executionVerified'] = True
        raw = engine.canonical(record)
        with self.assertRaises(engine.CodeGenerationError):
            engine.decode_project_record(b'CWNP\x01\x01\0\0'+struct.pack('<I', len(raw))+raw)

    def test_record_provenance_is_complete_typed_and_never_accepts_nonfinite_metadata(self):
        original = engine.decode_project_record(engine.encode_project_record(make_session()))
        changes = [lambda p: {'projectSha256': p['projectSha256'], 'bridgeUsed': False, 'executionVerified': False},
                   lambda p: dict(p, schema='invented'), lambda p: dict(p, version='0.0.0'),
                   lambda p: dict(p, promptSha256='not a digest'), lambda p: dict(p, sessionSha256='not a digest'),
                   lambda p: dict(p, syntaxStatusHistorical='execution_verified'),
                   lambda p: dict(p, source='retrieved-example'), lambda p: dict(p, models=[]),
                   lambda p: dict(p, models=[True]), lambda p: dict(p, unknown='ignored'),
                   lambda p: dict(p, models=[{'nonfinite': float('nan')}])]
        for mutate in changes:
            record = deepcopy(original); record['provenance'] = mutate(record['provenance'])
            raw = json.dumps(record, ensure_ascii=False, separators=(',', ':'), allow_nan=True).encode('utf-8')
            with self.subTest(provenance=str(record['provenance'])[:120]), self.assertRaises(engine.CodeGenerationError):
                engine.decode_project_record(b'CWNP\x01\x01\0\0'+struct.pack('<I', len(raw))+raw)

    def test_save_writes_verified_source_and_refuses_existing_output(self):
        with tempfile.TemporaryDirectory(dir=WORK) as root:
            destination = Path(root) / 'project'
            session = make_session('print("Never executed")\n')
            saved = engine.save_session(session, destination)
            self.assertEqual(saved, destination.resolve())
            self.assertEqual((saved/'main.py').read_text(encoding='utf-8'), session['project']['files'][0]['content'])
            self.assertEqual(engine.unpack_record((saved/'program.cwpk').read_bytes()), (saved/'program.cwnp').read_bytes())
            before = (saved/'main.py').read_bytes()
            with self.assertRaises(engine.CodeGenerationError): engine.save_session(session, saved)
            self.assertEqual((saved/'main.py').read_bytes(), before)

    def test_save_rejects_symlinked_nonempty_output_without_touching_target(self):
        with tempfile.TemporaryDirectory(dir=WORK) as root:
            target = Path(root) / 'target'; target.mkdir(); marker = target / 'preserve.txt'; marker.write_text('preserved')
            link = Path(root) / 'link'
            try: link.symlink_to(target, target_is_directory=True)
            except OSError as exc: self.skipTest('Local symlink creation unavailable: '+str(exc))
            with self.assertRaises(engine.CodeGenerationError): engine.save_session(make_session(), link)
            self.assertEqual(marker.read_text(), 'preserved')
            self.assertFalse((target/'main.py').exists())


class FixedRoleWrapperTests(unittest.TestCase):
    def test_single_role_wrappers_reject_equal_syntax_and_argparse_abbreviations(self):
        wrappers = Path(__file__).resolve().parents[1] / 'lctl'
        for role in engine.ROLES:
            wrapper = wrappers / role / 'code_agent.py'
            for arguments in (['--agents=adaptive'], ['--agents', 'adaptive'], ['--agent=adaptive'], ['--ag', 'adaptive']):
                with self.subTest(role=role, arguments=arguments):
                    result = subprocess.run([sys.executable, '-B', str(wrapper), *arguments, '--list-targets'],
                                            capture_output=True, text=True, timeout=20)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertIn('Use the shared code_cli.py', result.stderr)
            normal = subprocess.run([sys.executable, '-B', str(wrapper), '--version'], capture_output=True, text=True, timeout=20)
            self.assertEqual(normal.returncode, 0, normal.stderr)
            self.assertEqual(normal.stdout.strip(), engine.VERSION)


if __name__ == '__main__': unittest.main()
