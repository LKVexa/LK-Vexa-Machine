import type {SemanticProgram,PromptInterpretation} from './semantic-program.mjs';
import type {GeneratedBundle} from './corpus-languages.mjs';

export type CodeTaskOptions={signal?:AbortSignal;checkCancelled?:()=>boolean|null|undefined;now?:()=>Date};
export type CodeTaskRevisionOptions=CodeTaskOptions&{targetId?:string};
export type CodeTaskAgent={id:'parse'|'type-check'|'apply-edits'|'bounds-check'|'reference-preview'|'source-emission';name:string;version:'2.0.0';mode:'compiler-pass';status:'PASS';actualWork:string;changes:Array<Record<string,unknown>>;diagnostics:Array<Record<string,unknown>>;inputProgramHash:string|null;outputProgramHash:string|null};
export type CodeTask={
  schema:'cartwheel.code-task.v1';status:'PASS';mode:'compiler-task';version:'2.0.0';revision:number;targetId:string;initialPrompt:string;revisionPrompt:string|null;focusName:string|null;
  program:SemanticProgram;bytecode:Uint8Array;bundle:GeneratedBundle;source:string;compilerPasses:CodeTaskAgent[];agents:CodeTaskAgent[];
  dialogue:Array<{revision:number;kind:'generate'|'revise';prompt:string;targetId:string;programHash:string;previousTaskHash:string|null;edits:Array<Record<string,unknown>>}>;
  semanticPreview:{output:string[];assertions:number;usesClock:boolean;referenceOnly:true;runtime:string;variables:Record<string,unknown>;result:unknown};
  interpretation:PromptInterpretation|{mode:'revision';commands:string;statements:Array<{input:string;commands:string[]}>};
  provenance:{programHash:string;bytecodeHash:string;bundleHash:string;previousTaskHash:string|null;taskHash:string;integrityOnly:true;scope:string};
};
export class CodeTaskError extends Error {stage:string;code:string;diagnostics:readonly string[];compilerPasses:CodeTaskAgent[];agents:CodeTaskAgent[];constructor(message:string,options?:{stage?:string;code?:string;diagnostics?:string[];agents?:CodeTaskAgent[]});}
export function codeTaskCapabilities():{mode:'compiler-task';version:'2.0.0';neuralGeneration:false;unrestrictedSoftwareWriting:false;targetCount:number;targetIds:string[];families:string[];revisions:string[];limits:Record<string,number>&{revisions:128};nativeExecutionVerified:false};
/** Authored bounded synthesis. JSON records are frozen; mutable bytecode is
 * checked against hashes and decoded semantics before every revision. */
export function generateCodeTask(prompt:string,targetId?:string,options?:CodeTaskOptions):CodeTask;
/** Atomic revision. Source edits and output-language changes share a bounded
 * 128-revision history. Throws CodeTaskError without editing previous. */
export function reviseCodeTask(previous:CodeTask,revisionPrompt:string,options?:CodeTaskRevisionOptions):CodeTask;
