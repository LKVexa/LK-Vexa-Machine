import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { fieldFromOutline, rocketOutline } from '../src/lib/sequencer.ts';
import { planeAxes, COARSE } from '../src/lib/penteract.ts';

const fields = Array.from({length:64}, (_, index) => {
  const { i4, i5, i6 } = planeAxes(index);
  const c4=COARSE[i4],c5=COARSE[i5],c6=COARSE[i6];
  const scaleY=.86+.14*((c4+1)/2), scaleX=.9+.1*((c4+1)/2);
  const field=fieldFromOutline(rocketOutline.map(([x,y])=>[scaleX*x+c5*y/7,scaleY*y+c6*x/7]));
  return {x:Array.from(field.xBytes),y:Array.from(field.yBytes)};
});
await writeFile(new URL('../src/lib/wheel-fields.json',import.meta.url), JSON.stringify(fields));
const files = ['prompt-compiler.mjs','cartwheel-packet.mjs','semantic-program.mjs','ja-runtime.mjs','deepml-runtime.mjs','corpus-languages.mjs','reference-tensor-code.mjs','prose-reader.mjs','clock-runtime.mjs','reference-clock-code.mjs','technical-router.mjs','learned-source-generator.mjs','native-c-generator.mjs','native-managed-generators.mjs','native-script-generators.mjs','framework-generators.mjs','native-vba-generator.mjs','native-lua-generator.mjs','suite-projection-generators.mjs','project-archive.mjs'];
const sources = await Promise.all(files.map(file=>readFile(new URL('../src/lib/'+file,import.meta.url),'utf8')));
const fabricationFiles=['fabrication-renderer.mjs','fabrication-planner.mjs','fabrication-program.mjs','artifact-preview.mjs','lctl-agent-runtime.mjs'];
const fabricationSources=await Promise.all(fabricationFiles.map(file=>readFile(new URL('../src/lib/'+file,import.meta.url),'utf8')));
const codeProjectSource=await readFile(new URL('../src/lib/code-project-program.mjs',import.meta.url),'utf8');
const codeTaskSource=await readFile(new URL('../src/lib/code-task-agents.mjs',import.meta.url),'utf8');
const bytePipelineSource=await readFile(new URL('../src/lib/byte-pipeline.mjs',import.meta.url),'utf8');
const bytePipelineTables=await readFile(new URL('../src/lib/byte-pipeline-tables.json',import.meta.url),'utf8');
const codeLanguageProfiles=await readFile(new URL('../src/lib/code-language-profiles.json',import.meta.url),'utf8');
const agentCatalog=await readFile(new URL('../src/lib/lctl-agent-catalog.json',import.meta.url),'utf8');
const catalog = await readFile(new URL('../src/lib/corpus-catalog.json',import.meta.url),'utf8');
const trainedModel = await readFile(new URL('../training/technical-router/model.json',import.meta.url),'utf8');
const learnedModel = await readFile(new URL('../training/hermit-source/model.json',import.meta.url),'utf8');
const runtimeNames=['ja-runtime.mjs','deepml-runtime.mjs','clock-runtime.mjs'];
const portableRuntimeSources=runtimeNames.map(name=>({path:'runtime/'+name,content:sources[files.indexOf(name)]}));
await writeFile(new URL('../src/lib/portable-runtime-sources.json',import.meta.url),JSON.stringify(portableRuntimeSources));
// Imports form the leading module block. Native-language imports inside quoted
// templates must survive. Export declarations occur at column zero; an export
// inside a generated template is not a module declaration of this source file.
const withoutExports = source=>source.replace(/^(?:import [^\r\n]*;\r?\n)+/,'').replace(/^export\s+(?=(?:async\s+)?(?:function|const|class|let))/gm,'');
const compilerNames='compilePrompt,decodeBytecode,disassembleBytecode,generateCode,executeBytecode,hexBytes';
const packetNames='packBytecode,unpackBytecode,inspectPacket,scanLegacy,gfMul,spinByte';
const semanticNames='compileSemanticPrompt,compileUniversalPrompt,isSemanticProgram,decodeSemanticProgram,describeSemanticProgram,validateProgram,usesClockProgram,encodeSemanticProgram,parseExpression,SEMANTIC_LIMITS';
const jaNames='generateJA,executeJA';
const deepmlNames='generateDeepML,executeDeepML,createTensorEngine';
const languageNames='compileLanguagePrompt,generateTargetCode,generateTargetBundle,previewTargetBytes,describeLanguageBytes,executeGeneratedSource,LANGUAGE_TARGETS,GENERATION_PROFILES,topicsForTarget,isSourceRecord,decodeSourceRecord';
const nativeModules=[['nativeC',12,'generateNativeC'],['nativeManaged',13,'generateNativeManaged'],['nativeScript',14,'generateNativeScript'],['frameworkGenerator',15,'generateFramework'],['vbaGenerator',16,'generateNativeVBA'],['luaGenerator',17,'generateLuaLatex'],['suiteProjection',18,'generateSuiteProjection']].map(([name,index,exports])=>`const ${name}=(()=>{const {validateProgram,usesClockProgram}=semantic;const {generateJA}=jaRuntime;const {generateDeepML}=deepmlRuntime;const catalog=${catalog.replace(/</g,'\\u003c')};${withoutExports(sources[index])}\nreturn {${exports}};})();`).join('\n')+`\nconst projectZip=(()=>{${withoutExports(sources[19])}\nreturn {projectArchive,validateProjectPath};})();\n`;
const fabricationModules=`
const fabricationRenderer=(()=>{${withoutExports(fabricationSources[0])}\nreturn {validateWebsiteSpec,generateFabricatedWebsite,FABRICATION_WEB_TARGETS};})();
const fabricationPlanner=(()=>{const {validateWebsiteSpec}=fabricationRenderer;${withoutExports(fabricationSources[1])}\nreturn {isWebsiteBrief,planWebsiteBrief};})();
const fabricationCodec=(()=>{const {validateWebsiteSpec}=fabricationRenderer;${withoutExports(fabricationSources[2])}\nreturn {isFabricationProgram,validateFabricationProgram,encodeFabricationProgram,decodeFabricationProgram,describeFabricationProgram};})();
const artifactPreviewModule=(()=>{${withoutExports(fabricationSources[3])}\nreturn {artifactPreview};})();
const lctlRuntime=(()=>{const agentCatalog=${agentCatalog.replace(/</g,'\\u003c')};${withoutExports(fabricationSources[4])}\nreturn {executeLCTLAgent,lctlSha256,lctlAgentInfo,decodeLCTLImage,validateLCTLCatalog,runLCTLImage};})();
const codeProject=(()=>{const codeLanguageProfiles=${codeLanguageProfiles.replace(/</g,'\\u003c')};const {validateProjectPath}=projectZip;const {lctlSha256}=lctlRuntime;${withoutExports(codeProjectSource)}\nreturn {isCodeProjectProgram,decodeCodeProjectProgram,encodeCodeProjectProgram,describeCodeProjectProgram,validateCodeProjectRecord};})();
const bytePipeline=(()=>{const bytePipelineTables=${bytePipelineTables.replace(/</g,'\\u003c')};const {lctlSha256}=lctlRuntime;${withoutExports(bytePipelineSource)}\nreturn {processBytePipeline,recoverBytePipeline,isBytePipeline,bytePipelineInfo,canonicalBytePipelineJSON,validateBytePipelineTables};})();
`;
const script = `const FIELD_TABLES=${JSON.stringify(fields)};\nconst compiler=(()=>{${withoutExports(sources[0])}\nreturn {${compilerNames}};})();\nconst packetEngine=(()=>{${withoutExports(sources[1])}\nreturn {${packetNames}};})();\nconst proseReader=(()=>{${withoutExports(sources[7])}\nreturn {readProsePrompt};})();\nconst semantic=(()=>{const {readProsePrompt}=proseReader;${withoutExports(sources[2])}\nreturn {${semanticNames}};})();\nconst clockRuntime=(()=>{${withoutExports(sources[8])}\nreturn {createClockReader};})();\nconst clockReference=(()=>{const {createClockReader}=clockRuntime;${withoutExports(sources[9])}\nreturn {referenceClockLines};})();\nconst deepmlRuntime=(()=>{const {createClockReader}=clockRuntime;${withoutExports(sources[4])}\nreturn {${deepmlNames}};})();\nconst jaRuntime=(()=>{const {createTensorEngine}=deepmlRuntime;const {createClockReader}=clockRuntime;${withoutExports(sources[3])}\nreturn {${jaNames}};})();\nconst tensorReference=(()=>{const {validateProgram}=semantic;${withoutExports(sources[6])}\nreturn {generateTensorReference};})();\n${nativeModules}${fabricationModules}const languages=(()=>{const {isCodeProjectProgram,decodeCodeProjectProgram,describeCodeProjectProgram}=codeProject;const {isWebsiteBrief,planWebsiteBrief}=fabricationPlanner;const {isFabricationProgram,encodeFabricationProgram,decodeFabricationProgram,describeFabricationProgram}=fabricationCodec;const {generateFabricatedWebsite,FABRICATION_WEB_TARGETS}=fabricationRenderer;const portableRuntimeSources=${JSON.stringify(portableRuntimeSources).replace(/</g,"\\u003c")};const {generateNativeC}=nativeC;const {generateNativeManaged}=nativeManaged;const {generateNativeScript}=nativeScript;const {generateFramework}=frameworkGenerator;const {generateNativeVBA}=vbaGenerator;const {generateLuaLatex}=luaGenerator;const {generateSuiteProjection}=suiteProjection;const {validateProjectPath}=projectZip;const catalog=${catalog.replace(/</g,'\\u003c')};const {${compilerNames}}=compiler;const {${semanticNames}}=semantic;const {${jaNames}}=jaRuntime;const {${deepmlNames}}=deepmlRuntime;const {generateTensorReference}=tensorReference;const {referenceClockLines}=clockReference;${withoutExports(sources[5])}\nreturn {${languageNames}};})();`;
const template = await readFile(new URL('../src/playground-template.html',import.meta.url),'utf8');
const bundledScript = script + `\nconst technicalRouter=(()=>{const trainedModel=${trainedModel.replace(/</g,'\\u003c')};${withoutExports(sources[10])}\nreturn {classifyTechnicalPrompt,technicalTrainingInfo};})();\nconst learnedSource=(()=>{const {validateProgram}=semantic;const learnedModel=${learnedModel.replace(/</g,'\\u003c')};${withoutExports(sources[11])}\nreturn {generateLearnedSource};})();`;
const taskAgentScript=`\nconst codeTaskAgents=(()=>{const {compileUniversalPrompt,validateProgram,encodeSemanticProgram,decodeSemanticProgram,parseExpression,usesClockProgram,SEMANTIC_LIMITS}=semantic;const {readProsePrompt}=proseReader;const {LANGUAGE_TARGETS,generateTargetBundle,generateTargetCode,executeGeneratedSource}=languages;const {validateProjectPath}=projectZip;const {lctlSha256}=lctlRuntime;${withoutExports(codeTaskSource)}\nreturn {generateCodeTask,reviseCodeTask,CodeTaskError,codeTaskCapabilities};})();`;
const htmlSafeScript=(bundledScript+taskAgentScript).replace(/<\/script/gi,'<\\/script');
await writeFile(new URL('../playground.html',import.meta.url), template.replace('/*__BUNDLED_MODULES__*/',()=>htmlSafeScript));
if (process.env.CARTWHEEL_FRAGMENT_TEMPLATE && process.env.CARTWHEEL_FRAGMENT_OUTPUT) {
  const fragment = await readFile(process.env.CARTWHEEL_FRAGMENT_TEMPLATE, 'utf8');
  await writeFile(process.env.CARTWHEEL_FRAGMENT_OUTPUT, fragment.replace('/*__BUNDLED_MODULES__*/', () => htmlSafeScript));
}
console.log('Created standalone playground:',fileURLToPath(new URL('../playground.html',import.meta.url)));
