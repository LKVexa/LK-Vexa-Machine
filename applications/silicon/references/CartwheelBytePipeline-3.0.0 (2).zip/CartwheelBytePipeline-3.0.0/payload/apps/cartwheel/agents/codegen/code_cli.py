"""Cartwheel six-processor byte pipeline and embedded source-writing CLI."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

from code_engine import CodeTaskEngine,CodeGenerationError,save_session,validate_session,VERSION
from language_profiles import all_profiles
from portable_paths import output_directory, resolve_output_directory

def main(argv=None):
    parser=argparse.ArgumentParser(description='Process request/source bytes through six supplied compiled processors; author source with one embedded writer and bounded diagnostic repairs.')
    parser.add_argument('--prompt');parser.add_argument('--prompt-file')
    parser.add_argument('--revision');parser.add_argument('--session')
    parser.add_argument('--target')
    parser.add_argument('--engine',choices=['both','coder','vivian'],default='coder')
    parser.add_argument('--model');parser.add_argument('--vivian-root')
    parser.add_argument('--attempts',type=int,choices=range(1,5),default=4,help='Total primary writer attempts, including at most three diagnostic repairs; successful initial source ends immediately.')
    parser.add_argument('--agents',help=argparse.SUPPRESS)
    parser.add_argument('--max-tokens',type=int,default=1536)
    parser.add_argument('--context',type=int,default=8192)
    parser.add_argument('--threads',type=int,default=4)
    parser.add_argument('--plane',type=int,default=53)
    parser.add_argument('--out-dir');parser.add_argument('--list-targets',action='store_true')
    parser.add_argument('--version',action='version',version=VERSION)
    args=parser.parse_args(argv)
    if args.agents is not None:parser.error('--agents is retired for this CLI. All six byte processors are mandatory; use --attempts to bound the separate source writer.')
    if args.list_targets:
        for profile in all_profiles():print(profile['id']+'\t'+profile['sourceLanguage']+'\t'+profile.get('role',''))
        return 0
    previous=None
    if args.session:
        if args.prompt or args.prompt_file or not args.revision:parser.error('Use --session with --revision, independently of a new prompt.')
        path=Path(args.session)
        if path.stat().st_size>4194304:raise CodeGenerationError('Saved session exceeds 4 MiB.')
        previous=validate_session(json.loads(path.read_text(encoding='utf-8')));prompt=previous['initialPrompt']
        if args.target is None:args.target=previous['project']['target']
    else:
        if bool(args.prompt)==bool(args.prompt_file) or args.revision:parser.error('Provide exactly one --prompt or --prompt-file.')
        if args.prompt_file:
            path=Path(args.prompt_file)
            if path.stat().st_size>65536:raise CodeGenerationError('Prompt file exceeds 65536 UTF-8 bytes.')
            prompt=path.read_text(encoding='utf-8')
        else:prompt=args.prompt
    if not args.out_dir:parser.error('Choose a new --out-dir folder beneath ' + str(output_directory()) + '.')
    # Validate output scope before loading models or making a neural call.
    try:args.out_dir=str(resolve_output_directory(args.out_dir))
    except ValueError as exc:parser.error(str(exc))
    if args.target is None:args.target='python'
    from embedded_models import EmbeddedModel,VivianModel
    coder=EmbeddedModel(model_path=args.model,context_window=args.context,threads=args.threads) if args.engine in ('both','coder') else None
    vivian=VivianModel(vivian_root=args.vivian_root,threads=args.threads) if args.engine in ('both','vivian') else None
    engine=CodeTaskEngine(coder or vivian,vivian if args.engine=='both' else None)
    def progress(event):print(event['message'],file=sys.stderr,flush=True)
    try:
        result=engine.generate(prompt,args.target,previous=previous,revision=args.revision,attempts=args.attempts,max_tokens=args.max_tokens,on_progress=progress)
    except CodeGenerationError as exc:
        if exc.receipt:
            folder=resolve_output_directory(args.out_dir)
            folder.mkdir(parents=True,exist_ok=True)
            path=folder/'REJECTED_SOURCE_ATTEMPTS.json'
            if not path.exists():path.write_text(json.dumps(exc.receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        raise
    directory=save_session(result,args.out_dir,args.plane)
    print(json.dumps({'status':result['receipt']['status'],'directory':str(directory),'entrypoint':result['project']['entrypoint'],'runInstructions':result['project']['runInstructions'],'changedPaths':result['receipt']['changedPaths'],'executionVerified':False,'bridgeUsed':False},indent=2))
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (CodeGenerationError,OSError,ValueError,ImportError,RuntimeError) as exc:
        print(str(exc),file=sys.stderr);raise SystemExit(1)
