"""Independent strategy, byte fidelity, envelope, pin, and cancellation checks."""
from __future__ import annotations

import copy
from contextlib import redirect_stderr
from hashlib import sha256
import io
import json
from pathlib import Path
import random
import unittest
from unittest import mock

try:
    from . import byte_pipeline as b
except ImportError:
    import byte_pipeline as b


def independent_byte(agent_id: str, address: int) -> tuple[int, int]:
    """Formula oracle does not call the VM or read its instructions/tables."""
    output = 0
    opponent_previous = 0
    difference = 0
    step_count = 0
    for bit in range(8):
        if agent_id == "player_learner":
            action = int(difference > 0)
            steps = 5 + action
        elif agent_id == "player_best_reply":
            action = int(opponent_previous == 0)
            # Previous opponent zero takes the extra JMP, then MOVI review.
            steps = (8 if opponent_previous == 0 else 7) + action
        elif agent_id == "player_critic":
            action, steps = 1, 3
        elif agent_id == "player_cautious":
            action, steps = 0, 9
        else:
            raise AssertionError("Unknown independent strategy")
        output |= action << bit
        step_count += steps
        opponent = (address >> bit) & 1
        # With [[2,5],[4,1]], review-minus-draft gains +2 on zero and -4 on one.
        difference += 2 if opponent == 0 else -4
        opponent_previous = opponent
    return output, step_count


def split_artifact(artifact):
    fields = b.HEADER.unpack_from(artifact)
    size = fields[5]
    metadata = json.loads(artifact[48:48 + size])
    return fields, metadata, artifact[48 + size:]


def rewrite_artifact(artifact, metadata, body=None):
    fields, _, original_body = split_artifact(artifact)
    raw = b.canonical_bytes(metadata)
    header = b.HEADER.pack(*fields[:5], len(raw), fields[6])
    return header + raw + (original_body if body is None else body)


def refresh_chain(metadata):
    previous = metadata["sourceSha256"]
    for stage in metadata["stages"]:
        stage["previousStageSha256"] = previous
        stage.pop("stageSha256", None)
        previous = sha256(b.canonical_bytes(stage)).hexdigest()
        stage["stageSha256"] = previous
    metadata["pipelineSha256"] = previous


class BytePipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.full = bytes(range(256))
        cls.processed = b.process_bytes(cls.full)
        cls.artifact = cls.processed["artifact"]
        cls.tables = b.export_tables()

    def test_all_256_addresses_match_independent_strategies_and_steps(self):
        for slot, stage in zip(b.SLOTS, self.tables["stages"]):
            oracle = [independent_byte(slot.agent_id, address) for address in range(256)]
            self.assertEqual(stage["table"], [row[0] for row in oracle], slot.id)
            self.assertEqual(stage["tableBuild"]["vmSteps"], sum(row[1] for row in oracle), slot.id)
            self.assertEqual(stage["tableBuild"]["vmRuns"], 2048)
            self.assertEqual(stage["tableSha256"], sha256(bytes(stage["table"])).hexdigest())

    def test_all_six_lanes_are_authoritative_original_mappings(self):
        self.assertEqual(len(self.processed["lanes"]), 6)
        for lane, stage in zip(self.processed["lanes"], self.tables["stages"]):
            self.assertEqual(lane, bytes(stage["table"]))
        self.assertEqual(self.processed["lanes"][0], self.processed["lanes"][2])
        self.assertEqual(self.processed["lanes"][0], self.processed["lanes"][5])
        self.assertNotEqual(self.processed["lanes"][5], bytes([254]) * 256)
        self.assertEqual(self.processed["lanes"][3], b"\xff" * 256)
        self.assertEqual(self.processed["lanes"][4], b"\0" * 256)

    def test_binary_unicode_random_and_empty_recover_exactly(self):
        rng = random.Random(20261012)
        inputs = [b"", bytes(range(256)), b"\xff\xfe\x00\x80\xc0\xaf",
                  "雪 🦅 café\x00\n<script>execute nothing</script>".encode("utf-8"),
                  rng.randbytes(4096)]
        for original in inputs:
            result = b.process_bytes(original)
            self.assertEqual(b.recover_bytes(result["artifact"]), original)
            self.assertEqual(b.inspect_artifact(result["artifact"]), result["receipt"])
            self.assertEqual(result["receipt"]["sourceSha256"], sha256(original).hexdigest())

    def test_metadata_pins_chain_and_truthful_work(self):
        receipt = self.processed["receipt"]
        previous = receipt["sourceSha256"]
        self.assertEqual(receipt["stageCount"], 6)
        self.assertFalse(receipt["actualWork"]["semanticTaskExecution"])
        self.assertEqual(receipt["actualWork"]["payloadVmRuns"], 0)
        self.assertEqual(receipt["actualWork"]["tableBuildVmRuns"], 12288)
        self.assertEqual(receipt["actualWork"]["lookupBytes"], 1536)
        for slot, stage in zip(b.SLOTS, receipt["stages"]):
            self.assertEqual(stage["sourceArchiveSha256"], slot.source_archive_sha256)
            self.assertEqual(stage["policyImageSha256"], slot.image_sha256)
            self.assertEqual(stage["previousStageSha256"], previous)
            core = {key: value for key, value in stage.items() if key != "stageSha256"}
            self.assertEqual(stage["stageSha256"], sha256(b.canonical_bytes(core)).hexdigest())
            self.assertEqual(stage["changedBytes"], sum(a != v for a, v in zip(self.full, self.processed["lanes"][int(slot.id[-1]) - 1])))
            self.assertTrue(stage["lossy"])
            self.assertLess(stage["uniqueOutputValues"], 256)
            previous = stage["stageSha256"]
        self.assertEqual(receipt["pipelineSha256"], previous)
        self.assertEqual(receipt["stages"][2]["duplicateOf"], "processor-1")
        self.assertEqual(receipt["stages"][5]["duplicateOf"], "processor-1")

    def test_cached_calls_return_same_artifact_and_zero_current_vm_work(self):
        result = b.process_bytes(self.full)
        self.assertEqual(result["artifact"], self.artifact)
        self.assertEqual(result["work"]["tableBuild"], {"vmRuns": 0, "vmSteps": 0, "tablesBuilt": 0})
        self.assertEqual(result["work"]["lookupBytes"], 1536)

    def test_header_is_exact_documented_48_byte_profile(self):
        self.assertEqual(b.HEADER.size, 48)
        fields = b.HEADER.unpack_from(self.artifact)
        self.assertEqual(fields[:5], (b"CWBP", 1, 6, 0, 256))
        self.assertEqual(fields[6], sha256(self.full).digest())
        self.assertEqual(len(self.artifact), 48 + fields[5] + 7 * 256)

    def test_bad_headers_and_exact_length_reject(self):
        mutations = [(0, 0), (4, 2), (5, 5), (6, 1), (8, 255), (12, 0), (16, 0)]
        for offset, value in mutations:
            corrupted = bytearray(self.artifact)
            corrupted[offset] = value
            with self.assertRaises(b.BytePipelineError, msg=f"header offset {offset}"):
                b.recover_bytes(bytes(corrupted))
        for corrupted in [b"", self.artifact[:47], self.artifact[:-1], self.artifact + b"\0"]:
            with self.assertRaises(b.BytePipelineError):
                b.recover_bytes(corrupted)

    def test_original_and_every_lane_corruption_reject(self):
        fields, _, _ = split_artifact(self.artifact)
        start = 48 + fields[5]
        for part in range(7):
            corrupted = bytearray(self.artifact)
            corrupted[start + 256 * part + 50] ^= 1
            with self.assertRaises(b.BytePipelineError, msg=f"body part {part}"):
                b.recover_bytes(bytes(corrupted))

    def test_recomputed_false_lane_hashes_and_chain_reject(self):
        _, metadata, body = split_artifact(self.artifact)
        altered = bytearray(body)
        altered[256 + 42] ^= 1
        metadata["stages"][0]["outputSha256"] = sha256(altered[256:512]).hexdigest()
        metadata["stages"][0]["changedBytes"] = sum(a != v for a, v in zip(self.full, altered[256:512]))
        refresh_chain(metadata)
        with self.assertRaises(b.BytePipelineError):
            b.recover_bytes(rewrite_artifact(self.artifact, metadata, bytes(altered)))

    def test_recomputed_wrong_pins_order_fields_and_completion_reject(self):
        _, baseline, _ = split_artifact(self.artifact)
        variants = []
        changed = copy.deepcopy(baseline)
        changed["stages"][1]["policyImageSha256"] = "0" * 64
        variants.append(changed)
        changed = copy.deepcopy(baseline)
        changed["stages"][0], changed["stages"][1] = changed["stages"][1], changed["stages"][0]
        variants.append(changed)
        changed = copy.deepcopy(baseline)
        changed["taskCompleted"] = True
        variants.append(changed)
        changed = copy.deepcopy(baseline)
        changed["actualWork"]["semanticTaskExecution"] = True
        variants.append(changed)
        changed = copy.deepcopy(baseline)
        changed["stageCount"] = True
        variants.append(changed)
        changed = copy.deepcopy(baseline)
        changed["stages"] = changed["stages"][:5]
        variants.append(changed)
        for metadata in variants:
            refresh_chain(metadata)
            with self.assertRaises(b.BytePipelineError):
                b.recover_bytes(rewrite_artifact(self.artifact, metadata))

    def test_noncanonical_duplicate_invalid_unicode_and_excess_json_reject(self):
        fields, metadata, body = split_artifact(self.artifact)
        raw_variants = [json.dumps(metadata, indent=2).encode(), b'{"schema":"x","schema":"y"}',
                        b'"\xff"', b'{"number":NaN}', b'{"number":1.5}',
                        b"[" * 20 + b"0" + b"]" * 20]
        for raw in raw_variants:
            header = b.HEADER.pack(*fields[:5], len(raw), fields[6])
            with self.assertRaises(b.BytePipelineError):
                b.recover_bytes(header + raw + body)

    def test_one_mib_boundary_and_oversize_admission(self):
        original = bytes(range(256)) * (b.MAX_PAYLOAD_BYTES // 256)
        result = b.process_bytes(original)
        self.assertEqual(b.recover_bytes(result["artifact"]), original)
        with self.assertRaises(b.BytePipelineError):
            b.process_bytes(original + b"\0")
        with self.assertRaises(b.BytePipelineError):
            b.process_bytes(bytearray(b"not immutable bytes"))
        fields, _, body = split_artifact(self.artifact)
        header = b.HEADER.pack(*fields[:5], b.MAX_METADATA_BYTES + 1, fields[6])
        with self.assertRaises(b.BytePipelineError):
            b.recover_bytes(header + body)

    def test_cancellation_never_returns_complete_output(self):
        with self.assertRaises(b.BytePipelineCancelled):
            b.process_bytes(self.full, check_cancelled=lambda: True)
        with self.assertRaises(b.BytePipelineCancelled):
            b.recover_bytes(self.artifact, check_cancelled=lambda: True)
        with self.assertRaises(b.BytePipelineError):
            b.process_bytes(self.full, check_cancelled=1)
        with self.assertRaises(b.BytePipelineError):
            b.process_bytes(self.full, check_cancelled=lambda: "truthy is not a cancellation contract")
        ticks = 0
        def cancelled_during_mapping():
            nonlocal ticks
            ticks += 1
            return ticks > 10
        with self.assertRaises(b.BytePipelineCancelled):
            b.process_bytes(b"x" * 200000, check_cancelled=cancelled_during_mapping)

    def test_cancelled_table_build_is_not_cached(self):
        cached = b._TABLE_CACHE
        ticks = 0
        def cancelled_during_vm():
            nonlocal ticks
            ticks += 1
            return ticks > 30
        with mock.patch.object(b, "_TABLE_CACHE", None):
            with self.assertRaises(b.BytePipelineCancelled):
                b.process_bytes(b"x", check_cancelled=cancelled_during_vm)
            self.assertIsNone(b._TABLE_CACHE)
        self.assertIs(b._TABLE_CACHE, cached)

    def test_cached_table_rechecks_real_policy_asset_pins(self):
        original_read = b.runtime._bounded_read
        def tampered_snapshot(path, maximum):
            content = original_read(path, maximum)
            if path.name == "player_critic.brimg":
                altered = bytearray(content)
                altered[85] ^= 1
                return bytes(altered)
            return content
        with mock.patch.object(b.runtime, "_bounded_read", side_effect=tampered_snapshot):
            with self.assertRaises(b.BytePipelineError):
                b.process_bytes(b"using cached tables still checks actual image snapshots")

    def test_export_has_exact_pinned_slots_and_is_json_data(self):
        roundtrip = json.loads(b.canonical_bytes(self.tables))
        self.assertEqual(roundtrip, self.tables)
        self.assertEqual([stage["id"] for stage in self.tables["stages"]], [slot.id for slot in b.SLOTS])
        self.assertTrue(all(len(stage["table"]) == 256 for stage in self.tables["stages"]))
        self.assertEqual(self.tables["actualWork"]["lookupBytes"], 0)

    def test_cli_preserves_existing_outputs_and_sources(self):
        source = Path(__file__)
        existing_output = Path(b.__file__)
        before = sha256(existing_output.read_bytes()).hexdigest()
        with redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as error:
                b.main(["--input", str(source), "--output", str(existing_output)])
        self.assertEqual(error.exception.code, 2)
        self.assertEqual(sha256(existing_output.read_bytes()).hexdigest(), before)
        with redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                b.main(["--input", str(source), "--output", str(source)])
        exported = b.ROOT / "byte-pipeline-tables.json"
        if exported.is_file():
            before = exported.read_bytes()
            with redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    b.main(["--export-tables", str(exported)])
            self.assertEqual(exported.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
