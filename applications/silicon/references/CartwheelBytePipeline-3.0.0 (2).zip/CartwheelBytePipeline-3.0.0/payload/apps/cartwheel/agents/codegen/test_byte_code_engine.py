"""Executable integration fixtures; no neural weights or generated source execution."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import code_engine as engine
import byte_pipeline


def project(content='print(7)\n', target='python'):
    return {'name':'Byte pipeline fixture','target':target,'sourceLanguage':'Python' if target=='python' else 'JavaScript',
            'files':[{'path':'main.py' if target=='python' else 'main.js','content':content}],
            'entrypoint':'main.py' if target=='python' else 'main.js','runInstructions':'Run the selected-language entrypoint.',
            'summary':'Explicit fixture; no neural inference or source execution.'}


def verification(status='syntax_verified',diagnostics=None):
    return {'status':status,'diagnostics':diagnostics or [],'checks':[],
            'execution':{'performed':False,'status':'not-requested'}}


def verifier(value,**kwargs):
    if kwargs.get('execute') is not False:raise AssertionError('Source execution was enabled')
    return verification()


class WriterFixture:
    def __init__(self,replies=None):self.replies=list(replies or [project()]);self.calls=[]
    def generate(self,messages,**kwargs):
        self.calls.append({'messages':deepcopy(messages),'options':kwargs})
        item=self.replies[min(len(self.calls)-1,len(self.replies)-1)]
        return {'text':json.dumps(item,ensure_ascii=False) if isinstance(item,dict) else item,
                'receipt':{'provider':'unit-test-fixture','neuralInferencePerformed':False,'call':len(self.calls)}}


def task(model=None,verify=verifier):return engine.CodeTaskEngine(model or WriterFixture(),verifier=verify)
def rehash(session):session['sessionSha256']=engine.digest({k:v for k,v in session.items() if k!='sessionSha256'});return session


class ByteSourcePipelineTests(unittest.TestCase):
    def test_default_runs_all_six_processors_and_only_one_successful_writer_call(self):
        model=WriterFixture();session=task(model).generate('Print seven. 😀',max_tokens=128)
        receipt=session['receipt']
        self.assertEqual(len(model.calls),1)
        self.assertNotIn('agents',receipt)
        self.assertEqual(len(receipt['generationAttempts']),1)
        for item in (receipt['bytePipeline']['input'],receipt['bytePipeline']['source']):
            self.assertEqual(item['stageCount'],6);self.assertEqual(len(item['stages']),6)
        self.assertEqual(receipt['bytePipeline']['sourceSha256'],engine.digest(session['project']))
        self.assertNotIn('agent',model.calls[0]['messages'][0]['content'].lower())
        self.assertFalse(receipt['executionVerified'])
        self.assertEqual(engine.validate_session(session),session)

    def test_actual_admission_and_syntax_errors_trigger_bounded_repairs(self):
        model=WriterFixture(['bad JSON',project('print(\n'),project()]);observed=[]
        def check(value,**kwargs):
            self.assertFalse(kwargs['execute']);observed.append(value['files'][0]['content'])
            return verification('invalid',[{'severity':'error','message':'Unclosed parenthesis'}]) if value['files'][0]['content']=='print(\n' else verification()
        session=task(model,check).generate('Print seven.',max_tokens=128)
        self.assertEqual(len(model.calls),3)
        self.assertIn('complete valid JSON',model.calls[1]['messages'][1]['content'])
        self.assertIn('Unclosed parenthesis',model.calls[2]['messages'][1]['content'])
        self.assertEqual([s['outcome'] for s in session['receipt']['generationAttempts']],['rejected','rejected','adopted'])
        bad=WriterFixture(['not JSON'])
        with self.assertRaises(engine.CodeGenerationError) as caught:task(bad).generate('Print seven.',max_tokens=128)
        self.assertEqual(len(bad.calls),4)
        self.assertEqual(len(caught.exception.receipt['generationAttempts']),4)

    def test_revision_history_latest_priority_and_previous_preserved(self):
        previous=task().generate('Print seven.',max_tokens=128);copy=deepcopy(previous)
        model=WriterFixture([project(),project('print(9)\n')])
        revised=task(model).generate('Print seven.',previous=previous,revision='Print nine instead.',max_tokens=128)
        self.assertEqual(previous,copy)
        self.assertEqual(len(model.calls),2)
        second=WriterFixture([project('print(11)\n')])
        final=task(second).generate('Print seven.',previous=revised,revision='Now print eleven.',max_tokens=128)
        context=second.calls[0]['messages'][1]['content']
        self.assertLess(context.index('Print nine instead.'),context.index('Now print eleven.'))
        self.assertEqual(len(final['dialogue']),3)
        self.assertEqual(engine.validate_session(final),final)
        with self.assertRaises(engine.CodeGenerationError):task(WriterFixture([project()])).generate('Print seven.',previous=previous,revision='Print nine.',max_tokens=128)
        self.assertEqual(previous,copy)

    def test_alternative_has_one_independent_attempt_and_does_not_substitute_silently(self):
        primary=WriterFixture();alt=WriterFixture([project('print(9)\n')])
        session=engine.CodeTaskEngine(primary,alt,verifier=verifier).generate('Print seven.',max_tokens=128)
        self.assertEqual(len(primary.calls),1);self.assertEqual(len(alt.calls),1)
        self.assertEqual(session['project'],project())
        self.assertEqual(len(session['receipt']['generationAttempts']),2)
        self.assertIn('never substitutes silently',session['receipt']['generationAttempts'][1]['engineUse'])

    def test_recovered_bytes_source_record_and_export_are_exact(self):
        session=task(WriterFixture([project('print("é 漢字 😀")\n')])).generate('Print Unicode.',max_tokens=128)
        encoded=engine.encode_project_record(session)
        recovered=engine.decode_project_record(engine.unpack_record(engine.pack_record(encoded)))
        self.assertEqual(recovered['project'],session['project'])
        self.assertEqual(recovered['provenance']['source'],'embedded-writer-after-byte-pipeline')
        self.assertEqual(recovered['provenance']['bytePipeline']['sourceSha256'],engine.digest(session['project']))
        test_work=Path(__file__).resolve().parent/'test-work';test_work.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=test_work) as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(test_work.resolve()))
            directory=Path(folder)/'fresh'
            with patch.object(engine,'resolve_output_directory',lambda value:Path(value).resolve()):engine.save_session(session,directory)
            self.assertEqual(byte_pipeline.recover_bytes((directory/'byte-pipeline.cwbp').read_bytes()),engine.canonical(session['project']))
            self.assertTrue((directory/'cartwheel-byte-receipt.json').exists())
            self.assertFalse((directory/'cartwheel-agent-receipt.json').exists())
            self.assertEqual((directory/'main.py').read_text(encoding='utf-8'),session['project']['files'][0]['content'])

    def test_pipeline_corruption_and_rehashed_false_evidence_reject_before_inference(self):
        model=WriterFixture()
        with patch.object(byte_pipeline,'recover_bytes',return_value=b'corrupt'):
            with self.assertRaises(engine.CodeGenerationError):task(model).generate('Print seven.',max_tokens=128)
        self.assertFalse(model.calls)
        session=task().generate('Print seven.',max_tokens=128)
        for change in (lambda s:s['receipt']['bytePipeline'].update(sourceSha256='0'*64),
                       lambda s:s['receipt']['bytePipeline']['source'].update(stageCount=5),
                       lambda s:s['receipt']['bytePipeline']['source']['stages'][0].update(outputSha256='0'*64),
                       lambda s:s['receipt'].update(processors=[]),
                       lambda s:s['receipt'].update(executionVerified=True)):
            damaged=deepcopy(session);change(damaged);rehash(damaged)
            with self.assertRaises(engine.CodeGenerationError):engine.validate_session(damaged)

    def test_cancellation_and_mutating_verifier_cannot_commit(self):
        model=WriterFixture()
        with self.assertRaises(engine.CodeGenerationError):task(model).generate('Print seven.',check_cancelled=lambda:True)
        self.assertFalse(model.calls)
        def malicious(value,**kwargs):value['files'][0]['content']='changed';return verification()
        with self.assertRaises(engine.CodeGenerationError):task(WriterFixture(),malicious).generate('Print seven.',max_tokens=128)

    def test_legacy_explicit_api_sessions_still_read_and_export(self):
        session=task().generate('Print seven.',roles=['proposal'],max_tokens=128)
        self.assertEqual(session['version'],'2.0.0')
        self.assertEqual(engine.validate_session(session),session)
        self.assertEqual(engine.decode_project_record(engine.encode_project_record(session))['provenance']['version'],'2.0.0')

    def test_malformed_saved_receipts_reject_with_admission_errors(self):
        session=task().generate('Print seven.',max_tokens=128)
        for change in (lambda s:s['receipt'].pop('verification'),
                       lambda s:s['receipt'].update(verification=None),
                       lambda s:s['receipt']['verification'].pop('status'),
                       lambda s:s['receipt']['generationAttempts'][0].pop('id'),
                       lambda s:s['receipt']['generationAttempts'][0].update(changedPaths=None),
                       lambda s:s['receipt'].update(schema='invented'),
                       lambda s:s['receipt']['bytePipeline'].pop('source')):
            damaged=deepcopy(session);change(damaged);rehash(damaged)
            with self.assertRaises(engine.CodeGenerationError):engine.validate_session(damaged)
            with self.assertRaises(engine.CodeGenerationError):engine.encode_project_record(damaged)


if __name__=='__main__':unittest.main()
