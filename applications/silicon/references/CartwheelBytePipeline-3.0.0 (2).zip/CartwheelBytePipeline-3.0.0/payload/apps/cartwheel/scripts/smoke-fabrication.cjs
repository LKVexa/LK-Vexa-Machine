// Website composition is validated directly; processors retain independent lanes.
require('./smoke-byte-pipeline.cjs');
