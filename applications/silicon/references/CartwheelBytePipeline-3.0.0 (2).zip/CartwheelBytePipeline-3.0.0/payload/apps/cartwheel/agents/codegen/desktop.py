"""Native workbench for six compiled byte processors and an embedded source writer."""
from __future__ import annotations
import json
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk,filedialog,messagebox

from code_engine import CodeTaskEngine,CodeGenerationError,save_session,validate_session,VERSION,ROOT
from language_profiles import all_profiles
from portable_paths import PORTABLE, output_directory

class Workbench:
    def __init__(self,window):
        self.window=window;self.session=None;self.models={};self.events=queue.Queue();self.stop=threading.Event();self.busy=False
        self.profiles=all_profiles();self.labels={p.get('label',p['id'])+' · '+p['id']:p['id'] for p in self.profiles}
        window.title('Cartwheel byte processor pipeline '+VERSION);window.geometry('1180x850')
        outer=ttk.Frame(window,padding=18);outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='Write, revise, inspect',font=('Segoe UI',20,'bold')).pack(anchor='w')
        ttk.Label(outer,text='Six compiled processors preserve and inspect request/source bytes. One embedded writer authors source, with bounded repairs for actual diagnostics. Source is syntax checked; it is not automatically executed.').pack(anchor='w',pady=(4,14))
        selectors=ttk.Frame(outer);selectors.pack(fill='x')
        ttk.Label(selectors,text='Output language').grid(row=0,column=0,sticky='w')
        self.target=tk.StringVar(value=next(k for k,v in self.labels.items() if v=='html5'))
        self.target_box=ttk.Combobox(selectors,textvariable=self.target,values=list(self.labels),state='readonly',width=54);self.target_box.grid(row=1,column=0,padx=(0,18))
        ttk.Label(selectors,text='Source author').grid(row=0,column=1,sticky='w')
        self.engine=tk.StringVar(value='Embedded coder')
        self.engine_box=ttk.Combobox(selectors,textvariable=self.engine,values=['Embedded coder + VIVIAN alternative','Embedded coder','VIVIAN experimental only'],state='readonly',width=39);self.engine_box.grid(row=1,column=1)
        ttk.Label(outer,text='Your prose prompt').pack(anchor='w',pady=(16,5))
        self.prompt=tk.Text(outer,height=5,wrap='word');self.prompt.pack(fill='x');self.prompt.insert('1.0','Create a complete mock landing page for a fictional bicycle repair shop called Copper Spoke. Include a service list, a responsive navigation menu, and a local appointment request form that validates input and clearly says nothing is sent. Use a warm cream background and dark green accents.')
        row=ttk.Frame(outer);row.pack(fill='x',pady=9)
        self.generate_button=ttk.Button(row,text='Generate new code',command=self.generate);self.generate_button.pack(side='left')
        self.cancel_button=ttk.Button(row,text='Cancel',command=self.stop.set,state='disabled');self.cancel_button.pack(side='left',padx=9)
        self.save_button=ttk.Button(row,text='Save complete project',command=self.save,state='disabled');self.save_button.pack(side='left')
        ttk.Button(row,text='Open saved session',command=self.load).pack(side='right')
        ttk.Label(outer,text='Revision request').pack(anchor='w')
        self.revision=tk.Text(outer,height=2,wrap='word');self.revision.pack(fill='x',pady=5);self.revision.insert('1.0','Add an accessible FAQ section with three questions and an expandable answer for each. Preserve the rest of the page.')
        self.revise_button=ttk.Button(outer,text='Revise current code',command=self.revise,state='disabled');self.revise_button.pack(anchor='w')
        self.status=tk.StringVar(value='Choose a language and generate. The byte processors run before source inference; first model loading can take a little time.')
        ttk.Label(outer,textvariable=self.status,wraplength=1080).pack(anchor='w',pady=10)
        notebook=ttk.Notebook(outer);notebook.pack(fill='both',expand=True)
        source_tab=ttk.Frame(notebook,padding=8);trace_tab=ttk.Frame(notebook,padding=8)
        notebook.add(source_tab,text='Generated files');notebook.add(trace_tab,text='Processor and writer receipts')
        self.file=tk.StringVar();self.file_box=ttk.Combobox(source_tab,textvariable=self.file,state='readonly');self.file_box.pack(fill='x');self.file_box.bind('<<ComboboxSelected>>',lambda event:self.show_file())
        self.source=tk.Text(source_tab,wrap='none',font=('Consolas',11));self.source.pack(fill='both',expand=True,pady=8)
        self.trace=tk.Text(trace_tab,wrap='word',font=('Consolas',10));self.trace.pack(fill='both',expand=True)
        window.after(100,self.poll);window.protocol('WM_DELETE_WINDOW',self.close)

    def model_pair(self,choice):
        from embedded_models import EmbeddedModel,VivianModel
        coder=None;vivian=None
        if choice!='VIVIAN experimental only':
            if 'coder' not in self.models:self.models['coder']=EmbeddedModel(context_window=8192,threads=4)
            coder=self.models['coder']
        if choice!='Embedded coder':
            if 'vivian' not in self.models:self.models['vivian']=VivianModel(threads=4)
            vivian=self.models['vivian']
        return coder or vivian,vivian if choice=='Embedded coder + VIVIAN alternative' else None

    def begin(self,prompt,previous=None,revision=None):
        if self.busy:return
        self.busy=True;self.stop.clear()
        self.generate_button.configure(state='disabled');self.revise_button.configure(state='disabled');self.cancel_button.configure(state='normal');self.save_button.configure(state='disabled')
        target=self.labels[self.target.get()];choice=self.engine.get()
        self.target_box.configure(state='disabled');self.engine_box.configure(state='disabled')
        self.status.set('Starting the six byte processors and explicit source author…')
        def work():
            try:
                primary,experimental=self.model_pair(choice)
                result=CodeTaskEngine(primary,experimental).generate(prompt,target,previous=previous,revision=revision,check_cancelled=self.stop.is_set,on_progress=lambda event:self.events.put(('progress',event['message'])))
                self.events.put(('success',result))
            except Exception as exc:self.events.put(('failure',(str(exc),getattr(exc,'receipt',None))))
        threading.Thread(target=work,daemon=True).start()

    def generate(self):self.begin(self.prompt.get('1.0','end').strip())
    def revise(self):
        if self.session:self.begin(self.session['initialPrompt'],previous=self.session,revision=self.revision.get('1.0','end').strip())
    def set_text(self,widget,text):widget.configure(state='normal');widget.delete('1.0','end');widget.insert('1.0',text);widget.configure(state='disabled')
    def display(self):
        project=self.session['project'];self.file_box.configure(values=[f['path'] for f in project['files']]);self.file.set(project['entrypoint']);self.show_file()
        rows=[]
        receipt=self.session['receipt']
        if receipt.get('bytePipeline'):
            rows.append('All six supplied compiled processors ran on the request and final source. Policy lanes are evidence; the original bytes are recovered exactly.\n')
            for step in receipt.get('processors',[]):
                rows.append(str(step.get('name',step.get('id',step.get('slot','Processor'))))+'\n'+str(step.get('actualWork','Compiled byte policy lane'))+'\n')
        for step in receipt.get('generationAttempts',receipt.get('agents',[])):
            rows.append(step.get('name',step['id'])+' — '+step['outcome']+'\n'+step['actualWork']+'\nChanged files: '+(', '.join(step['changedPaths']) or 'none')+'\n')
        rows.append('Full receipt:\n'+json.dumps(receipt,indent=2,ensure_ascii=False));self.set_text(self.trace,'\n'.join(rows))
        self.status.set(self.session['receipt']['status']+'. '+project['runInstructions']+' Source execution has not been verified.')
    def show_file(self):
        if self.session:
            content=next((f['content'] for f in self.session['project']['files'] if f['path']==self.file.get()),'');self.set_text(self.source,content)
    def finish(self):
        self.busy=False;self.generate_button.configure(state='normal');self.cancel_button.configure(state='disabled');self.target_box.configure(state='readonly');self.engine_box.configure(state='readonly')
        self.revise_button.configure(state='normal' if self.session else 'disabled');self.save_button.configure(state='normal' if self.session else 'disabled')
    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='progress':self.status.set(value)
                elif kind=='success':self.session=value;self.display();self.finish()
                else:
                    message,receipt=value;self.status.set(message+' Previous project is preserved.');self.finish()
                    if receipt:self.set_text(self.trace,json.dumps(receipt,indent=2,ensure_ascii=False))
        except queue.Empty:pass
        if self.window.winfo_exists():self.window.after(100,self.poll)
    def save(self):
        if not self.session or self.busy:return
        root=output_directory()/'generated' if PORTABLE else ROOT/'examples/neural-generated'
        directory=root/(time.strftime('%Y%m%d-%H%M%S')+'-'+self.session['id'][:8])
        try:save_session(self.session,directory);self.status.set('Saved source, packet, session, six-processor artifact and writer receipts to '+str(directory))
        except Exception as exc:messagebox.showerror('Save failed',str(exc))
    def load(self):
        if self.busy:return
        path=filedialog.askopenfilename(title='Open a Cartwheel code session',initialdir=str(output_directory()),filetypes=[('Cartwheel session','*.json')])
        if not path:return
        try:
            if Path(path).stat().st_size>4194304:raise ValueError('Saved session exceeds 4 MiB.')
            self.session=validate_session(json.loads(Path(path).read_text(encoding='utf-8')));self.display();self.finish()
            self.target.set(next(k for k,v in self.labels.items() if v==self.session['project']['target']))
        except Exception as exc:messagebox.showerror('Session rejected',str(exc))
    def close(self):self.stop.set();self.window.destroy()

if __name__=='__main__':
    window=tk.Tk();Workbench(window);window.mainloop()
