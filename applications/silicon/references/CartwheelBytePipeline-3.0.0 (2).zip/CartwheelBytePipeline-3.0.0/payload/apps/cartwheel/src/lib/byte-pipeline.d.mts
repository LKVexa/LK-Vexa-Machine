export type BytePipelineResult={artifact:Uint8Array;payload:Uint8Array;lanes:Uint8Array[];receipt:Readonly<Record<string,any>>};
export function processBytePipeline(input:Uint8Array):BytePipelineResult;
export function recoverBytePipeline(artifact:Uint8Array):Omit<BytePipelineResult,'artifact'>;
export function isBytePipeline(bytes:Uint8Array):boolean;
export function bytePipelineInfo():Readonly<Record<string,any>>;
export function canonicalBytePipelineJSON(value:unknown):string;
export function validateBytePipelineTables(manifest?:unknown):unknown;
