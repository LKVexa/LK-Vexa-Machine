print("é 漢字 😀")
