"""Six pinned compiled policies applied to original bytes in retained side lanes.

CWBP v1 is an integrity-checked container, not encryption or a semantic task
runner. Its original payload remains authoritative because the policy lanes are
lossy. Every table address starts a fresh eight-round LSB-first VM observation.
The current original bit is disclosed only after the policy writes its action.
"""
from __future__ import annotations

import argparse
import copy
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import struct
import threading
from typing import Callable

ROOT = Path(__file__).resolve().parent
MAX_PAYLOAD_BYTES = 1_048_576
MAX_METADATA_BYTES = 65_536
STAGE_COUNT = 6
HEADER = struct.Struct("<4sBBHII32s")
MAGIC = b"CWBP"
VERSION = 1
PAYOFFS = ((2, 5), (4, 1))
SCHEMA = "codex.byte-pipeline.receipt.v1"
TABLE_SCHEMA = "codex.byte-pipeline.tables.v1"
TRANSFORM = {
    "id": "lctl-byte-lanes.v1",
    "bitOrder": "lsb-first",
    "roundsPerAddress": 8,
    "payoffs": [[2, 5], [4, 1]],
    "stateReset": "per-byte-value",
    "laneInput": "original-payload",
}
LIMITS = {"payloadBytes": MAX_PAYLOAD_BYTES, "metadataBytes": MAX_METADATA_BYTES}


class BytePipelineError(ValueError):
    """Invalid bytes, policy assets, or CWBP integrity evidence."""


class BytePipelineCancelled(BytePipelineError):
    """Processing stopped before returning a completed artifact."""


_RUNTIME_PINS = {
    "runtime.py": "937223bacd6fa654dcb59f80d395731123a30a26b77a3c61052fb8a2bba2d939",
    "brim_ref.py": "333b8bcf2c876efb6aec1373f24aa21da83e26036fecedd5bdcb99f10cae3056",
}


def _read_bounded(path: Path, maximum: int) -> bytes:
    with path.open("rb") as handle:
        content = handle.read(maximum + 1)
    if len(content) > maximum:
        raise BytePipelineError(f"Input file exceeds {maximum} bytes")
    return content


def _verify_runtime_assets() -> None:
    for name, expected in _RUNTIME_PINS.items():
        path = ROOT / "policy_runtime" / name
        try:
            content = _read_bounded(path, 262_144)
        except OSError as exc:
            raise BytePipelineError(f"Cannot read pinned reference runtime: {name}") from exc
        if len(content) > 262_144 or sha256(content).hexdigest() != expected:
            raise BytePipelineError(f"Reference runtime pin mismatch: {name}")


# Verify the two vendored source snapshots before importing either file.
_verify_runtime_assets()
try:
    from .policy_runtime import runtime
except ImportError:
    from policy_runtime import runtime


@dataclass(frozen=True)
class Slot:
    id: str
    name: str
    source_archive: str
    source_archive_sha256: str
    agent_id: str
    source_sha256: str
    image_sha256: str
    brir_sha256: str
    duplicate_of: str | None = None

    def identity(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "sourceArchive": self.source_archive,
            "sourceArchiveSha256": self.source_archive_sha256,
            "agentId": self.agent_id,
            "policySourceSha256": self.source_sha256,
            "policyImageSha256": self.image_sha256,
            "policyBrirSha256": self.brir_sha256,
            "duplicateOf": self.duplicate_of,
        }

    def pins(self) -> dict:
        return {
            "source_sha256": self.source_sha256,
            "image_sha256": self.image_sha256,
            "brir_sha256": self.brir_sha256,
        }


SLOTS = (
    Slot("processor-1", "Adaptive 1", "XZoRNj76KD3urnia-grok-workspace.zip",
         "da47af81d257c1d791d21cb362165af99e5653a35586f75f1db248dff2f3d42f",
         "player_learner", "d90f31e1955a8cc40a60d01dd4e5c1c0fd553e4261175017a8e7341c8eca5ac5",
         "46eb8daefaa53a222f915276ae04f9a788338b01f81cdf939fe72baa40bf5619",
         "b7fe2c5b77f2d8b3c02aa99538814dfbb1cbaf00795bc38d3c66bf3d512f853e"),
    Slot("processor-2", "Best Reply", "royal-eagle-fern-daisy-main.zip",
         "62aab08dda30a95f77b0016b03503c82e1a691e9fee6ebcde87c003bd38a05d3",
         "player_best_reply", "7645ffa4d1e20cd1b300b22ea985f1f496ebeb02888e7a240aa8f098bc6a989c",
         "a54c6c0185fd684bb45f33f105a22cfda2f2a38a592e1e8be5f715cbfc0d0db4",
         "23447d00c5bf5b82e603e57a10cf1827df30143e8cd577bbe84663e357da1b1b"),
    Slot("processor-3", "Adaptive 2", "Rz15aCprUVAm8qt2-grok-workspace.zip",
         "7fee04ace366841108c5435f054fb3f0ec8a45960257ac602610c912eb9c0dec",
         "player_learner", "d90f31e1955a8cc40a60d01dd4e5c1c0fd553e4261175017a8e7341c8eca5ac5",
         "46eb8daefaa53a222f915276ae04f9a788338b01f81cdf939fe72baa40bf5619",
         "b7fe2c5b77f2d8b3c02aa99538814dfbb1cbaf00795bc38d3c66bf3d512f853e", "processor-1"),
    Slot("processor-4", "Critique", "6GBVjumHKri0aCf7-grok-workspace.zip",
         "b4aa68c9ea719da70a417397fb24ee45040458ed0ce6ac1257fd3c7c66b5fa39",
         "player_critic", "8cd15080fd2a717b509891975cb16b791ca98cc8fe1263ac69188a4575e15ffc",
         "3c233d8f4b5786f99c9f3377df90bdf03519477d811633bec8720b9fa8827a8d",
         "dd3db47b025691d7eed7a0d55c6bafe44eb79a49658b75a274f9823e0e75c450"),
    Slot("processor-5", "Cautious", "SLMn2577cgd5QNKx-grok-workspace.zip",
         "be9d5cabc61eaa01cc7922a9e1196c079ced7856fdcb7aeb16a5958a4389bcfb",
         "player_cautious", "29c5443123bc6dc104b7d9f3e7f66c26d00bde44332e379be43605f42189b2e7",
         "5d10c93736d69b20a31311c7e736de5ba43cd0a2f1b94a97988ca32c81d3401a",
         "3db4677375194ce77634b50860d85cafee136368e3d1145719bd346ccd0dbd5b"),
    Slot("processor-6", "Adaptive 3", "AjS7wUlxjiuPhXQg-grok-workspace.zip",
         "70c09034d80f816110a27cd022f029daaae22bcb41857bd1595c39c58145f96e",
         "player_learner", "d90f31e1955a8cc40a60d01dd4e5c1c0fd553e4261175017a8e7341c8eca5ac5",
         "46eb8daefaa53a222f915276ae04f9a788338b01f81cdf939fe72baa40bf5619",
         "b7fe2c5b77f2d8b3c02aa99538814dfbb1cbaf00795bc38d3c66bf3d512f853e", "processor-1"),
)


@dataclass(frozen=True)
class PolicyTable:
    values: bytes
    vm_steps: int

    @property
    def digest(self) -> str:
        return sha256(self.values).hexdigest()

    @property
    def unique_values(self) -> int:
        return len(set(self.values))


_TABLE_CACHE: tuple[PolicyTable, ...] | None = None
_TABLE_LOCK = threading.Lock()


def canonical_bytes(value: object) -> bytes:
    """The artifact's cross-language canonical JSON for admitted metadata."""
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise BytePipelineError("Metadata is not canonical UTF-8 JSON") from exc


def _digest(value: object) -> str:
    return sha256(canonical_bytes(value)).hexdigest()


def _check(callback: Callable[[], object] | None) -> None:
    if callback is not None:
        if not callable(callback):
            raise BytePipelineError("check_cancelled must be callable or None")
        cancelled = callback()
        if cancelled is not None and type(cancelled) is not bool:
            raise BytePipelineError("check_cancelled must return bool or None")
        if cancelled is True:
            raise BytePipelineCancelled("Byte pipeline cancelled")


def _load_program(slot: Slot):
    policy_dir = ROOT / "byte_policies" / slot.id
    try:
        manifest_bytes = _read_bounded(policy_dir / "agent.json", 4096)
        manifest = json.loads(manifest_bytes.decode("utf-8"), object_pairs_hook=_unique_keys)
        if (type(manifest) is not dict or manifest.get("agent_id") != slot.agent_id
                or manifest.get("policy_sha256") != slot.pins()):
            raise BytePipelineError(f"Policy manifest mismatch: {slot.id}")
        return runtime.load_program(
            policy_dir / f"{slot.agent_id}.lctlc",
            policy_dir / f"{slot.agent_id}.brimg",
            policy_dir / f"{slot.agent_id}.brir",
            expected_hashes=slot.pins(),
        )
    except (OSError, UnicodeError, ValueError, TypeError, RecursionError) as exc:
        raise BytePipelineError(f"Cannot admit pinned policy {slot.id}: {exc}") from exc


def _build_table(program, callback) -> PolicyTable:
    values = bytearray(256)
    total_steps = 0
    for address in range(256):
        _check(callback)
        previous_own = previous_opponent = 0
        cumulative = [0, 0]
        output = 0
        for bit in range(8):
            inputs = [bit, previous_opponent, previous_own,
                      *[value + 1000 for row in PAYOFFS for value in row],
                      cumulative[0] + 100000, cumulative[1] + 100000]
            # The current address bit is absent from inputs until after HALT.
            result = runtime.run_program(program, inputs, check_cancelled=lambda: _check(callback))
            action = result["registers"][15]
            if type(action) is not int or action not in (0, 1):
                raise BytePipelineError("Compiled policy action is outside its bit contract")
            output |= action << bit
            total_steps += result["steps"]
            opponent = (address >> bit) & 1
            cumulative = [cumulative[row] + PAYOFFS[row][opponent] for row in range(2)]
            previous_own, previous_opponent = action, opponent
        values[address] = output
    return PolicyTable(bytes(values), total_steps)


def _ensure_tables(callback=None) -> tuple[tuple[PolicyTable, ...], dict]:
    global _TABLE_CACHE
    _check(callback)
    _verify_runtime_assets()
    # Recheck all source/image/IR snapshots even when the table is cached.
    programs = []
    for slot in SLOTS:
        _check(callback)
        programs.append(_load_program(slot))
    with _TABLE_LOCK:
        if _TABLE_CACHE is not None:
            return _TABLE_CACHE, {"vmRuns": 0, "vmSteps": 0, "tablesBuilt": 0}
        tables = tuple(_build_table(program, callback) for program in programs)
        _TABLE_CACHE = tables
        return tables, {"vmRuns": STAGE_COUNT * 256 * 8,
                        "vmSteps": sum(table.vm_steps for table in tables),
                        "tablesBuilt": STAGE_COUNT}


def _actual_work(byte_count: int, table_count: int = STAGE_COUNT) -> dict:
    # These table-build counts describe the attached LUT's generation, not the
    # current call. Current call build/cache statistics live in result['work'].
    return {"kind": "byte-transform", "semanticTaskExecution": False,
            "payloadVmRuns": 0, "lookupBytes": byte_count * table_count,
            "tableBuildVmRuns": 256 * 8 * table_count}


def _map_lane(data: bytes, table: bytes, callback) -> bytes:
    pieces = []
    for offset in range(0, len(data), 65536):
        _check(callback)
        pieces.append(data[offset:offset + 65536].translate(table))
    _check(callback)
    return b"".join(pieces)


def _validate_payload(data: bytes) -> None:
    if type(data) is not bytes:
        raise BytePipelineError("Payload must be bytes")
    if len(data) > MAX_PAYLOAD_BYTES:
        raise BytePipelineError("Original payload exceeds 1048576 bytes")


def process_bytes(data: bytes, check_cancelled=None) -> dict:
    """Return deterministic artifact bytes, all lanes, receipt, and call work.

    The artifact records table-generation VM work separately from cached payload
    lookups. result['work'] reports VM work actually performed in this call.
    """
    _validate_payload(data)
    _check(check_cancelled)
    tables, build_work = _ensure_tables(check_cancelled)
    source_hash = sha256(data).hexdigest()
    lanes = []
    records = []
    previous_hash = source_hash
    for slot, table in zip(SLOTS, tables):
        _check(check_cancelled)
        lane = _map_lane(data, table.values, check_cancelled)
        record = {
            **slot.identity(),
            "inputSha256": source_hash,
            "outputSha256": sha256(lane).hexdigest(),
            "previousStageSha256": previous_hash,
            "inputBytes": len(data),
            "outputBytes": len(lane),
            "changedBytes": sum(a != b for a, b in zip(data, lane)),
            "uniqueOutputValues": table.unique_values,
            "tableSha256": table.digest,
            "lossy": table.unique_values < 256,
            "actualWork": _actual_work(len(data), 1),
        }
        record["stageSha256"] = _digest(record)
        previous_hash = record["stageSha256"]
        records.append(record)
        lanes.append(lane)
    receipt = {
        "schema": SCHEMA,
        "format": "CWBP",
        "version": VERSION,
        "stageCount": STAGE_COUNT,
        "payloadBytes": len(data),
        "sourceSha256": source_hash,
        "transform": copy.deepcopy(TRANSFORM),
        "limits": dict(LIMITS),
        "exactRecovery": {"supported": True, "mechanism": "original-payload-retained"},
        "actualWork": _actual_work(len(data)),
        "stages": records,
        "pipelineSha256": previous_hash,
    }
    metadata = canonical_bytes(receipt)
    if len(metadata) > MAX_METADATA_BYTES:
        raise BytePipelineError("Receipt metadata exceeds 65536 bytes")
    header = HEADER.pack(MAGIC, VERSION, STAGE_COUNT, 0, len(data), len(metadata),
                         bytes.fromhex(source_hash))
    _check(check_cancelled)
    return {"artifact": header + metadata + data + b"".join(lanes),
            "receipt": receipt, "lanes": lanes,
            "work": {"tableBuild": build_work,
                     "lookupBytes": STAGE_COUNT * len(data), "payloadVmRuns": 0}}


def _unique_keys(pairs) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise BytePipelineError("Duplicate JSON metadata key")
        result[key] = value
    return result


def _reject_constant(value):
    raise BytePipelineError(f"Non-finite JSON metadata: {value}")


def _parse_artifact(artifact: bytes, callback):
    _check(callback)
    if type(artifact) is not bytes:
        raise BytePipelineError("Artifact must be bytes")
    if not HEADER.size <= len(artifact) <= HEADER.size + MAX_METADATA_BYTES + (STAGE_COUNT + 1) * MAX_PAYLOAD_BYTES:
        raise BytePipelineError("Artifact length is outside its bounds")
    magic, version, count, reserved, payload_len, metadata_len, original_hash = HEADER.unpack_from(artifact)
    if (magic, version, count, reserved) != (MAGIC, VERSION, STAGE_COUNT, 0):
        raise BytePipelineError("Unsupported CWBP header")
    if payload_len > MAX_PAYLOAD_BYTES or not 1 <= metadata_len <= MAX_METADATA_BYTES:
        raise BytePipelineError("CWBP payload or metadata length exceeds bounds")
    expected_length = HEADER.size + metadata_len + (STAGE_COUNT + 1) * payload_len
    if len(artifact) != expected_length:
        raise BytePipelineError("CWBP requires its exact declared length")
    raw_metadata = artifact[HEADER.size:HEADER.size + metadata_len]
    try:
        metadata = json.loads(raw_metadata.decode("utf-8"), object_pairs_hook=_unique_keys,
                              parse_constant=_reject_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise BytePipelineError("Invalid CWBP UTF-8 JSON metadata") from exc
    # Bound depth/nodes and forbid numeric coercion before comparing to replay.
    pending = [(metadata, 0)]
    nodes = 0
    while pending:
        _check(callback)
        value, depth = pending.pop()
        nodes += 1
        if depth > 16 or nodes > 4096:
            raise BytePipelineError("Metadata exceeds structural bounds")
        if type(value) is dict:
            pending.extend((child, depth + 1) for child in value.values())
        elif type(value) is list:
            pending.extend((child, depth + 1) for child in value)
        elif type(value) not in (str, int, bool, type(None)):
            raise BytePipelineError("Metadata contains unsupported values")
    if canonical_bytes(metadata) != raw_metadata:
        raise BytePipelineError("CWBP metadata must use exact canonical encoding")
    payload_offset = HEADER.size + metadata_len
    original = artifact[payload_offset:payload_offset + payload_len]
    if sha256(original).digest() != original_hash:
        raise BytePipelineError("Retained original payload hash mismatch")
    return original, metadata


def recover_bytes(artifact: bytes, check_cancelled=None) -> bytes:
    """Strictly replay every lane and pinned receipt before exact recovery."""
    original, _ = _parse_artifact(artifact, check_cancelled)
    replay = process_bytes(original, check_cancelled=check_cancelled)
    _check(check_cancelled)
    # Exact artifact comparison rejects extra fields, altered pins/order/stats,
    # refreshed false hashes, and modified lanes as well as simple corruption.
    if replay["artifact"] != artifact:
        raise BytePipelineError("CWBP lanes, pins, or receipt chain differ from replay")
    return original


def inspect_artifact(artifact: bytes, check_cancelled=None) -> dict:
    """Return the receipt only after the same complete fresh integrity replay."""
    original, metadata = _parse_artifact(artifact, check_cancelled)
    replay = process_bytes(original, check_cancelled=check_cancelled)
    _check(check_cancelled)
    if replay["artifact"] != artifact:
        raise BytePipelineError("CWBP lanes, pins, or receipt chain differ from replay")
    return metadata


def export_tables(check_cancelled=None) -> dict:
    """JSON data for browser/native consumers; these are real VM-built LUTs."""
    tables, _ = _ensure_tables(check_cancelled)
    return {
        "schema": TABLE_SCHEMA,
        "format": "CWBP",
        "version": VERSION,
        "stageCount": STAGE_COUNT,
        "transform": copy.deepcopy(TRANSFORM),
        "limits": dict(LIMITS),
        "actualWork": _actual_work(0),
        "stages": [
            {**slot.identity(), "table": list(table.values), "tableSha256": table.digest,
             "uniqueOutputValues": table.unique_values, "lossy": table.unique_values < 256,
             "tableBuild": {"vmRuns": 256 * 8, "vmSteps": table.vm_steps}}
            for slot, table in zip(SLOTS, tables)
        ],
    }


def _bounded_file(path: Path, maximum: int) -> bytes:
    return _read_bounded(path, maximum)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Six pinned byte processors with exact original recovery")
    parser.add_argument("--input", type=Path, help="Original input or CWBP artifact to recover")
    parser.add_argument("--output", type=Path, help="CWBP artifact or recovered original output")
    parser.add_argument("--receipt", type=Path, help="Verified receipt JSON output")
    parser.add_argument("--recover", action="store_true", help="Verify/recover the supplied CWBP artifact")
    parser.add_argument("--export-tables", type=Path, help="Export verified LUTs as JSON")
    args = parser.parse_args(argv)
    try:
        if args.export_tables:
            if args.input or args.output or args.receipt or args.recover:
                parser.error("--export-tables is a standalone operation")
            if args.export_tables.exists():
                raise BytePipelineError("Table output already exists; choose a new path")
            with args.export_tables.open("xb") as handle:
                handle.write(canonical_bytes(export_tables()) + b"\n")
            return 0
        if not args.input or not args.output:
            parser.error("--input and --output are required")
        if args.input.resolve() == args.output.resolve():
            raise BytePipelineError("Use a distinct output path to preserve the original input")
        if args.receipt and args.receipt.resolve() in (args.input.resolve(), args.output.resolve()):
            raise BytePipelineError("Receipt path must be distinct from input and output")
        if args.output.exists() or (args.receipt and args.receipt.exists()):
            raise BytePipelineError("Output or receipt already exists; choose new paths")
        if args.recover:
            content = _bounded_file(args.input, HEADER.size + MAX_METADATA_BYTES + 7 * MAX_PAYLOAD_BYTES)
            output = recover_bytes(content)
            receipt = inspect_artifact(content)
        else:
            content = _bounded_file(args.input, MAX_PAYLOAD_BYTES)
            result = process_bytes(content)
            output, receipt = result["artifact"], result["receipt"]
        with args.output.open("xb") as handle:
            handle.write(output)
        if args.receipt:
            with args.receipt.open("xb") as handle:
                handle.write(canonical_bytes(receipt) + b"\n")
        return 0
    except (OSError, BytePipelineError) as exc:
        parser.exit(2, f"Byte pipeline error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
