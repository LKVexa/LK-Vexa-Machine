// The updated smoke covers compiler revisions and byte-pipeline integrity.
require('./smoke-byte-pipeline.cjs');
