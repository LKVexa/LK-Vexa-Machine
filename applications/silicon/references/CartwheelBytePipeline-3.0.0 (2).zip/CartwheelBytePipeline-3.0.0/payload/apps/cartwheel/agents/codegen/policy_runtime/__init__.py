"""Reviewed bounded reference VM vendored with its original notices."""
