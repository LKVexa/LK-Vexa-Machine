// Native byte-processing surface. User content is data and is never executed here.
// CWPK encoding and validation are owned by CartwheelByteProcessorCore.
using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace VBJA21
{
    public sealed class CartwheelByteProcessorPanel : Grid
    {
        private const int HexEditorLimit = 65536;
        private const int PreviewLength = 4096;
        private readonly string _root;
        private readonly Action<string> _notify;
        private readonly TextBox _text;
        private readonly TextBox _hex;
        private readonly TextBox _numbers;
        private readonly TextBlock _bytesSummary;
        private readonly TextBlock _hexCaption;
        private readonly TextBlock _packetSummary;
        private readonly TextBlock _message;
        private readonly ComboBox _plane;
        private readonly ComboBox _numberMode;
        private readonly Button _saveBytes;
        private readonly Button _pack;
        private readonly Button _savePacket;
        private readonly Button _recover;
        private readonly Button _copyText;
        private readonly Button _applyHex;
        private readonly Button _encodeText;
        private byte[] _bytes;
        private byte[] _packet;
        private string _decoded;
        private string _name = "text";
        private bool _updating;
        private bool _hexDirty;
        private bool _textDirty;
        private CartwheelPipelineResult _pipeline;
        private readonly TextBox _pipelineReceipt;

        public CartwheelByteProcessorPanel(string root, Action<string> status)
        {
            if (String.IsNullOrWhiteSpace(root)) throw new ArgumentException("The console folder is required.");
            _root = System.IO.Path.GetFullPath(root);
            _notify = status ?? delegate { };
            CartwheelByteProcessorCore.Initialize(_root);
            CartwheelSixBytePipeline.Initialize(_root);

            StackPanel body = new StackPanel { Margin = new Thickness(18,14,18,18) };
            Children.Add(new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });
            body.Children.Add(new TextBlock { Text = "Text or files → bytes → Cartwheel packet → original bytes", FontSize = 21, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,7) });
            body.Children.Add(new TextBlock { Text = "This processor works locally in the console. It handles up to 1 MiB per input, preserves every byte, and checks packet integrity before recovery.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,15) });

            body.Children.Add(Heading("1. Choose your input"));
            body.Children.Add(new TextBlock { Text = "A prose prompt, text, or code", Margin = new Thickness(0,0,0,5) });
            _text = Editor(135);
            _text.Text = "Write a mock landing page with a clear title, three features, and a working contact form.";
            _text.TextChanged += delegate { if (!_updating) { _textDirty = true; SetMessage("Text changed. Choose Turn text into bytes to apply it.", false); } };
            body.Children.Add(_text);
            WrapPanel inputActions = Actions(body);
            _encodeText = AddButton(inputActions, "Turn text into bytes", delegate { EncodeText(_text.Text); });
            AddButton(inputActions, "Read a file as bytes…", OpenRawFile);
            _copyText = AddButton(inputActions, "Copy decoded text", delegate { RequireCommittedInput(); if (_decoded == null) throw new InvalidOperationException("These bytes are not valid UTF-8 text."); if (_decoded.IndexOf('\0') >= 0) throw new InvalidOperationException("This text contains null characters that the text clipboard cannot preserve. Use Save bytes to keep every byte."); Clipboard.SetText(_decoded); SetMessage("Decoded text copied. You can paste it into Code writing.", false); });

            body.Children.Add(Heading("2. Inspect or edit the bytes"));
            _bytesSummary = new TextBlock { FontFamily = new FontFamily("Consolas"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,10) };
            body.Children.Add(_bytesSummary);
            Grid columns = new Grid();
            columns.ColumnDefinitions.Add(new ColumnDefinition());
            columns.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(14) });
            columns.ColumnDefinitions.Add(new ColumnDefinition());
            body.Children.Add(columns);
            StackPanel hexSide = new StackPanel(); columns.Children.Add(hexSide);
            _hexCaption = new TextBlock { Text = "Hexadecimal · each pair is one byte", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,5) };
            hexSide.Children.Add(_hexCaption);
            _hex = Editor(190);
            _hex.TextChanged += delegate { if (!_updating) { _hexDirty = true; SetMessage("Hex changed. Choose Apply hex edits to use those bytes.", false); } };
            hexSide.Children.Add(_hex);
            WrapPanel hexActions = Actions(hexSide);
            _applyHex = AddButton(hexActions, "Apply hex edits", delegate { ApplyHexText(_hex.Text); });
            AddButton(hexActions, "Restore current bytes", RestoreCurrentInput);

            StackPanel numbersSide = new StackPanel(); Grid.SetColumn(numbersSide,2); columns.Children.Add(numbersSide);
            _numberMode = new ComboBox { Margin = new Thickness(0,0,0,5), MinWidth = 170, HorizontalAlignment = HorizontalAlignment.Left };
            _numberMode.Items.Add("Decimal · 0 to 255"); _numberMode.Items.Add("Binary · eight bits"); _numberMode.SelectedIndex = 0;
            _numberMode.SelectionChanged += delegate { if (!_updating) RefreshNumbers(); };
            numbersSide.Children.Add(_numberMode);
            _numbers = Editor(190); _numbers.IsReadOnly = true; numbersSide.Children.Add(_numbers);
            numbersSide.Children.Add(new TextBlock { Text = "Decimal and binary inspection show the first 4,096 bytes. Packing and saving use the complete byte buffer.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,7,0,0) });

            body.Children.Add(Heading("3. Run the six byte processors"));
            body.Children.Add(new TextBlock { Text = "Each supplied processor produces its own byte lane from the original buffer. All six are measured; repeated Adaptive policies remain visible. These transforms preserve a separate original payload for exact recovery.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,7) });
            WrapPanel pipelineActions = Actions(body);
            AddButton(pipelineActions,"Run six processors",RunPipeline);
            AddButton(pipelineActions,"Save pipeline artifact…",SavePipeline);
            AddButton(pipelineActions,"Open pipeline artifact…",OpenPipeline);
            AddButton(pipelineActions,"Recover pipeline payload",delegate { RequireCommittedInput(); if(_pipeline==null)throw new InvalidOperationException("Run or open a pipeline first."); RecoverPipeline(_pipeline.Artifact); });
            _pipelineReceipt=Editor(175);_pipelineReceipt.IsReadOnly=true;_pipelineReceipt.TextWrapping=TextWrapping.Wrap;_pipelineReceipt.HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled;body.Children.Add(_pipelineReceipt);
            _pipelineReceipt.Text="Run the processors to inspect their measured byte contributions.";
            body.Children.Add(Heading("4. Pack and recover"));
            WrapPanel packetActions = Actions(body);
            packetActions.Children.Add(new TextBlock { Text = "Wheel plane", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0,0,8,8) });
            _plane = new ComboBox { Width = 85, Margin = new Thickness(0,0,12,8), VerticalAlignment = VerticalAlignment.Center };
            for (int i=0;i<64;i++) _plane.Items.Add(i.ToString(System.Globalization.CultureInfo.InvariantCulture));
            _plane.SelectedIndex = 0; packetActions.Children.Add(_plane);
            _plane.SelectionChanged += delegate { if (!_updating && _packetSummary != null) { _packet = null; RefreshPacket(); SetMessage("Wheel plane changed. Pack the current bytes to create a new packet.",false); } };
            _pack = AddButton(packetActions, "Pack current bytes", delegate { PackCurrent(_plane.SelectedIndex); });
            _recover = AddButton(packetActions, "Recover original bytes", delegate { RecoverPacket(_packet); });
            AddButton(packetActions, "Open a Cartwheel packet…", OpenPacket);
            _packetSummary = new TextBlock { FontFamily = new FontFamily("Consolas"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,7) }; body.Children.Add(_packetSummary);
            WrapPanel exportActions = Actions(body);
            _saveBytes = AddButton(exportActions, "Save bytes…", delegate { SaveSelected(_bytes,false); });
            _savePacket = AddButton(exportActions, "Save packet…", delegate { SaveSelected(_packet,true); });
            body.Children.Add(new TextBlock { Text = "Exports are saved inside this console’s outputs folder. Byte operations do not run code. Use Code writing separately to turn prose into a new program.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,12) });
            _message = new TextBlock { TextWrapping = TextWrapping.Wrap, FontSize = 14, Margin = new Thickness(0,5,0,0) }; body.Children.Add(_message);
            _bytes = new byte[0];
            RefreshBytes(); RefreshPacket();
            _textDirty = true;
            SetMessage("Ready. Turn your text into bytes, read a file, or open an existing packet.", false);
        }

        public byte[] BytesSnapshot { get { return _bytes == null ? null : (byte[])_bytes.Clone(); } }
        public byte[] PacketSnapshot { get { return _packet == null ? null : (byte[])_packet.Clone(); } }
        public string StatusText { get { return _message.Text; } }

        private static TextBlock Heading(string text)
        {
            return new TextBlock { Text = text, FontSize = 17, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,12,0,8) };
        }

        private static TextBox Editor(double height)
        {
            return new TextBox { Height = height, AcceptsReturn = true, AcceptsTab = true, TextWrapping = TextWrapping.NoWrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, FontFamily = new FontFamily("Consolas"), FontSize = 13, Padding = new Thickness(8), Margin = new Thickness(0,0,0,5) };
        }

        private static WrapPanel Actions(Panel body)
        {
            WrapPanel actions = new WrapPanel { Margin = new Thickness(0,5,0,3) }; body.Children.Add(actions); return actions;
        }

        private Button AddButton(Panel panel, string label, Action action)
        {
            Button button = new Button { Content = label, Padding = new Thickness(12,7,12,7), Margin = new Thickness(0,0,8,8) };
            button.Click += delegate { try { action(); } catch (Exception error) { SetMessage(FriendlyError(error), true); } };
            panel.Children.Add(button); return button;
        }

        private static string FriendlyError(Exception error)
        {
            if (error is UnauthorizedAccessException) return "This file or folder cannot be accessed. Choose a writable location under console outputs.";
            if (error is PathTooLongException) return "That file path is too long. Choose a shorter file name or a folder closer to the drive root.";
            return error.Message;
        }

        private void SetMessage(string message, bool error)
        {
            if (_message == null) return;
            _message.Text = message;
            _message.Foreground = error ? Brushes.Firebrick : new SolidColorBrush(Color.FromRgb(30,75,50));
            _notify(message);
        }

        public void EncodeText(string text)
        {
            byte[] data = CartwheelByteProcessorCore.EncodeUtf8(text);
            LoadBytes(data,"text");
            _updating = true; try { _text.Text = text; } finally { _updating = false; }
            _textDirty = false;
            SetMessage("Text encoded as UTF-8. Every character is now represented by bytes.", false);
        }

        public void LoadBytes(byte[] data, string label)
        {
            if (data == null) throw new ArgumentNullException("data");
            if (data.Length > CartwheelByteProcessorCore.MaxPayloadLength) throw new ArgumentException("Input exceeds 1 MiB. Choose a smaller file; no bytes have been truncated.");
            _bytes = (byte[])data.Clone(); _name = SafeName(label); _packet = null; _textDirty = false;
            _pipeline=null;if(_pipelineReceipt!=null)_pipelineReceipt.Text="Buffer changed. Run six processors to refresh the evidence.";
            RefreshBytes(); RefreshPacket();
            _updating = true; try { _text.Text = _decoded == null ? "" : _decoded; } finally { _updating = false; }
            SetMessage("Loaded " + data.Length.ToString("N0") + " bytes. " + (_decoded == null ? "This input is binary data, so a UTF-8 text view is unavailable." : "The text view uses strict UTF-8 decoding."), false);
        }

        public void ApplyHexText(string hex)
        {
            byte[] data = CartwheelByteProcessorCore.ParseHex(hex);
            if (data.Length > HexEditorLimit) throw new ArgumentException("Hex editing is limited to 65,536 bytes. Read a file to process a larger input, up to 1 MiB.");
            LoadBytes(data,"edited-bytes");
            SetMessage("Hex edits applied. The current byte buffer and integrity check have been updated.", false);
        }

        public void PackCurrent(int plane)
        {
            RequireCommittedInput();
            byte[] packet = CartwheelByteProcessorCore.Pack(_bytes,plane);
            _packet = packet;
            _updating = true; try { _plane.SelectedIndex = plane; } finally { _updating = false; }
            RefreshPacket();
            SetMessage("Packed the complete byte buffer through wheel plane " + plane + ". Recovery checks the header, field fingerprint, length, and checksum.", false);
        }

        public void RunPipeline()
        {
            RequireCommittedInput();
            CartwheelPipelineResult result=CartwheelSixBytePipeline.Process(_bytes);
            byte[] recovered=CartwheelSixBytePipeline.Recover(result.Artifact);
            if(CartwheelByteProcessorCore.Sha256(recovered)!=CartwheelByteProcessorCore.Sha256(_bytes))throw new InvalidOperationException("Pipeline recovery mismatch.");
            _pipeline=result;ShowPipeline();
            SetMessage("Six processors completed. Original bytes and all six derived lanes passed exact replay.",false);
        }
        private void ShowPipeline()
        {
            StringBuilder report=new StringBuilder();
            report.AppendLine("Six byte processors · exact original recovery verified");
            report.AppendLine("Native mapping uses tables derived by running the pinned compiled images over all 256 byte values.");
            string[] names={"Adaptive 1","Best Reply","Adaptive 2 (duplicate of 1)","Critique","Cautious","Adaptive 3 (duplicate of 1)"};
            for(int i=0;i<6;i++)report.AppendLine((i+1)+". "+names[i]+" · "+_pipeline.Lanes[i].Length+" bytes · SHA-256 "+CartwheelByteProcessorCore.Sha256(_pipeline.Lanes[i]));
            report.AppendLine("Source authorship remains with the prompt compiler or embedded model. Byte transforms do not interpret prose.");
            report.AppendLine();report.AppendLine("Full pipeline receipt:");report.Append(_pipeline.Receipt);_pipelineReceipt.Text=report.ToString();_pipelineReceipt.CaretIndex=0;_pipelineReceipt.ScrollToHome();
        }
        public void RecoverPipeline(byte[] artifact)
        {
            byte[] payload=CartwheelSixBytePipeline.Recover(artifact);
            CartwheelPipelineResult result=CartwheelSixBytePipeline.Process(payload);
            LoadBytes(payload,"pipeline-recovered");_pipeline=result;ShowPipeline();
            SetMessage("Recovered every original byte after replaying all six processor lanes and their evidence.",false);
        }
        private void OpenPipeline()
        {
            OpenFileDialog dialog=new OpenFileDialog { Title="Open and verify a byte pipeline",Filter="Byte pipeline artifacts|*.cwbp|All files|*.*",CheckFileExists=true,Multiselect=false };
            if(dialog.ShowDialog(Window.GetWindow(this))==true)RecoverPipeline(ReadBounded(dialog.FileName,CartwheelSixBytePipeline.MaxArtifactLength));
        }
        private void SavePipeline()
        {
            RequireCommittedInput();if(_pipeline==null)throw new InvalidOperationException("Run six processors before saving their artifact.");
            string directory=System.IO.Path.GetDirectoryName(ValidateOutputPath(System.IO.Path.Combine(_root,"outputs","byte-processor","placeholder.cwbp")));Directory.CreateDirectory(directory);
            SaveFileDialog dialog=new SaveFileDialog { Title="Save verified byte pipeline",InitialDirectory=directory,FileName=_name+".cwbp",DefaultExt=".cwbp",AddExtension=true,OverwritePrompt=true,Filter="Byte pipeline artifacts|*.cwbp" };
            if(dialog.ShowDialog(Window.GetWindow(this))==true) { string selected=WriteExport(dialog.FileName,_pipeline.Artifact,true);SetMessage("Saved the original payload, six byte lanes and processor receipt to "+selected,false); }
        }

        private void RequireCommittedInput()
        {
            if (_hexDirty) throw new InvalidOperationException("Apply or restore your hex edits before packing, saving, or copying text.");
            if (_textDirty) throw new InvalidOperationException("Turn your changed text into bytes, or restore the current bytes, before packing, saving, or copying text.");
        }

        private void RestoreCurrentInput()
        {
            RefreshBytes();
            _updating = true; try { _text.Text = _decoded == null ? "" : _decoded; } finally { _updating = false; }
            _textDirty = false;
            SetMessage("Editors restored from the current byte buffer. The stored packet is unchanged.", false);
        }

        public void RecoverPacket(byte[] packet)
        {
            if (packet == null) throw new InvalidOperationException("Pack bytes or open a Cartwheel packet first.");
            byte[] recovered = CartwheelByteProcessorCore.Recover(packet);
            CartwheelPacketInfo info = CartwheelByteProcessorCore.InspectPacket(packet);
            // Do not mutate panel state until both recovery and inspection succeed.
            _bytes = recovered; _packet = (byte[])packet.Clone(); _textDirty = false; _name = "recovered";
            _pipeline=null;_pipelineReceipt.Text="Recovered buffer changed. Run six processors to refresh the evidence.";
            _updating = true; try { _plane.SelectedIndex = info.PlaneIndex; } finally { _updating = false; }
            RefreshBytes(); RefreshPacket();
            _updating = true; try { _text.Text = _decoded == null ? "" : _decoded; } finally { _updating = false; }
            SetMessage("Recovered all " + recovered.Length.ToString("N0") + " original bytes. Packet integrity checks passed.", false);
        }

        private void RefreshBytes()
        {
            _updating = true;
            try {
                _hexDirty = false;
                _decoded = null;
                try { _decoded = CartwheelByteProcessorCore.DecodeUtf8(_bytes); } catch (ArgumentException) { }
                _bytesSummary.Text = "Current buffer: " + _bytes.Length.ToString("N0") + " bytes\nSHA-256: " + CartwheelByteProcessorCore.Sha256(_bytes);
                bool editable = _bytes.Length <= HexEditorLimit;
                _hex.IsReadOnly = !editable;
                _applyHex.IsEnabled = editable;
                _hex.Text = CartwheelByteProcessorCore.FormatHex(editable ? _bytes : Prefix(_bytes,PreviewLength));
                _hexCaption.Text = editable ? "Editable hexadecimal · all " + _bytes.Length.ToString("N0") + " bytes" : "Read-only hexadecimal · first 4,096 of " + _bytes.Length.ToString("N0") + " bytes";
                _copyText.IsEnabled = !String.IsNullOrEmpty(_decoded) && _decoded.IndexOf('\0') < 0;
                _saveBytes.IsEnabled = true;
                _pack.IsEnabled = true;
                RefreshNumbers();
            } finally { _updating = false; }
        }

        private void RefreshNumbers()
        {
            if (_numbers == null || _bytes == null) return;
            byte[] sample = Prefix(_bytes,PreviewLength);
            _numbers.Text = _numberMode.SelectedIndex == 1 ? CartwheelByteProcessorCore.FormatBinary(sample) : CartwheelByteProcessorCore.FormatDecimal(sample);
        }

        private void RefreshPacket()
        {
            bool hasPacket = _packet != null;
            _savePacket.IsEnabled = hasPacket; _recover.IsEnabled = hasPacket;
            if (!hasPacket) { _packetSummary.Text = "No packet yet. Choose a plane and pack the current bytes."; return; }
            CartwheelPacketInfo info = CartwheelByteProcessorCore.InspectPacket(_packet);
            _packetSummary.Text = "CWPK version " + info.Version + " · plane " + info.PlaneIndex + "\n" + info.PayloadLength.ToString("N0") + " payload bytes + " + info.HeaderLength + " header bytes = " + info.PacketLength.ToString("N0") + " packet bytes\nChecksum: " + info.Checksum + " · field fingerprint: " + info.FieldFingerprint;
        }

        private static byte[] Prefix(byte[] data, int limit)
        {
            if (data.Length <= limit) return data;
            byte[] sample = new byte[limit]; Buffer.BlockCopy(data,0,sample,0,limit); return sample;
        }

        private void OpenRawFile()
        {
            OpenFileDialog dialog = new OpenFileDialog { Title = "Read a file as bytes", Filter = "All files|*.*", CheckFileExists = true, Multiselect = false };
            if (dialog.ShowDialog(Window.GetWindow(this)) == true) LoadBytes(ReadBounded(dialog.FileName,CartwheelByteProcessorCore.MaxPayloadLength),System.IO.Path.GetFileNameWithoutExtension(dialog.FileName));
        }

        private void OpenPacket()
        {
            OpenFileDialog dialog = new OpenFileDialog { Title = "Open and verify a Cartwheel packet", Filter = "Cartwheel packets|*.cwpk|All files|*.*", CheckFileExists = true, Multiselect = false };
            if (dialog.ShowDialog(Window.GetWindow(this)) == true) RecoverPacket(ReadBounded(dialog.FileName,CartwheelByteProcessorCore.MaxPayloadLength + CartwheelByteProcessorCore.HeaderLength));
        }

        private static byte[] ReadBounded(string path, int limit)
        {
            using (FileStream file = new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                if (file.Length > limit) throw new IOException("The selected file exceeds the 1 MiB input limit. No bytes have been truncated.");
                using (MemoryStream result = new MemoryStream()) {
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = file.Read(buffer,0,buffer.Length)) > 0) { if (result.Length + count > limit) throw new IOException("The selected file grew beyond the input limit while it was being read."); result.Write(buffer,0,count); }
                    return result.ToArray();
                }
            }
        }

        private static string SafeName(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return "bytes";
            StringBuilder name = new StringBuilder();
            foreach (char c in value) { if (name.Length >= 48) break; if (Char.IsLetterOrDigit(c) || c == '-' || c == '_') name.Append(c); }
            return name.Length == 0 ? "bytes" : "bytes-" + name.ToString();
        }

        public string ValidateOutputPath(string path)
        {
            string exportRoot = System.IO.Path.GetFullPath(System.IO.Path.Combine(_root,"outputs"));
            string selected = System.IO.Path.GetFullPath(path);
            if (!selected.StartsWith(exportRoot.TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase)) throw new IOException("Choose a file inside this console’s outputs folder. This prevents an export from replacing console components.");
            string relative = selected.Substring(exportRoot.Length + 1);
            foreach (string component in relative.Split(System.IO.Path.DirectorySeparatorChar)) {
                if (component.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0 || component.EndsWith(".",StringComparison.Ordinal) || component.EndsWith(" ",StringComparison.Ordinal)) throw new IOException("Choose an ordinary file name without reserved characters or trailing spaces.");
                string stem = component.Split('.')[0].ToUpperInvariant();
                if (stem == "CON" || stem == "PRN" || stem == "AUX" || stem == "NUL" || (stem.Length == 4 && (stem.StartsWith("COM",StringComparison.Ordinal) || stem.StartsWith("LPT",StringComparison.Ordinal)) && stem[3] >= '1' && stem[3] <= '9')) throw new IOException("That file name is reserved by Windows. Choose another name.");
            }
            string cursor = selected;
            while (!String.IsNullOrEmpty(cursor)) {
                if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0) throw new IOException("Choose a normal folder inside outputs; linked folders are not accepted for exports.");
                if (String.Equals(cursor,System.IO.Path.GetPathRoot(cursor),StringComparison.OrdinalIgnoreCase)) break;
                cursor = System.IO.Path.GetDirectoryName(cursor);
            }
            return selected;
        }

        private void SaveSelected(byte[] data, bool packet)
        {
            RequireCommittedInput();
            if (data == null) throw new InvalidOperationException("There is no packet to save yet.");
            string directory = ValidateOutputPath(System.IO.Path.Combine(_root,"outputs","byte-processor","placeholder.bin"));
            directory = System.IO.Path.GetDirectoryName(directory); Directory.CreateDirectory(directory);
            SaveFileDialog dialog = new SaveFileDialog { Title = packet ? "Save Cartwheel packet" : "Save exact bytes", InitialDirectory = directory, FileName = _name + (packet ? ".cwpk" : ".bin"), DefaultExt = packet ? ".cwpk" : ".bin", AddExtension = true, OverwritePrompt = true, Filter = packet ? "Cartwheel packets|*.cwpk|All files|*.*" : "Byte files|*.bin|Text files|*.txt|All files|*.*" };
            if (dialog.ShowDialog(Window.GetWindow(this)) != true) return;
            string selected = WriteExport(dialog.FileName,data,true);
            SetMessage("Saved " + data.Length.ToString("N0") + " exact bytes to " + selected, false);
        }

        // The dialog supplies the overwrite authorization. Tests call this same writer
        // with explicit fixture paths, so a saved byte/packet export is also checked.
        private string WriteExport(string path, byte[] data, bool allowOverwrite)
        {
            if (data == null) throw new ArgumentNullException("data");
            string selected = ValidateOutputPath(path);
            if (File.Exists(selected) && !allowOverwrite) throw new IOException("That export file already exists. Choose another name or explicitly approve replacement.");
            string temporary = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(selected),".byte-export-" + Guid.NewGuid().ToString("N") + ".tmp");
            try {
                using (FileStream stream = new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None)) { stream.Write(data,0,data.Length); stream.Flush(true); }
                ValidateOutputPath(selected);
                if (File.Exists(selected)) { if (!allowOverwrite) throw new IOException("That export file already exists. Choose another name."); File.Replace(temporary,selected,null); } else File.Move(temporary,selected);
            } finally { if (File.Exists(temporary)) File.Delete(temporary); }
            return selected;
        }
    }
}
