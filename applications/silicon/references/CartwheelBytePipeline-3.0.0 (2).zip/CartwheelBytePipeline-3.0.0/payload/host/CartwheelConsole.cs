// Portable Cartwheel application surface for the JA21 WPF console.
// WPF owns the window. The hosted Python UI owns its in-process model calls.
// No prompts, model responses, or inference commands cross this window boundary.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;

namespace VBJA21
{
    public static class CartwheelConsoleApplication
    {
        public static bool Enabled
        {
            get { return Ja21Design.ConsoleMode && String.Equals(Environment.GetEnvironmentVariable("JA21_CONSOLE_APP"), "cartwheel", StringComparison.Ordinal); }
        }

        public static void Run(string root)
        {
            Application app = new Application();
            app.ShutdownMode = ShutdownMode.OnMainWindowClose;
            app.Run(new CartwheelConsoleWindow(root));
        }
    }

    public sealed class CartwheelConsoleWindow : Window
    {
        private readonly string _root;
        private readonly TextBlock _status;
        private readonly Grid _codePanel;
        private readonly Grid _offlinePanel;
        private CartwheelNativeHost _native;
        private ICartwheelOfflineSurface _offline;
        private bool _closed;
        public const string Release = "3.0.0";

        public CartwheelConsoleWindow(string root)
        {
            _root = System.IO.Path.GetFullPath(root);
            Title = "Cartwheel Byte Processor " + Release;
            Width = 1260; Height = 960; MinWidth = 850; MinHeight = 700;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = new SolidColorBrush(Color.FromRgb(245,243,235));
            Grid shell = new Grid();
            shell.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            shell.RowDefinitions.Add(new RowDefinition());
            shell.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            Content = shell;
            TextBlock heading = new TextBlock { Text = "Cartwheel · process bytes, write code", FontSize = 22, FontWeight = FontWeights.SemiBold, Margin = new Thickness(18,12,18,9) };
            shell.Children.Add(heading);
            TabControl tabs = new TabControl { Margin = new Thickness(12,0,12,8) };
            Grid.SetRow(tabs,1); shell.Children.Add(tabs);
            _codePanel = new Grid();
            _offlinePanel = new Grid();
            _status = new TextBlock { Text = "Byte processor ready. Choose text, a file, or a Cartwheel packet.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(18,4,18,12) };
            Grid.SetRow(_status,2); shell.Children.Add(_status);
            TabItem byteTab = new TabItem { Header = "Byte processor", Content = new CartwheelByteProcessorPanel(_root,SetStatus) };
            TabItem codeTab = new TabItem { Header = "Code writing", Content = _codePanel };
            TabItem offlineTab = new TabItem { Header = "Prompt compiler", Content = _offlinePanel };
            TabItem filesTab = new TabItem { Header = "Files & readiness", Content = BuildFilesPanel() };
            tabs.Items.Add(byteTab); tabs.Items.Add(codeTab); tabs.Items.Add(offlineTab); tabs.Items.Add(filesTab);
            tabs.SelectedItem = byteTab;
            tabs.SelectionChanged += delegate {
                if (_closed) return;
                if (tabs.SelectedItem == codeTab && _native == null) StartCode();
                else if (tabs.SelectedItem == offlineTab) EnsureOffline();
            };
            Closed += delegate { _closed = true; if (_native != null) _native.Dispose(); if (_offline != null) _offline.Dispose(); };
        }

        private FrameworkElement BuildFilesPanel()
        {
            StackPanel panel = new StackPanel { Margin = new Thickness(22) };
            panel.Children.Add(new TextBlock { Text = "Everything travels with this console", FontSize = 20, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0,0,0,12) });
            panel.Children.Add(new TextBlock { Text = "Code agents, language suites, training evidence, both Qwen coding models, VIVIAN weights, and the bundled Python/Node checking runtimes are stored inside this folder. Save generated projects under outputs. The six agents and models run together in the hosted Python process.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,16) });
            panel.Children.Add(new TextBlock { Text = "Byte processor encodes UTF-8, inspects binary files, edits hexadecimal bytes, and packs or recovers CWPK packets across all 64 planes. It works independently of the models and browser. Prompt compiler retains the existing bounded language compiler. Execution with unavailable SDKs and custom JA/DeepML native runtimes remains unverified. VIVIAN remains experimental; its previous generation attempts produced no accepted code.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,0,0,18) });
            AddFolderButton(panel,"Byte exports","outputs/byte-processor");
            AddFolderButton(panel,"Generated projects","outputs");
            AddFolderButton(panel,"Complete Cartwheel system","apps/cartwheel");
            AddFolderButton(panel,"Model files","models");
            AddFileButton(panel,"Portability report","PORTABILITY_REPORT.txt");
            AddFileButton(panel,"Startup guide","START_HERE.txt");
            TextBlock readiness = new TextBlock { Text = Readiness(_root), TextWrapping = TextWrapping.Wrap, FontFamily = new FontFamily("Consolas"), Margin = new Thickness(0,18,0,0) };
            panel.Children.Add(readiness);
            return new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        }

        private void AddFolderButton(StackPanel panel,string label,string relative)
        {
            Button button = new Button { Content = label, Padding = new Thickness(14,7,14,7), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0,0,0,8) };
            button.Click += delegate { try { string path=PackagePath(_root,relative); Directory.CreateDirectory(path); Process.Start(new ProcessStartInfo(path) { UseShellExecute=true }); } catch(Exception error) { SetStatus(error.Message); } };
            panel.Children.Add(button);
        }

        private void AddFileButton(StackPanel panel,string label,string relative)
        {
            Button button = new Button { Content = label, Padding = new Thickness(14,7,14,7), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0,0,0,8) };
            button.Click += delegate { try { string path=PackagePath(_root,relative); if(!File.Exists(path))throw new IOException("This package does not include " + relative); Process.Start(new ProcessStartInfo(path) { UseShellExecute=true }); } catch(Exception error) { SetStatus(error.Message); } };
            panel.Children.Add(button);
        }

        public static string PackagePath(string root,string relative)
        {
            if (String.IsNullOrWhiteSpace(relative) || System.IO.Path.IsPathRooted(relative)) throw new ArgumentException("A package-relative path is required.");
            string basePath=System.IO.Path.GetFullPath(root).TrimEnd(System.IO.Path.DirectorySeparatorChar)+System.IO.Path.DirectorySeparatorChar;
            string path=System.IO.Path.GetFullPath(System.IO.Path.Combine(basePath,relative.Replace('/',System.IO.Path.DirectorySeparatorChar)));
            if(!path.StartsWith(basePath,StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Path leaves the console package.");
            RuntimeSeal.RejectReparsePoints(basePath,path);
            return path;
        }

        public static string Readiness(string root)
        {
            string[] paths={"host/CartwheelByteProcessorCore.cs","host/CartwheelByteProcessorPanel.cs","apps/cartwheel/agents/codegen/desktop.py","portable/python/pythonw.exe","portable/cartwheel-python/llama_cpp/__init__.py","models/cartwheel/qwen2.5-coder-7b-instruct-q4_k_m.gguf","models/cartwheel/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf","models/vivian/models/vivian-neural-coding-v1.0.0/model.safetensors","content/cartwheel/playground.html"};
            StringBuilder text=new StringBuilder();
            foreach(string relative in paths) text.AppendLine((File.Exists(PackagePath(root,relative))?"Ready  ":"Missing ")+relative);
            text.AppendLine("Readiness checks file presence. Integrity and model hashes are checked separately at launch/use.");
            return text.ToString();
        }

        private void SetStatus(string value)
        {
            if (_closed) return;
            if (!Dispatcher.CheckAccess()) { Dispatcher.BeginInvoke(new Action(delegate { SetStatus(value); })); return; }
            _status.Text=value;
        }

        private void StartCode()
        {
            if (_native != null) _native.Dispose();
            _codePanel.Children.Clear();
            _native = new CartwheelNativeHost(_root,SetStatus);
            _codePanel.Children.Add(_native);
            _native.Focus();
        }

        private void EnsureOffline()
        {
            if (_offline != null) return;
            try { _offline = CartwheelOfflineFactory.Create(_root,SetStatus); _offlinePanel.Children.Add(_offline.View); }
            catch(Exception error) {
                StackPanel panel=new StackPanel { Margin=new Thickness(22) };
                panel.Children.Add(new TextBlock { Text="Prompt compiler needs the packaged WebView2 runtime",FontSize=20,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,12) });
                panel.Children.Add(new TextBlock { Text=error.Message+" Byte processor and Code writing are available independently. The complete standalone compiler is retained at apps/cartwheel/playground.html.",TextWrapping=TextWrapping.Wrap });
                _offlinePanel.Children.Add(panel); SetStatus(error.Message);
            }
        }
    }

    public sealed class CartwheelNativeHost : HwndHost
    {
        private readonly string _root;
        private readonly Action<string> _status;
        private IntPtr _container;
        private IntPtr _child;
        private Process _process;
        private DispatcherTimer _poll;
        private int _ticks;
        private bool _destroyed;
        private const int WS_CHILD=0x40000000,WS_VISIBLE=0x10000000;
        private delegate bool EnumWindowProc(IntPtr hwnd,IntPtr param);
        [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)] private static extern IntPtr CreateWindowEx(int extended,string cls,string name,int style,int x,int y,int width,int height,IntPtr parent,IntPtr menu,IntPtr instance,IntPtr data);
        [DllImport("user32.dll")] private static extern bool DestroyWindow(IntPtr hwnd);
        [DllImport("user32.dll")] private static extern bool EnumChildWindows(IntPtr parent,EnumWindowProc callback,IntPtr param);
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint process);
        [DllImport("user32.dll")] private static extern bool MoveWindow(IntPtr hwnd,int x,int y,int width,int height,bool repaint);
        [DllImport("user32.dll")] private static extern IntPtr SetFocus(IntPtr hwnd);
        [DllImport("user32.dll")] private static extern bool PostMessage(IntPtr hwnd,uint message,IntPtr wparam,IntPtr lparam);
        [DllImport("user32.dll")] private static extern bool GetClientRect(IntPtr hwnd,out NativeRect rect);
        [StructLayout(LayoutKind.Sequential)] private struct NativeRect { public int Left,Top,Right,Bottom; }

        public CartwheelNativeHost(string root,Action<string> status) { _root=root;_status=status;Focusable=true; }

        protected override HandleRef BuildWindowCore(HandleRef parent)
        {
            _container=CreateWindowEx(0,"static","Cartwheel native workbench",WS_CHILD|WS_VISIBLE,0,0,1200,800,parent.Handle,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero);
            if(_container==IntPtr.Zero)throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            StartChild();
            return new HandleRef(this,_container);
        }

        private static string Quote(string value)
        {
            if(value.IndexOf('"')>=0 || value.IndexOf('\0')>=0)throw new ArgumentException("Invalid launch argument.");
            return "\""+value.Replace("\\\"","\\\\\"")+"\"";
        }

        private void StartChild()
        {
            string python=CartwheelConsoleWindow.PackagePath(_root,"portable/python/pythonw.exe");
            string entry=CartwheelConsoleWindow.PackagePath(_root,"host/hosted_desktop.py");
            if(!File.Exists(python)||!File.Exists(entry))throw new IOException("Bundled Python or hosted workbench entrypoint is missing.");
            ProcessStartInfo launch=new ProcessStartInfo(python);
            launch.Arguments="-I -B -X utf8 "+Quote(entry)+" --parent-window "+_container.ToInt64().ToString(System.Globalization.CultureInfo.InvariantCulture);
            launch.WorkingDirectory=_root;launch.UseShellExecute=false;launch.CreateNoWindow=true;launch.WindowStyle=ProcessWindowStyle.Hidden;
            launch.EnvironmentVariables["CARTWHEEL_CONSOLE_ROOT"]=_root;
            launch.EnvironmentVariables["PYTHONDONTWRITEBYTECODE"]="1";
            launch.EnvironmentVariables["PYTHONNOUSERSITE"]="1";
            launch.EnvironmentVariables["PYTHONPATH"]=CartwheelConsoleWindow.PackagePath(_root,"portable/cartwheel-python")+";"+CartwheelConsoleWindow.PackagePath(_root,"apps/cartwheel/agents/codegen");
            _process=Process.Start(launch);
            if(_process==null)throw new IOException("Python workbench did not start.");
            _ticks=0;_poll=new DispatcherTimer(DispatcherPriority.Background,Dispatcher);_poll.Interval=TimeSpan.FromMilliseconds(100);
            _poll.Tick+=delegate { PollChild(); };_poll.Start();
            _status("Loading the hosted code workbench. Models are loaded only when generation starts.");
        }

        private void PollChild()
        {
            if(_destroyed)return;
            _ticks++;
            if(_process.HasExited) { _poll.Stop(); _status("The code workbench exited ("+_process.ExitCode+"). See workspace/logs/cartwheel-desktop-error.txt."); return; }
            if(_child==IntPtr.Zero) {
                uint expected=(uint)_process.Id;
                EnumChildWindows(_container,delegate(IntPtr hwnd,IntPtr unused) { uint pid;GetWindowThreadProcessId(hwnd,out pid); if(pid==expected){_child=hwnd;return false;}return true; },IntPtr.Zero);
                if(_child!=IntPtr.Zero){ResizeChild();_status("Code workbench is ready. Enter a prose prompt or open a saved session.");}
                else if(_ticks>=300) { _poll.Stop();_status("The workbench has not attached after 30 seconds. See workspace/logs/cartwheel-desktop-error.txt; restart the console to retry."); }
            }
        }

        private void ResizeChild()
        {
            NativeRect client;
            if(_child!=IntPtr.Zero&&GetClientRect(_container,out client))MoveWindow(_child,0,0,Math.Max(1,client.Right-client.Left),Math.Max(1,client.Bottom-client.Top),true);
        }
        protected override void OnWindowPositionChanged(Rect bounds) { base.OnWindowPositionChanged(bounds); ResizeChild(); }
        protected override bool TabIntoCore(TraversalRequest request) { if(_child==IntPtr.Zero)return false;SetFocus(_child);return true; }
        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) { base.OnGotKeyboardFocus(e);if(_child!=IntPtr.Zero)SetFocus(_child); }

        protected override void DestroyWindowCore(HandleRef hwnd)
        {
            _destroyed=true;if(_poll!=null)_poll.Stop();
            if(_process!=null) {
                try { if(!_process.HasExited) { if(_child!=IntPtr.Zero)PostMessage(_child,0x0010,IntPtr.Zero,IntPtr.Zero); if(!_process.WaitForExit(1500))_process.Kill(); } } catch(InvalidOperationException) { } catch(System.ComponentModel.Win32Exception) { }
                _process.Dispose();_process=null;
            }
            if(_container!=IntPtr.Zero){DestroyWindow(_container);_container=IntPtr.Zero;}
        }
    }

    public interface ICartwheelOfflineSurface : IDisposable { FrameworkElement View { get; } }
}
