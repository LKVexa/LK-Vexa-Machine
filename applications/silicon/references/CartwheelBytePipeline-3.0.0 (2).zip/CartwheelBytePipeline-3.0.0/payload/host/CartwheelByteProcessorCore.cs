// Native CWPK v1 byte processing. This is reversible transport, not encryption.
// Framing and wheel arithmetic match the existing JavaScript and Python codecs.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;

namespace VBJA21
{
    public sealed class CartwheelPacketInfo
    {
        public int Version { get; internal set; }
        public int PlaneIndex { get; internal set; }
        public int PayloadLength { get; internal set; }
        public uint Checksum { get; internal set; }
        public uint FieldFingerprint { get; internal set; }
        public int PacketLength { get; internal set; }
        public int HeaderLength { get { return CartwheelByteProcessorCore.HeaderLength; } }
        public override string ToString()
        {
            return String.Format(CultureInfo.InvariantCulture,
                "CWPK v{0} | plane {1} | payload {2:N0} bytes | packet {3:N0} bytes | CRC32 {4:x8}",
                Version, PlaneIndex, PayloadLength, PacketLength, Checksum);
        }
    }

    public static class CartwheelByteProcessorCore
    {
        public const int MaxPayloadLength = 1024 * 1024;
        public const int HeaderLength = 20;
        public const int MaxPacketLength = MaxPayloadLength + HeaderLength;
        private const string WheelSha256 = "b33ca16b47d343f97c870be22449692afc78ce45c18ffdff487e7e92093693b1";
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);
        private static readonly uint[] CrcTable = MakeCrcTable();
        private static readonly object InitializationLock = new object();
        private static volatile WheelTables _tables;

        private sealed class WheelTables
        {
            public readonly byte[][] X;
            public readonly byte[][] Y;
            public readonly uint[] Fingerprints;
            public WheelTables(byte[][] x, byte[][] y, uint[] fingerprints)
            { X = x; Y = y; Fingerprints = fingerprints; }
        }

        /// <summary>Load the fixed, reviewed 64-plane table snapshot from this console.</summary>
        public static void Initialize(string consoleRoot)
        {
            if (String.IsNullOrWhiteSpace(consoleRoot)) throw new ArgumentException("The console folder is required.", "consoleRoot");
            string root = System.IO.Path.GetFullPath(consoleRoot);
            string wheelPath = System.IO.Path.Combine(root, "apps", "cartwheel", "src", "lib", "wheel-fields.json");
            RejectReparsePoints(wheelPath);
            byte[] data;
            using (FileStream file = new FileStream(wheelPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (file.Length < 1 || file.Length > 256 * 1024)
                    throw new InvalidDataException("The console's bounded wheel table snapshot is missing or invalid.");
                data = new byte[(int)file.Length];
                int read = 0;
                while (read < data.Length)
                {
                    int count = file.Read(data, read, data.Length - read);
                    if (count == 0) throw new InvalidDataException("The console's wheel table snapshot is truncated.");
                    read += count;
                }
            }
            if (!String.Equals(Sha256(data), WheelSha256, StringComparison.Ordinal))
                throw new InvalidDataException("The console's wheel table snapshot does not match the reviewed codec.");
            JavaScriptSerializer json = new JavaScriptSerializer();
            json.MaxJsonLength = 256 * 1024; json.RecursionLimit = 8;
            object[] fields = json.DeserializeObject(StrictUtf8.GetString(data)) as object[];
            if (fields == null || fields.Length != 64)
                throw new InvalidDataException("Exactly 64 wheel planes are required.");
            byte[][] xs = new byte[64][]; byte[][] ys = new byte[64][]; uint[] fingerprints = new uint[64];
            for (int plane = 0; plane < 64; plane++)
            {
                Dictionary<string, object> field = fields[plane] as Dictionary<string, object>;
                if (field == null || field.Count != 2 || !field.ContainsKey("x") || !field.ContainsKey("y"))
                    throw new InvalidDataException("Each wheel plane must contain exactly its x and y tables.");
                xs[plane] = ReadTable(field["x"]); ys[plane] = ReadTable(field["y"]);
                byte[] identity = new byte[513]; identity[0] = (byte)plane;
                Buffer.BlockCopy(xs[plane], 0, identity, 1, 256);
                Buffer.BlockCopy(ys[plane], 0, identity, 257, 256);
                fingerprints[plane] = Crc32(identity);
            }
            // Publish the complete validated snapshot atomically. Callers cannot mutate its arrays.
            lock (InitializationLock) { _tables = new WheelTables(xs, ys, fingerprints); }
        }

        public static byte[] EncodeUtf8(string text)
        {
            if (text == null) throw new ArgumentNullException("text");
            // Strict encoding rejects unpaired surrogate characters instead of replacing input.
            int count = StrictUtf8.GetByteCount(text);
            if (count > MaxPayloadLength) throw new ArgumentOutOfRangeException("text", "UTF-8 input exceeds the 1 MiB byte limit.");
            return StrictUtf8.GetBytes(text);
        }

        public static string DecodeUtf8(byte[] bytes)
        {
            RequirePayload(bytes, "bytes");
            // Invalid sequences fail; arbitrary binary data must remain binary.
            return StrictUtf8.GetString(bytes);
        }

        public static byte[] ParseHex(string text)
        {
            if (text == null) throw new ArgumentNullException("text");
            if (text.Length > MaxPacketLength * 6)
                throw new ArgumentOutOfRangeException("text", "Hexadecimal input exceeds the bounded byte limit.");
            List<byte> output = new List<byte>(Math.Min(text.Length / 2, MaxPacketLength));
            int index = 0;
            while (index < text.Length)
            {
                if (Char.IsWhiteSpace(text[index]) || text[index] == ',') { index++; continue; }
                int start = index;
                while (index < text.Length && !Char.IsWhiteSpace(text[index]) && text[index] != ',') index++;
                int length = index - start;
                bool prefixed = length >= 2 && text[start] == '0' && (text[start + 1] == 'x' || text[start + 1] == 'X');
                if (prefixed) { start += 2; length -= 2; }
                if (length == 0 || (length & 1) != 0 || (prefixed && length != 2))
                    throw new FormatException("Use complete two-digit hex bytes, compact even-length hex, or 0xNN bytes. Invalid token at character " + (start + 1).ToString(CultureInfo.InvariantCulture) + ".");
                for (int offset = 0; offset < length; offset += 2)
                {
                    int high = HexNibble(text[start + offset]); int low = HexNibble(text[start + offset + 1]);
                    if (high < 0 || low < 0)
                        throw new FormatException("Invalid hexadecimal character near character " + (start + offset + 1).ToString(CultureInfo.InvariantCulture) + ".");
                    if (output.Count >= MaxPacketLength)
                        throw new ArgumentOutOfRangeException("text", "Hexadecimal input exceeds the 1 MiB payload plus packet header limit.");
                    output.Add((byte)((high << 4) | low));
                }
            }
            return output.ToArray();
        }

        public static string FormatHex(byte[] bytes)
        {
            RequireBytes(bytes, "bytes", MaxPacketLength);
            StringBuilder result = new StringBuilder(bytes.Length * 3);
            for (int i = 0; i < bytes.Length; i++)
            {
                if (i != 0) result.Append(i % 16 == 0 ? Environment.NewLine : " ");
                result.Append(bytes[i].ToString("X2", CultureInfo.InvariantCulture));
            }
            return result.ToString();
        }

        public static string FormatDecimal(byte[] bytes)
        {
            RequireBytes(bytes, "bytes", MaxPacketLength);
            StringBuilder result = new StringBuilder(bytes.Length * 4);
            for (int i = 0; i < bytes.Length; i++)
            {
                if (i != 0) result.Append(i % 16 == 0 ? Environment.NewLine : " ");
                result.Append(bytes[i].ToString(CultureInfo.InvariantCulture));
            }
            return result.ToString();
        }

        public static string FormatBinary(byte[] bytes)
        {
            RequireBytes(bytes, "bytes", MaxPacketLength);
            StringBuilder result = new StringBuilder(bytes.Length * 9);
            for (int i = 0; i < bytes.Length; i++)
            {
                if (i != 0) result.Append(i % 8 == 0 ? Environment.NewLine : " ");
                for (int bit = 7; bit >= 0; bit--) result.Append((bytes[i] & (1 << bit)) != 0 ? '1' : '0');
            }
            return result.ToString();
        }

        public static string Sha256(byte[] bytes)
        {
            RequireBytes(bytes, "bytes", MaxPacketLength);
            using (SHA256 hash = SHA256.Create())
            {
                byte[] digest = hash.ComputeHash(bytes); StringBuilder text = new StringBuilder(64);
                foreach (byte value in digest) text.Append(value.ToString("x2", CultureInfo.InvariantCulture));
                return text.ToString();
            }
        }

        public static uint Crc32(byte[] bytes)
        {
            RequireBytes(bytes, "bytes", MaxPacketLength);
            uint value = 0xffffffff;
            foreach (byte item in bytes) value = CrcTable[(value ^ item) & 255] ^ (value >> 8);
            return value ^ 0xffffffff;
        }

        public static byte[] Pack(byte[] payload, int plane)
        {
            RequirePayload(payload, "payload"); RequirePlane(plane);
            WheelTables tables = RequireTables();
            byte[] packet = new byte[HeaderLength + payload.Length];
            packet[0] = 0x43; packet[1] = 0x57; packet[2] = 0x50; packet[3] = 0x4b;
            packet[4] = 1; packet[5] = (byte)plane;
            WriteUInt32(packet, 8, (uint)payload.Length);
            WriteUInt32(packet, 12, Crc32(payload));
            WriteUInt32(packet, 16, tables.Fingerprints[plane]);
            Transform(payload, 0, payload.Length, packet, HeaderLength, tables.X[plane], tables.Y[plane]);
            return packet;
        }

        /// <summary>Inspect framing only. Recover additionally validates the wheel and decoded CRC.</summary>
        public static CartwheelPacketInfo InspectPacket(byte[] packet)
        {
            RequireBytes(packet, "packet", MaxPacketLength);
            if (packet.Length < HeaderLength) throw new InvalidDataException("Truncated CWPK header.");
            if (packet[0] != 0x43 || packet[1] != 0x57 || packet[2] != 0x50 || packet[3] != 0x4b)
                throw new InvalidDataException("Invalid CWPK magic.");
            if (packet[4] != 1) throw new InvalidDataException("Unsupported CWPK version.");
            RequirePlane(packet[5]);
            if (packet[6] != 0 || packet[7] != 0) throw new InvalidDataException("Reserved CWPK header bytes must be zero.");
            uint length = ReadUInt32(packet, 8);
            if (length > MaxPayloadLength) throw new InvalidDataException("CWPK payload exceeds the 1 MiB packet limit.");
            if ((long)packet.Length != HeaderLength + (long)length)
                throw new InvalidDataException("CWPK payload length does not match the packet.");
            return new CartwheelPacketInfo {
                Version = packet[4], PlaneIndex = packet[5], PayloadLength = (int)length,
                Checksum = ReadUInt32(packet, 12), FieldFingerprint = ReadUInt32(packet, 16), PacketLength = packet.Length
            };
        }

        public static byte[] Recover(byte[] packet)
        {
            CartwheelPacketInfo info = InspectPacket(packet); WheelTables tables = RequireTables();
            if (info.FieldFingerprint != tables.Fingerprints[info.PlaneIndex])
                throw new InvalidDataException("CWPK plane or wheel tables do not match the packet.");
            byte[] payload = new byte[info.PayloadLength];
            Transform(packet, HeaderLength, info.PayloadLength, payload, 0, tables.X[info.PlaneIndex], tables.Y[info.PlaneIndex]);
            if (Crc32(payload) != info.Checksum)
                throw new InvalidDataException("CWPK payload checksum mismatch: the packet is corrupt.");
            return payload;
        }

        private static void Transform(byte[] source, int sourceOffset, int count, byte[] destination, int destinationOffset, byte[] xs, byte[] ys)
        {
            double tau = Math.PI * 2;
            for (int i = 0; i < count; i++)
            {
                byte x = xs[i & 255]; byte y = ys[i & 255];
                double t = count <= 1 ? 0 : (double)i / (count - 1);
                double phi = ((double)y / 255) * tau + tau * t; phi %= tau;
                if (phi < 0) phi += tau;
                int phase = ((int)Math.Floor((phi / tau) * 255 + 0.5)) & 255;
                double up = Math.Pow(Math.Cos((Math.PI * x) / 255 / 2), 2);
                int polar = ((int)Math.Floor(up * 255 + 0.5)) & 255;
                destination[destinationOffset + i] = (byte)(source[sourceOffset + i] ^ GfMultiply(x, 3) ^ phase ^ polar);
            }
        }

        private static int GfMultiply(int a, int b)
        {
            int product = 0;
            for (int i = 0; i < 8; i++)
            {
                if ((b & 1) != 0) product ^= a;
                a = ((a << 1) ^ ((a & 128) != 0 ? 0x1b : 0)) & 255; b >>= 1;
            }
            return product;
        }

        private static byte[] ReadTable(object value)
        {
            object[] array = value as object[];
            if (array == null || array.Length != 256) throw new InvalidDataException("Each wheel table must contain exactly 256 bytes.");
            byte[] bytes = new byte[256];
            for (int index = 0; index < 256; index++)
            {
                if (!(array[index] is int) || (int)array[index] < 0 || (int)array[index] > 255)
                    throw new InvalidDataException("Wheel values must be integral bytes from 0 to 255.");
                bytes[index] = (byte)(int)array[index];
            }
            return bytes;
        }

        private static WheelTables RequireTables()
        {
            WheelTables tables = _tables;
            if (tables == null) throw new InvalidOperationException("Initialize the console's wheel tables before packing or recovery.");
            return tables;
        }

        private static void RequirePayload(byte[] bytes, string name) { RequireBytes(bytes, name, MaxPayloadLength); }
        private static void RequireBytes(byte[] bytes, string name, int limit)
        {
            if (bytes == null) throw new ArgumentNullException(name);
            if (bytes.Length > limit) throw new ArgumentOutOfRangeException(name, "Input exceeds the bounded byte limit.");
        }
        private static void RequirePlane(int plane)
        { if (plane < 0 || plane > 63) throw new ArgumentOutOfRangeException("plane", "Plane must be an integer from 0 to 63."); }
        private static int HexNibble(char value)
        {
            if (value >= '0' && value <= '9') return value - '0';
            if (value >= 'a' && value <= 'f') return value - 'a' + 10;
            if (value >= 'A' && value <= 'F') return value - 'A' + 10;
            return -1;
        }
        private static uint[] MakeCrcTable()
        {
            uint[] table = new uint[256];
            for (uint index = 0; index < 256; index++)
            {
                uint value = index;
                for (int bit = 0; bit < 8; bit++) value = (value & 1) != 0 ? 0xedb88320 ^ (value >> 1) : value >> 1;
                table[index] = value;
            }
            return table;
        }
        private static uint ReadUInt32(byte[] bytes, int offset)
        { return (uint)bytes[offset] | ((uint)bytes[offset + 1] << 8) | ((uint)bytes[offset + 2] << 16) | ((uint)bytes[offset + 3] << 24); }
        private static void WriteUInt32(byte[] bytes, int offset, uint value)
        {
            bytes[offset] = (byte)value; bytes[offset + 1] = (byte)(value >> 8);
            bytes[offset + 2] = (byte)(value >> 16); bytes[offset + 3] = (byte)(value >> 24);
        }
        private static void RejectReparsePoints(string path)
        {
            string current = path;
            while (true)
            {
                if ((File.Exists(current) || Directory.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidDataException("Wheel data cannot be loaded through a symbolic link or junction.");
                string parent = System.IO.Path.GetDirectoryName(current);
                if (String.IsNullOrEmpty(parent) || String.Equals(current, parent, StringComparison.OrdinalIgnoreCase)) break;
                current = parent;
            }
        }
    }
}

// Six measured byte transforms derived from the supplied pinned LCTL images.
// The original payload remains authoritative; lossy lanes never replace it.
namespace VBJA21
{
    public sealed class CartwheelPipelineResult
    {
        public byte[] Artifact { get; internal set; }
        public string Receipt { get; internal set; }
        public byte[][] Lanes { get; internal set; }
    }

    public static class CartwheelSixBytePipeline
    {
        public const int MaxArtifactLength = 48 + 65536 + 7 * 1048576;
        private const string TablesSha256 = "a7d661c50f023e0381a10b514ff7528815fe749db63ffd68f820170fe996f3e9";
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false,true);
        private static Dictionary<string,object> _manifest;
        private static byte[][] _maps;
        private static object[] _stages;

        public static void Initialize(string root)
        {
            string path = System.IO.Path.Combine(root,"apps","cartwheel","src","lib","byte-pipeline-tables.json");
            string cursor=System.IO.Path.GetFullPath(path);
            while (!String.IsNullOrEmpty(cursor)) {
                if ((File.Exists(cursor)||Directory.Exists(cursor)) && (File.GetAttributes(cursor)&FileAttributes.ReparsePoint)!=0)
                    throw new InvalidDataException("Byte pipeline tables must be ordinary local files.");
                cursor=System.IO.Path.GetDirectoryName(cursor);
            }
            byte[] raw;
            using (FileStream stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                if (stream.Length<1||stream.Length>131072) throw new InvalidDataException("Byte pipeline table snapshot exceeds its limit.");
                raw=new byte[(int)stream.Length]; int offset=0;
                while (offset<raw.Length) { int got=stream.Read(raw,offset,raw.Length-offset); if(got==0)throw new InvalidDataException("Byte pipeline tables are truncated."); offset+=got; }
            }
            if (CartwheelByteProcessorCore.Sha256(raw)!=TablesSha256) throw new InvalidDataException("Byte pipeline table snapshot has changed.");
            JavaScriptSerializer json=new JavaScriptSerializer { MaxJsonLength=131072,RecursionLimit=16 };
            Dictionary<string,object> manifest=json.DeserializeObject(Utf8.GetString(raw)) as Dictionary<string,object>;
            if(manifest==null||(string)manifest["schema"]!="codex.byte-pipeline.tables.v1"||Convert.ToInt32(manifest["version"])!=1||Convert.ToInt32(manifest["stageCount"])!=6)throw new InvalidDataException("Invalid byte pipeline table contract.");
            object[] stages=manifest["stages"] as object[]; if(stages==null||stages.Length!=6)throw new InvalidDataException("Exactly six byte processors are required.");
            byte[][] maps=new byte[6][];
            for(int i=0;i<6;i++) {
                Dictionary<string,object> stage=stages[i] as Dictionary<string,object>;
                if(stage==null||(string)stage["id"]!="processor-"+(i+1).ToString(CultureInfo.InvariantCulture))throw new InvalidDataException("Byte processor order changed.");
                object[] values=stage["table"] as object[]; if(values==null||values.Length!=256)throw new InvalidDataException("Byte lookup table requires 256 entries.");
                maps[i]=new byte[256];
                for(int j=0;j<256;j++) { if(!(values[j] is int)||(int)values[j]<0||(int)values[j]>255)throw new InvalidDataException("Invalid byte lookup value."); maps[i][j]=(byte)(int)values[j]; }
                if(CartwheelByteProcessorCore.Sha256(maps[i])!=(string)stage["tableSha256"])throw new InvalidDataException("Byte lookup digest mismatch.");
            }
            _manifest=manifest;_stages=stages;_maps=maps;
        }

        private static Dictionary<string,object> Object(params object[] pairs)
        {
            Dictionary<string,object> value=new Dictionary<string,object>(StringComparer.Ordinal);
            for(int i=0;i<pairs.Length;i+=2)value.Add((string)pairs[i],pairs[i+1]); return value;
        }
        private static string Canonical(object value)
        {
            StringBuilder builder=new StringBuilder(); WriteJson(builder,value); return builder.ToString();
        }
        private static void WriteJson(StringBuilder b,object value)
        {
            if(value==null){b.Append("null");return;}
            string s=value as string;
            if(s!=null) {
                b.Append('"'); foreach(char c in s) { switch(c) {
                    case '"':b.Append("\\\"");break;case '\\':b.Append("\\\\");break;
                    case '\b':b.Append("\\b");break;case '\f':b.Append("\\f");break;case '\n':b.Append("\\n");break;case '\r':b.Append("\\r");break;case '\t':b.Append("\\t");break;
                    default:if(c<32)b.Append("\\u"+((int)c).ToString("x4",CultureInfo.InvariantCulture));else b.Append(c);break;
                }} b.Append('"');return;
            }
            if(value is bool){b.Append((bool)value?"true":"false");return;}
            Dictionary<string,object> dict=value as Dictionary<string,object>;
            if(dict!=null) {
                List<string> keys=new List<string>(dict.Keys);keys.Sort(StringComparer.Ordinal);b.Append('{');
                for(int i=0;i<keys.Count;i++){if(i>0)b.Append(',');WriteJson(b,keys[i]);b.Append(':');WriteJson(b,dict[keys[i]]);}b.Append('}');return;
            }
            System.Collections.IEnumerable list=value as System.Collections.IEnumerable;
            if(list!=null){b.Append('[');bool first=true;foreach(object item in list){if(!first)b.Append(',');first=false;WriteJson(b,item);}b.Append(']');return;}
            if(value is int||value is long||value is uint){b.Append(Convert.ToString(value,CultureInfo.InvariantCulture));return;}
            throw new InvalidDataException("Unsupported byte pipeline metadata type.");
        }
        private static string Digest(object value){return CartwheelByteProcessorCore.Sha256(Utf8.GetBytes(Canonical(value)));}
        private static void UInt32(byte[] data,int offset,int value){for(int i=0;i<4;i++)data[offset+i]=(byte)((uint)value>>(8*i));}
        private static int UInt32(byte[] data,int offset){uint value=0;for(int i=0;i<4;i++)value|=(uint)data[offset+i]<<(8*i);if(value>Int32.MaxValue)throw new InvalidDataException("Pipeline size exceeds its limit.");return (int)value;}

        public static CartwheelPipelineResult Process(byte[] payload)
        {
            if(payload==null||payload.Length>1048576)throw new ArgumentException("Pipeline input must contain at most 1 MiB.");
            if(_maps==null)throw new InvalidOperationException("Byte pipeline tables are not initialized.");
            string sourceHash=CartwheelByteProcessorCore.Sha256(payload),previous=sourceHash;
            byte[][] lanes=new byte[6][];object[] records=new object[6];
            string[] fields={"id","name","sourceArchive","sourceArchiveSha256","agentId","policySourceSha256","policyImageSha256","policyBrirSha256","tableSha256","uniqueOutputValues","lossy","duplicateOf"};
            for(int i=0;i<6;i++) {
                Dictionary<string,object> staticStage=(Dictionary<string,object>)_stages[i];
                Dictionary<string,object> stage=new Dictionary<string,object>(StringComparer.Ordinal);
                foreach(string field in fields)stage.Add(field,staticStage[field]);
                byte[] lane=new byte[payload.Length];int changed=0;
                for(int j=0;j<payload.Length;j++){lane[j]=_maps[i][payload[j]];if(lane[j]!=payload[j])changed++;}lanes[i]=lane;
                stage.Add("inputSha256",sourceHash);stage.Add("outputSha256",CartwheelByteProcessorCore.Sha256(lane));stage.Add("previousStageSha256",previous);
                stage.Add("inputBytes",payload.Length);stage.Add("outputBytes",payload.Length);stage.Add("changedBytes",changed);
                stage.Add("actualWork",Object("kind","byte-transform","lookupBytes",payload.Length,"payloadVmRuns",0,"tableBuildVmRuns",2048,"semanticTaskExecution",false));
                previous=Digest(stage);stage.Add("stageSha256",previous);records[i]=stage;
            }
            Dictionary<string,object> receipt=Object("schema","codex.byte-pipeline.receipt.v1","format","CWBP","version",1,"stageCount",6,"payloadBytes",payload.Length,"sourceSha256",sourceHash,
                "transform",_manifest["transform"],"limits",_manifest["limits"],"exactRecovery",Object("supported",true,"mechanism","original-payload-retained"),
                "actualWork",Object("kind","byte-transform","semanticTaskExecution",false,"payloadVmRuns",0,"lookupBytes",6*payload.Length,"tableBuildVmRuns",12288),"stages",records,"pipelineSha256",previous);
            string metadata=Canonical(receipt);byte[] raw=Utf8.GetBytes(metadata);if(raw.Length>65536)throw new InvalidDataException("Pipeline metadata exceeds 64 KiB.");
            byte[] artifact=new byte[48+raw.Length+7*payload.Length];artifact[0]=67;artifact[1]=87;artifact[2]=66;artifact[3]=80;artifact[4]=1;artifact[5]=6;
            UInt32(artifact,8,payload.Length);UInt32(artifact,12,raw.Length);
            for(int i=0;i<32;i++)artifact[16+i]=Byte.Parse(sourceHash.Substring(2*i,2),NumberStyles.HexNumber,CultureInfo.InvariantCulture);
            Buffer.BlockCopy(raw,0,artifact,48,raw.Length);int offset=48+raw.Length;Buffer.BlockCopy(payload,0,artifact,offset,payload.Length);offset+=payload.Length;
            foreach(byte[] lane in lanes){Buffer.BlockCopy(lane,0,artifact,offset,lane.Length);offset+=lane.Length;}
            return new CartwheelPipelineResult { Artifact=artifact,Receipt=metadata,Lanes=lanes };
        }
        public static byte[] Recover(byte[] artifact)
        {
            if(artifact==null||artifact.Length<48||artifact.Length>MaxArtifactLength||artifact[0]!=67||artifact[1]!=87||artifact[2]!=66||artifact[3]!=80||artifact[4]!=1||artifact[5]!=6||artifact[6]!=0||artifact[7]!=0)throw new InvalidDataException("Invalid CWBP pipeline header.");
            int length=UInt32(artifact,8),metadata=UInt32(artifact,12);
            if(length>1048576||metadata<1||metadata>65536||artifact.Length!=48+metadata+7*length)throw new InvalidDataException("Invalid CWBP pipeline length.");
            byte[] payload=new byte[length];Buffer.BlockCopy(artifact,48+metadata,payload,0,length);
            byte[] expected=Process(payload).Artifact;int differences=expected.Length^artifact.Length;
            if(expected.Length==artifact.Length)for(int i=0;i<expected.Length;i++)differences|=expected[i]^artifact[i];
            if(differences!=0)throw new InvalidDataException("Pipeline replay rejected changed bytes, metadata, or processor evidence.");
            return payload;
        }
    }
}
