@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "D:\Codex\CartwheelConsole\Start Console.cmd" (
    echo Cartwheel is missing from D:\Codex\CartwheelConsole.
    echo Keep the complete installed console folder at that location.
    pause
    exit /b 2
)
call "D:\Codex\CartwheelConsole\Start Console.cmd" %*
exit /b %ERRORLEVEL%
