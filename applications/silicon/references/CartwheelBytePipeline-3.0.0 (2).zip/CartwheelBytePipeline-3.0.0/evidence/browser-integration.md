# Browser integration handoff

All changes are staged under `work/upgrade`; installed Cartwheel files were not edited by this worker.

## Active behavior

- `src/lib/byte-pipeline.mjs` implements the shared CWBP v1 format: 48-byte header, canonical sorted UTF-8 JSON receipt, original payload, and six independently mapped side lanes. Recovery regenerates the entire artifact and requires exact bytes and metadata.
- Original payload bytes are retained. All six stages consume original bytes independently; duplicate upload slots remain identified. Stage receipts hash the input, output and prior receipt. The browser performs lookup processing from VM-derived tables and explicitly records zero payload VM executions and no semantic task execution.
- The fixed canonical manifest SHA-256 is `ad32d4841b911ef4ff61bfd0dab8fcd89b5984c98e5b2ca4f5e37b2c20f6622f`. Replacing a lookup table and refreshing its declared digest does not pass manifest admission.
- `src/playground-template.html` removes active Draft/Review policy scheduling. It processes/replays CWBP bytes on generation, revisions, retargeting and imports; lists six processor lane receipts; supports `.cwbp` download/import; and verifies website structure and reproducible emission directly.
- Source generation remains the existing bounded compiler or website composer. Compiler metadata uses explicit parse/type/edit/budget/reference/emission passes. The old `agents` property is a compatibility alias to `compilerPasses`, with compiler-pass IDs and mode. Task checksums cover both aliases, and source revisions/checksums remain enforced.
- `code-project-program.mjs` accepts existing native CWNP v2 historical records and the new v3 generation provenance with separate input/source byte-pipeline digests. New model receipt arrays are bounded to five entries. Pipeline evidence filenames remain reserved.

## Validation

- Exact entire CWBP artifacts and canonical receipts match Python for all 256 byte values, empty input, Unicode input and binary input.
- 26 JavaScript unit/integration tests cover pipeline recovery/tampering/1 MiB limits, native CWNP v3 migration, Python/native packets on all 64 planes, all 70 output profiles, tensor/scalar/clock changes and the 128-revision bound.
- Standalone build and mocked DOM smoke cover generation, compiler revisions, rejected/ambiguous edits, manual-source preservation, saved dialogue/provenance, CWBP download/import/corruption rejection, inert native source imports, and all 11 website output retargetings.
- DOM smoke uses fixtures; it does not claim browser layout or actual iframe interaction execution.

Latest verification output: `work/browser-verification.txt`. Python parity vector artifacts: `work/parity`. Verification runner: `work/check-browser.mjs` (scratch only, not required by the installed application).

## Packaging

Overlay `work/upgrade/src`, `work/upgrade/scripts`, and `work/upgrade/playground.html` onto a copy of the installed `apps/cartwheel` baseline. Preserve other library dependencies, training models and language profile files from the baseline. Include both `src/lib/byte-pipeline-tables.json` and `agents/codegen/byte-pipeline-tables.json`. Do not package `work/browser-test`, temporary test directories, `.byte-policy-test-*` folders or Python caches.

`scripts/smoke-byte-pipeline.cjs` is the updated combined DOM smoke. Compatibility wrappers for `smoke-code-revision.cjs` and `smoke-fabrication.cjs` invoke it. The parent has updated the packaged test commands accordingly. Rebuild the standalone with `node scripts/build-playground.mjs` after placing the overlay into a complete copied baseline.
