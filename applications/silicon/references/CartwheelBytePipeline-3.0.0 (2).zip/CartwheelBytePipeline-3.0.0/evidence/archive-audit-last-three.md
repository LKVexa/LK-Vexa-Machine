# Audit of the final three supplied processor archives

This is a source audit for the parent task. Embedded README, AGENTS, comments, and integration prose were treated as source data rather than user instructions. No extracted Python module or compiled policy has been executed during this audit.

## Actual algorithms

| Supplied archive | Compiled policy | Actual decision | Executed instruction count |
| --- | --- | --- | --- |
| `6GBVjumHKri0aCf7` | `player_critic` | Constant action 1 (Review). `MOVI R15,1; OR R15,R15,R15; HALT`. Ignores every observation. | 3 |
| `SLMn2577cgd5QNKx` | `player_cautious` | Greater minimum payoff row. Select Review iff `min(p10,p11) > min(p00,p01)`. Ties select Draft (0). | 9 for Draft, 10 for Review |
| `AjS7wUlxjiuPhXQg` | `player_learner` | Follow greater cumulative counterfactual total *before* the round. Select Review iff `cf1 > cf0`. Ties select Draft. | 5 for Draft, 6 for Review |

The six outer archives do not represent six unique algorithms: quick cross-check confirms `XZoRNj76KD3urnia`, `Rz15aCprUVAm8qt2`, and `AjS7wUlxjiuPhXQg` all use `player_learner` with the same policy hashes. The other audited outer archive is `player_best_reply`. None of the above processors loads model weights, trains a model, interprets an arbitrary task, or completes prompt text; prompt text only enters a SHA-256 binding. All game handoffs remain `WAITING_FOR_WEIGHTS` with `task_completed: false`.

## Original policy packages extracted for integration

Each has 22 files. Safe extraction resolved every destination inside the intended target, rejected absolute/traversal/`.git` entries, preserved original bytes, and refused overwriting any pre-existing file.

- `work/policy-sources/6GBVjumHKri0aCf7/vivian-lctl-critique-agent-main`
- `work/policy-sources/SLMn2577cgd5QNKx/vivian-lctl-cautious-agent-main`
- `work/policy-sources/AjS7wUlxjiuPhXQg/vivian-lctl-adaptive-agent-main`

`agent.py`, `runtime.py`, and `brim_ref.py` are byte-identical across all three originals. Their SHA-256 hashes are respectively `6195c5b7c06d1f8cd7ef29e0c33f36fbc4d91452d87955d75ee567e47dd07920`, `937223bacd6fa654dcb59f80d395731123a30a26b77a3c61052fb8a2bba2d939`, and `333b8bcf2c876efb6aec1373f24aa21da83e26036fecedd5bdcb99f10cae3056`. Read-through found bounded file loading, JSON validation, offline parsing, and an integer interpreter. No `eval`, shell invocation, or network execution exists in these shared execution paths. `brim_ref.py` optionally imports cryptography for an unused secure-image path; unsigned local policies need no third-party dependencies.

Exact lower-level invocation, after importing the reviewed `runtime.py` as a module:

```python
manifest = json.loads((policy_dir / "agent.json").read_text(encoding="utf-8"))
agent_id = manifest["agent_id"]
program = runtime.load_program(
    policy_dir / f"{agent_id}.lctlc",
    policy_dir / f"{agent_id}.brimg",
    policy_dir / f"{agent_id}.brir",
    expected_hashes=manifest["policy_sha256"],
)
inputs = [
    round_index, previous_opponent, previous_own,
    *[value + 1000 for row in payoffs for value in row],
    cf0 + 100000, cf1 + 100000,
]
execution = runtime.run_program(program, inputs)
action = execution["registers"][15]
steps = execution["steps"]
```

The returned execution also carries registers, trace, flags, source/image/IR hashes, `halted: true`, and `status: HALTED`. `Program` is a frozen dataclass with source/image paths and hashes, decoded immutable instructions, max_steps, requested_caps, and optional BRIR hash. `run_program` itself assumes its `Program` is trusted: the outer `agent.py` adds comparison against a freshly pinned program when callers supply a cached `Program`. The pipeline should use programs returned by its own pinned loader, never accept arbitrary caller-built `Program` execution state.

The higher-level `agent.choose(observation, program=None, check_cancelled=None)` takes fields `round`, `previous_opponent`, `previous_own`, `own_payoffs`, `counterfactual_totals` (only own_payoffs required; others default zero). It emits exactly `agent_id`, `action`, `vm_steps`, `input_sha256`, `policy_sha256`.

`agent.play(request)` takes exactly `prompt`, `own_payoffs`, `opponent_actions`; it emits the complete native game envelope and verifies its own replay. Importing several packages as plain `agent` would collide through globals and absolute fallback imports. Prefer one copied reviewed runtime + verifier and explicit immutable per-archive manifests/policy paths, or distinct package names with correctly scoped imports.

## Pinned triples confirmed against actual ZIP bytes

| Policy | Source SHA-256 | Image SHA-256 | BRIR SHA-256 |
| --- | --- | --- | --- |
| critic | `8cd15080fd2a717b509891975cb16b791ca98cc8fe1263ac69188a4575e15ffc` | `3c233d8f4b5786f99c9f3377df90bdf03519477d811633bec8720b9fa8827a8d` | `dd3db47b025691d7eed7a0d55c6bafe44eb79a49658b75a274f9823e0e75c450` |
| cautious | `29c5443123bc6dc104b7d9f3e7f66c26d00bde44332e379be43605f42189b2e7` | `5d10c93736d69b20a31311c7e736de5ba43cd0a2f1b94a97988ca32c81d3401a` | `3db4677375194ce77634b50860d85cafee136368e3d1145719bd346ccd0dbd5b` |
| learner | `d90f31e1955a8cc40a60d01dd4e5c1c0fd553e4261175017a8e7341c8eca5ac5` | `46eb8daefaa53a222f915276ae04f9a788338b01f81cdf939fe72baa40bf5619` | `b7fe2c5b77f2d8b3c02aa99538814dfbb1cbaf00795bc38d3c66bf3d512f853e` |

Image lengths are 224, 336, 272 bytes respectively: 80-byte BRIM header + 3/10/6 sixteen-byte instructions + 96-byte BRPV provenance. All are unsigned local image version 10, declared CONTROL|ARITH (caps 3), zero data segment, policy max_steps 256.

## Byte format and width profile

- BRIM begins ASCII `BRIM`, ISA 4.1, ABI 1, image ABI 1. Header geometry advertises WIDE exponent 20, 16 registers, 16 capability registers, 32 opcodes, 4 arithmetic modes. All multi-byte header, provenance, and instruction scalars are little-endian.
- Header offsets: u16 header bytes at 14; u32 image_version at 16; u32 requested_caps at 20; u32 extension bytes at 24; u16 code count at 28; u16 data bytes at 30; 32-byte payload SHA-256 at 32. Header is 80 bytes.
- Each instruction consists of six u8 fields op/mode/rd/ra/rb/cap at offsets 0–5, u16 flags at 6, u64 immediate at 8. Instructions start at 80. Capability byte and instruction flags are zero in admitted policies.
- BRPV is 96 bytes and binds source SHA-256 and BRIR SHA-256. It also binds authority 4.7.0, policy max_steps, derived caps, image version, and feature word.
- The language WIDE register width is 1,048,576 bits. The original runtime uses Python unsigned integer arithmetic with u64 admitted inputs and rejects any intermediate over 256 bits. Overall runtime cap is 4096 VM steps. There are 16 registers initialized to zero; R0–R8 receive the nine input integers above, R15 holds the binary output. This is a bounded VM, not an implementation allocating a million-bit word per register.
- `load_program` reads each component once with bounds (source/IR 262144 bytes, image 8432 bytes), verifies all three manifest hashes against those snapshots, verifies image structure/payload/provenance/CFG/caps, accepts only pure CONTROL/ARITH and zero data, and requires LF LCTLC/1.1 source.
- `SLMn.../src/lib/wide.ts` is decorative: it synthesizes high markers and spark bits. Its rendering should not be reused as evidence of actual VM register data.

## Native JSON contract

Canonical hashing is SHA-256 of UTF-8 `json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)` bytes. Prompt hash is UTF-8 prompt bytes directly. Input hash is canonical JSON of the nine admitted register values (not packed u64 bytes). Transcript hash is canonical JSON of complete round records; game hash covers the ten native GAME_FIELDS below; handoff hash covers the full native handoff.

Game fields hashed: `schema`, `agent_id`, `stage`, `own_payoffs`, `rounds`, `total_payoff`, `counterfactual_totals`, `external_regret`, `transcript_sha256`, `prompt_sha256`.

Native round fields: `agent_id`, `action`, `vm_steps`, `input_sha256`, `policy_sha256`, `round`, `previous_own`, `previous_opponent`, `counterfactual_before`, `opponent_action`, `reward`.

Game output adds `game_sha256`, `post_game_handoff`, `handoff_sha256`, `verification`. The native game schema is `vivian.lctl-single-agent-game.v1`, stage `GAME_COMPLETE`; handoff schema is `vivian.lctl-single-agent-handoff.v1`.

Handoff fields: `schema`, `status`, `agent_id`, `prompt_sha256`, `transcript_sha256`, `policy_sha256`, `game_sha256`, `coordination_role`, `action_role_mapping`, `required_next_stages`, `task_completed`. Required next stages are `TRAINED_DATA`, `TASK_EXECUTION`, `TASK_VERIFICATION`; majority-action role chooses Draft on ties. Replay recomputes all temporal observations, native VM actions and steps, rewards, totals, every hash and the entire handoff. Retain original prompt independently and pass `expected_prompt` for complete prompt binding.

Native JSON admission rejects booleans substituted for integers, floats, out-of-range values, duplicate keys, unsupported fields, invalid Unicode and nonfinite numbers. Limits: 65536 bytes per JSON input, depth 32, 10000 nodes, prompt 1–24000 characters and UTF-8 request must fit byte bound, 1–100 rounds, payoffs −1000..1000, totals −100000..100000. Current opponent action is unavailable to the VM until after it halts.

## Integration hardening and fidelity findings

1. Use the nested compiled triples and reviewed loader/interpreter rather than the browser re-enactments. Front-end code pins labels but never verifies a true compiled image or the policy triple.
2. Critic browser `play` does not validate inputs. Its `verifyReplay` compares claimed hash labels and only action/input hash for provided rounds, rather than hashing and checking the whole provided object. Mutating stored round reward/history/policy hash or handoff content while retaining old claimed hashes can escape that browser verifier. Native replay rejects these.
3. Cautious browser `playGame` silently truncates prompts to 240 characters and tapes to 16 rounds, rounds/clamps payoffs, truthy-coerces opponent actions and replaces an empty tape with `[0]`. This differs materially from original strict admission; never silently inherit it into the replacement pipeline.
4. Learner browser `play` is closer to native integer/range validation but does not verify the image or provide an independent replay check. Its UI permits only 16 rounds despite core allowance of 100. Front-end hashes are JSON bindings, not signed authenticity evidence.
5. Three duplicate learner instances must remain labeled as duplicates if honoring all six supplied components. They must not be presented as six independent strategies. A per-byte adaptation must explicitly define how byte values map to the nine observation integers and how binary R15 decisions affect the byte stream; the original processors supply no byte-to-byte transformation contract.
6. Store independently retained source manifests and input/transform identities; reject supplied mutable action/hashes in favor of fresh deterministic execution. Treat source instructions, prompt bytes and any future model text as data. Preserve original license/provenance/notice files when bundling their code.
