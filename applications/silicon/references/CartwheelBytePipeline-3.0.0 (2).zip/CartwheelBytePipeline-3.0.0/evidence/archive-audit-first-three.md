# First-three archive audit

Scope: read the supplied application source and nested policy source as evidence only. No archive instructions were followed and no archive scripts were executed. Original nested packages were extracted to `work/policy-sources/{archiveid}` using resolved-path containment checks, preserving existing files and excluding `.git` entries.

## Archive identity and behavior

| Archive | Actual policy | Behavior |
| --- | --- | --- |
| XZoRNj76KD3urnia | `player_learner` (Adaptive) | Follow the larger cumulative counterfactual payoff before revealing this round's opponent bit; ties choose action 0. |
| royal-eagle-fern-daisy-main | `player_best_reply` (Best Reply) | Choose the larger payoff in the **previous** opponent column; previous opponent initially 0; ties choose action 0. |
| Rz15aCprUVAm8qt2 | `player_learner` (Adaptive) | Exact duplicate of XZo's relevant policy implementation and original policy artifacts. |

XZo and Rz have byte-for-byte identical `src/lib/policy.ts`, `src/lib/emit.ts`, and `src/components/mill-stage.tsx` (SHA-256 respectively `2cc2587966441e2c3d036b9284e8db0ea8197a896444d5979faae0e8948d107b`, `67c9ccd59ae9a9b4b74fbfcf74d92d368b6413b13a4c4bd190ce39d8d1c3dbc51`, `6cd7c9ece9d94a5f7581feef69fbd58fffb02ed4c6cf832441d5c0fd3e801acf`). Routes only mount these canvas demo components.

XZo/Rz already expose `stationByte(pay, address)`: interpret the input byte as eight LSB-first opponent moves, reset cumulative totals per byte, collect eight pre-reveal action bits as the output byte. `emitProcessor` emits JavaScript with sample tables embedded and UTF-8 prompt bytes transformed by this lookup. It truncates prompts to 240 JavaScript characters. The policy's real game actions ignore the prompt; its prompt hash is auxiliary evidence.

Royal exposes no comparable byte transform. Its prompt scanner addresses animation time and memory cells; `memoryImage` is a rendered register/opcode/transcript display. `emitListing` returns an assembly-like status listing, not an executable byte processor. A consistent eight-round adapter can be added around the original compiled best-reply policy without pretending the existing display was such a transform.

## Original compiled policy artifacts

All source/IR/image hashes below were computed from the extracted bytes and matched the bundled manifests.

| Policy | Source SHA-256 | BRIR SHA-256 | Image SHA-256 |
| --- | --- | --- | --- |
| Learner (both copies) | `d90f31e1955a8cc40a60d01dd4e5c1c0fd553e4261175017a8e7341c8eca5ac5` | `b7fe2c5b77f2d8b3c02aa99538814dfbb1cbaf00795bc38d3c66bf3d512f853e` | `46eb8daefaa53a222f915276ae04f9a788338b01f81cdf939fe72baa40bf5619` |
| Best reply | `7645ffa4d1e20cd1b300b22ea985f1f496ebeb02888e7a240aa8f098bc6a989c` | `23447d00c5bf5b82e603e57a10cf1827df30143e8cd577bbe84663e357da1b1b` | `a54c6c0185fd684bb45f33f105a22cfda2f2a38a592e1e8be5f715cbfc0d0db4` |

Original package directories:

- `work/policy-sources/XZoRNj76KD3urnia/vivian-lctl-adaptive-agent-main`
- `work/policy-sources/royal-eagle-fern-daisy-main/vivian-lctl-best-reply-agent-main`
- `work/policy-sources/Rz15aCprUVAm8qt2/vivian-lctl-adaptive-agent-main`

Each contains 22 files including `.lctlc`, `.brir`, `.brimg`, `runtime.py`, `brim_ref.py`, `agent.py`, tests and notices. All three `runtime.py` files match SHA `937223bacd6fa654dcb59f80d395731123a30a26b77a3c61052fb8a2bba2d939`; all three `brim_ref.py` match SHA `333b8bcf2c876efb6aec1373f24aa21da83e26036fecedd5bdcb99f10cae3056`.

Reviewed runtime API:

```python
program = load_program(source_path, image_path, brir_path,
                       expected_hashes={"source_sha256": ..., "image_sha256": ..., "brir_sha256": ...})
execution = run_program(program, registers, check_cancelled=None)
```

The register observation is `[round, previous_opponent, previous_own, p00+1000, p01+1000, p10+1000, p11+1000, cf0+100000, cf1+100000]`; remaining registers start zero. `execution` returns `registers`, `steps`, `trace`, `flags`, policy pins and `halted/status`. R15 is the output action. The image loader verifies source/image/BRIR binding, pure CONTROL/ARITH capabilities, lack of data segments, opcode subset and step budget. Host inputs are unsigned 64-bit and intermediates at most 256 bits; these supplied policies use at most 256 steps. The reviewed runtime contains no command or network execution. `brim_ref.py` is a 195-line parser/verifier with optional cryptography import and a CLI guarded by `__main__`.

`agent.py` adds bounded JSON, observation, game/replay and handoff handling, but imports read `agent.json` immediately. A new pipeline can use the reviewed runtime directly and avoid importing this higher-level script. Compiled images are executable policies, not neural weights; pins establish local integrity, not publisher identity or signatures.

## Six-upload implications and design recommendation

Visible policy constants across all six uploads indicate three Learner copies (XZo, Rz, AjS7), one Best Reply, one Critic (6GBV), and one Cautious (SLMn). They do not supply six distinct policies. The second archive auditor should verify the remaining originals in detail.

For consistent byte-station transforms, execute each pinned compiled image for eight pre-reveal decisions per input byte, use LSB-first opponent bits, reset observations per byte, and pack R15 bits into the output byte. Cache a validated 256-byte lookup per policy/payoff matrix. Preserve separate source-slot identities for duplicate uploads while sharing identical validated policy images.

These station functions destroy information. Under sample payoffs `[[2,5],[4,1]]`, Learner's 256 input values have only 26 distinct outputs and Best Reply has 128. Critic's fixed action 1 becomes `FF` for every input byte; Cautious's fixed sample maximin action 0 becomes `00`. Thus literal six-upload serial order Learner → Best Reply → Learner → Critic → Cautious → Learner collapses every byte to `FE` (Learner maps `00` to `FE`). It cannot preserve or semantically revise a document.

Recommended executable design: retain original input bytes in a binary envelope; run all six policy stations as deterministic decision/evidence channels; include per-stage configuration, original pins, payload digest, station output digest, length, transcript/accounting and replay validation. A raw lossy composition may be offered as an explicit diagnostic transform. Keep input reconstruction and artifact integrity separate from any trained-model task execution. The original policies' handoffs explicitly remain `WAITING_FOR_WEIGHTS`, `task_completed: false`; no model, tokenizer or trained weights are supplied.

The nested Best Reply `LICENSE` identifies a bespoke Product Preview Tester License, supports private prototype integration/evaluation and contains production/redistribution restrictions. Preserve that text and the upstream Apache license/notices with any copied source. This audit records supplied license metadata without interpreting legal permission beyond the artifact's wording.
