import { decodeData, encodeData, KIND_INPUT, PROTOCOL } from "@/vendor/vws/frame.js";

export type ConnState = "booting" | "open" | "active" | "reset" | "halted" | "error";

export type RamStatus = {
  sessionId: string;
  cwd: string;
  cols: number;
  rows: number;
  busy: boolean;
  user?: string;
  host?: string;
  nodes: { key: string; node: string; present: boolean; built: boolean }[];
  ram?: { bytes: number; nodes: number; maxBytes: number; maxNodes: number };
  profile?: string;
  disk?: {
    device: string;
    model: string;
    fs: string;
    mount: string;
    synced: boolean;
    restored: boolean;
    writtenAt: number;
    error?: string;
  };
  seal?: string;
  digest?: string;
  drifted?: boolean;
  epoch?: string;
  uptimeMs?: number;
  protocol?: string;
  version?: string;
  commands?: number;
};

export type BrowserState = { visible: boolean; url: string; engine: string };

export type HoloState = {
  n: number;
  phase: number[];
  intensity: number[];
  zMm: number;
  lambdaNm: number;
  pitchUm: number;
  op: string;
  gate: string;
  bit: number | null;
  detector: number;
  frames: number;
  nmse: number | null;
  open?: boolean;
  cycles?: number;
  stage?: string;
  info?: number;
  moved?: number;
  logical1?: number;
  erased?: number;
  landauerJ?: number;
  sampleUs?: number;
  padic?: number;
  margin?: number;
  bloch?: [number, number, number];
  purity?: number;
  wigner?: number[] | null;
  wignerN?: number;
  wMin?: number;
  wNeg?: number;
  gifAlpha?: number;
  gifChi?: number;
  gifNbar?: number;
  orderR?: number;
  penteract?: { x: number; y: number; z: number; t: number; p: number } | null;
  recorded?: string;
  fidelity?: number | null;
  macOps?: number;
  oamValue?: number | null;
  oamBits?: string;
  oamCharge?: number;
  oamRem?: number;
  oamOverflow?: number;
  byteStages?: { id: string; name: string; changed: number; unique: number; owned?: number; same?: string; cpuCycles?: number; gpuWarps?: number; equivalent?: boolean }[] | null;
  byteWritten?: number;
  route?: number[] | null;
};

type Handler<T> = (payload: T) => void;

const CREDIT = 262144;

function randomId() {
  const b = new Uint8Array(8);
  crypto.getRandomValues(b);
  return [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
}

type Socket = {
  port: MessagePort;
  sid: string | null;
  epoch: string | null;
  inSeq: number;
  outSeq: number;
  consumed: number;
  opened: boolean;
  decoder: TextDecoder;
};

/**
 * One hermit.vws.v2 socket per terminal tab, carried on a MessagePort into
 * the guest worker. The filesystem is flushed to the local SSD, so stopping
 * the worker does not drop the volume.
 */
export class RamLink {
  worker: Worker | null = null;
  private booted: Promise<void> | null = null;
  private generation = 0;
  epoch = "";
  seal = "";
  version = "";
  restored = false;
  device = "nvme0n1";
  private sockets = new Map<string, Socket>();
  private statusWait = new Map<string, (status: RamStatus | null) => void>();

  onData: Handler<{ sessionId: string; chunk: string }> = () => {};
  onExit: Handler<{ sessionId: string; code: number; reason: string }> = () => {};
  onState: Handler<{ sessionId: string; state: ConnState; detail?: string }> = () => {};
  onBrowser: Handler<BrowserState> = () => {};
  onHolo: Handler<HoloState> = () => {};
  onHalt: Handler<{ reason: string }> = () => {};

  boot(): Promise<void> {
    if (this.booted) return this.booted;
    this.booted = new Promise((resolve, reject) => {
      if (typeof Worker === "undefined") {
        reject(new Error("The server only boots in the browser"));
        return;
      }
      const worker = new Worker(new URL("../vendor/ram-worker.js", import.meta.url), { type: "module" });
      this.worker = worker;
      const timer = window.setTimeout(() => reject(new Error("The SSD did not finish mounting")), 8000);
      worker.onmessage = (ev: MessageEvent) => {
        const data = ev.data as {
          type?: string;
          epoch?: string;
          seal?: string;
          version?: string;
          restored?: boolean;
          device?: string;
          message?: string;
          reason?: string;
          payload?: BrowserState | HoloState;
        };
        if (data?.type === "ready") {
          window.clearTimeout(timer);
          this.epoch = data.epoch || "";
          this.seal = data.seal || "";
          this.version = data.version || "";
          this.restored = Boolean(data.restored);
          if (data.device) this.device = data.device;
          resolve();
        } else if (data?.type === "error") {
          window.clearTimeout(timer);
          reject(new Error(data.message || "SSD mount failed"));
        } else if (data?.type === "halt") {
          this.onHalt({ reason: data.reason || "poweroff" });
        } else if (data?.type === "browser" && data.payload) {
          this.onBrowser(data.payload as BrowserState);
        } else if (data?.type === "holo" && data.payload) {
          this.onHolo(data.payload as HoloState);
        }
      };
      worker.onerror = (ev) => {
        window.clearTimeout(timer);
        reject(new Error(ev.message || "Server error"));
      };
    });
    return this.booted;
  }

  async reboot(reason = "power cycle") {
    const gen = ++this.generation;
    for (const id of this.sockets.keys()) {
      this.onState({ sessionId: id, state: "reset", detail: reason });
    }
    this.sockets.clear();
    this.worker?.terminate();
    this.worker = null;
    this.booted = null;
    await this.boot();
    if (gen !== this.generation) return;
  }

  peekHolo() {
    this.worker?.postMessage({ type: "holo-peek" });
  }

  destroy() {
    this.generation += 1;
    this.worker?.terminate();
    this.worker = null;
    this.booted = null;
    this.sockets.clear();
  }

  async open(cols: number, rows: number): Promise<{ sessionId: string }> {
    await this.boot();
    const worker = this.worker;
    if (!worker) throw new Error("Server is down");
    const channel = new MessageChannel();
    const port = channel.port2;
    const sock: Socket = {
      port,
      sid: null,
      epoch: null,
      inSeq: 0,
      outSeq: 0,
      consumed: 0,
      opened: false,
      decoder: new TextDecoder("utf-8"),
    };
    const rid = randomId();
    return new Promise((resolve, reject) => {
      const timer = window.setTimeout(() => reject(new Error("session open timed out")), 5000);
      port.onmessage = (ev: MessageEvent) => {
        if (typeof ev.data !== "string") {
          if (!sock.sid || !sock.opened) return;
          let frame;
          try {
            frame = decodeData(new Uint8Array(ev.data as ArrayBuffer));
          } catch {
            return;
          }
          if (frame.seq !== sock.outSeq + 1) return;
          sock.outSeq = frame.seq;
          sock.consumed += frame.payload.length;
          const text = sock.decoder.decode(frame.payload, { stream: true });
          if (text) this.onData({ sessionId: sock.sid, chunk: text });
          this.credit(sock);
          return;
        }
        let msg: {
          type?: string;
          rid?: string;
          sid?: string;
          epoch?: string;
          payload?: Record<string, unknown>;
        };
        try {
          msg = JSON.parse(ev.data as string) as typeof msg;
        } catch {
          return;
        }
        if (msg.type === "hello") {
          port.postMessage(
            JSON.stringify({
              v: 2,
              type: "session.open",
              rid,
              payload: { cols, rows, mode: "virtual", creditBytes: CREDIT },
            }),
          );
          return;
        }
        if (msg.type === "session.opened" && msg.rid === rid && msg.sid) {
          window.clearTimeout(timer);
          sock.sid = msg.sid;
          sock.epoch = msg.epoch || this.epoch;
          sock.opened = true;
          this.sockets.set(msg.sid, sock);
          this.onState({ sessionId: msg.sid, state: "active" });
          resolve({ sessionId: msg.sid });
          return;
        }
        if (msg.type === "session.exit" && msg.sid) {
          const payload = msg.payload || {};
          this.sockets.delete(msg.sid);
          this.onExit({
            sessionId: msg.sid,
            code: Number(payload.code) || 0,
            reason: String(payload.reason || "closed"),
          });
          return;
        }
        if (msg.type === "session.status" && msg.rid && this.statusWait.has(msg.rid)) {
          const done = this.statusWait.get(msg.rid);
          this.statusWait.delete(msg.rid);
          done?.(msg.payload as unknown as RamStatus);
          return;
        }
        if (msg.type === "error") {
          const payload = msg.payload || {};
          if (!sock.opened) {
            window.clearTimeout(timer);
            reject(new Error(String(payload.message || "open failed")));
          } else if (sock.sid) {
            this.onState({
              sessionId: sock.sid,
              state: "error",
              detail: String(payload.message || payload.code || "error"),
            });
          }
        }
      };
      worker.postMessage({ type: "attach" }, [channel.port1]);
    });
  }

  start(sessionId: string) {
    const sock = this.sockets.get(sessionId);
    if (!sock) return;
    sock.port.postMessage(JSON.stringify({ v: 2, type: "session.start", sid: sessionId }));
  }

  write(sessionId: string, text: string) {
    const sock = this.sockets.get(sessionId);
    if (!sock?.sid) return;
    const bytes = new TextEncoder().encode(text);
    const max = 8192;
    for (let i = 0; i < bytes.length; i += max) {
      const part = bytes.subarray(i, Math.min(bytes.length, i + max));
      sock.inSeq += 1;
      const frame = encodeData(KIND_INPUT, sock.inSeq, part);
      sock.port.postMessage(frame, [frame.buffer]);
    }
  }

  resize(sessionId: string, cols: number, rows: number) {
    const sock = this.sockets.get(sessionId);
    if (!sock?.sid) return;
    sock.port.postMessage(
      JSON.stringify({ v: 2, type: "terminal.resize", sid: sock.sid, payload: { cols, rows } }),
    );
  }

  signal(sessionId: string, signal = "SIGINT") {
    const sock = this.sockets.get(sessionId);
    if (!sock?.sid) return;
    sock.port.postMessage(
      JSON.stringify({ v: 2, type: "terminal.signal", sid: sock.sid, payload: { signal } }),
    );
  }

  close(sessionId: string) {
    const sock = this.sockets.get(sessionId);
    if (!sock?.sid) return;
    sock.port.postMessage(
      JSON.stringify({ v: 2, type: "session.close", sid: sock.sid, payload: { reason: "closed" } }),
    );
    this.sockets.delete(sessionId);
  }

  status(sessionId: string): Promise<RamStatus | null> {
    const sock = this.sockets.get(sessionId);
    if (!sock?.sid) return Promise.resolve(null);
    const rid = randomId();
    return new Promise((resolve) => {
      const timer = window.setTimeout(() => {
        this.statusWait.delete(rid);
        resolve(null);
      }, 2000);
      this.statusWait.set(rid, (st) => {
        window.clearTimeout(timer);
        resolve(st);
      });
      sock.port.postMessage(JSON.stringify({ v: 2, type: "session.status", rid, sid: sock.sid }));
    });
  }

  private credit(sock: Socket) {
    if (!sock.sid) return;
    sock.port.postMessage(
      JSON.stringify({
        v: 2,
        type: "flow.credit",
        sid: sock.sid,
        epoch: sock.epoch,
        payload: { consumedSeq: sock.outSeq, creditBytes: sock.consumed + CREDIT },
      }),
    );
  }
}

export const LINK_PROTOCOL = PROTOCOL;
