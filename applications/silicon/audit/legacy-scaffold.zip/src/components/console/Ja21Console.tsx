import { useEffect, useRef, useState } from "react";
import { Power, Plus, PanelRight, AppWindow, Aperture, X } from "lucide-react";
import { Parser as VtParser } from "@/vendor/vt/parser.js";
import { CanvasRenderer as VtCanvas } from "@/vendor/vt/renderer-canvas.js";
import { Screen as VtScreen } from "@/vendor/vt/screen.js";
import { RamLink, type BrowserState, type ConnState, type HoloState, type RamStatus } from "@/lib/ram-link";

type EngineScreen = InstanceType<typeof VtScreen>;
type EngineParser = InstanceType<typeof VtParser>;
type EnginePainter = InstanceType<typeof VtCanvas>;

type TabMeta = { id: string; n: number; title: string; closed: boolean };

const LOCAL_ORIGINS = new Set(["http://127.0.0.1:8788", "http://127.0.0.1:8791"]);
const TRIALS = ["hpu bytes vortex", "hpu oam 13", "hpu gate xor 1 0", "disk", "write /tmp/note kept"];

function fmtBytes(n: number | undefined) {
  if (n == null || !Number.isFinite(n)) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1048576) return `${(n / 1024).toFixed(1)} KiB`;
  return `${(n / 1048576).toFixed(2)} MiB`;
}

function screenText(screen: EngineScreen) {
  const grid = screen.grid ?? [];
  return grid
    .map((row: { ch: string }[]) => row.map((cell) => cell?.ch ?? " ").join("").replace(/\s+$/, ""))
    .join("\n");
}

function admit(raw: string): { url: string; note: string } {
  const url = raw.trim() || "about:blank";
  if (url === "about:blank") return { url, note: "blank" };
  if (url.startsWith("ram://")) return { url, note: "ram" };
  try {
    const origin = new URL(url).origin;
    if (LOCAL_ORIGINS.has(origin)) return { url, note: "admitted" };
  } catch {
    return { url, note: "rejected" };
  }
  return { url, note: "rejected" };
}

function parseHex(raw: string): [number, number, number] {
  const hex = raw.trim().replace("#", "");
  if (hex.length < 6) return [12, 15, 19];
  return [parseInt(hex.slice(0, 2), 16), parseInt(hex.slice(2, 4), 16), parseInt(hex.slice(4, 6), 16)];
}

function atto(j: number | undefined) {
  if (j == null || !Number.isFinite(j)) return "—";
  const aj = j * 1e18;
  if (Math.abs(aj) >= 0.01) return `${aj.toFixed(2)} aJ`;
  return `${(aj * 1e3).toFixed(2)} zJ`;
}

function FieldCanvas({ samples, n, kind }: { samples: number[]; n: number; kind: "phase" | "intensity" | "wigner" }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || n < 2 || samples.length < n * n) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    canvas.width = n;
    canvas.height = n;
    const img = ctx.createImageData(n, n);
    const style = getComputedStyle(document.documentElement);
    const bg = parseHex(style.getPropertyValue("--color-bg"));
    const fg = parseHex(style.getPropertyValue("--color-fg"));
    const pri = parseHex(style.getPropertyValue("--color-primary"));
    const danger = parseHex(style.getPropertyValue("--color-danger"));
    const data = img.data;
    for (let i = 0; i < n * n; i++) {
      let r: number;
      let g: number;
      let b: number;
      if (kind === "wigner") {
        const u = Math.max(-1, Math.min(1, ((samples[i] ?? 128) - 128) / 127));
        const src = u >= 0 ? pri : danger;
        const t = Math.abs(u);
        r = bg[0] + (src[0] - bg[0]) * t;
        g = bg[1] + (src[1] - bg[1]) * t;
        b = bg[2] + (src[2] - bg[2]) * t;
      } else if (kind === "intensity") {
        const t = Math.max(0, Math.min(1, (samples[i] ?? 0) / 255));
        r = bg[0] + (fg[0] - bg[0]) * t;
        g = bg[1] + (fg[1] - bg[1]) * t;
        b = bg[2] + (fg[2] - bg[2]) * t;
      } else {
        const t = Math.max(0, Math.min(1, (samples[i] ?? 0) / 255));
        const ang = t * Math.PI * 2;
        const wPri = (1 + Math.cos(ang)) * 0.5;
        const wFg = (1 + Math.sin(ang)) * 0.35;
        const wBg = Math.max(0.08, 1 - wPri * 0.85);
        const s = wBg + wPri + wFg;
        r = (bg[0] * wBg + pri[0] * wPri + fg[0] * wFg) / s;
        g = (bg[1] * wBg + pri[1] * wPri + fg[1] * wFg) / s;
        b = (bg[2] * wBg + pri[2] * wPri + fg[2] * wFg) / s;
      }
      const o = i * 4;
      data[o] = r;
      data[o + 1] = g;
      data[o + 2] = b;
      data[o + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
  }, [samples, n, kind]);
  return <canvas ref={ref} className="holo-field" width={n} height={n} aria-hidden="true" />;
}

function Mark() {
  return (
    <svg className="mark" viewBox="0 0 64 64" aria-hidden="true">
      <g fill="none" stroke="var(--color-primary)" strokeWidth="3" strokeLinecap="square">
        <path d="M4 16 V4 H16" />
        <path d="M48 4 H60 V16" />
        <path d="M60 48 V60 H48" />
        <path d="M16 60 H4 V48" />
      </g>
      <g stroke="var(--color-line)" strokeWidth="1.6" strokeDasharray="2 2.4">
        <line x1="32" y1="32" x2="32" y2="12" />
        <line x1="32" y1="32" x2="52" y2="32" />
        <line x1="32" y1="32" x2="32" y2="52" />
        <line x1="32" y1="32" x2="12" y2="32" />
      </g>
      <g fill="var(--color-raised)" stroke="var(--color-line)">
        <rect x="28" y="6" width="8" height="8" rx="1.5" />
        <rect x="50" y="28" width="8" height="8" rx="1.5" />
        <rect x="28" y="50" width="8" height="8" rx="1.5" />
        <rect x="6" y="28" width="8" height="8" rx="1.5" />
      </g>
      <polygon points="32,24 39,28 32,32 25,28" fill="var(--color-primary)" />
      <polygon points="25,28 32,32 32,40 25,36" fill="var(--color-primary)" opacity="0.75" />
      <polygon points="39,28 32,32 32,40 39,36" fill="var(--color-primary)" opacity="0.5" />
    </svg>
  );
}

export function Ja21Console() {
  const termRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imeRef = useRef<HTMLTextAreaElement>(null);
  const mirrorRef = useRef<HTMLPreElement>(null);
  const api = useRef<{
    run: (cmd: string) => void;
    newTab: () => void;
    closeTab: (id: string) => void;
    activate: (id: string) => void;
    power: () => void;
    peekHolo: () => void;
    focus: () => void;
  } | null>(null);

  const [tabs, setTabs] = useState<TabMeta[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [conn, setConn] = useState<ConnState>("booting");
  const [detail, setDetail] = useState("mounting nvme0n1");
  const [status, setStatus] = useState<RamStatus | null>(null);
  const [geom, setGeom] = useState("80×24");
  const [scrolled, setScrolled] = useState(false);
  const [panel, setPanel] = useState(false);
  const [surface, setSurface] = useState(false);
  const [holoOpen, setHoloOpen] = useState(false);
  const [holo, setHolo] = useState<HoloState | null>(null);
  const [browser, setBrowser] = useState<BrowserState>({
    visible: false,
    url: "about:blank",
    engine: "VB-JA21/9.8.7",
  });
  const [policyNote, setPolicyNote] = useState("blank");
  const [urlDraft, setUrlDraft] = useState("about:blank");
  const [bootError, setBootError] = useState("");

  useEffect(() => {
    if (window.innerWidth >= 960) setPanel(true);
  }, []);

  useEffect(() => {
    const canvasEl = canvasRef.current;
    const termEl = termRef.current;
    const imeEl = imeRef.current;
    if (!canvasEl || !termEl || !imeEl) return;
    const canvas: HTMLCanvasElement = canvasEl;
    const term: HTMLElement = termEl;
    const ime: HTMLTextAreaElement = imeEl;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const fontFamily = '"IBM Plex Mono", ui-monospace, monospace';
    const fontSize = window.innerWidth < 640 ? 13 : 15;
    const painter = new VtCanvas(canvas, new VtScreen(80, 24), {
      background: "#0c0f13",
      foreground: "#e9eff4",
      cursor: "#2fd0e4",
      cursorText: "#0c0f13",
      fontFamily,
      fontSize,
      lineHeight: 1.45,
    }) as EnginePainter;
    if (reduce) painter.cursorOn = true;

    const link = new RamLink();
    link.onHolo = (payload) => {
      setHolo(payload);
      if (payload.open) setHoloOpen(true);
    };
    const sessions = new Map<string, { screen: EngineScreen; parser: EngineParser; title: string }>();
    let current: string | null = null;
    let seq = 0;
    let cycling = false;
    let dead = false;
    let needs = true;
    const paint = () => {
      needs = true;
    };

    function mirror() {
      const tab = current && sessions.get(current);
      if (tab && mirrorRef.current) mirrorRef.current.textContent = screenText(tab.screen);
    }

    function geometry() {
      const rect = term.getBoundingClientRect();
      const style = getComputedStyle(term);
      const w = rect.width - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
      const h = rect.height - parseFloat(style.paddingTop) - parseFloat(style.paddingBottom);
      const g = painter.fit(Math.max(40, w), Math.max(40, h));
      const cols = Math.max(2, Math.min(400, g.cols));
      const rows = Math.max(1, Math.min(200, g.rows));
      setGeom(`${cols}×${rows}`);
      return { cols, rows };
    }

    function relayout() {
      const { cols, rows } = geometry();
      for (const [id, tab] of sessions) {
        if (tab.screen.cols !== cols || tab.screen.rows !== rows) {
          tab.screen.resize(cols, rows);
          link.resize(id, cols, rows);
        }
      }
      paint();
    }

    function activate(id: string) {
      const tab = sessions.get(id);
      if (!tab) return;
      current = id;
      setActive(id);
      painter.screen = tab.screen;
      painter.scrollToBottom();
      setScrolled(false);
      paint();
      mirror();
      ime.focus({ preventScroll: true });
    }

    async function openTab() {
      const { cols, rows } = geometry();
      const screen = new VtScreen(cols, rows) as EngineScreen;
      const parser = new VtParser(screen) as EngineParser;
      try {
        const res = await link.open(cols, rows);
        if (dead) return;
        const id = res.sessionId;
        const n = ++seq;
        screen.onTitle = (title: string) => {
          const tab = sessions.get(id);
          if (tab) tab.title = title || "session";
          setTabs((list) => list.map((t) => (t.id === id ? { ...t, title: title || "session" } : t)));
        };
        sessions.set(id, { screen, parser, title: "session" });
        setTabs((list) => [...list, { id, n, title: "session", closed: false }]);
        activate(id);
        link.start(id);
      } catch (err) {
        painter.screen = screen;
        parser.write(`\x1b[31m[could not open a session: ${err instanceof Error ? err.message : "failed"}]\x1b[0m\r\n`);
        paint();
        setBootError(err instanceof Error ? err.message : "could not open a session");
        setConn("error");
      }
    }

    function closeTab(id: string) {
      link.close(id);
      sessions.delete(id);
      setTabs((list) => list.filter((t) => t.id !== id));
      if (current === id) {
        const rest = [...sessions.keys()];
        const next = rest[rest.length - 1];
        if (next) activate(next);
        else void openTab();
      }
    }

    async function cycle(reason: string) {
      if (cycling || dead) return;
      cycling = true;
      setConn("reset");
      setDetail(reason);
      sessions.clear();
      setTabs([]);
      current = null;
      setActive(null);
      try {
        await link.reboot(reason);
        if (dead) return;
        setConn("open");
        setDetail(link.restored ? "nvme0n1 remounted" : "nvme0n1 formatted");
        await openTab();
      } catch (err) {
        setBootError(err instanceof Error ? err.message : "reboot failed");
        setConn("error");
      } finally {
        cycling = false;
      }
    }

    link.onData = ({ sessionId, chunk }) => {
      const tab = sessions.get(sessionId);
      if (!tab) return;
      tab.parser.write(chunk);
      if (sessionId === current) {
        painter.scrollToBottom();
        setScrolled(false);
        paint();
        mirror();
      }
    };
    link.onExit = ({ sessionId, code, reason }) => {
      const tab = sessions.get(sessionId);
      if (!tab) return;
      tab.parser.write(`\r\n\x1b[2m[session closed${reason ? " · " + reason : ""}${code ? " · exit " + code : ""}]\x1b[0m\r\n`);
      setTabs((list) => list.map((t) => (t.id === sessionId ? { ...t, closed: true } : t)));
      if (sessionId === current) paint();
    };
    link.onState = ({ sessionId, state, detail: d }) => {
      if (sessionId === current || !current) {
        setConn(state);
        if (d) setDetail(d);
      }
      if (d && (state === "error" || state === "reset")) {
        const tab = sessions.get(sessionId);
        tab?.parser.write(`\r\n\x1b[33m[${state}: ${d}]\x1b[0m\r\n`);
        if (sessionId === current) paint();
      }
    };
    link.onBrowser = (next) => {
      setBrowser(next);
      setUrlDraft(next.url);
      setPolicyNote(admit(next.url).note);
      if (next.visible) setSurface(true);
    };
    link.onHalt = ({ reason }) => {
      void cycle("power cycle — SSD flushed, remounting nvme0n1");
    };

    function send(data: string) {
      if (!current) return;
      painter.scrollToBottom();
      setScrolled(false);
      link.write(current, data);
    }

    function encodeKey(e: KeyboardEvent) {
      const k = e.key;
      if (e.ctrlKey && !e.altKey && !e.metaKey && k.length === 1) {
        const c = k.toLowerCase().charCodeAt(0);
        if (c >= 97 && c <= 122) return String.fromCharCode(c - 96);
      }
      switch (k) {
        case "Enter":
          return "\r";
        case "Backspace":
          return "\x7f";
        case "Tab":
          return "\t";
        case "Escape":
          return "\x1b";
        case "ArrowUp":
          return "\x1b[A";
        case "ArrowDown":
          return "\x1b[B";
        case "ArrowRight":
          return "\x1b[C";
        case "ArrowLeft":
          return "\x1b[D";
        case "Home":
          return "\x1b[H";
        case "End":
          painter.scrollToBottom();
          setScrolled(false);
          return "\x1b[F";
        case "Delete":
          return "\x1b[3~";
        case "PageUp":
          painter.scrollBy(painter.screen.rows - 1);
          setScrolled(painter.scrollOffset !== 0);
          paint();
          return null;
        case "PageDown":
          painter.scrollBy(-(painter.screen.rows - 1));
          setScrolled(painter.scrollOffset !== 0);
          paint();
          return null;
        default:
          if (k.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) return k;
          return null;
      }
    }

    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT") return;
      if (e.isComposing) return;
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "t") {
        e.preventDefault();
        void openTab();
        return;
      }
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "w") {
        e.preventDefault();
        if (current) closeTab(current);
        return;
      }
      const data = encodeKey(e);
      if (data !== null) {
        e.preventDefault();
        send(data);
      }
    }

    function onPaste(e: ClipboardEvent) {
      if ((e.target as HTMLElement | null)?.tagName === "INPUT") return;
      const text = e.clipboardData?.getData("text") ?? "";
      if (!text) return;
      if (text.length > 262144) return;
      e.preventDefault();
      send(text.replace(/\r?\n/g, "\r"));
    }

    function onWheel(e: WheelEvent) {
      painter.scrollBy(e.deltaY > 0 ? -3 : 3);
      setScrolled(painter.scrollOffset !== 0);
      paint();
      e.preventDefault();
    }

    function onInput() {
      if (ime.value) {
        send(ime.value.replace(/\r?\n/g, "\r"));
        ime.value = "";
      }
    }

    api.current = {
      run: (cmd) => {
        ime.focus({ preventScroll: true });
        send(cmd + "\r");
      },
      newTab: () => void openTab(),
      closeTab,
      activate,
      power: () => {
        if (current) send("poweroff\r");
        else void cycle("power cycle — SSD flushed, remounting nvme0n1");
      },
      peekHolo: () => link.peekHolo(),
      focus: () => ime.focus({ preventScroll: true }),
    };

    const frame = window.requestAnimationFrame(function loop() {
      if (needs) {
        painter.render();
        needs = false;
      }
      if (!dead) window.requestAnimationFrame(loop);
    });
    const blink = window.setInterval(() => {
      if (reduce) return;
      painter.cursorOn = !painter.cursorOn;
      paint();
    }, 530);
    const poll = window.setInterval(() => {
      if (!current) return;
      void link.status(current).then((st) => {
        if (st) setStatus(st);
      });
    }, 1000);
    const observer = new ResizeObserver(() => relayout());
    observer.observe(term);
    document.addEventListener("keydown", onKey);
    document.addEventListener("paste", onPaste);
    term.addEventListener("wheel", onWheel, { passive: false });
    ime.addEventListener("input", onInput);

    void (async () => {
      try {
        if (document.fonts) {
          await document.fonts.load(`${fontSize}px ${fontFamily}`);
          await document.fonts.ready;
        }
        painter.setTheme({ fontFamily, fontSize });
        relayout();
        await link.boot();
        if (dead) return;
        setConn("open");
        setDetail(link.restored ? "nvme0n1 restored — opening terminal" : "nvme0n1 ready — opening terminal");
        await openTab();
        if (!dead) link.peekHolo();
      } catch (err) {
        setBootError(err instanceof Error ? err.message : "boot failed");
        setConn("error");
      }
    })();

    return () => {
      dead = true;
      window.cancelAnimationFrame(frame);
      window.clearInterval(blink);
      window.clearInterval(poll);
      observer.disconnect();
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("paste", onPaste);
      term.removeEventListener("wheel", onWheel);
      ime.removeEventListener("input", onInput);
      api.current = null;
      link.destroy();
    };
  }, []);

  const ram = status?.ram;
  const usedPct = ram && ram.maxBytes ? Math.min(100, Math.round((100 * ram.bytes) / ram.maxBytes)) : 0;
  const dot = conn === "active" || conn === "open" ? "" : conn === "error" ? "bad" : "warn";
  const stageClass = `stage${panel ? " panel" : ""}${surface ? " surface" : ""}${holoOpen ? " holo" : ""}`;

  return (
    <div className="console font-sans">
      <header className="console-bar">
        <Mark />
        <div className="min-w-0">
          <div className="truncate text-sm font-medium tracking-wide text-fg">JA21 Console</div>
          <div className="truncate font-mono text-xs text-muted">1.4.0 · HERMIT terminal · SSD server</div>
        </div>
        <nav className="tabs" aria-label="Sessions">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              className={tab.id === active ? "tab active" : "tab"}
              onClick={() => api.current?.activate(tab.id)}
            >
              <span>{String(tab.n).padStart(2, "0")}</span>
              <span className="max-w-24 truncate">{tab.closed ? "closed" : tab.title}</span>
              <span
                className="x"
                role="presentation"
                onClick={(e) => {
                  e.stopPropagation();
                  api.current?.closeTab(tab.id);
                }}
              >
                <X className="size-3" aria-hidden="true" />
              </span>
            </button>
          ))}
          <button type="button" className="tab" onClick={() => api.current?.newTab()} aria-label="New session">
            <Plus className="size-4" />
          </button>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            className={`inline-flex min-h-11 items-center gap-2 rounded-md border px-3 text-sm ${
              holoOpen ? "border-primary text-primary" : "border-line text-muted"
            }`}
            aria-pressed={holoOpen}
            onClick={() => {
              setHoloOpen((v) => !v);
              api.current?.peekHolo();
            }}
          >
            <Aperture className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">Holo</span>
          </button>
          <button
            type="button"
            className={`inline-flex min-h-11 items-center gap-2 rounded-md border px-3 text-sm ${
              surface ? "border-primary text-primary" : "border-line text-muted"
            }`}
            onClick={() => setSurface((v) => !v)}
          >
            <AppWindow className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">Surface</span>
          </button>
          <button
            type="button"
            className={`inline-flex min-h-11 items-center gap-2 rounded-md border px-3 text-sm ${
              panel ? "border-primary text-primary" : "border-line text-muted"
            }`}
            onClick={() => setPanel((v) => !v)}
          >
            <PanelRight className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">Ledger</span>
          </button>
          <button
            type="button"
            className="inline-flex min-h-11 items-center gap-2 rounded-md border border-warn px-3 text-sm text-warn"
            onClick={() => api.current?.power()}
          >
            <Power className="size-4" aria-hidden="true" />
            Power
          </button>
        </div>
      </header>

      <div className="suggestions" aria-label="Try a command">
        {TRIALS.map((cmd) => (
          <button key={cmd} type="button" onClick={() => api.current?.run(cmd)}>
            {cmd}
          </button>
        ))}
      </div>

      <div className={stageClass}>
        <section
          ref={termRef}
          className="term"
          onMouseDown={(e) => {
            e.preventDefault();
            api.current?.focus();
          }}
        >
          <span className="bracket tl" />
          <span className="bracket tr" />
          <span className="bracket bl" />
          <span className="bracket br" />
          <div className="frame-tag">
            <span className={`live-dot ${dot}`} />
            <span>SPIRAL // {conn}</span>
          </div>
          <canvas ref={canvasRef} role="img" aria-label="Virtual terminal" />
          <textarea
            ref={imeRef}
            className="ime"
            aria-label="Terminal input"
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
            rows={1}
          />
          <pre ref={mirrorRef} className="sr-only" aria-live="polite" />
          {scrolled ? <div className="scrollhint">scrolled · End returns</div> : null}
          {bootError ? (
            <p className="absolute bottom-3 left-4 right-4 font-mono text-sm text-danger">{bootError}</p>
          ) : null}
        </section>

        {surface ? (
          <aside className="surface-pane" aria-label="JA21 blank surface">
            <p className="font-mono text-xs tracking-wide text-primary">VB-JA21 // {browser.engine}</p>
            <h2 className="mt-2 text-base font-medium text-fg">Blank console surface</h2>
            <p className="mt-1 text-sm leading-relaxed text-muted">
              No tabs, no toolbar. Public web stays closed. Exact local origins and ram:// pages are admitted.
            </p>
            <form
              className="mt-3 flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                const next = admit(urlDraft);
                setPolicyNote(next.note);
                setBrowser((b) => ({ ...b, visible: true, url: next.url }));
              }}
            >
              <input
                value={urlDraft}
                onChange={(e) => setUrlDraft(e.target.value)}
                aria-label="Surface address"
                spellCheck={false}
                className="min-h-11 min-w-0 flex-1 rounded-md border border-line bg-bg px-3 font-mono text-sm text-fg"
              />
              <button type="submit" className="min-h-11 rounded-md bg-primary px-3 text-sm font-medium text-bg">
                Open
              </button>
            </form>
            <div className="blank mt-3">
              {policyNote === "rejected" ? (
                <div>
                  <p className="text-sm text-danger">Navigation rejected</p>
                  <p className="mt-1 text-xs">This origin is not in console.json.</p>
                </div>
              ) : policyNote === "admitted" ? (
                <div>
                  <p className="text-sm text-ok">Origin admitted</p>
                  <p className="mt-1 text-xs">No guest is bound to that port in this image.</p>
                </div>
              ) : policyNote === "ram" ? (
                <div className="text-left font-mono text-xs leading-relaxed text-fg">
                  <p>epoch {status?.epoch ?? "booting"}</p>
                  <p>seal {(status?.seal ?? "—").slice(0, 24)}</p>
                  <p>vfs {fmtBytes(ram?.bytes)} / {fmtBytes(ram?.maxBytes)}</p>
                  <p>drift {status?.drifted ? "yes" : "no"}</p>
                </div>
              ) : (
                <div>
                  <p className="text-sm text-fg">about:blank</p>
                  <p className="mt-1 text-xs">The console is empty until a local guest is loaded. This one is the SSD server.</p>
                </div>
              )}
            </div>
          </aside>
        ) : null}

        {holoOpen ? (
          <aside className="holo-pane" aria-label="Holographic processor">
            <p className="font-mono text-xs tracking-wide text-primary">
              HPU // {holo ? `${holo.lambdaNm.toFixed(0)} nm` : "532 nm"}
            </p>
            <h2 className="mt-1 text-base font-medium text-fg">Processable hologram</h2>
            {holo ? (
              <>
                <p className="mt-1 font-mono text-sm text-fg">
                  {holo.gate ? `${holo.gate} → bit ${holo.bit}` : holo.op}
                </p>
                <p className="mt-1 text-sm leading-relaxed text-muted">
                  {holo.stage && holo.stage !== "idle" ? `${holo.stage} · ` : ""}
                  cycle {holo.cycles ?? 0} · z {holo.zMm.toFixed(2)} mm · spool {holo.frames}
                </p>
                <div className="holo-fields">
                  <figure>
                    <figcaption className="mb-1 font-mono text-xs text-muted">Phase · TIFF</figcaption>
                    <FieldCanvas samples={holo.phase} n={holo.n} kind="phase" />
                  </figure>
                  <figure>
                    <figcaption className="mb-1 font-mono text-xs text-muted">Intensity · GIF</figcaption>
                    <FieldCanvas samples={holo.intensity} n={holo.n} kind="intensity" />
                  </figure>
                  {holo.route && holo.route.length >= holo.n * holo.n ? (
                    <figure>
                      <figcaption className="mb-1 font-mono text-xs text-muted">Processor 7 · route</figcaption>
                      <FieldCanvas samples={holo.route} n={holo.n} kind="intensity" />
                    </figure>
                  ) : null}
                  {holo.wigner && holo.wignerN && holo.wigner.length >= holo.wignerN * holo.wignerN ? (
                    <figure>
                      <figcaption className="mb-1 font-mono text-xs text-muted">Wigner · interaction frame</figcaption>
                      <FieldCanvas samples={holo.wigner} n={holo.wignerN} kind="wigner" />
                    </figure>
                  ) : null}
                  {holo.wigner && holo.penteract ? (
                    <div className="font-mono text-xs leading-relaxed text-fg">
                      <p className="text-muted">non-Gaussian</p>
                      <p>{((holo.wNeg ?? 0) * 100).toFixed(1)}% negative</p>
                      <p>χ {(holo.gifChi ?? 0).toFixed(2)} · n̄ {(holo.gifNbar ?? 0).toFixed(2)}</p>
                      <p>order R {(holo.orderR ?? 0).toFixed(2)}</p>
                      <p className="mt-2 text-muted">penteract</p>
                      <p>x {holo.penteract.x.toFixed(1)} · y {holo.penteract.y.toFixed(1)}</p>
                      <p>z {holo.penteract.z.toFixed(2)} mm</p>
                      <p>t {holo.penteract.t} · ⟨v₂⟩ {holo.penteract.p.toFixed(2)}</p>
                    </div>
                  ) : null}
                </div>
                {holo.stage === "sample" || holo.stage === "relocate" || holo.stage === "reproject" || holo.stage === "diffuse" ? (
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs">
                    <div>
                      <dt className="text-muted">carriers</dt>
                      <dd className="text-fg">{holo.moved ?? 0} moved · {holo.info ?? 0} info</dd>
                    </div>
                    <div>
                      <dt className="text-muted">bit / anti-bit</dt>
                      <dd className="text-fg">
                        {(holo.n * holo.n - (holo.logical1 ?? 0)).toLocaleString()} / {holo.logical1 ?? 0}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-muted">Landauer</dt>
                      <dd className="text-fg">{atto(holo.landauerJ)}</dd>
                    </div>
                    <div>
                      <dt className="text-muted">2-adic ⟨v₂⟩</dt>
                      <dd className="text-fg">{(holo.padic ?? 0).toFixed(2)}</dd>
                    </div>
                    <div className="col-span-2">
                      <dt className="text-muted">Bloch rx ry rz</dt>
                      <dd className="text-fg">
                        {(holo.bloch ?? [0, 0, 1]).map((v) => v.toFixed(2)).join("  ")}
                        <span className="text-muted"> · purity {(holo.purity ?? 1).toFixed(2)}</span>
                      </dd>
                    </div>
                  </dl>
                ) : holo.stage === "record" || holo.stage === "replay" ? (
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs">
                    <div>
                      <dt className="text-muted">weight</dt>
                      <dd className="text-fg">{holo.recorded || "—"} in the array</dd>
                    </div>
                    <div>
                      <dt className="text-muted">bus</dt>
                      <dd className="text-fg">0 bytes moved</dd>
                    </div>
                    <div>
                      <dt className="text-muted">MAC</dt>
                      <dd className="text-fg">{(holo.macOps ?? 0).toLocaleString()} in place</dd>
                    </div>
                    <div>
                      <dt className="text-muted">fidelity</dt>
                      <dd className="text-fg">{holo.fidelity == null ? "—" : holo.fidelity.toFixed(3)}</dd>
                    </div>
                  </dl>
                ) : holo.stage === "oam" ? (
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs">
                    <div>
                      <dt className="text-muted">value</dt>
                      <dd className="text-fg">{holo.oamValue ?? "—"}</dd>
                    </div>
                    <div>
                      <dt className="text-muted">charge ℓ</dt>
                      <dd className="text-fg">{holo.oamCharge && holo.oamCharge > 0 ? `+${holo.oamCharge}` : holo.oamCharge ?? "—"}</dd>
                    </div>
                    <div className="col-span-2">
                      <dt className="text-muted">wells MSB → LSB</dt>
                      <dd className="text-fg">{holo.oamBits || "—"}</dd>
                    </div>
                    <div>
                      <dt className="text-muted">overflow</dt>
                      <dd className="text-fg">{holo.oamOverflow ? "yes" : "no"}</dd>
                    </div>
                    <div>
                      <dt className="text-muted">remainder</dt>
                      <dd className="text-fg">{holo.oamRem ?? 0}</dd>
                    </div>
                  </dl>
                ) : holo.stage === "bytes" && holo.byteStages ? (
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs">
                    {holo.byteStages.map((stage) => (
                      <div key={stage.id} className={stage.id === "processor-7" ? "col-span-2" : undefined}>
                        <dt className="text-muted">{stage.name}</dt>
                        <dd className="text-fg">
                          {stage.equivalent === true ? "CPU≡GPU" : stage.equivalent === false ? "diverged" : "restored"}
                          {stage.cpuCycles ? (
                            <span className="text-muted">
                              {" "}
                              · {stage.cpuCycles.toLocaleString()} cyc · {stage.gpuWarps} warps
                            </span>
                          ) : null}
                          <span className="text-muted">
                            {" "}
                            · {(stage.owned ?? 0).toLocaleString()} owned · {stage.changed.toLocaleString()} changed
                          </span>
                          {stage.same ? <span className="text-muted"> · same table as {stage.same}</span> : null}
                        </dd>
                      </div>
                    ))}
                  </dl>
                ) : (
                  <p className="mt-2 text-sm leading-relaxed text-muted">
                    Run a cycle to project the field, diffract it, RAM-sample it, and walk the bright pixels along the intensity gradient.
                  </p>
                )}
                <div className="mt-3 flex flex-wrap gap-2">
                  {["hpu bytes vortex", "hpu oam 13", "hpu shift left"].map((cmd) => (
                    <button
                      key={cmd}
                      type="button"
                      className="min-h-11 rounded-md border border-line px-3 font-mono text-xs text-fg"
                      onClick={() => api.current?.run(cmd)}
                    >
                      {cmd}
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <p className="mt-2 text-sm leading-relaxed text-muted">
                The field is still settling. Run hpu cycle to close the five-stage loop.
              </p>
            )}
            <p className="mt-3 text-xs leading-relaxed text-muted">
              16-bit phase leaves as TIFF. The relocated intensity leaves as GIF89a. Both stay on nvme0n1.
            </p>
          </aside>
        ) : null}

        {panel ? (
          <aside className="side" aria-label="SSD ledger">
            <p className="font-mono text-xs tracking-wide text-primary">{status?.profile ?? "LOCAL_SSD"}</p>
            <h2 className="mt-1 text-base font-medium text-fg">SSD volume</h2>
            <p className="mt-1 text-sm leading-relaxed text-muted">{detail}</p>
            <dl className="mt-4 space-y-3 font-mono text-xs">
              <div>
                <dt className="text-muted">epoch</dt>
                <dd className="truncate text-fg">{status?.epoch ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-muted">boot seal</dt>
                <dd className="break-all text-fg">{(status?.seal ?? "measuring").slice(0, 32)}</dd>
              </div>
              <div>
                <dt className="text-muted">volume</dt>
                <dd className={!status ? "text-muted" : status.disk && !status.disk.synced ? "text-warn" : "text-ok"}>
                  {!status
                    ? "—"
                    : status.disk && !status.disk.synced
                      ? "flushing"
                      : status.drifted
                        ? "on SSD · differs from seal"
                        : "on SSD · matches seal"}
                </dd>
              </div>
              <div>
                <dt className="mb-1 text-muted">used</dt>
                <dd>
                  <div className="meter" aria-hidden="true">
                    <span style={{ width: `${usedPct}%` }} />
                  </div>
                  <p className="mt-1 text-fg">
                    {fmtBytes(ram?.bytes)} / {fmtBytes(ram?.maxBytes)} · {ram ? `${ram.nodes} nodes` : "—"}
                  </p>
                </dd>
              </div>
              <div>
                <dt className="text-muted">block device</dt>
                <dd className="text-fg">{status?.disk ? `${status.disk.device} · ${status.disk.model}` : "nvme0n1"}</dd>
              </div>
              <div>
                <dt className="text-muted">protocol</dt>
                <dd className="text-fg">hermit.vws.v2</dd>
              </div>
              <div>
                <dt className="text-muted">fabric images</dt>
                <dd className="mt-1 flex gap-2">
                  {(status?.nodes?.length ? status.nodes : [
                    { key: "small", node: "N_SMALL", present: false, built: false },
                    { key: "medium", node: "N_MEDIUM", present: false, built: false },
                    { key: "large", node: "N_LARGE", present: false, built: false },
                    { key: "xlarge", node: "N_XLARGE", present: false, built: false },
                  ]).map((n) => (
                    <span
                      key={n.key}
                      title={n.node}
                      className={`inline-block size-3 rounded-sm ${n.built ? "bg-primary" : "bg-line"}`}
                    />
                  ))}
                </dd>
              </div>
            </dl>
            <p className="mt-4 text-xs leading-relaxed text-muted">
              Writes flush to nvme0n1. Power and reload remount the same volume. The seal is only the factory image.
            </p>
          </aside>
        ) : null}
      </div>

      <footer className="statusline">
        <span className="chip">
          session <b>{active ?? "—"}</b>
        </span>
        <span className="chip">
          <b>{status?.cwd ?? "~"}</b>
        </span>
        <span className="chip">{geom}</span>
        <span className="chip">
          link <b>{conn}</b>
        </span>
        <span className="chip hidden md:inline">
          {status?.disk?.device ?? "nvme0n1"}
          {status?.disk ? (status.disk.synced ? " · synced" : " · syncing") : ""}
        </span>
        <span className="chip ml-auto hidden lg:inline">Ctrl-C abort · Ctrl-L clear · Ctrl-Shift-T tab</span>
      </footer>
    </div>
  );
}
