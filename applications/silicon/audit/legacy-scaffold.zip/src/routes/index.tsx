import { createFileRoute } from "@tanstack/react-router";
import { Ja21Console } from "@/components/console/Ja21Console";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <Ja21Console />;
}
