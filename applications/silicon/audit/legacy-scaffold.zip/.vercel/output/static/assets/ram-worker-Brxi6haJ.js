(function(){var e=class{constructor(){this._l=/* @__PURE__ */ new Map}on(e,t){let n=this._l.get(e)||[];return n.push(t),this._l.set(e,n),this}emit(e,...t){let n=this._l.get(e);if(!n)return!1;for(let e of n.slice())e(...t);return!0}};function t(e){return Object.defineProperty(e,"_buf",{value:!0}),e.toString=function(e){if(e===`base64`){let e=``,t=32768;for(let n=0;n<this.length;n+=t){let r=this.subarray(n,n+t);e+=String.fromCharCode.apply(null,r)}return btoa(e)}return new TextDecoder().decode(this)},e}let n={isBuffer(e){return!!e&&typeof e==`object`&&e._buf===!0},byteLength(e){return new TextEncoder().encode(String(e)).length},from(e,n){if(n===`base64`){let n=atob(String(e)),r=new Uint8Array(n.length);for(let e=0;e<n.length;e++)r[e]=n.charCodeAt(e)&255;return t(r)}return typeof e==`string`?t(new TextEncoder().encode(e)):e instanceof Uint8Array||typeof e==`number`?t(new Uint8Array(e)):t(Uint8Array.from(e))},concat(e){let n=0;for(let t of e)n+=t.length;let r=new Uint8Array(n),i=0;for(let t of e)r.set(t,i),i+=t.length;return t(r)}};function r(e){return String(e).split(`/`).filter(e=>e.length>0)}function i(e,t){let n=String(t??``),i=n.startsWith(`/`)?[]:r(e);for(let e of r(n))e!==`.`&&(e===`..`?i.pop():i.push(e));return`/`+i.join(`/`)}function a(e){let t=r(e);return t.length?t[t.length-1]:``}function o(e){let t=r(e);return t.pop(),`/`+t.join(`/`)}function s(){return{type:`dir`,children:/* @__PURE__ */ new Map,mtime:Date.now(),mode:493}}function c(e=``){return{type:`file`,contents:e,mtime:Date.now(),mode:420}}var l=class extends Error{constructor(e,t){super(t),this.code=e,this.name=`VFSError`}};function u(e){return n.isBuffer(e)?e.length:n.byteLength(String(e))}function d(e,t){return n.isBuffer(e)||n.isBuffer(t)?n.concat([n.isBuffer(e)?e:n.from(String(e),`utf8`),n.isBuffer(t)?t:n.from(String(t),`utf8`)]):e+t}function f(e){if(e.type===`file`)return{bytes:u(e.contents),nodes:1};let t=0,n=1;for(let r of e.children.values()){let e=f(r);t+=e.bytes,n+=e.nodes}return{bytes:t,nodes:n}}var p=class{constructor(e={}){this.maxBytes=Number.isFinite(e.maxBytes)?e.maxBytes:1/0,this.maxNodes=Number.isFinite(e.maxNodes)?e.maxNodes:1/0,this.usedBytes=0,this.nodeCount=1,this.root=s(),this.onMutate=()=>{},this._seed()}_reserve(e,t){if(this.usedBytes+e>this.maxBytes)throw new l(`EDQUOT`,`workspace byte quota exceeded (${this.maxBytes} bytes)`);if(this.nodeCount+t>this.maxNodes)throw new l(`EDQUOT`,`workspace node quota exceeded (${this.maxNodes} nodes)`);this.usedBytes+=e,this.nodeCount+=t}usage(){return{bytes:this.usedBytes,nodes:this.nodeCount,maxBytes:this.maxBytes,maxNodes:this.maxNodes}}_walk(e,{parents:t=!1}={}){let n=r(e),i=this.root;for(let r=0;r<n.length;r++){if(i.type!==`dir`)throw new l(`ENOTDIR`,`not a directory: ${n[r-1]}`);let a=i.children.get(n[r]);if(!a){if(t)this._reserve(0,1),a=s(),i.children.set(n[r],a);else throw new l(`ENOENT`,`no such file or directory: ${e}`)}i=a}return i}stat(e){let t=this._walk(e);return{path:e,type:t.type,size:t.type===`file`?u(t.contents):t.children.size,mtime:t.mtime,mode:t.mode}}exists(e){try{return this._walk(e),!0}catch{return!1}}isDir(e){try{return this._walk(e).type===`dir`}catch{return!1}}readFile(e){let t=this._walk(e);if(t.type!==`file`)throw new l(`EISDIR`,`is a directory: ${e}`);return t.contents}writeFile(e,t,{append:r=!1}={}){let i=this._walk(o(e));if(i.type!==`dir`)throw new l(`ENOTDIR`,`not a directory: ${o(e)}`);let s=a(e),f=i.children.get(s);if(f&&f.type===`dir`)throw new l(`EISDIR`,`is a directory: ${e}`);if(n.isBuffer(t)||(t=String(t??``)),f&&r&&f.type===`file`)this._reserve(u(t),0),f.contents=d(f.contents,t),f.mtime=Date.now();else{let e=f?u(f.contents):0;this._reserve(u(t)-e,+!f),i.children.set(s,c(t))}return this.onMutate(),!0}mkdir(e,{recursive:t=!1}={}){if(t)return this._walk(e,{parents:!0}),this.onMutate(),!0;let n=this._walk(o(e));if(n.type!==`dir`)throw new l(`ENOTDIR`,`not a directory: ${o(e)}`);let r=a(e);if(n.children.has(r))throw new l(`EEXIST`,`file exists: ${e}`);return this._reserve(0,1),n.children.set(r,s()),this.onMutate(),!0}readdir(e){let t=this._walk(e);if(t.type!==`dir`)throw new l(`ENOTDIR`,`not a directory: ${e}`);return[...t.children.entries()].map(([e,t])=>({name:e,type:t.type,size:t.type===`file`?u(t.contents):t.children.size,mtime:t.mtime,mode:t.mode})).sort((e,t)=>e.name.localeCompare(t.name))}remove(e,{recursive:t=!1}={}){if(e===`/`)throw new l(`EPERM`,`cannot remove root`);let n=this._walk(o(e)),r=a(e),i=n.children.get(r);if(!i)throw new l(`ENOENT`,`no such file or directory: ${e}`);if(i.type===`dir`&&i.children.size>0&&!t)throw new l(`ENOTEMPTY`,`directory not empty: ${e}`);let s=f(i);return n.children.delete(r),this.usedBytes-=s.bytes,this.nodeCount-=s.nodes,this.onMutate(),!0}move(e,t){let n=this._walk(e),r=this.isDir(t)?i(t,a(e)):t;if(r===e)return r;if(n.type===`dir`&&(r+`/`).startsWith(e+`/`))throw new l(`EINVAL`,`cannot move a directory into itself`);let s=this._walk(o(r));if(s.type!==`dir`)throw new l(`ENOTDIR`,`not a directory: ${o(r)}`);let c=s.children.get(a(r));if(c){let e=f(c);this.usedBytes-=e.bytes,this.nodeCount-=e.nodes}return s.children.set(a(r),n),this._walk(o(e)).children.delete(a(e)),this.onMutate(),r}exportSnapshot(){let e=t=>t.type===`file`?{k:`f`,m:t.mode,t:t.mtime,e:n.isBuffer(t.contents)?`b64`:`utf8`,c:n.isBuffer(t.contents)?t.contents.toString(`base64`):t.contents}:{k:`d`,m:t.mode,t:t.mtime,ch:[...t.children.entries()].map(([t,n])=>[t,e(n)])};return{v:1,root:e(this.root)}}importSnapshot(e){if(!e||e.v!==1||!e.root||e.root.k!==`d`)throw new l(`EINVAL`,`unsupported snapshot`);let t=0,r=0,i=(e,a)=>{if(a>64)throw new l(`EINVAL`,`snapshot too deep`);if(r++,r>this.maxNodes)throw new l(`EDQUOT`,`snapshot node quota`);if(e&&e.k===`f`){if(typeof e.c!=`string`||e.e!==`utf8`&&e.e!==`b64`)throw new l(`EINVAL`,`bad file record`);let r=e.e===`b64`?n.from(e.c,`base64`):e.c;if(t+=u(r),t>this.maxBytes)throw new l(`EDQUOT`,`snapshot byte quota`);let i=c(r);return i.mode=e.m|0,i.mtime=Number(e.t)||Date.now(),i}if(e&&e.k===`d`&&Array.isArray(e.ch)){let t=s();t.mode=e.m|0,t.mtime=Number(e.t)||Date.now();for(let n of e.ch){if(!Array.isArray(n)||typeof n[0]!=`string`||!n[0]||n[0]===`.`||n[0]===`..`||n[0].includes(`/`)||n[0].length>255)throw new l(`EINVAL`,`bad entry name`);if(t.children.has(n[0]))throw new l(`EINVAL`,`duplicate entry`);t.children.set(n[0],i(n[1],a+1))}return t}throw new l(`EINVAL`,`bad node record`)},a=i(e.root,0);return this.root=a,this.usedBytes=t,this.nodeCount=r,this.usage()}_seed(){this.mkdir(`/home`,{recursive:!0}),this.mkdir(`/home/operator`,{recursive:!0}),this.mkdir(`/etc`,{recursive:!0}),this.mkdir(`/var/log`,{recursive:!0}),this.mkdir(`/tmp`,{recursive:!0}),this.writeFile(`/etc/hermit.conf`,`# HERMIT runtime configuration
backend = SPIRAL
vt = internal
browser = VB-JA21/9.8.7
`),this.writeFile(`/home/operator/README`,"Welcome to HERMIT — a virtual terminal on the SPIRAL backend.\nType `help` for the command index, `about` for the architecture.\n"),this.writeFile(`/home/operator/.hermitrc`,`# sourced at session start
export PS1="\\u@hermit:\\w$ "
alias ll="ls -l"
`)}},m=class{constructor(){this.commands=/* @__PURE__ */ new Map,this.aliases=/* @__PURE__ */ new Map}register(e){if(!e||!e.name||typeof e.run!=`function`)throw Error(`registry.register: descriptor needs { name, run }`);this.commands.set(e.name,e);for(let t of e.aka||[])this.aliases.set(t,e.name);return this}install(e){let t=Array.isArray(e)?e:e&&e.commands;if(!Array.isArray(t))throw Error(`registry.install: expected array or { commands: [] }`);for(let e of t)this.register(e);return this}alias(e,t){return this.aliases.set(e,t),this}resolve(e){return this.commands.has(e)?this.commands.get(e):this.aliases.has(e)?this.commands.get(this.aliases.get(e)):null}has(e){return this.commands.has(e)||this.aliases.has(e)}list(){return[...this.commands.values()].sort((e,t)=>e.name.localeCompare(t.name))}names(){return[...this.commands.keys(),...this.aliases.keys()].sort()}};function h(e,t={}){let n=new Set(t.valued||[]),r={},i=[],a=0,o=!1;for(;a<e.length;){let t=e[a];if(o||t===`-`||t[0]!==`-`){i.push(t),a++;continue}if(t===`--`){o=!0,a++;continue}if(t.startsWith(`--`)){let e=t.slice(2),n=e.indexOf(`=`);n>=0?r[e.slice(0,n)]=e.slice(n+1):r[e]=!0,a++;continue}let s=t.slice(1).split(``);for(let t=0;t<s.length;t++){let i=s[t];if(n.has(i)){r[i]=s.slice(t+1).join(``)||e[++a];break}r[i]=!0}a++}return{flags:r,args:i}}var g=class e{constructor(e={},t=null){this.parent=t,this.vars=/* @__PURE__ */ new Map;for(let[t,n]of Object.entries(e))this.vars.set(t,String(n))}get(e){return this.vars.has(e)?this.vars.get(e):this.parent?this.parent.get(e):void 0}set(e,t){return this.vars.set(e,t==null?``:String(t)),this}unset(e){return this.vars.delete(e)}has(e){return this.vars.has(e)||(this.parent?this.parent.has(e):!1)}toObject(){let e=this.parent?this.parent.toObject():{};for(let[t,n]of this.vars)e[t]=n;return e}child(t={}){return new e(t,this)}};let _=[`&&`,`||`,`>>`,`;`,`|`,`>`,`<`];function v(e){let t=[],n=0,r=e.length;for(;n<r;){let i=e[n];if(i===` `||i===`	`){n++;continue}if(i===`#`)break;let a=null;for(let t of _)if(e.startsWith(t,n)){a=t;break}if(a){t.push({type:`op`,value:a}),n+=a.length;continue}let o=``,s=!1;for(;n<r;){let t=e[n];if(t===` `||t===`	`||t===`#`||_.some(t=>e.startsWith(t,n)))break;if(t===`\\`)o+=e[n+1]==null?``:e[n+1],n+=2;else if(t===`'`){for(s=!0,n++;n<r&&e[n]!==`'`;)o+=e[n++];n++}else if(t===`"`){for(s=!0,n++;n<r&&e[n]!==`"`;)e[n]===`\\`&&'"\\$`'.includes(e[n+1])?(o+=e[n+1],n+=2):o+=e[n++];n++}else o+=t,n++}t.push({type:`word`,value:o,quoted:s})}return t}function y(e,t){let n=e.value;return!e.quoted&&(n===`~`||n.startsWith(`~/`))&&(n=(t.get(`HOME`)||`/home/operator`)+n.slice(1)),n=n.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)|\$\?/g,(e,n,r)=>{if(e===`$?`)return String(t.get(`?`)??`0`);let i=n||r;return t.get(i)??``}),n}function b(e,t){let n=v(e),r=[],i={op:null,pipeline:[]},a={argv:[],redirects:[]},o=()=>{(a.argv.length||a.redirects.length)&&i.pipeline.push(a),a={argv:[],redirects:[]}},s=e=>{o(),i.pipeline.length&&r.push(i),i={op:e,pipeline:[]}};for(let e=0;e<n.length;e++){let r=n[e];if(r.type===`word`)a.argv.push(y(r,t));else switch(r.value){case`|`:o();break;case`;`:s(null);break;case`&&`:s(`&&`);break;case`||`:s(`||`);break;case`>`:case`>>`:case`<`:{let i=n[++e];if(!i||i.type!==`word`)throw Error(`syntax error near '${r.value}'`);a.redirects.push({type:r.value===`<`?`in`:r.value===`>>`?`append`:`out`,target:y(i,t)});break}}}return s(null),r}function x(e){return e.replace(/\x1b\[[0-9;?]*[A-Za-z]/g,``).length}var ee=class{constructor(e){this.write=e.write,this.prompt=e.prompt||``,this.history=e.history||[],this.completer=e.completer||null,this.maxChars=Number.isFinite(e.maxChars)?e.maxChars:4096,this.done=!1,this.buf=``,this.cur=0,this.escBuf=``,this.histIndex=this.history.length,this.savedLine=``,this.lastTab=!1,this._resolve=null,this.promise=new Promise(e=>{this._resolve=e})}start(){return this.write(this.prompt),this.promise}_finish(e){if(this.done=!0,this._resolve){let t=this._resolve;this._resolve=null,t(e)}}_repaint(){this.write(`\r\x1B[2K`+this.prompt+this.buf);let e=x(this.prompt)+this.cur;this.write(`\r`),e>0&&this.write(`\x1B[`+e+`C`)}feed(e){for(let t=0;t<e.length;t++){if(this.done)return e.slice(t);let n=e[t];if(this.escBuf){this.escBuf+=n;let e=this._tryEscape();if(e===`incomplete`)continue;if(e===`flush`){let e=this.escBuf;this.escBuf=``,this._insert(e.slice(1))}continue}if(n===`\x1B`){this.escBuf=`\x1B`;continue}if(n.charCodeAt(0)>=32&&n!==``){let n=t+1;for(;n<e.length;){let t=e.charCodeAt(n);if(t<32||t===127)break;n++}if(n-t>1){this.lastTab=!1,this._insert(e.slice(t,n)),t=n-1;continue}}let r=n===`	`;r||(this.lastTab=!1),this._control(n,r)}return``}_tryEscape(){let e=this.escBuf;if(e.length>16)return`flush`;let t={"\x1B[A":`up`,"\x1BOA":`up`,"\x1B[B":`down`,"\x1BOB":`down`,"\x1B[C":`right`,"\x1BOC":`right`,"\x1B[D":`left`,"\x1BOD":`left`,"\x1B[H":`home`,"\x1BOH":`home`,"\x1B[1~":`home`,"\x1B[7~":`home`,"\x1B[F":`end`,"\x1BOF":`end`,"\x1B[4~":`end`,"\x1B[8~":`end`,"\x1B[3~":`delete`};return t[e]?(this.escBuf=``,this._key(t[e]),`done`):Object.keys(t).some(t=>t.startsWith(e))||/^\x1b(\[|O)[0-9;]*$/.test(e)?`incomplete`:`flush`}_key(e){switch(e){case`left`:this.cur>0&&(this.cur--,this._repaint());break;case`right`:this.cur<this.buf.length&&(this.cur++,this._repaint());break;case`home`:this.cur=0,this._repaint();break;case`end`:this.cur=this.buf.length,this._repaint();break;case`delete`:this.cur<this.buf.length&&(this.buf=this.buf.slice(0,this.cur)+this.buf.slice(this.cur+1),this._repaint());break;case`up`:this._history(-1);break;case`down`:this._history(1)}}_control(e,t){let n=e.charCodeAt(0);switch(e){case`\r`:case`
`:this.write(`\r
`),this._finish(this.buf);return;case``:case`\b`:this.cur>0&&(this.buf=this.buf.slice(0,this.cur-1)+this.buf.slice(this.cur),this.cur--,this._repaint());return;case``:this.write(`^C\r
`),this.buf=``,this.cur=0,this._finish({aborted:!0});return;case``:if(this.buf.length===0){this._finish(null);return}return;case``:this.cur=0,this._repaint();return;case``:this.cur=this.buf.length,this._repaint();return;case``:this._key(`left`);return;case``:this._key(`right`);return;case``:this.buf=this.buf.slice(this.cur),this.cur=0,this._repaint();return;case`\v`:this.buf=this.buf.slice(0,this.cur),this._repaint();return;case``:this._killWord();return;case`\f`:this.write(`\x1B[2J\x1B[H`),this._repaint();return;case`	`:this._complete();return;default:n>=32&&this._insert(e);return}}_insert(e){this.buf.length+e.length>this.maxChars?this.write(`\x07`):(this.buf=this.buf.slice(0,this.cur)+e+this.buf.slice(this.cur),this.cur+=e.length,this._repaint())}_killWord(){let e=this.cur;for(;e>0&&this.buf[e-1]===` `;)e--;for(;e>0&&this.buf[e-1]!==` `;)e--;this.buf=this.buf.slice(0,e)+this.buf.slice(this.cur),this.cur=e,this._repaint()}_history(e){if(!this.history.length)return;this.histIndex===this.history.length&&(this.savedLine=this.buf);let t=this.histIndex+e;t<0||t>this.history.length||(this.histIndex=t,this.buf=t===this.history.length?this.savedLine:this.history[t],this.cur=this.buf.length,this._repaint())}_complete(){if(!this.completer)return;let e=this.completer(this.buf,this.cur);e&&(Array.isArray(e.candidates)&&e.candidates.length>1&&this.lastTab?(this.write(`\r
`+e.candidates.join(`  `)+`\r
`),this._repaint(),this.lastTab=!1):(e.replace!=null&&e.replace.length<=this.maxChars&&(this.buf=e.replace,this.cur=e.cursor==null?e.replace.length:e.cursor,this._repaint()),this.lastTab=Array.isArray(e.candidates)&&e.candidates.length>1))}};async function S(e){if(e.args.length){let t=``;for(let n of e.args){let r=e.resolve(n);t+=e.vfs.readFile(r)}return t}if(e.stdin&&typeof e.stdin.readAll==`function`){if(!e.stdin.isTTY)return e.stdin.readAll();let t=``;for(;;){let n=await e.stdin.readLine(``);if(n===null)break;t+=n+`
`}return t}return``}function C(e){if(e===``)return[];let t=e.endsWith(`
`),n=e.split(`
`);return t&&n.pop(),n}function w(e,t,n,r=1){return e.stderr.write(`\x1b[31m${t}: ${n}\x1b[0m\n`),r}function te(e,t){return e=String(e),e.length>=t?e:e+` `.repeat(t-e.length)}function ne(e,t){return e=String(e),e.length>=t?e:` `.repeat(t-e.length)+e}function re(e){let t=[`B`,`K`,`M`,`G`,`T`],n=e,r=0;for(;n>=1024&&r<t.length-1;)n/=1024,r++;return(r===0?n:n.toFixed(1))+t[r]}var ie=[{name:`help`,summary:`list available commands`,usage:`help [command]`,async run(e){if(e.args.length){let t=e.registry.resolve(e.args[0]);return t?(e.stdout.write(`\x1b[1m${t.name}\x1b[0m — ${t.summary}\n\n  \x1b[2musage:\x1b[0m ${t.usage||t.name}\n`),t.aka&&e.stdout.write(`  \x1b[2malias:\x1b[0m ${t.aka.join(`, `)}\n`),0):w(e,`help`,`no such command: ${e.args[0]}`)}let t=e.registry.list();e.stdout.write(`\x1B[1mHERMIT / SPIRAL — command index\x1B[0m

`);for(let n of t)e.stdout.write(`  \x1b[38;5;79m${te(n.name,12)}\x1b[0m ${n.summary}\n`);return e.stdout.write(`\n  \x1b[2m${t.length} commands. \`help NAME\` for details, \`about\` for architecture.\x1b[0m\n`),0}},{name:`man`,summary:`display the manual for a command`,usage:`man command`,async run(e){if(!e.args.length)return w(e,`man`,`what manual page do you want?`);let t=e.registry.resolve(e.args[0]);if(!t)return w(e,`man`,`no manual entry for ${e.args[0]}`);let n=`─`.repeat(Math.min(60,(e.cols||80)-4));return e.stdout.write(`\x1b[1m${t.name.toUpperCase()}(1)\x1b[0m\n${n}\n\n\x1b[1mNAME\x1b[0m\n    ${t.name} — ${t.summary}\n\n\x1b[1mSYNOPSIS\x1b[0m\n    ${t.usage||t.name}\n\n`),t.parse&&t.parse.valued&&e.stdout.write(`\x1b[1mOPTIONS\x1b[0m\n    value-taking flags: ${t.parse.valued.map(e=>`-`+e).join(`, `)}\n\n`),t.aka&&e.stdout.write(`\x1b[1mALIASES\x1b[0m\n    ${t.aka.join(`, `)}\n\n`),0}},{name:`about`,summary:`show the HERMIT / SPIRAL architecture`,usage:`about`,async run(e){let t=e.host.version&&e.host.version()||`1.0.0`,n=(e,t)=>{let n=`  ${e.padEnd(9)} : ${t}`;return`  │`+n+` `.repeat(Math.max(0,60-[...n].length))+`│`};return e.stdout.write([`\x1b[1mJA21 SSD server\x1b[0m v${t}  \x1b[2m— HERMIT virtual terminal\x1b[0m`,``,`  \x1B[38;5;44mArchitecture\x1B[0m`,`  ┌`+`─`.repeat(60)+`┐`,n(`console`,`JA21 1.4.0 blank host · presenter 9.8.7`),n(`vt`,`HERMIT parser · screen · canvas renderer`),n(`link`,`hermit.vws.v2 virtual websocket`),n(`SPIRAL`,`session kernel · SSD volume · pipes`),n(`image`,`sealed factory image, measured at format`),n(`storage`,`nvme0n1 · LOCAL_SSD, flushed on write`),n(`optics`,`processable hologram · TIFF · GIF`),`  └`+`─`.repeat(60)+`┘`,``,`  The root filesystem is the SSD volume. A power cycle remounts it.`,`  Files you write are still there after poweroff and a reload.`,"  `image verify` only reports drift from the sealed factory tree.",``,`  \x1B[2mTry:\x1B[0m  disk  ·  write /tmp/note kept  ·  image verify  ·  poweroff`,``].join(`
`)+`
`),0}},{name:`clear`,summary:`clear the terminal screen`,usage:`clear`,aka:[`cls`],async run(e){return e.stdout.write(`\x1B[2J\x1B[3J\x1B[H`),0}},{name:`history`,summary:`show the command history`,usage:`history [-c]`,async run(e){if(e.flags.c)return e.session.history.length=0,0;let t=e.session.history,n=String(t.length).length;return e.stdout.write(t.map((e,t)=>`\x1b[2m${String(t+1).padStart(n)}\x1b[0m  ${e}`).join(`
`)+(t.length?`
`:``)),0}},{name:`env`,summary:`print the environment`,usage:`env`,aka:[`printenv`],async run(e){let t=e.env.toObject();for(let n of Object.keys(t).sort())n!==`?`&&e.stdout.write(`${n}=${t[n]}\n`);return 0}},{name:`export`,summary:`set an environment variable`,usage:`export NAME[=value] ...`,aka:[`set`],async run(e){for(let t of e.args){let n=t.indexOf(`=`);n>=0?e.env.set(t.slice(0,n),t.slice(n+1)):e.env.has(t)||e.env.set(t,``)}return 0}},{name:`unset`,summary:`remove an environment variable`,usage:`unset NAME ...`,async run(e){for(let t of e.args)e.env.unset(t);return 0}},{name:`alias`,summary:`define or list command aliases`,usage:`alias [name=value ...]`,async run(e){if(!e.args.length){for(let[t,n]of Object.entries(e.aliases))e.stdout.write(`alias ${t}='${n}'\n`);return 0}for(let t of e.args){let n=t.indexOf(`=`);if(n<0){let n=e.aliases[t];e.stdout.write(n?`alias ${t}='${n}'\n`:``)}else e.aliases[t.slice(0,n)]=t.slice(n+1).replace(/^['"]|['"]$/g,``)}return 0}},{name:`unalias`,summary:`remove an alias`,usage:`unalias name ...`,async run(e){for(let t of e.args)delete e.aliases[t];return 0}},{name:`which`,summary:`locate a command`,usage:`which name ...`,aka:[`type`],async run(e){let t=0;for(let n of e.args)e.aliases[n]?e.stdout.write(`${n}: aliased to ${e.aliases[n]}\n`):e.registry.has(n)?e.stdout.write(`${n}: spiral built-in\n`):(e.stdout.write(`${n}: not found\n`),t=1);return t}},{name:`whoami`,summary:`print the current user`,usage:`whoami`,async run(e){return e.stdout.write((e.env.get(`USER`)||`operator`)+`
`),0}},{name:`uname`,summary:`print system information`,usage:`uname [-a]`,async run(e){let t=e.host.version&&e.host.version()||`1.0.0`;return e.flags.a?e.stdout.write(`JA21 ssd0 ${t} SPIRAL persistent hermit-256color\n`):e.stdout.write(`JA21
`),0}},{name:`date`,summary:`print the current date and time`,usage:`date`,async run(e){return e.stdout.write((/* @__PURE__ */ new Date()).toString()+`
`),0}},{name:`sysinfo`,summary:`terminal runtime status`,usage:`sysinfo`,async run(e){let t=e.host.browserState?e.host.browserState():{visible:!1};return e.stdout.write([`\x1B[1mSPIRAL runtime\x1B[0m`,`  session   : ${e.session.id}`,`  geometry  : ${e.cols}x${e.rows}`,`  cwd       : ${e.session.cwd}`,`  commands  : ${e.registry.list().length}`,`  browser   : ${t.visible?`visible`:`hidden`} (${t.engine||`n/a`})`,``].join(`
`)+`
`),0}},{name:`exit`,summary:`close the session`,usage:`exit [code]`,aka:[`logout`,`quit`],async run(e){let t=parseInt(e.args[0],10);return e.stdout.write(`logout
`),e.exit(Number.isInteger(t)?t:0),Number.isInteger(t)?t:0}}];function ae(e){let t=e.type===`dir`?`d`:`-`,n=e.mode||(e.type===`dir`?493:420),r=(e,t)=>n&e?t:`-`;return t+r(256,`r`)+r(128,`w`)+r(64,`x`)+r(32,`r`)+r(16,`w`)+r(8,`x`)+r(4,`r`)+r(2,`w`)+r(1,`x`)}function T(e){return e.type===`dir`?`\x1b[1;38;5;75m${e.name}\x1b[0m`:e.mode&64?`\x1b[1;38;5;114m${e.name}\x1b[0m`:e.name}var oe=[{name:`pwd`,summary:`print working directory`,usage:`pwd`,async run(e){return e.stdout.write(e.session.cwd+`
`),0}},{name:`cd`,summary:`change the working directory`,usage:`cd [dir]`,async run(e){let t=e.args[0]||e.env.get(`HOME`)||`/`,n=e.resolve(t===`-`?e.env.get(`OLDPWD`)||e.session.cwd:t);return e.vfs.exists(n)?e.vfs.isDir(n)?(e.env.set(`OLDPWD`,e.session.cwd),e.chdir(n),0):w(e,`cd`,`not a directory: ${t}`):w(e,`cd`,`no such file or directory: ${t}`)}},{name:`ls`,summary:`list directory contents`,usage:`ls [-l] [-a] [-h] [path...]`,aka:[`dir`],async run(e){let t=e.args.length?e.args:[`.`],n=0,r=t.length>1;for(let i of t){let t=e.resolve(i);if(!e.vfs.exists(t)){n=w(e,`ls`,`cannot access '${i}': no such file or directory`,2);continue}if(r&&e.stdout.write(`\n${i}:\n`),!e.vfs.isDir(t)){e.stdout.write(i+`
`);continue}let a=e.vfs.readdir(t);if(e.flags.a||(a=a.filter(e=>!e.name.startsWith(`.`))),e.flags.l)for(let t of a){let n=e.flags.h?re(t.size):String(t.size),r=new Date(t.mtime).toISOString().slice(0,16).replace(`T`,` `);e.stdout.write(`${ae(t)}  ${ne(n,7)}  \x1b[2m${r}\x1b[0m  ${T(t)}\n`)}else{let t=Math.max(1,Math.floor((e.cols||80)/22)),n=``;a.forEach((r,i)=>{n+=te(T(r),22+(T(r).length-r.name.length)),(i+1)%t===0&&(e.stdout.write(n.trimEnd()+`
`),n=``)}),n.trim()&&e.stdout.write(n.trimEnd()+`
`)}}return n}},{name:`tree`,summary:`list contents recursively as a tree`,usage:`tree [path]`,async run(e){let t=e.resolve(e.args[0]||`.`);if(!e.vfs.isDir(t))return w(e,`tree`,`not a directory: ${e.args[0]||`.`}`);let n=0,r=0,i=(t,a)=>{let o=e.vfs.readdir(t).filter(e=>!e.name.startsWith(`.`));o.forEach((s,c)=>{let l=c===o.length-1;e.stdout.write(a+(l?`└── `:`├── `)+T(s)+`
`),s.type===`dir`?(n++,i(t+`/`+s.name,a+(l?`    `:`│   `))):r++})};return e.stdout.write(`\x1b[1;38;5;75m${e.args[0]||`.`}\x1b[0m\n`),i(t,``),e.stdout.write(`\n${n} directories, ${r} files\n`),0}},{name:`find`,summary:`search for files by name`,usage:`find [path] [-name PATTERN] [-type f|d]`,parse:{valued:[`name`,`type`]},async run(e){let t=e.resolve(e.args[0]||`.`),n=e.flags.name?RegExp(`^`+String(e.flags.name).replace(/[.+^${}()|[\]\\]/g,`\\$&`).replace(/\*/g,`.*`).replace(/\?/g,`.`)+`$`):null,r=e.flags.type,i=[],a=t=>{let o;try{o=e.vfs.readdir(t)}catch{return}for(let e of o){let o=t===`/`?`/`+e.name:t+`/`+e.name,s=!n||n.test(e.name),c=!r||(r===`d`?e.type===`dir`:e.type===`file`);s&&c&&i.push(o),e.type===`dir`&&a(o)}};return!n&&!r&&i.push(t),a(t),e.stdout.write(i.join(`
`)+(i.length?`
`:``)),0}},{name:`mkdir`,summary:`make directories`,usage:`mkdir [-p] dir...`,async run(e){if(!e.args.length)return w(e,`mkdir`,`missing operand`);let t=0;for(let n of e.args)try{e.vfs.mkdir(e.resolve(n),{recursive:!!e.flags.p})}catch(n){t=w(e,`mkdir`,n.message)}return t}},{name:`rmdir`,summary:`remove empty directories`,usage:`rmdir dir...`,async run(e){let t=0;for(let n of e.args){let r=e.resolve(n);if(!e.vfs.isDir(r))t=w(e,`rmdir`,`not a directory: ${n}`);else try{e.vfs.remove(r,{recursive:!1})}catch(n){t=w(e,`rmdir`,n.message)}}return t}},{name:`rm`,summary:`remove files or directories`,usage:`rm [-r] [-f] path...`,async run(e){if(!e.args.length&&!e.flags.f)return w(e,`rm`,`missing operand`);let t=0;for(let n of e.args){let r=e.resolve(n);if(!e.vfs.exists(r))e.flags.f||(t=w(e,`rm`,`cannot remove '${n}': no such file or directory`));else try{e.vfs.remove(r,{recursive:!!e.flags.r})}catch(n){t=w(e,`rm`,n.message)}}return t}},{name:`touch`,summary:`create empty files / update mtime`,usage:`touch file...`,async run(e){if(!e.args.length)return w(e,`touch`,`missing file operand`);for(let t of e.args){let n=e.resolve(t);if(e.vfs.exists(n)){let t=e.vfs._walk(n);t.mtime=Date.now()}else e.vfs.writeFile(n,``)}return 0}},{name:`cp`,summary:`copy files`,usage:`cp src dst`,async run(e){if(e.args.length<2)return w(e,`cp`,`usage: cp src dst`);let t=e.resolve(e.args[0]),n=e.vfs.readFile(t),r=e.resolve(e.args[1]);return e.vfs.isDir(r)&&(r=r+`/`+e.args[0].split(`/`).pop()),e.vfs.writeFile(r,n),0}},{name:`mv`,summary:`move or rename files`,usage:`mv src dst`,async run(e){if(e.args.length<2)return w(e,`mv`,`usage: mv src dst`);try{e.vfs.move(e.resolve(e.args[0]),e.resolve(e.args[1]))}catch(t){return w(e,`mv`,t.message)}return 0}},{name:`stat`,summary:`display file status`,usage:`stat file...`,async run(e){if(!e.args.length)return w(e,`stat`,`missing operand`);let t=0;for(let n of e.args)try{let t=e.vfs.stat(e.resolve(n));e.stdout.write(`  File: ${n}\n  Type: ${t.type}\n  Size: ${t.size}\n  Mode: ${t.mode.toString(8)}\n  Modify: ${new Date(t.mtime).toISOString()}\n`)}catch(n){t=w(e,`stat`,n.message)}return t}},{name:`write`,summary:`write text into a file (write FILE text...)`,usage:`write [-a] FILE text...`,async run(e){if(e.args.length<1)return w(e,`write`,`usage: write [-a] FILE text...`);let t=e.resolve(e.args[0]),n=e.args.slice(1).join(` `)+`
`;return e.vfs.writeFile(t,n,{append:!!e.flags.a}),0}}],se=[{name:`echo`,summary:`write arguments to standard output`,usage:`echo [-n] [-e] [args...]`,parse:{},async run(e){let t=e.flags.n===!0,n=e.args.join(` `);return e.flags.e&&(n=n.replace(/\\n/g,`
`).replace(/\\t/g,`	`).replace(/\\r/g,`\r`).replace(/\\e/g,`\x1B`).replace(/\\\\/g,`\\`)),e.stdout.write(n+(t?``:`
`)),0}},{name:`printf`,summary:`format and print data`,usage:`printf FORMAT [args...]`,async run(e){if(!e.args.length)return w(e,`printf`,`usage: printf FORMAT [args...]`);let t=e.args[0].replace(/\\n/g,`
`).replace(/\\t/g,`	`).replace(/\\e/g,`\x1B`).replace(/\\r/g,`\r`),n=e.args.slice(1),r=0,i=t.replace(/%[-0-9.]*[sdxfc%]/g,e=>{if(e===`%%`)return`%`;let t=n[r++],i=e[e.length-1];return i===`d`?String(parseInt(t,10)||0):i===`x`?(parseInt(t,10)||0).toString(16):i===`f`?String(Number(t)||0):t==null?``:String(t)});return e.stdout.write(i),0}},{name:`cat`,summary:`concatenate files and print`,usage:`cat [-n] [file...]`,parse:{},async run(e){let t=await S(e);if(e.flags.n){let n=C(t),r=String(n.length).length;e.stdout.write(n.map((e,t)=>`\x1b[2m${String(t+1).padStart(r)}\x1b[0m  ${e}`).join(`
`)+(n.length?`
`:``))}else e.stdout.write(t);return 0}},{name:`head`,summary:`output the first part of files`,usage:`head [-n count] [file...]`,parse:{valued:[`n`]},async run(e){let t=parseInt(e.flags.n,10)||10,n=C(await S(e)).slice(0,t);return e.stdout.write(n.join(`
`)+(n.length?`
`:``)),0}},{name:`tail`,summary:`output the last part of files`,usage:`tail [-n count] [file...]`,parse:{valued:[`n`]},async run(e){let t=parseInt(e.flags.n,10)||10,n=C(await S(e)),r=n.slice(Math.max(0,n.length-t));return e.stdout.write(r.join(`
`)+(r.length?`
`:``)),0}},{name:`wc`,summary:`count lines, words and bytes`,usage:`wc [-l] [-w] [-c] [file...]`,async run(e){let t=await S(e),r=C(t).length,i=(t.match(/\S+/g)||[]).length,a=n.byteLength(t),o=e.flags.l||e.flags.w||e.flags.c,s=[];return(!o||e.flags.l)&&s.push(String(r).padStart(6)),(!o||e.flags.w)&&s.push(String(i).padStart(6)),(!o||e.flags.c)&&s.push(String(a).padStart(6)),e.stdout.write(s.join(` `).trim()+`
`),0}},{name:`grep`,summary:`search for a pattern`,usage:`grep [-i] [-v] [-n] [-c] PATTERN [file...]`,parse:{},async run(e){if(!e.args.length)return w(e,`grep`,`usage: grep PATTERN [file...]`);let t=e.args[0];e.args=e.args.slice(1);let n=`g`+(e.flags.i?`i`:``),r=e.limits||{};if(r.regexChars&&t.length>r.regexChars)return w(e,`grep`,`pattern longer than ${r.regexChars} characters`,2);let i;try{i=new RegExp(t,n)}catch(t){return w(e,`grep`,t.message,2)}let a=!!e.flags.v,o=C(await S(e)),s=0,c=[];return o.forEach((t,n)=>{if(r.regexLineChars&&t.length>r.regexLineChars&&(t=t.slice(0,r.regexLineChars)),i.lastIndex=0,i.test(t)!==a){if(s++,e.flags.c)return;let r=t;a||(i.lastIndex=0,r=t.replace(i,e=>`\x1b[1;31m${e}\x1b[0m`)),c.push((e.flags.n?`\x1b[32m${n+1}\x1b[0m:`:``)+r)}}),e.flags.c?e.stdout.write(s+`
`):c.length&&e.stdout.write(c.join(`
`)+`
`),+!s}},{name:`sort`,summary:`sort lines of text`,usage:`sort [-r] [-n] [-u] [file...]`,async run(e){let t=C(await S(e));return t.sort(e.flags.n?(e,t)=>parseFloat(e)-parseFloat(t):(e,t)=>e.localeCompare(t)),e.flags.r&&t.reverse(),e.flags.u&&(t=[...new Set(t)]),e.stdout.write(t.join(`
`)+(t.length?`
`:``)),0}},{name:`uniq`,summary:`report or omit repeated adjacent lines`,usage:`uniq [-c] [file...]`,async run(e){let t=C(await S(e)),n=[],r=null,i=0,a=()=>{r!==null&&n.push(e.flags.c?`${String(i).padStart(4)} ${r}`:r)};for(let e of t)e===r?i++:(a(),r=e,i=1);return a(),e.stdout.write(n.join(`
`)+(n.length?`
`:``)),0}},{name:`rev`,summary:`reverse characters of each line`,usage:`rev [file...]`,async run(e){let t=C(await S(e)).map(e=>[...e].reverse().join(``));return e.stdout.write(t.join(`
`)+(t.length?`
`:``)),0}},{name:`tr`,summary:`translate or delete characters`,usage:`tr [-d] SET1 [SET2]`,async run(e){let t=await ce(e);if(e.flags.d){let n=new Set(e.args[0]||``);return e.stdout.write([...t].filter(e=>!n.has(e)).join(``)),0}let n=e.args[0]||``,r=e.args[1]||``,i={};for(let e=0;e<n.length;e++)i[n[e]]=r[e]==null?r[r.length-1]||``:r[e];return e.stdout.write([...t].map(e=>e in i?i[e]:e).join(``)),0}},{name:`seq`,summary:`print a sequence of numbers`,usage:`seq [first [incr]] last`,async run(e){let t=e.args.map(Number),n=1,r=1,i;if(t.length===1)[i]=t;else if(t.length===2)[n,i]=t;else if(t.length>=3)[n,r,i]=t;else return w(e,`seq`,`usage: seq [first [incr]] last`);if(![n,r,i].every(Number.isFinite))return w(e,`seq`,`arguments must be finite numbers`);let a=e.limits&&e.limits.seqItems||1e6,o=r===0?0:Math.floor((i-n)/r)+1;if(o>a)return w(e,`seq`,`sequence of ${o} items exceeds the limit of ${a}`);let s=[],c=async()=>{if(s.length&&(e.stdout.write(s.join(`
`)+`
`),s=[],e.yield&&await e.yield()),e.signal&&e.signal.aborted)throw Error(`interrupted`)};if(r>0)for(let e=n;e<=i;e+=r)s.push(e),s.length>=1e3&&await c();else if(r<0)for(let e=n;e>=i;e+=r)s.push(e),s.length>=1e3&&await c();return await c(),0}},{name:`true`,summary:`do nothing, successfully`,usage:`true`,async run(){return 0}},{name:`false`,summary:`do nothing, unsuccessfully`,usage:`false`,async run(){return 1}},{name:`sleep`,summary:`delay for a number of seconds`,usage:`sleep SECONDS`,async run(e){let t=parseFloat(e.args[0])||0;return await new Promise((n,r)=>{let i=setTimeout(n,t*1e3);e.signal.addEventListener(`abort`,()=>{clearTimeout(i),r(/* @__PURE__ */ Error(`interrupted`))},{once:!0})}),0}}];async function ce(e){if(e.stdin&&!e.stdin.isTTY)return e.stdin.readAll();let t=``;for(;;){let n=await e.stdin.readLine(``);if(n===null)break;t+=n+`
`}return t}var le=[{name:`browser`,summary:`control the embedded browser pane`,usage:`browser <open|go|close|info> [url]`,aka:[`br`],async run(e){let t=e.args[0],n=e.args.slice(1).join(` `),r=e.host;switch(t){case`open`:{if(!r.openBrowser)return w(e,`browser`,`host bridge unavailable`);let t=r.openBrowser(n||`about:blank`);return e.stdout.write(`\x1b[38;5;79m▸\x1b[0m browser open  \x1b[2m${t&&t.url||n}\x1b[0m  [${t&&t.engine||`?`}]\n`),0}case`go`:case`nav`:{if(!n)return w(e,`browser`,`usage: browser go <url>`);let t=r.navigateBrowser?r.navigateBrowser(n):null;return t&&!t.visible&&r.openBrowser&&r.openBrowser(n),e.stdout.write(`\x1b[38;5;79m▸\x1b[0m navigate  \x1b[2m${t&&t.url||n}\x1b[0m\n`),0}case`close`:case`hide`:return r.closeBrowser&&r.closeBrowser(),e.stdout.write(`browser pane hidden
`),0;case`info`:case void 0:{let t=r.browserState?r.browserState():{visible:!1};return e.stdout.write([`\x1B[1mBrowser pane\x1B[0m`,`  engine  : ${t.engine||`n/a`}`,`  visible : ${t.visible}`,`  url     : ${t.url||`—`}`,``].join(`
`)+`
`),0}default:return w(e,`browser`,`unknown subcommand: ${t}`)}},complete(e,t){return[`open`,`go`,`close`,`info`].filter(e=>e.startsWith(t))}},{name:`open`,summary:`open a URL in the browser pane`,usage:`open <url>`,async run(e){let t=e.args.join(` `)||`about:blank`;if(!e.host.openBrowser)return w(e,`open`,`host bridge unavailable`);let n=e.host.openBrowser(t);return e.stdout.write(`\x1b[38;5;79m▸\x1b[0m ${n&&n.url||t}\n`),0}}];let ue=[{key:`small`,node:`N_SMALL`,role:`edge microvm`},{key:`medium`,node:`N_MEDIUM`,role:`general compute`},{key:`large`,node:`N_LARGE`,role:`memory-bound inference`},{key:`xlarge`,node:`N_XLARGE`,role:`CXL window consumer`}];function de(e){let t=e.host.fabricRoster?e.host.fabricRoster():[];return t.length?t:ue.map(e=>({...e,present:!0,built:!0}))}function E(e){return Number.isFinite(e)?e<1024?`${e} B`:e<1048576?`${(e/1024).toFixed(1)} KiB`:`${(e/1048576).toFixed(2)} MiB`:`unlimited`}async function fe(e){return e.host.image?e.host.image():null}var pe=[{name:`memstat`,summary:`show the volume and page-cache ledger`,usage:`memstat`,async run(e){let t=e.vfs.usage(),n=t.maxBytes&&Number.isFinite(t.maxBytes)?Math.round(100*t.bytes/t.maxBytes):0,r=e.host.disk&&e.host.disk()||{};return e.stdout.write([`\x1B[1mLOCAL_SSD ledger\x1B[0m`,`  volume    : ${E(t.bytes)} / ${E(t.maxBytes)}  (${n}%)`,`  nodes     : ${t.nodes} / ${t.maxNodes}`,`  block dev : ${r.device||`nvme0n1`}  (${r.model||`JA21 NVMe`})`,`  sync      : ${r.synced?`clean`:`dirty`}${r.error?`  `+r.error:``}`,`  cache     : worker page cache — the volume itself is the SSD`,``].join(`
`)),0}},{name:`image`,summary:`show or verify the sealed boot image`,usage:`image [verify]`,async run(e){let t=await fe(e);if(!t)return w(e,`image`,`no image controller on this host`);let n=e.args[0]||`show`;return n===`verify`?t.digest===t.seal?(e.stdout.write(`\x1b[38;5;79mSEAL OK\x1b[0m  ${t.seal}\n  runtime tree matches the boot image\n`),0):(e.stdout.write(`\x1b[33mDRIFT\x1b[0m\n  boot ${t.seal}\n  now  ${t.digest}\n  the SSD volume differs from the sealed factory image\n`),1):n===`show`?(e.stdout.write([`\x1B[1mboot image\x1B[0m`,`  profile : ${t.profile}`,`  epoch   : ${t.epoch}`,`  seal    : ${t.seal}`,`  medium  : SSD nvme0n1 — poweroff flushes, it does not erase`,``].join(`
`)),0):w(e,`image`,`usage: image [verify]`)}},{name:`disk`,summary:`show the SSD volume this server is mounted from`,usage:`disk`,async run(e){let t=e.host.disk&&e.host.disk()||null;if(!t)return w(e,`disk`,`no block device on this host`);let n=t.writtenAt?new Date(t.writtenAt).toISOString():`never`;return e.stdout.write([`\x1b[1m${t.device}\x1b[0m  ${t.model}`,`  fs      : ${t.fs}`,`  mount   : ${t.mount||`/`}`,`  state   : ${t.synced?`synced`:`dirty`}${t.restored?`  (remounted)`:``}`,`  written : ${n}`,t.error?`  error   : ${t.error}`:``,`  note    : poweroff and reload remount this volume`,``].filter(e=>e!==``).join(`
`)+`
`),+!!t.error}},{name:`mount`,summary:`show the only filesystem mount`,usage:`mount`,async run(e){return e.stdout.write(`/dev/nvme0n1 on / type ssd (rw,noatime,local_ssd)
`),0}},{name:`cxl`,summary:`show this server's memory window as hot and warm tiers`,usage:`cxl [status]`,async run(e){let t=e.args[0]||`status`;if(t!==`status`&&t!==`pool`)return w(e,`cxl`,`usage: cxl [status]`);let n=e.vfs.usage(),r=Math.max(0,n.maxBytes-n.bytes);return e.stdout.write([`\x1B[1mmemory window\x1B[0m  \x1B[2m(admission quota for the page cache)\x1B[0m`,`  hot  resident file bytes   ${E(n.bytes)}`,`  warm unused quota          ${E(r)}`,`  fabric  byte-addressable load/store inside the worker heap`,`  note    not a physical CXL device — the tier split is this quota`,``].join(`
`)),0}},{name:`df`,summary:`fabric roster stored on the SSD`,usage:`df [status|nodes|where]`,async run(e){let t=e.args[0]||`status`;if(t===`where`)return e.stdout.write(`DF root : /df   (on nvme0n1, not a host path)
`),0;let n=de(e);if(t===`nodes`||t===`status`){e.stdout.write(`\x1B[1mDF fabric\x1B[0m  on nvme0n1
`);for(let t of n)e.stdout.write(`  ${t.present?`\x1B[38;5;79m●\x1B[0m`:`○`} ${t.node.padEnd(10)} ${t.role}  ${t.built?`image built`:`cold`}\n`);return 0}return w(e,`df`,`usage: df [status|nodes|where]`)}},{name:`fabric`,summary:`render the federation on this volume`,usage:`fabric [status|topology]`,async run(e){let t=e.args[0]||`status`,n=de(e);if(t===`topology`)return e.stdout.write([`        N_SMALL ──┐`,`        N_MEDIUM ─┼── DF0  (this host)`,`        N_LARGE ──┤`,`        N_XLARGE ─┘`,`  links are names inside the worker, not network hops.`,``].join(`
`)),0;if(t===`status`){let t=n.filter(e=>e.present&&e.built).length;return e.stdout.write(`fabric  ${t}/${n.length} node images resident · root /df\n`),0}return w(e,`fabric`,`usage: fabric [status|topology]`)}},{name:`node`,summary:`inspect one fabric node on the volume`,usage:`node <small|medium|large|xlarge> [status]`,async run(e){let t=e.args[0],n=de(e).find(e=>e.key===t||e.node.toLowerCase()===String(t||``).toLowerCase());return n?(e.stdout.write(`${n.node}  ${n.role}\n  present : ${n.present}\n  image   : ${n.built?`on nvme0n1`:`absent`}\n  disk    : nvme0n1\n`),0):w(e,`node`,`usage: node <small|medium|large|xlarge>`)}},{name:`link`,summary:`show the virtual websocket this terminal is attached to`,usage:`link`,async run(e){let t=e.host.linkInfo&&e.host.linkInfo()||{};return e.stdout.write([`\x1B[1mvirtual websocket\x1B[0m`,`  protocol : ${t.protocol||`hermit.vws.v2`}`,`  profile  : ${t.profile||`LOCAL_SSD`}`,`  epoch    : ${t.epoch||`—`}`,`  path     : worker message port (one socket per session)`,`  frames   : 7-byte header, kind 1 input / kind 2 output, uint48 seq`,``].join(`
`)),0}},{name:`poweroff`,summary:`flush the SSD and cut power`,usage:`poweroff`,aka:[`halt`,`shutdown`],async run(e){e.stdout.write(`\x1B[33mflushing nvme0n1\x1B[0m
`);try{e.host.sync&&await e.host.sync()}catch(t){return w(e,`poweroff`,t.message||`flush failed`)}return e.stdout.write(`\x1B[33mcutting power — the volume stays on the SSD\x1B[0m
`),await new Promise(e=>setTimeout(e,40)),e.host.poweroff&&await e.host.poweroff(),0}},{name:`reboot`,summary:`flush the SSD and remount it`,usage:`reboot`,async run(e){e.stdout.write(`\x1B[33mflushing nvme0n1 — remounting the same volume\x1B[0m
`);try{e.host.sync&&await e.host.sync()}catch(t){return w(e,`reboot`,t.message||`flush failed`)}return await new Promise(e=>setTimeout(e,40)),e.host.poweroff&&await e.host.poweroff(),0}}];let me=`namespace Spiral.Hpu;

/// <summary>
/// Wraparound for six general byte processors and the seventh controller.
/// Each of the six owns a 64×64 gray TIFF built from the same RAM sample.
/// Each of the six is a CPU and a GPU equivalent of the same mask.
/// The scalar CPU retires fetch, decode, execute, and writeback.
/// The GPU retires the same byte in warps of 32. Sample keeps a plane
/// only when those two lanes match. Processor 7 issues the byte that
/// moves farthest. A tie keeps the lowest index. The lanes are not chained.
/// </summary>
public sealed class ChipHarness
{
    public const int Width = 64;
    public const int Height = 64;
    public const int Processors = 6;
    public const int Warp = 32;

    static readonly byte[][] Tables =
    {
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1,255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255 },
        new byte[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 }
    };

    public byte[][] Planes { get; private set; } = new byte[Processors][];
    public byte[] Route { get; private set; } = System.Array.Empty<byte>();
    public byte[] Chip { get; private set; } = System.Array.Empty<byte>();

    public static int RouteOf(byte sample)
    {
        int best = -1;
        int pick = 0;
        for (int s = 0; s < Processors; s++)
        {
            int delta = System.Math.Abs(Tables[s][sample] - sample);
            if (delta > best)
            {
                best = delta;
                pick = s;
            }
        }
        return pick;
    }

    public byte[] Cpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        for (int i = 0; i < ram.Length; i++)
            lane[i] = table[ram[i]];
        return lane;
    }

    public byte[] Gpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        int warps = ram.Length / Warp;
        for (int warp = 0; warp < warps; warp++)
        {
            int start = warp * Warp;
            for (int laneId = 0; laneId < Warp; laneId++)
            {
                int i = start + laneId;
                lane[i] = table[ram[i]];
            }
        }
        return lane;
    }

    public void Sample(byte[] ram)
    {
        if (ram == null || ram.Length != Width * Height)
            throw new System.ArgumentException("RAM sample must be 4096 bytes.");
        Route = new byte[ram.Length];
        Chip = new byte[ram.Length];
        for (int s = 0; s < Processors; s++)
        {
            var cpu = Cpu(s, ram);
            var gpu = Gpu(s, ram);
            for (int i = 0; i < ram.Length; i++)
                if (cpu[i] != gpu[i])
                    throw new System.InvalidOperationException("CPU and GPU lanes diverged.");
            Planes[s] = cpu;
        }
        for (int i = 0; i < ram.Length; i++)
        {
            int pick = RouteOf(ram[i]);
            Route[i] = (byte)(pick + 1);
            Chip[i] = Planes[pick][i];
        }
    }

    /// <summary>Index 1–6 is that processor's TIFF. Index 7 is the controller route.</summary>
    public byte[] Tiff(int index)
    {
        if (Planes[0] == null) throw new System.InvalidOperationException("Call Sample first.");
        if (index < 1 || index > 7) throw new System.ArgumentOutOfRangeException(nameof(index));
        var samples = new ushort[Width * Height];
        if (index == 7)
        {
            for (int i = 0; i < samples.Length; i++)
            {
                int r = Route[i];
                samples[i] = (ushort)((r << 8) | r);
            }
        }
        else
        {
            var lane = Planes[index - 1];
            for (int i = 0; i < samples.Length; i++)
                samples[i] = (ushort)(lane[i] * 257);
        }
        return EncodeGray16(Width, Height, samples);
    }

    /// <summary>Sample the RAM bytes and return the seven TIFF payloads.</summary>
    public byte[][] Wrap(byte[] ram)
    {
        Sample(ram);
        var all = new byte[7][];
        for (int i = 0; i < 7; i++) all[i] = Tiff(i + 1);
        return all;
    }

    static byte[] EncodeGray16(int width, int height, ushort[] samples)
    {
        int[][] tags =
        {
            new[] { 256, 4, 1, width },
            new[] { 257, 4, 1, height },
            new[] { 258, 3, 1, 16 },
            new[] { 259, 3, 1, 1 },
            new[] { 262, 3, 1, 1 },
            new[] { 273, 4, 1, 0 },
            new[] { 277, 3, 1, 1 },
            new[] { 278, 4, 1, height },
            new[] { 279, 4, 1, width * height * 2 },
            new[] { 282, 5, 1, 0 },
            new[] { 283, 5, 1, 0 },
            new[] { 296, 3, 1, 2 },
        };
        int ifd = 8;
        int nTags = tags.Length;
        int ifdBytes = 2 + nTags * 12 + 4;
        int xres = ifd + ifdBytes;
        int yres = xres + 8;
        int strip = yres + 8;
        var outb = new byte[strip + width * height * 2];
        void U16(int at, int value) { outb[at] = (byte)value; outb[at + 1] = (byte)(value >> 8); }
        void U32(int at, int value)
        {
            outb[at] = (byte)value;
            outb[at + 1] = (byte)(value >> 8);
            outb[at + 2] = (byte)(value >> 16);
            outb[at + 3] = (byte)(value >> 24);
        }
        U16(0, 0x4949);
        U16(2, 42);
        U32(4, ifd);
        U16(ifd, nTags);
        tags[5][3] = strip;
        tags[9][3] = xres;
        tags[10][3] = yres;
        int p = ifd + 2;
        foreach (var tag in tags)
        {
            U16(p, tag[0]);
            U16(p + 2, tag[1]);
            U32(p + 4, tag[2]);
            if (tag[1] == 3) U16(p + 8, tag[3]);
            else U32(p + 8, tag[3]);
            p += 12;
        }
        U32(p, 0);
        U32(xres, 3175);
        U32(xres + 4, 1);
        U32(yres, 3175);
        U32(yres + 4, 1);
        for (int i = 0; i < samples.Length; i++) U16(strip + i * 2, samples[i]);
        return outb;
    }
}
`,D=[{id:`processor-1`,name:`Processor 1`,unique:26,table:new Uint8Array([254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0])},{id:`processor-2`,name:`Processor 2`,unique:128,table:new Uint8Array([255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1,255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1])},{id:`processor-3`,name:`Processor 3`,unique:26,table:new Uint8Array([254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0])},{id:`processor-4`,name:`Processor 4`,unique:1,table:new Uint8Array([255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255])},{id:`processor-5`,name:`Processor 5`,unique:1,table:new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])},{id:`processor-6`,name:`Processor 6`,unique:26,table:new Uint8Array([254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0])}];function he(e){return e.host.hpu?e.host.hpu:null}function O(e){e.host.hpuTouch&&e.host.hpuTouch()}function k(e,t){let n=Number(e);return Number.isFinite(n)?n:t}function ge(e,t,n,r){let i=e.resolve(t||n);if(!i.startsWith(`/var/hpu/`))return null;let a=i.slice(i.lastIndexOf(`/`)+1),o=a.lastIndexOf(`.`);return o<=0||a.slice(o)!==r||a.length>64?null:i}function _e(){if(!`namespace Spiral.Hpu;

/// <summary>
/// Wraparound for six general byte processors and the seventh controller.
/// Each of the six owns a 64×64 gray TIFF built from the same RAM sample.
/// Each of the six is a CPU and a GPU equivalent of the same mask.
/// The scalar CPU retires fetch, decode, execute, and writeback.
/// The GPU retires the same byte in warps of 32. Sample keeps a plane
/// only when those two lanes match. Processor 7 issues the byte that
/// moves farthest. A tie keeps the lowest index. The lanes are not chained.
/// </summary>
public sealed class ChipHarness
{
    public const int Width = 64;
    public const int Height = 64;
    public const int Processors = 6;
    public const int Warp = 32;

    static readonly byte[][] Tables =
    {
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1,255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255 },
        new byte[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 }
    };

    public byte[][] Planes { get; private set; } = new byte[Processors][];
    public byte[] Route { get; private set; } = System.Array.Empty<byte>();
    public byte[] Chip { get; private set; } = System.Array.Empty<byte>();

    public static int RouteOf(byte sample)
    {
        int best = -1;
        int pick = 0;
        for (int s = 0; s < Processors; s++)
        {
            int delta = System.Math.Abs(Tables[s][sample] - sample);
            if (delta > best)
            {
                best = delta;
                pick = s;
            }
        }
        return pick;
    }

    public byte[] Cpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        for (int i = 0; i < ram.Length; i++)
            lane[i] = table[ram[i]];
        return lane;
    }

    public byte[] Gpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        int warps = ram.Length / Warp;
        for (int warp = 0; warp < warps; warp++)
        {
            int start = warp * Warp;
            for (int laneId = 0; laneId < Warp; laneId++)
            {
                int i = start + laneId;
                lane[i] = table[ram[i]];
            }
        }
        return lane;
    }

    public void Sample(byte[] ram)
    {
        if (ram == null || ram.Length != Width * Height)
            throw new System.ArgumentException("RAM sample must be 4096 bytes.");
        Route = new byte[ram.Length];
        Chip = new byte[ram.Length];
        for (int s = 0; s < Processors; s++)
        {
            var cpu = Cpu(s, ram);
            var gpu = Gpu(s, ram);
            for (int i = 0; i < ram.Length; i++)
                if (cpu[i] != gpu[i])
                    throw new System.InvalidOperationException("CPU and GPU lanes diverged.");
            Planes[s] = cpu;
        }
        for (int i = 0; i < ram.Length; i++)
        {
            int pick = RouteOf(ram[i]);
            Route[i] = (byte)(pick + 1);
            Chip[i] = Planes[pick][i];
        }
    }

    /// <summary>Index 1–6 is that processor's TIFF. Index 7 is the controller route.</summary>
    public byte[] Tiff(int index)
    {
        if (Planes[0] == null) throw new System.InvalidOperationException("Call Sample first.");
        if (index < 1 || index > 7) throw new System.ArgumentOutOfRangeException(nameof(index));
        var samples = new ushort[Width * Height];
        if (index == 7)
        {
            for (int i = 0; i < samples.Length; i++)
            {
                int r = Route[i];
                samples[i] = (ushort)((r << 8) | r);
            }
        }
        else
        {
            var lane = Planes[index - 1];
            for (int i = 0; i < samples.Length; i++)
                samples[i] = (ushort)(lane[i] * 257);
        }
        return EncodeGray16(Width, Height, samples);
    }

    /// <summary>Sample the RAM bytes and return the seven TIFF payloads.</summary>
    public byte[][] Wrap(byte[] ram)
    {
        Sample(ram);
        var all = new byte[7][];
        for (int i = 0; i < 7; i++) all[i] = Tiff(i + 1);
        return all;
    }

    static byte[] EncodeGray16(int width, int height, ushort[] samples)
    {
        int[][] tags =
        {
            new[] { 256, 4, 1, width },
            new[] { 257, 4, 1, height },
            new[] { 258, 3, 1, 16 },
            new[] { 259, 3, 1, 1 },
            new[] { 262, 3, 1, 1 },
            new[] { 273, 4, 1, 0 },
            new[] { 277, 3, 1, 1 },
            new[] { 278, 4, 1, height },
            new[] { 279, 4, 1, width * height * 2 },
            new[] { 282, 5, 1, 0 },
            new[] { 283, 5, 1, 0 },
            new[] { 296, 3, 1, 2 },
        };
        int ifd = 8;
        int nTags = tags.Length;
        int ifdBytes = 2 + nTags * 12 + 4;
        int xres = ifd + ifdBytes;
        int yres = xres + 8;
        int strip = yres + 8;
        var outb = new byte[strip + width * height * 2];
        void U16(int at, int value) { outb[at] = (byte)value; outb[at + 1] = (byte)(value >> 8); }
        void U32(int at, int value)
        {
            outb[at] = (byte)value;
            outb[at + 1] = (byte)(value >> 8);
            outb[at + 2] = (byte)(value >> 16);
            outb[at + 3] = (byte)(value >> 24);
        }
        U16(0, 0x4949);
        U16(2, 42);
        U32(4, ifd);
        U16(ifd, nTags);
        tags[5][3] = strip;
        tags[9][3] = xres;
        tags[10][3] = yres;
        int p = ifd + 2;
        foreach (var tag in tags)
        {
            U16(p, tag[0]);
            U16(p + 2, tag[1]);
            U32(p + 4, tag[2]);
            if (tag[1] == 3) U16(p + 8, tag[3]);
            else U32(p + 8, tag[3]);
            p += 12;
        }
        U32(p, 0);
        U32(xres, 3175);
        U32(xres + 4, 1);
        U32(yres, 3175);
        U32(yres + 4, 1);
        for (int i = 0; i < samples.Length; i++) U16(strip + i * 2, samples[i]);
        return outb;
    }
}
`.includes(`public byte[] Cpu(`)||!`namespace Spiral.Hpu;

/// <summary>
/// Wraparound for six general byte processors and the seventh controller.
/// Each of the six owns a 64×64 gray TIFF built from the same RAM sample.
/// Each of the six is a CPU and a GPU equivalent of the same mask.
/// The scalar CPU retires fetch, decode, execute, and writeback.
/// The GPU retires the same byte in warps of 32. Sample keeps a plane
/// only when those two lanes match. Processor 7 issues the byte that
/// moves farthest. A tie keeps the lowest index. The lanes are not chained.
/// </summary>
public sealed class ChipHarness
{
    public const int Width = 64;
    public const int Height = 64;
    public const int Processors = 6;
    public const int Warp = 32;

    static readonly byte[][] Tables =
    {
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1,255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255 },
        new byte[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 }
    };

    public byte[][] Planes { get; private set; } = new byte[Processors][];
    public byte[] Route { get; private set; } = System.Array.Empty<byte>();
    public byte[] Chip { get; private set; } = System.Array.Empty<byte>();

    public static int RouteOf(byte sample)
    {
        int best = -1;
        int pick = 0;
        for (int s = 0; s < Processors; s++)
        {
            int delta = System.Math.Abs(Tables[s][sample] - sample);
            if (delta > best)
            {
                best = delta;
                pick = s;
            }
        }
        return pick;
    }

    public byte[] Cpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        for (int i = 0; i < ram.Length; i++)
            lane[i] = table[ram[i]];
        return lane;
    }

    public byte[] Gpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        int warps = ram.Length / Warp;
        for (int warp = 0; warp < warps; warp++)
        {
            int start = warp * Warp;
            for (int laneId = 0; laneId < Warp; laneId++)
            {
                int i = start + laneId;
                lane[i] = table[ram[i]];
            }
        }
        return lane;
    }

    public void Sample(byte[] ram)
    {
        if (ram == null || ram.Length != Width * Height)
            throw new System.ArgumentException("RAM sample must be 4096 bytes.");
        Route = new byte[ram.Length];
        Chip = new byte[ram.Length];
        for (int s = 0; s < Processors; s++)
        {
            var cpu = Cpu(s, ram);
            var gpu = Gpu(s, ram);
            for (int i = 0; i < ram.Length; i++)
                if (cpu[i] != gpu[i])
                    throw new System.InvalidOperationException("CPU and GPU lanes diverged.");
            Planes[s] = cpu;
        }
        for (int i = 0; i < ram.Length; i++)
        {
            int pick = RouteOf(ram[i]);
            Route[i] = (byte)(pick + 1);
            Chip[i] = Planes[pick][i];
        }
    }

    /// <summary>Index 1–6 is that processor's TIFF. Index 7 is the controller route.</summary>
    public byte[] Tiff(int index)
    {
        if (Planes[0] == null) throw new System.InvalidOperationException("Call Sample first.");
        if (index < 1 || index > 7) throw new System.ArgumentOutOfRangeException(nameof(index));
        var samples = new ushort[Width * Height];
        if (index == 7)
        {
            for (int i = 0; i < samples.Length; i++)
            {
                int r = Route[i];
                samples[i] = (ushort)((r << 8) | r);
            }
        }
        else
        {
            var lane = Planes[index - 1];
            for (int i = 0; i < samples.Length; i++)
                samples[i] = (ushort)(lane[i] * 257);
        }
        return EncodeGray16(Width, Height, samples);
    }

    /// <summary>Sample the RAM bytes and return the seven TIFF payloads.</summary>
    public byte[][] Wrap(byte[] ram)
    {
        Sample(ram);
        var all = new byte[7][];
        for (int i = 0; i < 7; i++) all[i] = Tiff(i + 1);
        return all;
    }

    static byte[] EncodeGray16(int width, int height, ushort[] samples)
    {
        int[][] tags =
        {
            new[] { 256, 4, 1, width },
            new[] { 257, 4, 1, height },
            new[] { 258, 3, 1, 16 },
            new[] { 259, 3, 1, 1 },
            new[] { 262, 3, 1, 1 },
            new[] { 273, 4, 1, 0 },
            new[] { 277, 3, 1, 1 },
            new[] { 278, 4, 1, height },
            new[] { 279, 4, 1, width * height * 2 },
            new[] { 282, 5, 1, 0 },
            new[] { 283, 5, 1, 0 },
            new[] { 296, 3, 1, 2 },
        };
        int ifd = 8;
        int nTags = tags.Length;
        int ifdBytes = 2 + nTags * 12 + 4;
        int xres = ifd + ifdBytes;
        int yres = xres + 8;
        int strip = yres + 8;
        var outb = new byte[strip + width * height * 2];
        void U16(int at, int value) { outb[at] = (byte)value; outb[at + 1] = (byte)(value >> 8); }
        void U32(int at, int value)
        {
            outb[at] = (byte)value;
            outb[at + 1] = (byte)(value >> 8);
            outb[at + 2] = (byte)(value >> 16);
            outb[at + 3] = (byte)(value >> 24);
        }
        U16(0, 0x4949);
        U16(2, 42);
        U32(4, ifd);
        U16(ifd, nTags);
        tags[5][3] = strip;
        tags[9][3] = xres;
        tags[10][3] = yres;
        int p = ifd + 2;
        foreach (var tag in tags)
        {
            U16(p, tag[0]);
            U16(p + 2, tag[1]);
            U32(p + 4, tag[2]);
            if (tag[1] == 3) U16(p + 8, tag[3]);
            else U32(p + 8, tag[3]);
            p += 12;
        }
        U32(p, 0);
        U32(xres, 3175);
        U32(xres + 4, 1);
        U32(yres, 3175);
        U32(yres + 4, 1);
        for (int i = 0; i < samples.Length; i++) U16(strip + i * 2, samples[i]);
        return outb;
    }
}
`.includes(`public byte[] Gpu(`)||!`namespace Spiral.Hpu;

/// <summary>
/// Wraparound for six general byte processors and the seventh controller.
/// Each of the six owns a 64×64 gray TIFF built from the same RAM sample.
/// Each of the six is a CPU and a GPU equivalent of the same mask.
/// The scalar CPU retires fetch, decode, execute, and writeback.
/// The GPU retires the same byte in warps of 32. Sample keeps a plane
/// only when those two lanes match. Processor 7 issues the byte that
/// moves farthest. A tie keeps the lowest index. The lanes are not chained.
/// </summary>
public sealed class ChipHarness
{
    public const int Width = 64;
    public const int Height = 64;
    public const int Processors = 6;
    public const int Warp = 32;

    static readonly byte[][] Tables =
    {
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1,255,253,251,249,247,245,243,241,239,237,235,233,231,229,227,225,223,221,219,217,215,213,211,209,207,205,203,201,199,197,195,193,191,189,187,185,183,181,179,177,175,173,171,169,167,165,163,161,159,157,155,153,151,149,147,145,143,141,139,137,135,133,131,129,127,125,123,121,119,117,115,113,111,109,107,105,103,101,99,97,95,93,91,89,87,85,83,81,79,77,75,73,71,69,67,65,63,61,59,57,55,53,51,49,47,45,43,41,39,37,35,33,31,29,27,25,23,21,19,17,15,13,11,9,7,5,3,1 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 },
        new byte[] { 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255 },
        new byte[] { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
        new byte[] { 254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,128,246,128,130,0,254,128,130,0,134,0,2,0,254,144,146,0,150,0,2,0,158,0,2,0,6,0,2,0,254,176,178,0,182,0,2,0,190,0,2,0,6,0,2,0,190,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,240,242,0,246,0,2,0,254,0,2,0,6,0,2,0,254,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0,254,48,50,0,54,0,2,0,62,0,2,0,6,0,2,0,62,16,18,0,22,0,2,0,30,0,2,0,6,0,2,0 }
    };

    public byte[][] Planes { get; private set; } = new byte[Processors][];
    public byte[] Route { get; private set; } = System.Array.Empty<byte>();
    public byte[] Chip { get; private set; } = System.Array.Empty<byte>();

    public static int RouteOf(byte sample)
    {
        int best = -1;
        int pick = 0;
        for (int s = 0; s < Processors; s++)
        {
            int delta = System.Math.Abs(Tables[s][sample] - sample);
            if (delta > best)
            {
                best = delta;
                pick = s;
            }
        }
        return pick;
    }

    public byte[] Cpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        for (int i = 0; i < ram.Length; i++)
            lane[i] = table[ram[i]];
        return lane;
    }

    public byte[] Gpu(int processor, byte[] ram)
    {
        if (processor < 0 || processor >= Processors) throw new System.ArgumentOutOfRangeException(nameof(processor));
        if (ram == null || ram.Length == 0 || ram.Length % Warp != 0) throw new System.ArgumentException("RAM sample must fill whole warps.");
        var table = Tables[processor];
        var lane = new byte[ram.Length];
        int warps = ram.Length / Warp;
        for (int warp = 0; warp < warps; warp++)
        {
            int start = warp * Warp;
            for (int laneId = 0; laneId < Warp; laneId++)
            {
                int i = start + laneId;
                lane[i] = table[ram[i]];
            }
        }
        return lane;
    }

    public void Sample(byte[] ram)
    {
        if (ram == null || ram.Length != Width * Height)
            throw new System.ArgumentException("RAM sample must be 4096 bytes.");
        Route = new byte[ram.Length];
        Chip = new byte[ram.Length];
        for (int s = 0; s < Processors; s++)
        {
            var cpu = Cpu(s, ram);
            var gpu = Gpu(s, ram);
            for (int i = 0; i < ram.Length; i++)
                if (cpu[i] != gpu[i])
                    throw new System.InvalidOperationException("CPU and GPU lanes diverged.");
            Planes[s] = cpu;
        }
        for (int i = 0; i < ram.Length; i++)
        {
            int pick = RouteOf(ram[i]);
            Route[i] = (byte)(pick + 1);
            Chip[i] = Planes[pick][i];
        }
    }

    /// <summary>Index 1–6 is that processor's TIFF. Index 7 is the controller route.</summary>
    public byte[] Tiff(int index)
    {
        if (Planes[0] == null) throw new System.InvalidOperationException("Call Sample first.");
        if (index < 1 || index > 7) throw new System.ArgumentOutOfRangeException(nameof(index));
        var samples = new ushort[Width * Height];
        if (index == 7)
        {
            for (int i = 0; i < samples.Length; i++)
            {
                int r = Route[i];
                samples[i] = (ushort)((r << 8) | r);
            }
        }
        else
        {
            var lane = Planes[index - 1];
            for (int i = 0; i < samples.Length; i++)
                samples[i] = (ushort)(lane[i] * 257);
        }
        return EncodeGray16(Width, Height, samples);
    }

    /// <summary>Sample the RAM bytes and return the seven TIFF payloads.</summary>
    public byte[][] Wrap(byte[] ram)
    {
        Sample(ram);
        var all = new byte[7][];
        for (int i = 0; i < 7; i++) all[i] = Tiff(i + 1);
        return all;
    }

    static byte[] EncodeGray16(int width, int height, ushort[] samples)
    {
        int[][] tags =
        {
            new[] { 256, 4, 1, width },
            new[] { 257, 4, 1, height },
            new[] { 258, 3, 1, 16 },
            new[] { 259, 3, 1, 1 },
            new[] { 262, 3, 1, 1 },
            new[] { 273, 4, 1, 0 },
            new[] { 277, 3, 1, 1 },
            new[] { 278, 4, 1, height },
            new[] { 279, 4, 1, width * height * 2 },
            new[] { 282, 5, 1, 0 },
            new[] { 283, 5, 1, 0 },
            new[] { 296, 3, 1, 2 },
        };
        int ifd = 8;
        int nTags = tags.Length;
        int ifdBytes = 2 + nTags * 12 + 4;
        int xres = ifd + ifdBytes;
        int yres = xres + 8;
        int strip = yres + 8;
        var outb = new byte[strip + width * height * 2];
        void U16(int at, int value) { outb[at] = (byte)value; outb[at + 1] = (byte)(value >> 8); }
        void U32(int at, int value)
        {
            outb[at] = (byte)value;
            outb[at + 1] = (byte)(value >> 8);
            outb[at + 2] = (byte)(value >> 16);
            outb[at + 3] = (byte)(value >> 24);
        }
        U16(0, 0x4949);
        U16(2, 42);
        U32(4, ifd);
        U16(ifd, nTags);
        tags[5][3] = strip;
        tags[9][3] = xres;
        tags[10][3] = yres;
        int p = ifd + 2;
        foreach (var tag in tags)
        {
            U16(p, tag[0]);
            U16(p + 2, tag[1]);
            U32(p + 4, tag[2]);
            if (tag[1] == 3) U16(p + 8, tag[3]);
            else U32(p + 8, tag[3]);
            p += 12;
        }
        U32(p, 0);
        U32(xres, 3175);
        U32(xres + 4, 1);
        U32(yres, 3175);
        U32(yres + 4, 1);
        for (int i = 0; i < samples.Length; i++) U16(strip + i * 2, samples[i]);
        return outb;
    }
}
`.includes(`public const int Warp = 32`))return!1;let e=me.match(/new byte\[\] \{([^}]*)\}/g);if(!e||e.length!==D.length)return!1;for(let t=0;t<D.length;t++){let n=e[t].slice(e[t].indexOf(`{`)+1,e[t].lastIndexOf(`}`)).split(`,`);if(n.length!==256)return!1;let r=D[t].table;for(let e=0;e<256;e++)if(Number(n[e])!==r[e])return!1}return!0}function ve(e){return Number.isFinite(e)?e>=1e3?`${(e/1e3).toFixed(2)} ms`:`${e.toFixed(1)} µs`:`—`}function ye(e){let t=e*0xde0b6b3a7640000;return Number.isFinite(t)?Math.abs(t)>=.01?`${t.toFixed(2)} aJ`:`${(t*1e3).toFixed(2)} zJ`:`—`}function A(e,t,n){let r=t._report(),i=r.bloch;e.stdout.write([`\x1b[1m${n}\x1b[0m  stage ${r.stage}  cycle ${r.cycles}`,`  project  : ${t.n}×${t.n} complex field`,`  evolve   : ASM  z ${r.zMm.toFixed(2)} mm`,`  sample   : ${r.info} info pixels  ·  harness ${ve(r.stepUs||r.sampleUs)}`,`  relocate : ${r.moved} carriers along −∇I`,`  bit line : ${r.logical0} logical 0   anti-bit : ${r.logical1} logical 1`,`  Landauer : ${ye(r.landauer)} cumulative  ·  ${r.erased} bits erased`,`  Bloch    : ${i[0].toFixed(2)}  ${i[1].toFixed(2)}  ${i[2].toFixed(2)}   purity ${r.purity.toFixed(2)}`,`  2-adic   : ⟨v₂⟩ ${r.padic.toFixed(2)}  on the GIF gray`,``].join(`
`))}var be=[{name:`hpu`,summary:`run the TIFF–GIF holographic processor`,usage:`hpu [pattern|prop|gs|gate|cycle|diffuse|bit|tiff|gif|reset]`,async run(e){let t=he(e);if(!t)return w(e,`hpu`,`no holographic processor on this host`);let r=(e.args[0]||`status`).toLowerCase();try{if(r===`status`){let n=t.preview();return e.stdout.write([`\x1B[1mHPU\x1B[0m  processable hologram · TIFF phase · GIF spool`,`  field   : ${n.n}×${n.n}  λ ${n.lambdaNm.toFixed(0)} nm  pitch ${n.pitchUm.toFixed(1)} µm`,`  plane   : ${n.op}`,`  stage   : ${n.stage}  cycle ${n.cycles}`,`  z       : ${n.zMm.toFixed(2)} mm`,`  spool   : ${n.frames} frame${n.frames===1?``:`s`}`,n.gate?`  gate    : ${n.gate} → ${n.bit}`:``,n.nmse==null?``:`  nmse    : ${n.nmse.toFixed(3)}`,n.cycles?`  carriers: ${n.moved}  info ${n.info}  Landauer ${(n.landauerJ*0xde0b6b3a7640000).toFixed(2)} aJ`:``,`  pattern aperture|grating|vortex|twin`,`  prop [mm]    angular spectrum`,`  gs [target] [iters]    spots|bar|ring`,`  gate <and|or|nand|xor|xnor> <0|1> <0|1>`,`  cycle [n]    project, evolve, sample, relocate, reproject`,`  frame [pattern]  Gaussian interaction frame (Wigner)`,`  record [pattern]  interfere a tilted reference into the array`,`  replay       multiply that weight in place and drop the twin`,`  oam <0-255>  place charge-+1 wells, LSB on the right`,`  shift <left|right> [k]   ×2^k or integer ÷2^k`,`  bytes [pattern]  six processors as CPU and GPU, TIFF if they agree`,`  kuramoto [n] sync phases inside 2-adic balls`,`  diffuse [n]  walk carriers along −∇I`,`  bit | bloch | padic`,`  spool | tiff [path] | gif [path] | reset`,``].filter(e=>e!==``).join(`
`)+`
`),O(e),0}if(r===`pattern`){let n=t.pattern(e.args[1]||`aperture`);return e.stdout.write(`phase mask set · ${n}\n`),O(e),0}if(r===`prop`||r===`propagate`){let n=k(e.args[1],5);return n<-80||n>80?w(e,`hpu`,`propagation must stay within ±80 mm`):(t.propagate(n/1e3),e.stdout.write(`ASM  ${n.toFixed(2)} mm   z now ${(t.z*1e3).toFixed(2)} mm\n`),O(e),0)}if(r===`gs`){let n=e.args[1]&&Number.isNaN(Number(e.args[1]))?e.args[1]:`spots`,r=e.args[1]&&!Number.isNaN(Number(e.args[1]))?k(e.args[1],8):k(e.args[2],8),i=t.gerchberg(n,r);return e.stdout.write(`Gerchberg–Saxton  ${i.target}  ${i.iters} iters\n  NMSE ${i.nmse.toFixed(3)}  (phase mask at the SLM, intensity at focus)\n`),O(e),i.nmse<2?0:1}if(r===`gate`){let n=e.args[1],r=e.args[2],i=e.args[3];if(r!==`0`&&r!==`1`||i!==`0`&&i!==`1`)return w(e,`hpu`,`usage: hpu gate <op> <0|1> <0|1>`);let a=t.gate(n,Number(r),Number(i)),o=a.differential?`π on input B, on-axis null test`:`in-phase focus, on-axis threshold`;return e.stdout.write([`\x1b[1m${a.op.toUpperCase()}\x1b[0m ${a.a} ${a.b}  →  \x1b[38;5;79m${a.bit}\x1b[0m`,`  detector : ${a.detector.toFixed(3)}`,`  medium   : ${o}`,``].join(`
`)),O(e),0}if(r===`spool`){let n=t.spool();return e.stdout.write(`GIF frame ${n} spooled from the current intensity\n`),O(e),0}if(r===`reset`)return t._resetLedger(),t.pattern(`aperture`),t.resetSpool(),t.z=0,e.stdout.write(`processor reset · aperture · empty spool · ledger cleared
`),O(e),0;if(r===`frame`||r===`wigner`||r===`gif-frame`){e.args[1]&&t.pattern(e.args[1]);let n=t.frame(),r=n.penteract;return e.stdout.write([`\x1B[1mGIF\x1B[0m  Gaussian interaction frame`,`  displacement removed : α ${n.alpha.toFixed(3)}`,`  residual : n̄ ${n.nbar.toFixed(3)}   Kerr χ ${n.chi.toFixed(3)}`,`  Wigner   : min ${n.wMin.toFixed(4)}   negative ${(n.neg*100).toFixed(1)}%`,n.chi<.02?`  portrait : vacuum, no negativity`:`  portrait : non-Gaussian residual`,`  penteract: x ${r.x.toFixed(1)}  y ${r.y.toFixed(1)}  z ${r.z.toFixed(2)} mm  t ${r.t}  ⟨v₂⟩ ${r.p.toFixed(2)}`,``].join(`
`)),O(e),0}if(r===`kuramoto`){let n=Math.max(1,Math.min(12,k(e.args[1],4)|0)),r=t.kuramoto(n),i=r.penteract;return e.stdout.write([`\x1b[1mKURAMOTO\x1b[0m  ${r.steps} steps on 2-adic balls`,`  order R  : ${r.order.toFixed(3)}`,`  Wigner   : min ${r.wMin.toFixed(4)}   negative ${(r.neg*100).toFixed(1)}%`,`  penteract: x ${i.x.toFixed(1)}  y ${i.y.toFixed(1)}  z ${i.z.toFixed(2)} mm  t ${i.t}  ⟨v₂⟩ ${i.p.toFixed(2)}`,``].join(`
`)),O(e),0}if(r===`record`){let n=t.record(e.args[1]||`aperture`);return e.stdout.write([`\x1b[1mRECORD\x1b[0m  ${n.name}`,`  reference : 4 px tilt, interfered in the field array`,`  weight    : real interferogram, one cell per pixel`,`  bus       : 0 bytes moved`,``].join(`
`)),O(e),0}if(r===`replay`){let n=t.replay();return n?(e.stdout.write([`\x1b[1mREPLAY\x1b[0m  ${n.name}`,`  MAC      : ${n.macOps.toLocaleString()} in-array products`,`  bus      : 0 bytes moved`,`  fidelity : ${n.fidelity.toFixed(3)} overlap with the recorded object`,`  twin     : rejected by the low-pass`,``].join(`
`)),O(e),0):w(e,`hpu`,`record a hologram before replay`)}if(r===`oam`){if(e.args[1]==null)return w(e,`hpu`,`usage: hpu oam <0-255>`);let n=t.oam(k(e.args[1],0));return e.stdout.write([`\x1b[1mOAM\x1b[0m  ${n.value} = ${n.bits}`,`  wells    : LSB at the right, one helical beam per 1`,`  charge   : ℓ ${n.charge>0?`+`:``}${n.charge}`,``].join(`
`)),O(e),n.value===(k(e.args[1],0)&255)?0:1}if(r===`shift`||r===`mul`||r===`div`){let n=1,i=e.args[1];if(r===`div`&&(n=-1),r===`shift`){let t=String(e.args[1]||`left`).toLowerCase();if(t===`right`||t===`r`)n=-1;else if(t!==`left`&&t!==`l`)return w(e,`hpu`,`usage: hpu shift <left|right> [k]`);i=e.args[2]}let a=t.shift(n,k(i,1));if(!a)return w(e,`hpu`,`load a value with hpu oam first`);let o=a.sign>0?`×${1<<a.k}`:`÷${1<<a.k}`;return e.stdout.write([`\x1b[1mSHIFT\x1b[0m  ${a.before} ${o} → ${a.value} = ${a.bits}`,`  charge   : ℓ ${a.charge>0?`+`:``}${a.charge} kept`,a.sign>0?`  overflow : ${a.overflow}`:`  remainder: ${a.rem}`,``].join(`
`)),O(e),0}if(r===`bytes`||r===`chip`){if(!_e())return w(e,`hpu`,`byte harness does not match the six processor tables`);e.args[1]&&t.pattern(e.args[1]);let r=t.bytes();e.vfs.mkdir(`/var/hpu`,{recursive:!0});let i=[`\x1b[1mBYTES\x1b[0m  ${t.n*t.n} RAM samples · CPU≡GPU`];for(let a=1;a<=7;a++){let o=t.tiffPlane(a);if(!o)return w(e,`hpu`,`processor plane was not produced`);let s=`/var/hpu/processor-${a}.tif`;e.vfs.writeFile(s,n.from(o));let c=r.stages[a-1],l=c.same?` · same table as ${c.same}`:``,u=c.cpuCycles?`CPU ${c.cpuCycles.toLocaleString()} cyc · GPU ${c.gpuWarps} warps`:`issues the agreeing byte`;i.push(`  ${c.name}  ${u}`),i.push(`    owns ${c.owned.toLocaleString()}  ${c.changed.toLocaleString()} changed${l}`),i.push(`    ${s}`)}return e.vfs.writeFile(`/var/hpu/ChipHarness.cs`,me),i.push(`  chip     : ${r.written.toLocaleString()} lit pixels took the routed phase`),i.push(`  harness  : /var/hpu/ChipHarness.cs wraps the six TIFFs`),i.push(``),e.stdout.write(i.join(`
`)),O(e),r.written>0?0:1}if(r===`cycle`){let n=Math.max(1,Math.min(8,k(e.args[1],1)|0));return t.cycle(n),A(e,t,`CYCLE`),O(e),0}if(r===`diffuse`){let n=Math.max(1,Math.min(16,k(e.args[1],1)|0));return t.diffuse(n),A(e,t,`DIFFUSE`),O(e),0}if(r===`sample`||r===`bit`)return t.sample(),A(e,t,`SAMPLE`),O(e),0;if(r===`bloch`){t.sample();let n=t.bloch;return e.stdout.write(`Bloch  ${n[0].toFixed(3)}  ${n[1].toFixed(3)}  ${n[2].toFixed(3)}   purity ${t.purity.toFixed(3)}\n  θ from the bit/anti-bit populations, φ from the info-pixel phase
`),O(e),0}if(r===`padic`||r===`p-adic`)return t.sample(),e.stdout.write(`2-adic  ⟨v₂⟩ ${t.padic.toFixed(3)}   mean valuation of nonzero GIF samples\n  larger v₂ means the gray level sits closer to 0 in the ultrametric
`),O(e),0;if(r===`tiff`){let r=ge(e,e.args[1],`/var/hpu/phase.tif`,`.tif`);if(!r)return w(e,`hpu`,`TIFF paths stay under /var/hpu and end in .tif`);e.vfs.mkdir(`/var/hpu`,{recursive:!0});let i=t.tiff();return e.vfs.writeFile(r,n.from(i)),e.stdout.write(`wrote ${r}  ${i.length} bytes  16-bit gray phase TIFF\n`),O(e),0}if(r===`gif`){let r=ge(e,e.args[1],`/var/hpu/spool.gif`,`.gif`);if(!r)return w(e,`hpu`,`GIF paths stay under /var/hpu and end in .gif`);e.vfs.mkdir(`/var/hpu`,{recursive:!0}),t.frames.length||t.spool();let i=t.gif();return e.vfs.writeFile(r,n.from(i)),e.stdout.write(`wrote ${r}  ${i.length} bytes  GIF89a ×${t.frames.length}\n`),O(e),0}return w(e,`hpu`,`usage: hpu [pattern|prop|gs|gate|cycle|frame|record|replay|oam|shift|bytes|kuramoto|diffuse|bit|tiff|gif|reset]`)}catch(t){return w(e,`hpu`,t.message||String(t))}}}],xe=[...ie,...oe,...se,...le,...pe,...be];let Se=e=>setTimeout(e,0),Ce=0,j=Object.freeze({minCols:2,maxCols:400,minRows:1,maxRows:200}),we=Object.freeze({captureBytes:8388608,lineChars:4096,historyEntries:1e3,seqItems:1e6,regexChars:256,regexLineChars:16384});function Te(e,t){return Number.isInteger(e)&&Number.isInteger(t)&&e>=j.minCols&&e<=j.maxCols&&t>=j.minRows&&t<=j.maxRows}var Ee=class extends Error{constructor(e){super(`pipeline capture limit exceeded (${e} chars)`),this.code=`ECAPTURE`}};let De=`\x1B[38;5;44m\\u\x1B[38;5;245m@\\h\x1B[0m \x1B[38;5;252m\\w\x1B[0m \x1B[38;5;44m›\x1B[0m `;var M=class{constructor(e){this.isTTY=!1,this._text=String(e||``),this._lines=this._text.length?this._text.split(`
`):[],this._lines.length&&this._lines[this._lines.length-1]===``&&this._lines.pop(),this._i=0,this._consumed=!1}readAll(){return this._consumed=!0,this._text}read(){return this._consumed?``:(this._consumed=!0,this._text)}async readLine(){return this._i<this._lines.length?this._lines[this._i++]:null}},Oe=class{constructor(e){this.isTTY=!0,this.session=e}read(){return``}readAll(){return``}async readLine(e=``){let t=await this.session.readLine(e,{history:!1});return t===null||t&&typeof t==`object`&&t.aborted?null:t}},ke=class extends e{constructor({hostBridge:e={},limits:t={},vfsLimits:n={},commandFilter:r=null,baseEnv:i={}}={}){super(),this.host=e,this.limits=Object.assign({},we,t),this.vfs=new p(n),this.registry=new m,this.registry.install(r?xe.filter(e=>r(e)):xe),this.sessions=/* @__PURE__ */ new Map,this.baseEnv=new g({SHELL:`spiral`,TERM:`hermit-256color`,HOME:`/home/operator`,USER:`operator`,HOST:`hermit`,PS1:De,PATH:`/bin:/usr/bin`,"?":`0`,...i})}openSession(e={}){let t=e.cols===void 0?80:e.cols,n=e.rows===void 0?24:e.rows;if(!Te(t,n))throw RangeError(`invalid geometry ${String(t).slice(0,12)}x${String(n).slice(0,12)}`);let r=`s${++Ce}`,i=this.baseEnv.child(),a={id:r,env:i,cwd:i.get(`HOME`),cols:t,rows:n,history:[],aliases:Object.create(null),alive:!0,started:!1,exited:!1,pending:null,running:null,readLine:null};return a.readLine=(e,t)=>this._readLine(a,e,t),this.sessions.set(r,a),e.deferStart||queueMicrotask(()=>this.startSession(r)),{sessionId:r,cols:a.cols,rows:a.rows}}startSession(e){let t=this.sessions.get(e);return!t||t.started||!t.alive?!1:(t.started=!0,this._repl(t),!0)}_finishSession(e,t,n){if(e.exited)return!1;e.exited=!0,e.alive=!1,this.sessions.delete(e.id);let r=e.pending;if(e.pending=null,r&&r._finish(null),e.running)try{e.running.abort(`SESSION_CLOSED`)}catch{}return this.emit(`exit`,{sessionId:e.id,code:t|0,reason:n||`closed`}),!0}closeSession(e,t=`closed`){let n=this.sessions.get(e);return n?this._finishSession(n,0,t):!1}resize(e,t,n){let r=this.sessions.get(e);return!r||!r.alive||!Te(t,n)?!1:(r.cols=t,r.rows=n,!0)}write(e,t){let n=this.sessions.get(e);if(n&&n.alive&&typeof t==`string`){if(n.pending){let e=n.pending.feed(t);e&&this._typeahead(n,e)}else n.running&&t.indexOf(``)!==-1?(n.typeahead=``,n.running.abort(`SIGINT`)):this._typeahead(n,t)}}_typeahead(e,t){let n=this.limits.lineChars*2-(e.typeahead||``).length;n<=0?this._emit(e,`\x07`):(e.typeahead=(e.typeahead||``)+t.slice(0,n),t.length>n&&this._emit(e,`\x07`))}signal(e,t){let n=this.sessions.get(e);n&&(t===`SIGINT`||t===`INT`)&&(n.typeahead=``,n.running?n.running.abort(`SIGINT`):n.pending&&n.pending.feed(``))}_emit(e,t){e.alive&&this.emit(`data`,{sessionId:e.id,chunk:t})}async _repl(e){for(this._emit(e,this._banner(e));e.alive;){let t=this._buildPrompt(e),n;try{n=await e.readLine(t,{history:!0})}catch{break}if(n===null){this._emit(e,`logout\r
`);break}if(n&&typeof n==`object`&&n.aborted)continue;let r=n;if(r.trim()){e.history[e.history.length-1]!==r&&(e.history.push(r),e.history.length>this.limits.historyEntries&&e.history.splice(0,e.history.length-this.limits.historyEntries));try{await this._executeLine(e,r)}catch(t){this._emit(e,`\x1b[31mspiral: ${t.message}\x1b[0m\r\n`)}if(this.host.afterCommand)try{await this.host.afterCommand()}catch(t){this._emit(e,`\x1b[31mssd: ${t.message}\x1b[0m\r\n`)}this.emit(`command-complete`,{sessionId:e.id,code:Number(e.env.get(`?`))|0})}}this._finishSession(e,e._exitCode||0,`logout`)}_readLine(e,t,n={}){let r=new ee({write:t=>this._emit(e,t),prompt:t||``,history:n.history?e.history:[],maxChars:this.limits.lineChars,completer:(t,n)=>this._complete(e,t,n)});return e.alive?(e.pending=r,e.typeahead&&queueMicrotask(()=>{if(e.pending!==r||!e.typeahead)return;let t=e.typeahead;e.typeahead=``;let n=r.feed(t);n&&this._typeahead(e,n)}),r.start().then(t=>(e.pending===r&&(e.pending=null),t))):Promise.resolve(null)}_buildPrompt(e){let t=e.env.get(`PS1`)||De;return this._expandPrompt(e,t)}_expandPrompt(e,t){let n=e.env.get(`HOME`),r=e.cwd;return n&&(r===n||r.startsWith(n+`/`))&&(r=`~`+r.slice(n.length)),t.replace(/\\e/g,`\x1B`).replace(/\\u/g,e.env.get(`USER`)||`operator`).replace(/\\h/g,e.env.get(`HOST`)||`hermit`).replace(/\\w/g,r).replace(/\\W/g,a(r)||`/`).replace(/\\n/g,`\r
`).replace(/\\\$/g,e.env.get(`USER`)===`root`?`#`:`$`)}_banner(e){let t=this.host.version&&this.host.version()||`1.0.0`,n=`\x1B[38;5;44m`,r=`\x1B[38;5;240m`,i=`\x1B[2m`,a=`\x1B[0m`,o=`\x1B[1m`;return[``,`  ${n}⌜${a}                                                        ${n}⌝${a}`,`        ${r}▪${a}      ${r}▪${a}      ${r}▪${a}        ${o}[38;5;252mHERMIT${a}  ${r}/${a}  ${n}${o}JA21${a}`,`          ${r}╲  ┆  ╱${a}              ${i}SSD server · hermit.vws.v2 · v${t}${a}`,`        ${r}▪ ┄┄ ${a}${n}◆${a}${r} ┄┄ ▪${a}            ${i}SPIRAL on nvme0n1 · writes stay on disk${a}`,`          ${r}╱  ┆  ╲${a}              ${i}JA21 console host · profile LOCAL_SSD${a}`,`        ${r}▪${a}      ${r}▪${a}      ${r}▪${a}`,`  ${n}⌞${a}                                                        ${n}⌟${a}`,``,`  ${i}Type${a} ${n}help${a} ${i}·${a} ${n}disk${a} ${i}·${a} ${n}image verify${a} ${i}·${a} ${n}poweroff${a} ${i}keeps this volume${a}`,``,``].join(`\r
`)}status(e){let t=this.sessions.get(e);if(!t)return null;let n=this.host.fabricRoster?this.host.fabricRoster():[],r=t.env.get(`HOME`),i=t.cwd;return r&&(i===r||i.startsWith(r+`/`))&&(i=`~`+i.slice(r.length)),{sessionId:t.id,cwd:i,cols:t.cols,rows:t.rows,busy:!!t.running,user:t.env.get(`USER`),host:t.env.get(`HOST`),dfRoot:`/df`,photon:{url:null,token:!1},nodes:n,commands:this.registry.list().length,ram:this.vfs.usage(),disk:this.host.disk?this.host.disk():null,profile:this.host.profile&&this.host.profile()||`LOCAL_SSD`}}async _executeLine(e,t){let n=b(t,e.env),r=0;for(let t of n)if((t.op!==`&&`||r===0)&&(t.op!==`||`||r!==0)){if(this.host.flow&&(await new Promise(e=>Se(e)),this.host.flow.paused()&&await new Promise(e=>this.host.flow.onDrain(e))),!e.alive)break;r=await this._runPipeline(e,t.pipeline)}return e.env.set(`?`,String(r)),r}async _runPipeline(e,t){if(!t.length)return 0;let n=new AbortController;e.running=n;let r=``,a=0;try{for(let o=0;o<t.length;o++){let s=t[o],c=o===t.length-1,l=s.argv.slice(),u=l.shift();if(u==null)continue;let d=/* @__PURE__ */ new Set;for(;u!=null&&e.aliases[u]&&!d.has(u);){d.add(u);let t=e.aliases[u].split(/\s+/).filter(Boolean);u=t.shift(),l=t.concat(l)}let f=this.registry.resolve(u);if(!f){this._emit(e,`\x1b[31mspiral: ${u}: command not found\x1b[0m\r\n`),a=127;break}let p=s.redirects.find(e=>e.type===`out`||e.type===`append`),m=s.redirects.find(e=>e.type===`in`),h;if(m){let t=i(e.cwd,m.target);h=new M(this.vfs.readFile(t))}else h=o>0?new M(r):t.length===1?new Oe(e):new M(``);let g=``,_=this.limits.captureBytes,v={write:e=>{if(e=String(e),g.length+e.length>_)throw n.abort(`CAPTURE_LIMIT`),new Ee(_);g+=e}},y=p?v:c?{write:t=>this._emit(e,String(t).replace(/\r?\n/g,`\r
`))}:v,b={write:t=>this._emit(e,String(t).replace(/\r?\n/g,`\r
`))},x=this._makeContext(e,f,l,{stdin:h,stdout:y,stderr:b,signal:n.signal});try{let e=await f.run(x);a=Number.isInteger(e)?e:0}catch(t){if(t&&t.code===`ECAPTURE`){b.write(`\x1b[31m${u}: ${t.message}\x1b[0m\n`),a=1;break}if(n.signal.aborted){this._emit(e,`\r
`),a=130;break}b.write(`\x1b[31m${u}: ${t.message}\x1b[0m\n`),a=1}if(n.signal.aborted){a=n.signal.reason===`CAPTURE_LIMIT`?1:130;break}if(p){let t=i(e.cwd,p.target);this.vfs.writeFile(t,g,{append:p.type===`append`})}else c||(r=g)}}finally{e.running=null,this.host.flow&&typeof this.host.flow.clearOverflow==`function`&&this.host.flow.clearOverflow()}return a}_makeContext(e,t,n,r){let{flags:a,args:o}=h(n,t.parse||{});return{argv:n,args:o,flags:a,stdin:r.stdin,stdout:r.stdout,stderr:r.stderr,signal:r.signal,env:e.env,session:e,vfs:this.vfs,host:this.host,registry:this.registry,limits:this.limits,cwd:e.cwd,resolve:t=>i(e.cwd,t),chdir:t=>{e.cwd=t},aliases:e.aliases,yield:()=>new Promise(e=>Se(()=>{this.host.flow&&this.host.flow.paused()?this.host.flow.onDrain(e):e()})),exit:t=>{e.alive=!1,e._exitCode=t||0},cols:e.cols,rows:e.rows}}_complete(e,t,n){let r=t.slice(0,n),i=r.split(/\s+/),a=i[i.length-1],o=i.length===1,s,c;if(o)s=this.registry.names().filter(e=>e.startsWith(a));else{let t=i[0];e.aliases[t]&&(t=e.aliases[t].split(/\s+/)[0]);let n=this.registry.resolve(t);if(n&&typeof n.complete==`function`&&i.length===2)try{s=(n.complete({session:e,env:e.env},a)||[]).filter(e=>e.startsWith(a))}catch{s=[]}(!s||!s.length)&&(s=this._pathCandidates(e,a))}if(!s.length)return null;if(s.length===1){c=s[0];let e=c.endsWith(`/`)?``:` `,i=r.slice(0,r.length-a.length)+c+e;return{replace:i+t.slice(n),cursor:i.length,candidates:s}}let l=Ae(s);if(l.length>a.length){let e=r.slice(0,r.length-a.length)+l;return{replace:e+t.slice(n),cursor:e.length,candidates:s}}return{candidates:s}}_pathCandidates(e,t){let n=t.includes(`/`)?t.slice(0,t.lastIndexOf(`/`)+1):``,r=t.slice(n.length),a=i(e.cwd,n||`.`),o;try{o=this.vfs.readdir(a)}catch{return[]}return o.filter(e=>e.name.startsWith(r)).map(e=>n+e.name+(e.type===`dir`?`/`:``))}};function Ae(e){if(!e.length)return``;let t=e[0];for(let n of e){for(;!n.startsWith(t);)t=t.slice(0,-1);if(!t)break}return t}let N=`nvme0n1`,P=`volumes`;function je(){return new Promise((e,t)=>{let n=indexedDB.open(`ja21-ssd`,1);n.onupgradeneeded=()=>{let e=n.result;e.objectStoreNames.contains(P)||e.createObjectStore(P)},n.onerror=()=>t(n.error||/* @__PURE__ */ Error(`ssd open failed`)),n.onsuccess=()=>e(n.result)})}async function Me(){let e=await je();try{return await new Promise((t,n)=>{let r=e.transaction(P,`readonly`).objectStore(P).get(N);r.onsuccess=()=>t(r.result||null),r.onerror=()=>n(r.error||/* @__PURE__ */ Error(`ssd read failed`))})}finally{e.close()}}async function Ne(e){let t=await je();try{await new Promise((n,r)=>{let i=t.transaction(P,`readwrite`);i.objectStore(P).put(e,N),i.oncomplete=()=>n(),i.onerror=()=>r(i.error||/* @__PURE__ */ Error(`ssd write failed`)),i.onabort=()=>r(i.error||/* @__PURE__ */ Error(`ssd write aborted`))})}finally{t.close()}}let F=.012,Pe=4141947e-27*Math.LN2;function Fe(e,t,n,r){let i=0;for(let r=1;r<n;r++){let a=n>>1;for(;i&a;a>>=1)i^=a;if(i^=a,r<i){let n=e[r];e[r]=e[i],e[i]=n;let a=t[r];t[r]=t[i],t[i]=a}}for(let i=2;i<=n;i<<=1){let a=r*2*Math.PI/i,o=Math.cos(a),s=Math.sin(a),c=i>>1;for(let r=0;r<n;r+=i){let n=1,i=0;for(let a=0;a<c;a++){let l=e[r+a],u=t[r+a],d=e[r+a+c]*n-t[r+a+c]*i,f=e[r+a+c]*i+t[r+a+c]*n;e[r+a]=l+d,t[r+a]=u+f,e[r+a+c]=l-d,t[r+a+c]=u-f;let p=n*o-i*s;i=n*s+i*o,n=p}}}if(r<0){let r=1/n;for(let i=0;i<n;i++)e[i]*=r,t[i]*=r}}function I(e,t,n,r){let i=new Float32Array(n),a=new Float32Array(n);for(let o=0;o<n;o++){let s=o*n;i.set(e.subarray(s,s+n)),a.set(t.subarray(s,s+n)),Fe(i,a,n,r),e.set(i,s),t.set(a,s)}let o=new Float32Array(n),s=new Float32Array(n);for(let i=0;i<n;i++){for(let r=0;r<n;r++)o[r]=e[r*n+i],s[r]=t[r*n+i];Fe(o,s,n,r);for(let r=0;r<n;r++)e[r*n+i]=o[r],t[r*n+i]=s[r]}}function L(e,t,n,r){let i=Math.cos(r),a=Math.sin(r),o=e[n],s=t[n];e[n]=o*i-s*a,t[n]=o*a+s*i}function R(e){let t=e>>>0;if(!t)return 0;let n=0;for(;!(t&1);)t>>>=1,n+=1;return n}function Ie(e){let t=e&255,n=0;for(;t;)n+=t&1,t>>>=1;return n}let z=[1];for(let e=1;e<=10;e++)z[e]=z[e-1]*e;function Le(e,t){if(e===0)return 1;if(e===1)return 2*t;let n=1,r=2*t;for(let i=1;i<e;i++){let e=2*t*r-2*i*n;n=r,r=e}return r}function Re(e,t){let n=Math.exp(-.5*t*t),r=0,i=0;for(let a=0;a<e.length;a++){let o=n*Le(a,t)/Math.sqrt(Math.sqrt(Math.PI)*2**a*z[a]);r+=e[a].re*o,i+=e[a].im*o}return{re:r,im:i}}function ze(e,t,n){let r=e*e+t*t,i=Math.exp(-r/2),a=[],o=1,s=0;for(let r=0;r<=10;r++){let c=-n*r*(r-1)/2,l=Math.cos(c),u=Math.sin(c),d=i/Math.sqrt(z[r]);a.push({re:d*(o*l-s*u),im:d*(o*u+s*l)});let f=o*e-s*t;s=o*t+s*e,o=f}return a}function Be(e,t,n){let r=new Float32Array(t*t),i=10/48;for(let a=0;a<t;a++){let o=-n+(a+.5)*(2*n)/t;for(let s=0;s<t;s++){let c=-n+(s+.5)*(2*n)/t,l=0;for(let t=0;t<48;t++){let n=-5+(t+.5)*i,r=Re(e,c+n),a=Re(e,c-n),s=r.re*a.re+r.im*a.im,u=r.im*a.re-r.re*a.im,d=Math.cos(2*o*n),f=Math.sin(2*o*n);l+=(s*d+u*f)*i}r[a*t+s]=l/Math.PI}}return r}function Ve(e,t,n){let r=e.length;if(r%32!=0||t.length!==6||n.length!==r)return!1;for(let n=0;n<6;n++){let i=D[n].table,a=t[n];if(!a||a.length!==r)return!1;for(let t=0;t<r;t++)if(a[t]!==i[e[t]])return!1;for(let t=0;t<r/32;t++){let n=t*32;for(let t=0;t<32;t++){let r=n+t;if(a[r]!==i[e[r]])return!1}}}for(let i=0;i<r;i++){let r=-1,a=0;for(let n=0;n<6;n++){let o=Math.abs(t[n][i]-e[i]);o>r&&(r=o,a=n)}if(n[i]!==a+1)return!1}return!0}var He=class{constructor(){this.n=64,this.pitch=8e-6,this.lambda=532e-9,this.z=0,this.op=`idle`,this.gateLabel=``,this.bit=null,this.detector=0,this.nmse=null,this.frames=[],this.re=/* @__PURE__ */ new Float32Array(4096),this.im=/* @__PURE__ */ new Float32Array(4096),this._resetLedger(),this.pattern(`aperture`)}_resetLedger(){this.cycles=0,this.stage=`idle`,this.info=0,this.moved=0,this.logical1=0,this.erased=0,this.landauer=0,this.sampleUs=0,this.stepUs=0,this.padic=0,this.margin=0,this.bloch=[0,0,1],this.purity=1,this.gifRam=null,this.ramI=null,this.wigner=null,this.wignerN=0,this.wMin=0,this.wNeg=0,this.gifAlpha=0,this.gifChi=0,this.gifNbar=0,this.orderR=0,this.penteract=null,this.recorded=``,this.objectRe=null,this.objectIm=null,this.fidelity=null,this.macOps=0,this.oamValue=null,this.oamBits=``,this.oamCharge=0,this.oamRem=0,this.oamOverflow=0,this.byteStages=null,this.byteWritten=0,this.byteRoute=null,this.byteLanes=null}clear(){this.re.fill(0),this.im.fill(0)}pattern(e){let t=e||`aperture`;if(![`aperture`,`grating`,`vortex`,`twin`].includes(t))throw Error(`unknown pattern ${t}`);this.clear(),this.wigner=null,this.recorded=``,this.objectRe=null,this.objectIm=null,this.fidelity=null,this.oamValue=null,this.oamBits=``,this.byteStages=null,this.byteWritten=0,this.byteRoute=null,this.byteLanes=null,this.z=0,this.nmse=null,this.gateLabel=``,this.bit=null;let n=this.n,r=n>>1,i=(e,t,r,i)=>{let a=Math.cos(i),o=Math.sin(i);for(let i=0;i<n;i++)for(let s=0;s<n;s++){let c=s-e,l=i-t;if(c*c+l*l<=r*r){let e=i*n+s;this.re[e]=a,this.im[e]=o}}};if(e===`grating`)for(let e=0;e<n;e++)for(let t=0;t<n;t++)(t&3)<2&&(this.re[e*n+t]=1);else if(e===`vortex`)for(let e=0;e<n;e++)for(let t=0;t<n;t++){let i=t-r,a=e-r,o=Math.hypot(i,a);if(o<18&&o>2){let r=Math.exp(-((o-10)**2)/40),s=Math.atan2(a,i),c=e*n+t;this.re[c]=r*Math.cos(s),this.im[c]=r*Math.sin(s)}}else e===`twin`?(i(22,r,6,0),i(42,r,6,0)):i(r,r,10,0);return this.op=t,t}lens(e){let t=this.n,n=t>>1,r=2*Math.PI/this.lambda;for(let i=0;i<t;i++)for(let a=0;a<t;a++){let o=(a-n)*this.pitch,s=(i-n)*this.pitch;L(this.re,this.im,i*t+a,-r*(o*o+s*s)/(2*e))}}_steer(e,t){let n=this.n,r=n>>1,i=2*Math.PI/this.lambda*((r-e)*this.pitch)*this.pitch/t;for(let t=0;t<n;t++)for(let a=0;a<n;a++){let o=a-e,s=t-r;o*o+s*s>36||L(this.re,this.im,t*n+a,i*o)}}propagate(e){this.wigner=null;let t=this.n;I(this.re,this.im,t,1);let n=2*Math.PI/this.lambda,r=1/(t*this.pitch);for(let i=0;i<t;i++){let a=(i<=t/2?i:i-t)*r;for(let o=0;o<t;o++){let s=(o<=t/2?o:o-t)*r,c=n*n-4*Math.PI*Math.PI*(s*s+a*a),l=i*t+o;c<=0?(this.re[l]=0,this.im[l]=0):L(this.re,this.im,l,e*Math.sqrt(c))}}I(this.re,this.im,t,-1),this.z+=e,this.op=`prop ${(this.z*1e3).toFixed(2)} mm`}intensity(){let e=new Float32Array(this.re.length);for(let t=0;t<e.length;t++)e[t]=this.re[t]*this.re[t]+this.im[t]*this.im[t];return e}gerchberg(e,t){let n=this.n,r=new Float32Array(n*n),i=n>>1,a=(e,t,i,a)=>{for(let o=0;o<n;o++)for(let s=0;s<n;s++){let c=s-e,l=o-t;c*c+l*l<=i*i&&(r[o*n+s]=a)}};if(e===`bar`)for(let e=28;e<=36;e++)for(let t=12;t<=52;t++)r[e*n+t]=1;else if(e===`ring`)for(let e=0;e<n;e++)for(let t=0;t<n;t++){let a=Math.hypot(t-i,e-i);a>12&&a<16&&(r[e*n+t]=1)}else e=`spots`,a(20,32,4,1),a(44,32,4,1);let o=0;for(let e=0;e<r.length;e++)o+=r[e]*r[e];this.pattern(`aperture`),this.lens(F);let s=Float32Array.from(this.re),c=Float32Array.from(this.im),l=new Float32Array(n*n);for(let e=0;e<l.length;e++)l[e]=Math.hypot(s[e],c[e]);let u=Math.max(1,Math.min(40,t|0));for(let e=0;e<u;e++)this.propagate(F),this._swapAmp(r),this.propagate(-.012),this._swapAmp(l);this.propagate(F);let d=this.intensity(),f=0;for(let e=0;e<d.length;e++)f+=d[e];let p=o>0&&f>0?Math.sqrt(o/f):1,m=0;for(let e=0;e<d.length;e++){let t=p*Math.sqrt(d[e])-r[e];m+=t*t}return this.nmse=o>0?m/o:0,this.op=`gs ${e} ×${u}`,this.z=F,{target:e,iters:u,nmse:this.nmse}}_swapAmp(e){for(let t=0;t<this.re.length;t++){let n=Math.hypot(this.re[t],this.im[t])||1,r=e[t]/n;this.re[t]*=r,this.im[t]*=r}}gate(e,t,n){this.wigner=null;let r=String(e||``).toLowerCase();if(![`and`,`or`,`nand`,`xor`,`xnor`].includes(r))throw Error(`gate must be and, or, nand, xor, or xnor`);let i=Number(t),a=Number(n);if(i!==0&&i!==1||a!==0&&a!==1)throw Error(`gate bits must be 0 or 1`);this.clear();let o=this.n,s=o>>1,c=(e,t)=>{for(let n=0;n<o;n++)for(let r=0;r<o;r++){let i=r-e,a=n-s;if(i*i+a*a<=36){let e=n*o+r;this.re[e]=Math.cos(t),this.im[e]=Math.sin(t)}}},l=r===`xor`||r===`xnor`;i&&c(22,0),a&&c(42,l?Math.PI:0),i&&this._steer(22,F),a&&this._steer(42,F),this.propagate(F);let u=s*o+s,d=this.re[u]*this.re[u]+this.im[u]*this.im[u];this.detector=d;let f;if(l){let e=d>.4;f=r===`xor`?+!!e:+!e}else f=r===`or`?+(d>.4):d>2.5?r===`nand`?0:1:+(r===`nand`);return this.gateLabel=`${r.toUpperCase()} ${i}${a}`,this.bit=f,this.op=`gate ${this.gateLabel}`,{op:r,a:i,b:a,bit:f,detector:d,differential:l}}sample(){let e=performance.now(),t=this._intensityBytes(),n=t.length,r=this.gifRam,i=0,a=0,o=0,s=0,c=0;for(let e=0;e<n;e++){let n=t[e];i+=Ie(n^(r?r[e]:0));let l=n/255,u=l-(1-l);u<0&&(a+=1),o+=Math.abs(u),n&&(s+=R(n),c+=1)}let l=this.intensity(),u=0;for(let e=0;e<n;e++)u+=l[e];let d=u/n||0,f=0,p=0,m=0,h=0;for(let e=0;e<n;e++){if(l[e]<=d)continue;f+=1;let t=Math.atan2(this.im[e],this.re[e]);p+=Math.cos(t)*l[e],m+=Math.sin(t)*l[e],h+=l[e]}let g=1-a/n*2,_=h>0?Math.hypot(p,m)/h:0,v=Math.sqrt(Math.max(0,1-g*g))*Math.min(1,_),y=Math.atan2(m,p),b=v*Math.cos(y),x=v*Math.sin(y);return this.gifRam=t,this.ramI=l,this.erased=i,this.landauer+=i*Pe,this.logical1=a,this.info=f,this.padic=c?s/c:0,this.margin=o/n,this.bloch=[b,x,g],this.purity=.5*(1+b*b+x*x+g*g),this.sampleUs=(performance.now()-e)*1e3,this.stage=`sample`,this._report()}relocate(){let e=this.n,t=this.ramI||this.intensity(),n=0;for(let e=0;e<t.length;e++)n+=t[e];let r=n/t.length||0,i=new Uint8Array(e*e);i.fill(1);let a=[];for(let n=1;n<e-1;n++)for(let o=1;o<e-1;o++){let s=n*e+o;if(t[s]<=r)continue;let c=t[s+1]-t[s-1],l=t[s+e]-t[s-e];if(c===0&&l===0)continue;let u=o,d=n;Math.abs(c)>=Math.abs(l)?u+=c>0?-1:1:d+=l>0?-1:1,i[s]=0,a.push({to:d*e+u,re:this.re[s],im:this.im[s]})}let o=new Float32Array(e*e),s=new Float32Array(e*e);for(let e=0;e<i.length;e++)i[e]&&(o[e]=this.re[e],s[e]=this.im[e]);for(let e of a)o[e.to]+=e.re,s[e.to]+=e.im;return this.re=o,this.im=s,this.moved=a.length,this.stage=`relocate`,this.ramI=null,a.length}cycle(e){this.wigner=null;let t=Math.max(1,Math.min(8,e|0||1)),n=performance.now();for(let e=0;e<t;e++)this.stage=`project`,this.stage=`evolve`,this.propagate(6e-4),this.sample(),this.relocate(),this.spool(),this.stage=`reproject`,this.cycles+=1;return this.sampleUs=(performance.now()-n)*1e3/t,this.stepUs=this.sampleUs,this.op=`cycle ${this.cycles}`,this._report()}diffuse(e){this.wigner=null;let t=Math.max(1,Math.min(16,e|0||1));for(let e=0;e<t;e++)this.stage=`project`,this.sample(),this.relocate(),this.cycles+=1;return this.spool(),this.stage=`diffuse`,this.op=`diffuse ${this.cycles}`,this._report()}frame(){let e=this._mode(),t=0,n=0;for(let r=0;r<e.g.length;r++){let i=this.re[r]-e.re*e.g[r],a=this.im[r]-e.im*e.g[r];t+=i*i+a*a,n+=this.re[r]*this.re[r]+this.im[r]*this.im[r]}let r=n>1e-12?t/n:0,i=Math.min(.55,r*.9),a=Math.sqrt(Math.min(r,2.4)*1.6),o=Math.atan2(e.im,e.re),s=Be(ze(a*Math.cos(o),a*Math.sin(o),i),40,3.6),c=0,l=0,u=0;for(let e=0;e<s.length;e++)s[e]<c&&(c=s[e]),s[e]>l&&(l=s[e]),s[e]<-1e-4&&(u+=1);let d=Array.from(s,e=>Math.abs(e)).sort((e,t)=>e-t),f=Math.max(d[Math.floor(d.length*.86)]||0,1e-6),p=new Uint8Array(s.length);for(let e=0;e<s.length;e++)p[e]=Math.max(0,Math.min(255,Math.round(128+127*s[e]/f)));return this.wigner=p,this.wignerN=40,this.wMin=c,this.wNeg=u/s.length,this.gifAlpha=Math.hypot(e.re,e.im),this.gifChi=i,this.gifNbar=r,this.penteract=this._penteract(),this.stage=`frame`,this.op=i<.02?`gif vacuum`:`gif χ ${i.toFixed(2)}`,{alpha:this.gifAlpha,chi:i,nbar:r,wMin:c,neg:this.wNeg,order:this.orderR,penteract:this.penteract}}kuramoto(e){let t=Math.max(1,Math.min(12,e|0||1)),n=this.n,r=this._intensityBytes();for(let e=0;e<t;e++){let e=/* @__PURE__ */ new Map;for(let t=0;t<r.length;t++){if(this.re[t]===0&&this.im[t]===0)continue;let n=r[t]?R(r[t]):8,i=e.get(n);i||(i=[],e.set(n,i)),i.push(t)}let t=new Float32Array(r.length);for(let r of e.values()){if(r.length<2)continue;let e=0,i=0,a=new Float32Array(r.length);for(let t=0;t<r.length;t++)a[t]=Math.atan2(this.im[r[t]],this.re[r[t]]),e+=Math.cos(a[t]),i+=Math.sin(a[t]);e/=r.length,i/=r.length;for(let o=0;o<r.length;o++){let s=r[o],c=s%n,l=s/n|0;t[s]=((c*3+l*5)%7-3)*.04+.9*(i*Math.cos(a[o])-e*Math.sin(a[o]))}}for(let e=0;e<t.length;e++)t[e]&&L(this.re,this.im,e,t[e])}let i=0,a=0,o=0;for(let e=0;e<this.re.length;e++){let t=Math.hypot(this.re[e],this.im[e]);if(t<1e-6)continue;let n=Math.atan2(this.im[e],this.re[e]);i+=Math.cos(n)*t,a+=Math.sin(n)*t,o+=t}this.orderR=o>0?Math.hypot(i,a)/o:0;let s=this.frame();return this.stage=`kuramoto`,this.op=`kuramoto R ${this.orderR.toFixed(2)}`,{steps:t,order:this.orderR,...s}}_mode(){let e=this.n,t=(e-1)/2,n=e/7,r=new Float32Array(e*e),i=0;for(let a=0;a<e;a++)for(let o=0;o<e;o++){let s=Math.exp(-((o-t)**2+(a-t)**2)/(2*n*n));r[a*e+o]=s,i+=s*s}let a=Math.sqrt(i)||1,o=0,s=0;for(let e=0;e<r.length;e++)r[e]/=a,o+=this.re[e]*r[e],s+=this.im[e]*r[e];return{g:r,re:o,im:s}}_penteract(){let e=this.n,t=this.intensity(),n=this._intensityBytes(),r=0,i=0,a=0,o=0,s=0;for(let c=0;c<e;c++)for(let l=0;l<e;l++){let u=c*e+l;r+=l*t[u],i+=c*t[u],a+=t[u],n[u]&&(o+=R(n[u]),s+=1)}return{x:a>0?r/a:e/2,y:a>0?i/a:e/2,z:this.z*1e3,t:this.frames.length,p:s?o/s:0}}record(e){let t=this.pattern(e||`aperture`),n=this.n;this.objectRe=Float32Array.from(this.re),this.objectIm=Float32Array.from(this.im);let r=1e-6;for(let e=0;e<n*n;e++){let t=Math.hypot(this.objectRe[e],this.objectIm[e]);t>r&&(r=t)}let i=2*Math.PI/4;for(let e=0;e<n;e++)for(let t=0;t<n;t++){let a=e*n+t,o=this.objectRe[a]+r*Math.cos(i*t),s=this.objectIm[a]+r*Math.sin(i*t);this.re[a]=o*o+s*s,this.im[a]=0}return this.recorded=t,this.fidelity=null,this.macOps=0,this.wigner=null,this.stage=`record`,this.op=`record ${t}`,{name:t}}replay(){if(!this.recorded||!this.objectRe)return null;let e=this.n,t=2*Math.PI/4,n=new Float32Array(e*e),r=new Float32Array(e*e),i=0;for(let a=0;a<e;a++)for(let o=0;o<e;o++){let s=a*e+o,c=this.re[s];n[s]=c*Math.cos(t*o),r[s]=c*Math.sin(t*o),i+=1}I(n,r,e,1);for(let t=0;t<e;t++){let i=t<=e/2?t:t-e;for(let a=0;a<e;a++){let o=a<=e/2?a:a-e;if(Math.abs(o)>10||Math.abs(i)>10){let i=t*e+a;n[i]=0,r[i]=0}}}I(n,r,e,-1);let a=0,o=0,s=0,c=0;for(let e=0;e<n.length;e++)a+=this.objectRe[e]*n[e]+this.objectIm[e]*r[e],o+=this.objectRe[e]*r[e]-this.objectIm[e]*n[e],s+=this.objectRe[e]*this.objectRe[e]+this.objectIm[e]*this.objectIm[e],c+=n[e]*n[e]+r[e]*r[e];return this.re=n,this.im=r,this.fidelity=s>0&&c>0?(a*a+o*o)/(s*c):0,this.macOps=i,this.wigner=null,this.z=0,this.stage=`replay`,this.op=`replay ${this.recorded}`,{name:this.recorded,fidelity:this.fidelity,macOps:i}}oam(e){let t=this.n,n=Math.max(0,Math.min(255,e|0));this.clear(),this.wigner=null,this.z=0;for(let e=0;e<8;e++){if(!(n>>e&1))continue;let r=t-4-e*8,i=t>>1;for(let e=i-4;e<=i+4;e++)for(let n=r-4;n<=r+4;n++){let a=n-r,o=e-i,s=Math.hypot(a,o);if(s<1.3||s>3.3)continue;let c=Math.atan2(o,a),l=e*t+n;this.re[l]=Math.cos(c),this.im[l]=Math.sin(c)}}let r=this._readOam();return this.oamValue=r.value,this.oamBits=r.bits,this.oamCharge=r.charge,this.oamRem=0,this.oamOverflow=0,this.stage=`oam`,this.op=`oam ${r.value}`,r}shift(e,t){if(this.oamValue==null)return null;let n=this.n,r=Math.max(1,Math.min(7,t|0||1)),i=e<0?-1:1,a=this.oamValue,o=0,s=0;for(let e=0;e<r;e++){let t=Float32Array.from(this.re),r=Float32Array.from(this.im);this.re.fill(0),this.im.fill(0);for(let a=0;a<8;a++){let c=a+i;if(c<0||c>7){let c=(7-a)*8,l=0;for(let e=0;e<n;e++)for(let i=0;i<8;i++){let a=e*n+c+i;l+=t[a]*t[a]+r[a]*r[a]}l>2&&(i>0?s=1:o|=1<<e);continue}let l=(7-a)*8,u=(7-c)*8;for(let e=0;e<n;e++)for(let i=0;i<8;i++)this.re[e*n+u+i]=t[e*n+l+i],this.im[e*n+u+i]=r[e*n+l+i]}}let c=this._readOam();return this.oamValue=c.value,this.oamBits=c.bits,this.oamCharge=c.charge,this.oamRem=o,this.oamOverflow=s,this.wigner=null,this.stage=`oam`,this.op=i>0?`×${1<<r}`:`÷${1<<r}`,{before:a,...c,rem:o,overflow:s,k:r,sign:i}}_readOam(){let e=this.n,t=0,n=0,r=0,i=[];for(let a=0;a<8;a++){let o=e-4-a*8,s=e>>1,c=0;for(let t=s-4;t<=s+4;t++)for(let n=o-4;n<=o+4;n++){let r=t*e+n;c+=this.re[r]*this.re[r]+this.im[r]*this.im[r]}let l=+(c>2);i.push(l),l&&(t|=1<<a,n+=this._winding(o,s),r+=1)}let a=i.reverse().join(``);return{value:t,bits:a,charge:r?Math.round(n/r):0}}_winding(e,t){let n=this.n,r=2.2,i=0,a=null;for(let o=0;o<=24;o++){let s=o/24*Math.PI*2,c=Math.round(e+r*Math.cos(s)),l=Math.round(t+r*Math.sin(s)),u=Math.atan2(this.im[l*n+c],this.re[l*n+c]);if(a!=null){let e=u-a;e>Math.PI&&(e-=Math.PI*2),e<-Math.PI&&(e+=Math.PI*2),i+=e}a=u}return i/(Math.PI*2)}bytes(){this.sample();let e=this.gifRam;if(!e||e.length%32!=0)throw Error(`RAM sample is not a whole number of GPU warps`);let t=[],n=[];for(let r of D){let i=new Uint8Array(e.length),a=new Uint8Array(e.length),o=0;for(let t=0;t<e.length;t++){let n=e[t],a=r.table[n];i[t]=a,a!==n&&(o+=1)}let s=e.length/32;for(let t=0;t<s;t++){let n=t*32;for(let t=0;t<32;t++){let i=n+t;a[i]=r.table[e[i]]}}let c=!0;for(let t=0;t<e.length;t++)i[t]!==a[t]&&(c=!1);if(!c)throw Error(`${r.name} CPU and GPU lanes diverged`);t.push(i);let l=``;for(let e=0;e<n.length;e++){let t=D[e].table,n=!0;for(let e=0;e<256;e++)if(t[e]!==r.table[e]){n=!1;break}if(n){l=D[e].name;break}}n.push({id:r.id,name:r.name,changed:o,unique:r.unique,owned:0,same:l,cpuCycles:e.length*4,gpuWarps:s,equivalent:c})}let r=new Uint8Array(e.length),i=new Uint8Array(e.length),a=/* @__PURE__ */ new Set,o=0;for(let s=0;s<e.length;s++){let c=e[s],l=-1,u=0;for(let e=0;e<t.length;e++){let n=Math.abs(t[e][s]-c);n>l&&(l=n,u=e)}r[s]=u+1,i[s]=t[u][s],n[u].owned+=1,i[s]!==c&&(o+=1),a.add(i[s])}n.push({id:`processor-7`,name:`Processor 7`,changed:o,unique:a.size,owned:e.length,same:``,equivalent:!0});let s=0;for(let e=0;e<i.length;e++){let t=Math.hypot(this.re[e],this.im[e]);if(!(t>=1e-6))continue;let n=i[e]/255*Math.PI*2-Math.PI;this.re[e]=t*Math.cos(n),this.im[e]=t*Math.sin(n),s+=1}return this.byteStages=n,this.byteWritten=s,this.byteRoute=r,this.byteLanes=t,this.wigner=null,this.stage=`bytes`,this.op=`byte chip`,{written:s,stages:n}}tiffPlane(e){let t=this.n*this.n,n=new Uint16Array(t);if(e===7){let e=this.byteRoute;if(!e)return null;for(let r=0;r<t;r++){let t=e[r];n[r]=t<<8|t}}else{let r=this.byteLanes&&this.byteLanes[e-1];if(!r)return null;for(let e=0;e<t;e++)n[e]=r[e]*257}return Ue(this.n,this.n,n)}_report(){return{cycles:this.cycles,stage:this.stage,info:this.info,moved:this.moved,logical1:this.logical1,logical0:this.n*this.n-this.logical1,erased:this.erased,landauer:this.landauer,sampleUs:this.sampleUs,stepUs:this.stepUs,padic:this.padic,margin:this.margin,bloch:this.bloch,purity:this.purity,zMm:this.z*1e3}}spool(){let e=this._intensityBytes();return this.frames.push(e),this.frames.length>24&&this.frames.shift(),this.frames.length}resetSpool(){this.frames=[]}phaseBytes(){let e=this.n,t=new Uint16Array(e*e);for(let e=0;e<t.length;e++){let n=Math.atan2(this.im[e],this.re[e]);t[e]=Math.max(0,Math.min(65535,Math.round((n+Math.PI)/(2*Math.PI)*65535)))}return t}_intensityBytes(){let e=this.intensity(),t=1e-12;for(let n=0;n<e.length;n++)e[n]>t&&(t=e[n]);let n=new Uint8Array(e.length);for(let r=0;r<e.length;r++)n[r]=Math.max(0,Math.min(255,Math.round(255*e[r]/t)));return n}preview(){let e=this.n,t=new Uint8Array(e*e),n=this._intensityBytes();for(let e=0;e<t.length;e++){let n=Math.atan2(this.im[e],this.re[e]);t[e]=Math.round((n+Math.PI)/(2*Math.PI)*255)}return{n:e,phase:Array.from(t),intensity:Array.from(n),zMm:this.z*1e3,lambdaNm:this.lambda*1e9,pitchUm:this.pitch*1e6,op:this.op,gate:this.gateLabel,bit:this.bit,detector:this.detector,frames:this.frames.length,nmse:this.nmse,cycles:this.cycles,stage:this.stage,info:this.info,moved:this.moved,logical1:this.logical1,erased:this.erased,landauerJ:this.landauer,sampleUs:this.sampleUs,padic:this.padic,margin:this.margin,bloch:this.bloch,purity:this.purity,wigner:this.wigner?Array.from(this.wigner):null,wignerN:this.wignerN,wMin:this.wMin,wNeg:this.wNeg,gifAlpha:this.gifAlpha,gifChi:this.gifChi,gifNbar:this.gifNbar,orderR:this.orderR,penteract:this.penteract,recorded:this.recorded,fidelity:this.fidelity,macOps:this.macOps,oamValue:this.oamValue,oamBits:this.oamBits,oamCharge:this.oamCharge,oamRem:this.oamRem,oamOverflow:this.oamOverflow,byteStages:this.byteStages,byteWritten:this.byteWritten,route:this.stage===`bytes`&&this.byteRoute?Array.from(this.byteRoute,e=>e*42):null}}tiff(){return Ue(this.n,this.n,this.phaseBytes())}gif(){let e=this.frames.length?this.frames:[this._intensityBytes()];return Ge(this.n,this.n,e)}save(){let e=this.n,t=this.frames,n=new TextEncoder,r=n.encode(this.op).subarray(0,16),i=0,a=[];if(this.byteRoute&&this.byteLanes&&this.byteStages&&this.byteStages.length===7){for(let e of this.byteStages)a.push({owned:e.owned>>>0,changed:e.changed>>>0,unique:e.unique&65535,name:n.encode(String(e.name||``)).subarray(0,24),same:n.encode(String(e.same||``)).subarray(0,24)});i=8;for(let e of a)i+=12+e.name.length+e.same.length;i+=e*e*7,this.gifRam&&this.gifRam.length===e*e&&(i+=e*e)}let o=32+e*e*8+t.length*e*e+i,s=new Uint8Array(o),c=new DataView(s.buffer);c.setUint32(0,1213224241,!0),c.setUint32(4,e,!0),c.setFloat32(8,this.z,!0),c.setUint32(12,t.length,!0);let l=32;new Uint8Array(s.buffer,l,e*e*4).set(new Uint8Array(this.re.buffer)),l+=e*e*4,new Uint8Array(s.buffer,l,e*e*4).set(new Uint8Array(this.im.buffer)),l+=e*e*4;for(let e of t)s.set(e,l),l+=e.length;if(s.set(r,16),i){c.setUint32(l,1111053367,!0),c.setUint32(l+4,this.byteWritten>>>0,!0),l+=8;for(let e of a)c.setUint32(l,e.owned,!0),c.setUint32(l+4,e.changed,!0),c.setUint16(l+8,e.unique,!0),l+=10,s[l++]=e.name.length,s.set(e.name,l),l+=e.name.length,s[l++]=e.same.length,s.set(e.same,l),l+=e.same.length;s.set(this.byteRoute,l),l+=this.byteRoute.length;for(let e of this.byteLanes)s.set(e,l),l+=e.length;this.gifRam&&this.gifRam.length===e*e&&s.set(this.gifRam,l)}return s}load(e){let t=e instanceof Uint8Array?e:new Uint8Array(e);if(t.byteLength<32)return!1;let n=new DataView(t.buffer,t.byteOffset,t.byteLength);if(n.getUint32(0,!0)!==1213224241)return!1;let r=n.getUint32(4,!0);if(r!==this.n)return!1;this.z=n.getFloat32(8,!0),Number.isFinite(this.z)||(this.z=0);let i=n.getUint32(12,!0);if(i>24)return!1;let a=32,o=a+r*r*8+i*r*r;if(t.byteLength<o)return!1;this.re=new Float32Array(t.slice(a,a+r*r*4).buffer),a+=r*r*4,this.im=new Float32Array(t.slice(a,a+r*r*4).buffer),a+=r*r*4,this.frames=[];for(let e=0;e<i;e++)this.frames.push(t.slice(a,a+r*r)),a+=r*r;this.op=new TextDecoder().decode(t.subarray(16,32)).replace(/\0/g,``)||`restored`;for(let e=0;e<this.re.length;e++)Number.isFinite(this.re[e])||(this.re[e]=0),Number.isFinite(this.im[e])||(this.im[e]=0);if(this.byteRoute=null,this.byteLanes=null,this.byteStages=null,this.byteWritten=0,a+8<=t.byteLength&&n.getUint32(a,!0)===1111053367){let e=t.byteLength,i=a+4,o=n.getUint32(i,!0);i+=4;let s=[],c=!0;for(let r=0;r<7&&c;r++){if(i+11>e){c=!1;break}let a=n.getUint32(i,!0),o=n.getUint32(i+4,!0),l=n.getUint16(i+8,!0);i+=10;let u=t[i++];if(u>24||i+u+1>e){c=!1;break}let d=new TextDecoder().decode(t.subarray(i,i+u));i+=u;let f=t[i++];if(f>24||i+f>e){c=!1;break}let p=new TextDecoder().decode(t.subarray(i,i+f));i+=f,s.push({id:`processor-${r+1}`,name:d,changed:o,unique:l,owned:a,same:p})}let l=r*r;if(!c||i+l*7>e)this.byteStages=null;else{let n=t.slice(i,i+l);i+=l;let r=!0;for(let e=0;e<n.length;e++)(n[e]<1||n[e]>6)&&(r=!1);let a=[];for(let e=0;e<6;e++)a.push(t.slice(i,i+l)),i+=l;if(r&&i+l<=e&&Ve(t.subarray(i,i+l),a,n)){this.byteRoute=n,this.byteLanes=a,this.byteStages=s,this.byteWritten=o,this.gifRam=t.slice(i,i+l),this.stage=`bytes`;for(let e of s)e.id===`processor-7`||(e.cpuCycles=l*4,e.gpuWarps=l/32),e.equivalent=!0}else r&&i===e&&(this.byteRoute=n,this.byteLanes=a,this.byteStages=s,this.byteWritten=o,this.stage=`bytes`)}}return!0}};function Ue(e,t,n){let r=[[256,4,1,e],[257,4,1,t],[258,3,1,16],[259,3,1,1],[262,3,1,1],[273,4,1,0],[277,3,1,1],[278,4,1,t],[279,4,1,e*t*2],[282,5,1,0],[283,5,1,0],[296,3,1,2]],i=r.length,a=8+(2+i*12+4),o=a+8,s=o+8,c=new Uint8Array(s+e*t*2),l=new DataView(c.buffer);l.setUint16(0,18761,!0),l.setUint16(2,42,!0),l.setUint32(4,8,!0),l.setUint16(8,i,!0),r[5][3]=s,r[9][3]=a,r[10][3]=o;let u=10;for(let[e,t,n,i]of r)l.setUint16(u,e,!0),l.setUint16(u+2,t,!0),l.setUint32(u+4,n,!0),t===3?l.setUint16(u+8,i,!0):l.setUint32(u+8,i,!0),u+=12;l.setUint32(u,0,!0),l.setUint32(a,3175,!0),l.setUint32(a+4,1,!0),l.setUint32(o,3175,!0),l.setUint32(o+4,1,!0);for(let e=0;e<n.length;e++)l.setUint16(s+e*2,n[e],!0);return c}function We(e){let t=9,n=258,r=/* @__PURE__ */ new Map,i=[],a=0,o=0,s=e=>{for(a+=e*2**o,o+=t;o>=8;)i.push(a&255),a=Math.floor(a/256),o-=8},c=()=>{r.clear(),t=9,n=258};c(),s(256);let l=e[0];for(let i=1;i<e.length;i++){let a=e[i],o=l*512+a,u=r.get(o);u===void 0?(s(l),n<4096?(r.set(o,n),n+=1,n===(1<<t)+1&&t<12&&(t+=1)):(s(256),c()),l=a):l=u}return s(l),s(257),o&&i.push(a&255),i}function Ge(e,t,n){let r=[],i=(...e)=>r.push(...e);i(71,73,70,56,57,97),i(e&255,e>>8,t&255,t>>8,247,0,0);for(let e=0;e<256;e++)i(e,e,e);i(33,255,11);for(let e of`NETSCAPE2.0`)i(e.charCodeAt(0));i(3,1,0,0,0);for(let r of n){i(33,249,4,4,10,0,0,0),i(44,0,0,0,0,e&255,e>>8,t&255,t>>8,0);let n=We(r);i(8);let a=0;for(;a<n.length;){let e=Math.min(255,n.length-a);i(e);for(let t=0;t<e;t++)i(n[a+t]);a+=e}i(0)}return i(59),Uint8Array.from(r)}let B=`hermit.vws.v2`;function Ke(e,t,n){let r=n instanceof Uint8Array?n:new Uint8Array(n),i=new Uint8Array(7+r.length);i[0]=e;let a=t;for(let e=6;e>=1;e--)i[e]=a&255,a=Math.floor(a/256);return i.set(r,7),i}function qe(e){let t=e instanceof Uint8Array?e:new Uint8Array(e);if(t.length<8)throw Error(`short data frame`);let n=0;for(let e=1;e<=6;e++)n=n*256+t[e];return{kind:t[0],seq:n,payload:t.subarray(7)}}let V=`2.0.0-ramws.1`,H=`LOCAL_SSD`,Je=262144,Ye=new TextEncoder,Xe=Date.now(),U=null,W=null,G=``,Ze=``,K=!1,q=/* @__PURE__ */ new Map,J={device:N,model:`JA21 NVMe`,fs:`ssd`,mount:`/`,synced:!1,restored:!1,writtenAt:0,error:``},Y=0,X=0,Z=null;function Qe(e){return new TextEncoder().encode(e)}async function $e(e){let t=await crypto.subtle.digest(`SHA-256`,Qe(e));return[...new Uint8Array(t)].map(e=>e.toString(16).padStart(2,`0`)).join(``)}function et(e){e.vfs.mkdir(`/usr/share/doc`,{recursive:!0}),e.vfs.mkdir(`/df/nodes`,{recursive:!0}),e.vfs.writeFile(`/etc/os-release`,[`NAME=JA21 SSD Server`,`ID=ja21`,`VERSION=2.0.0-ramws.1`,`CONSOLE=1.4.0`,`PRESENTER=9.8.7`,`VT=HERMIT`,`PROTOCOL=hermit.vws.v2`,`PROFILE=LOCAL_SSD`,`STORAGE=nvme0n1`,``].join(`
`)),e.vfs.writeFile(`/etc/ja21-console.json`,JSON.stringify({start_url:`about:blank`,local_origins:[`http://127.0.0.1:8788`,`http://127.0.0.1:8791`,`ram://status`],mode:`blank-console`},null,2)+`
`),e.vfs.writeFile(`/etc/boot-image.note`,"The factory measurement lives in the boot controller, not in this file.\nRun `image` and `image verify`.\n"),e.vfs.writeFile(`/home/operator/README`,[`JA21 console, HERMIT terminal, SPIRAL backend.`,`This tree is the root filesystem on nvme0n1.`,`Writes flush to the SSD. poweroff does not erase them.`,``,`  disk             volume status`,`  hpu gate xor 1 0 optical logic on the phase plane`,`  image verify     compare the tree to the factory seal`,`  cxl status       hot bytes vs unused quota`,`  fabric topology  four node images on this volume`,`  ls -l /etc`,`  echo hi | rev`,`  write /tmp/note hello`,``].join(`
`)),e.vfs.writeFile(`/usr/share/doc/architecture.txt`,[`The console is the JA21 blank host: a window with a local-origin policy`,`and no toolbar. It loads one guest — this SSD server — instead of a page.`,``,`The guest speaks hermit.vws.v2. Each terminal tab is its own socket.`,`Input and output are binary frames (kind, uint48 sequence, bytes).`,`The SPIRAL kernel is the machine: a filesystem flushed to nvme0n1,`,`a command registry, pipelines, and a line editor that answers in ANSI.`,``,`Power loss stops the worker. The next boot remounts the same SSD`,`volume. The sealed image is only the factory tree, not the volume.`,``].join(`
`)),e.vfs.writeFile(`/usr/share/doc/hpu.txt`,(/* @__PURE__ */ `Holographic processor. The field is a processable hologram.(Five stages close the loop: project the whole complex field,(evolve it by the band-limited angular spectrum, RAM-sample it,(relocate information-bearing pixels one step along -grad I,(and reproject that frame into the GIF spool.(The GIF gray level is the bit line. Its complement is the anti-bit.(V1-V2 > 0 reads logical 0. V1-V2 < 0 reads logical 1.(Every bit flipped in the sample buffer is charged kT ln 2.(The Bloch vector uses those populations and the mean carrier phase.(hpu frame draws the Gaussian interaction frame: the TEM00(displacement is removed, and the residual is a Kerr state whose(Wigner function can go negative. hpu kuramoto syncs phase inside(each 2-adic ball of the GIF gray, then redraws that frame.(The penteract stamp is centroid x, y, cavity z, spool time, and v2.(hpu record interferes the pattern with a 4 px reference tilt.(The interferogram stays in the field array. hpu replay multiplies(that weight by the reference in place, then drops the twin image.(hpu oam places a charge-+1 helical well for each 1-bit. The LSB(sits on the right. hpu shift left multiplies by 2. hpu shift right(divides by 2. The helix is copied, so the charge does not change.(hpu bytes samples the field into RAM. Processors 1–6 each run that(sample as a scalar CPU and as a 32-wide GPU. The TIFF is kept only(when the two lanes match. Processor 7 issues the byte that moved(farthest. Ties keep the lowest index.(ChipHarness.cs wraps the six TIFFs and writes the same seven planes.(Phase leaves as a 16-bit TIFF. Intensity leaves as GIF89a.(The live field is stored at /var/hpu/field.bin and remounts with the SSD.(That file keeps the RAM sample with the lanes. A reload proves the(CPU and GPU walks still match before it will claim they agree.((  hpu(  hpu cycle(  hpu diffuse 4(  hpu bit(  hpu gate xor 1 0(  hpu tiff(  hpu gif(`.split(`(`)).join(`
`)),e.vfs.writeFile(`/var/log/boot.log`,`boot: factory image measured
boot: block device nvme0n1 mounted
boot: virtual websocket hermit.vws.v2 listening
`);for(let t of ue)e.vfs.mkdir(`/df/nodes/${t.node}`,{recursive:!0}),e.vfs.writeFile(`/df/nodes/${t.node}/image.txt`,`${t.node}\nrole: ${t.role}\nmedium: ssd\npersistence: nvme0n1\n`)}let Q={visible:!1,url:`about:blank`,engine:`VB-JA21/9.8.7`};function tt(){postMessage({type:`browser`,payload:{...Q}})}function nt(){return{protocol:B,profile:H,epoch:G}}function rt(){Y+=1,J.synced=!1,it()}function it(){return Z||(Z=(async()=>{try{for(;U&&X!==Y;){let e=Y,t=U.vfs.usage(),n=U.vfs.exportSnapshot(),r=Date.now();await Ne({v:1,device:N,snap:n,writtenAt:r,bytes:t.bytes,nodes:t.nodes}),Y===e&&(X=e,J.synced=!0,J.writtenAt=r,J.error=``)}}catch(e){J.synced=!1,J.error=String(e&&e.message?e.message:e)}finally{Z=null,U&&X!==Y&&!J.error&&it()}})(),Z)}function at(e){if(!W)return;let t=W.preview();postMessage({type:`holo`,payload:{...t,open:!!e}})}function ot(){U&&W&&(U.vfs.mkdir(`/var/hpu`,{recursive:!0}),U.vfs.writeFile(`/var/hpu/field.bin`,n.from(W.save())),at(!0))}async function $(){if(U&&(Z&&await Z,!(X===Y&&J.synced)&&(X===Y&&(Y+=1),J.synced=!1,await it(),!J.synced)))throw Error(J.error||`ssd flush failed`)}async function st(){G=crypto.randomUUID();let e={version:()=>V,openBrowser(e){return Q.visible=!0,Q.url=ct(e||`about:blank`),tt(),{...Q}},navigateBrowser(e){return Q.url=ct(e),tt(),{...Q}},closeBrowser(){Q.visible=!1,tt()},browserState:()=>({...Q}),fabricRoster:()=>ue.map(e=>({...e,present:!0,built:!0})),profile:()=>H,disk:()=>({...J}),sync:()=>$(),afterCommand:()=>$(),async poweroff(){await $(),postMessage({type:`halt`,reason:`poweroff`})},linkInfo:nt,image:async()=>({seal:Ze,digest:await $e(JSON.stringify(U.vfs.exportSnapshot())),epoch:G,profile:H})};U=new ke({hostBridge:e,vfsLimits:{maxBytes:2097152,maxNodes:1500},limits:{historyEntries:400,captureBytes:1048576},baseEnv:{HOST:`ssd0`,USER:`operator`,PROFILE:H,CONSOLE:`JA21/1.4.0`}}),et(U),Ze=await $e(JSON.stringify(U.vfs.exportSnapshot()));try{let e=await Me();e&&e.v===1&&e.snap&&(U.vfs.importSnapshot(e.snap),K=!0,J.restored=!0,J.writtenAt=e.writtenAt||0,J.synced=!0)}catch(e){K=!1,J.error=String(e&&e.message?e.message:e)}U.vfs.onMutate=()=>rt(),K||await $(),W=new He;try{if(U.vfs.exists(`/var/hpu/field.bin`)){let e=U.vfs.readFile(`/var/hpu/field.bin`);W.load(e)||(W=new He)}}catch{W=new He}e.hpu=W,e.hpuTouch=ot,U.on(`data`,e=>{let t=q.get(e.sessionId);t&&t.emitText(e.chunk)}),U.on(`command-complete`,e=>{let t=q.get(e.sessionId);t&&(t.executedSeq=t.inSeq)}),U.on(`exit`,e=>{let t=q.get(e.sessionId);t&&!t.exited&&(t.exited=!0,t.send({v:2,type:`session.exit`,sid:e.sessionId,payload:{code:e.code|0,reason:e.reason||`closed`}}),q.delete(e.sessionId))}),postMessage({type:`ready`,epoch:G,seal:Ze,restored:K,device:N,protocol:B,version:V,startedAt:Xe}),at(!1)}function ct(e){return String(e||``).trim()||`about:blank`}function lt(e){let t={sid:null,inSeq:0,executedSeq:0,outSeq:0,credit:0,sent:0,queue:[],exited:!1,decoder:new TextDecoder(`utf-8`,{fatal:!1}),send(t){e.postMessage(JSON.stringify(t))},emitText(e){let n=Ye.encode(e);for(let e=0;e<n.length;e+=16384)t.queue.push(n.subarray(e,Math.min(n.length,e+16384)));t.pump()},pump(){for(;t.queue.length;){let n=t.queue[0];if(t.sent+n.length>t.credit)return;t.queue.shift(),t.outSeq+=1,t.sent+=n.length;let r=Ke(2,t.outSeq,n);e.postMessage(r,[r.buffer])}}};e.onmessage=e=>{let n=e.data;if(typeof n!=`string`){let e;try{e=qe(new Uint8Array(n))}catch{t.send({v:2,type:`error`,payload:{code:`BAD_MESSAGE`,message:`bad data frame`,retryable:!1}});return}if(e.kind!==1||!t.sid)return;if(e.seq!==t.inSeq+1){t.send({v:2,type:`error`,sid:t.sid,payload:{code:`BAD_SEQ`,message:`expected input ${t.inSeq+1}`,retryable:!1}});return}t.inSeq=e.seq;let r=t.decoder.decode(e.payload,{stream:!0});if(r)try{U.write(t.sid,r)}catch(e){t.send({v:2,type:`error`,sid:t.sid,payload:{code:`INPUT`,message:String(e&&e.message?e.message:e),retryable:!1}})}t.send({v:2,type:`input.ack`,sid:t.sid,payload:{acceptedSeq:t.inSeq,executedSeq:t.executedSeq}});return}let r;try{r=JSON.parse(n)}catch{return}ut(t,r)},t.send({v:2,type:`hello`,payload:{protocol:B,serverEpoch:G,profile:H,version:V,limits:{maxCreditWindowBytes:Je}}})}function ut(e,t){switch(t.type){case`session.open`:{if(e.sid)return;let n=t.payload?.cols|0,r=t.payload?.rows|0,i;try{i=U.openSession({cols:n,rows:r,deferStart:!0})}catch(n){e.send({v:2,type:`error`,rid:t.rid,payload:{code:`OPEN`,message:String(n.message||n),retryable:!0}});return}e.sid=i.sessionId,e.credit=Math.min(Je,t.payload?.creditBytes|0||Je),q.set(e.sid,e),e.send({v:2,type:`session.opened`,rid:t.rid,sid:e.sid,epoch:G,payload:{cols:i.cols,rows:i.rows,restored:!1}});return}case`session.start`:e.sid&&U.startSession(e.sid);return;case`flow.credit`:{let n=t.payload?.creditBytes|0;n>=e.credit&&(e.credit=n),e.pump();return}case`terminal.resize`:e.sid&&U.resize(e.sid,t.payload?.cols|0,t.payload?.rows|0);return;case`terminal.signal`:e.sid&&U.signal(e.sid,t.payload?.signal||`SIGINT`);return;case`session.close`:e.sid&&U.closeSession(e.sid,t.payload?.reason||`closed`);return;case`session.status`:{if(!e.sid)return;let n=U.status(e.sid);U.host.image().then(r=>{e.send({v:2,type:`session.status`,rid:t.rid,sid:e.sid,payload:{...n,seal:r.seal,digest:r.digest,drifted:r.digest!==r.seal,epoch:G,uptimeMs:Date.now()-Xe,protocol:B,version:V}})}).catch(()=>{});return}case`heartbeat.ping`:e.send({v:2,type:`heartbeat.pong`,rid:t.rid,payload:{nonce:t.payload?.nonce||``}});return;default:return}}self.onmessage=e=>{let t=e.data;t&&t.type===`holo-peek`?at(!1):t&&t.type===`attach`&&e.ports&&e.ports[0]&&lt(e.ports[0])},st().catch(e=>{postMessage({type:`error`,message:String(e&&e.message?e.message:e)})})})();