//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CGH5VLR1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DoYQe0V_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DoYQe0V_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CSig35Hj.js"]
	}
} });
//#endregion
export { tsrStartManifest };
