import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PanelRight, i as Plus, o as AppWindow, r as Power, s as Aperture, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CcjgZtaB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* VT engine — ANSI/VT parser (state machine)
* ---------------------------------------------------------------------------
* A ground/escape/CSI/OSC state machine modeled on the DEC VT500 parser. It
* decodes a byte stream into semantic operations and dispatches them to a
* terminal handler (the Screen, plus a couple of controller callbacks).
*
* Supported:
*   C0 controls           BEL BS HT LF VT FF CR
*   ESC                   7 8 D E M c H (and keypad/charset no-ops)
*   CSI                   A B C D E F G ` d H f J K L M @ P X S T r m h l s u
*   private modes         ?25 (DECTCEM cursor show/hide)
*   OSC                   0/2 ;  window title  (terminated by BEL or ST)
*   SGR                   0-9, 22-29, 30-37/40-47, 90-97/100-107,
*                         38/48 (5;n palette and 2;r;g;b truecolor), 39/49
*/
var S = {
	GROUND: 0,
	ESC: 1,
	CSI: 2,
	OSC: 3,
	DCS: 4,
	OSC_ESC: 5,
	DCS_ESC: 6,
	CSI_IGNORE: 7
};
var MAX_OSC = 4096;
var MAX_TITLE = 256;
var MAX_PARAMS = 64;
var MAX_INTERMEDIATES = 4;
var MAX_PARAM_VALUE = 65535;
var Parser = class {
	/** @param {object} term  the Screen (with optional onTitle callback) */
	constructor(term) {
		this.term = term;
		this.state = S.GROUND;
		this.params = "";
		this.intermediates = "";
		this.osc = "";
		this.oscOverflow = false;
		this.printBuf = "";
	}
	reset() {
		this.state = S.GROUND;
		this.params = this.intermediates = this.osc = this.printBuf = "";
	}
	write(data) {
		for (let i = 0; i < data.length; i++) this._byte(data[i], data.charCodeAt(i));
		this._flush();
	}
	_flush() {
		if (this.printBuf) {
			this.term.print(this.printBuf);
			this.printBuf = "";
		}
	}
	_byte(ch, code) {
		switch (this.state) {
			case S.GROUND: return this._ground(ch, code);
			case S.ESC: return this._esc(ch, code);
			case S.CSI: return this._csi(ch, code);
			case S.OSC: return this._oscState(ch, code);
			case S.DCS: return this._dcs(ch, code);
			case S.CSI_IGNORE:
				if (code === 27) {
					this.state = S.ESC;
					this.intermediates = "";
				} else if (code >= 64 && code <= 126 || code === 24 || code === 26) this.state = S.GROUND;
				return;
			case S.OSC_ESC: return this._stringEsc(ch, code, true);
			case S.DCS_ESC: return this._stringEsc(ch, code, false);
			default: return;
		}
	}
	_ground(ch, code) {
		if (code === 27) {
			this._flush();
			this.state = S.ESC;
			this.intermediates = "";
			return;
		}
		if (code === 155) {
			this._flush();
			this.state = S.CSI;
			this.params = "";
			this.intermediates = "";
			return;
		}
		if (code < 32) {
			this._flush();
			this._c0(code);
			return;
		}
		if (code === 127) return;
		this.printBuf += ch;
	}
	_c0(code) {
		const t = this.term;
		switch (code) {
			case 7:
				t.bell();
				break;
			case 8:
				t.backspace();
				break;
			case 9:
				t.tab();
				break;
			case 10:
			case 11:
			case 12:
				t.lineFeed();
				break;
			case 13: t.carriageReturn();
		}
	}
	_esc(ch, code) {
		if (code >= 32 && code <= 47) {
			if (this.intermediates.length < MAX_INTERMEDIATES) this.intermediates += ch;
			return;
		}
		switch (ch) {
			case "[":
				this.state = S.CSI;
				this.params = "";
				this.intermediates = "";
				return;
			case "]":
				this.state = S.OSC;
				this.osc = "";
				this.oscOverflow = false;
				return;
			case "P":
				this.state = S.DCS;
				return;
			case "7":
				this.term.saveCursor();
				break;
			case "8":
				this.term.restoreCursor();
				break;
			case "D":
				this.term.index();
				break;
			case "E":
				this.term.nextLine();
				break;
			case "M":
				this.term.reverseIndex();
				break;
			case "H":
				this.term.tabs && this.term.tabs.add(this.term.cursor.x);
				break;
			case "c": this.term.reset();
		}
		this.state = S.GROUND;
	}
	_csi(ch, code) {
		if (code >= 48 && code <= 63) {
			if (this.params.length >= MAX_PARAMS) {
				this.state = S.CSI_IGNORE;
				return;
			}
			this.params += ch;
			return;
		}
		if (code >= 32 && code <= 47) {
			if (this.intermediates.length < MAX_INTERMEDIATES) this.intermediates += ch;
			return;
		}
		if (code === 27) {
			this.state = S.ESC;
			this.intermediates = "";
			return;
		}
		if (code === 24 || code === 26) {
			this.state = S.GROUND;
			return;
		}
		if (code < 32) {
			this._c0(code);
			return;
		}
		if (code >= 64 && code <= 126) {
			this._dispatchCsi(ch);
			this.state = S.GROUND;
			return;
		}
		this.state = S.GROUND;
	}
	_numParams() {
		let str = this.params;
		const priv = str.startsWith("?");
		if (priv) str = str.slice(1);
		return {
			nums: (str.length ? str.split(";") : []).slice(0, 32).map((p) => p === "" ? void 0 : Math.min(MAX_PARAM_VALUE, parseInt(p, 10))),
			priv
		};
	}
	_dispatchCsi(final) {
		const t = this.term;
		const { nums, priv } = this._numParams();
		const p = (i, d) => nums[i] === void 0 || Number.isNaN(nums[i]) ? d : nums[i];
		switch (final) {
			case "A":
				t.cursorUp(p(0, 1));
				break;
			case "B":
				t.cursorDown(p(0, 1));
				break;
			case "C":
				t.cursorForward(p(0, 1));
				break;
			case "D":
				t.cursorBack(p(0, 1));
				break;
			case "E":
				t.cursorNextLine(p(0, 1));
				break;
			case "F":
				t.cursorPrevLine(p(0, 1));
				break;
			case "G":
			case "`":
				t.cursorCol(p(0, 1));
				break;
			case "d":
				t.cursorRow(p(0, 1));
				break;
			case "H":
			case "f":
				t.cursorPos(p(0, 1), p(1, 1));
				break;
			case "J":
				t.eraseInDisplay(p(0, 0));
				break;
			case "K":
				t.eraseInLine(p(0, 0));
				break;
			case "L":
				t.insertLines(p(0, 1));
				break;
			case "M":
				t.deleteLines(p(0, 1));
				break;
			case "@":
				t.insertChars(p(0, 1));
				break;
			case "P":
				t.deleteChars(p(0, 1));
				break;
			case "X":
				t.eraseChars(p(0, 1));
				break;
			case "S":
				t.scrollUp(p(0, 1));
				break;
			case "T":
				t.scrollDown(p(0, 1));
				break;
			case "r":
				t.setScrollRegion(p(0, 1), p(1, t.rows));
				break;
			case "m":
				t.setSGR(nums.map((n) => n === void 0 ? 0 : n));
				break;
			case "h":
				t.setMode(nums.filter((n) => n !== void 0), priv);
				break;
			case "l":
				t.resetMode(nums.filter((n) => n !== void 0), priv);
				break;
			case "s":
				t.saveCursor();
				break;
			case "u": t.restoreCursor();
		}
	}
	_oscState(ch, code) {
		if (code === 7) {
			this._dispatchOsc();
			this.state = S.GROUND;
			return;
		}
		if (code === 156) {
			this._dispatchOsc();
			this.state = S.GROUND;
			return;
		}
		if (code === 27) {
			this.state = S.OSC_ESC;
			return;
		}
		if (code === 24 || code === 26) {
			this.osc = "";
			this.state = S.GROUND;
			return;
		}
		if (this.osc.length >= MAX_OSC) {
			this.oscOverflow = true;
			return;
		}
		this.osc += ch;
	}
	/** After ESC inside OSC/DCS: only `ESC \\` is a String Terminator. Anything else aborts the string
	*  WITHOUT dispatching it, and the byte is processed as the start of a new escape sequence. */
	_stringEsc(ch, code, isOsc) {
		if (ch === "\\") {
			if (isOsc) this._dispatchOsc();
			this.state = S.GROUND;
			return;
		}
		this.osc = "";
		this.oscOverflow = false;
		this.state = S.ESC;
		this.intermediates = "";
		this._esc(ch, code);
	}
	_dispatchOsc() {
		const s = this.osc;
		const overflow = this.oscOverflow;
		this.osc = "";
		this.oscOverflow = false;
		if (overflow) return;
		const semi = s.indexOf(";");
		if (semi < 0) return;
		const code = s.slice(0, semi);
		const val = s.slice(semi + 1);
		if ((code === "0" || code === "2") && this.term.onTitle) this.term.onTitle(val.replace(/[\u0000-\u001f\u007f-\u009f]/g, "").slice(0, MAX_TITLE));
	}
	_dcs(ch, code) {
		if (code === 7 || code === 156 || code === 24 || code === 26) this.state = S.GROUND;
		else if (code === 27) this.state = S.DCS_ESC;
	}
};
/**
* VT engine — Canvas renderer
* ---------------------------------------------------------------------------
* Paints a Screen buffer onto a 2D canvas: background fills, glyphs with the
* bold/dim/italic/underline/strike/inverse attributes, the block cursor, and a
* scrollback viewport. Handles HiDPI via devicePixelRatio and computes the grid
* geometry (cols × rows) that fits the element.
*/
var ANSI16 = [
	"#0c0f13",
	"#ef6b73",
	"#58d6a9",
	"#e4c26a",
	"#4fb3e8",
	"#b98cf0",
	"#2fd0e4",
	"#c9d2da",
	"#4a535e",
	"#ff8189",
	"#7ee8c4",
	"#f0d48a",
	"#79c8f5",
	"#cfa9ff",
	"#7ee8f5",
	"#f2f6f9"
];
function build256() {
	const table = ANSI16.slice();
	const steps = [
		0,
		95,
		135,
		175,
		215,
		255
	];
	for (let r = 0; r < 6; r++) for (let g = 0; g < 6; g++) for (let b = 0; b < 6; b++) table.push(rgb(steps[r], steps[g], steps[b]));
	for (let i = 0; i < 24; i++) {
		const v = 8 + i * 10;
		table.push(rgb(v, v, v));
	}
	return table;
}
function rgb(r, g, b) {
	const h = (n) => n.toString(16).padStart(2, "0");
	return `#${h(r)}${h(g)}${h(b)}`;
}
var PALETTE = build256();
var DEFAULT_THEME = {
	background: "#0c0f13",
	foreground: "#dfe6ec",
	cursor: "#2fd0e4",
	cursorText: "#0c0f13",
	fontFamily: "\"Cascadia Mono\",\"JetBrains Mono\",\"SF Mono\",Menlo,Consolas,\"DejaVu Sans Mono\",monospace",
	fontSize: 14,
	lineHeight: 1.4
};
var CanvasRenderer = class {
	constructor(canvas, screen, theme = {}) {
		this.canvas = canvas;
		this.ctx = canvas.getContext("2d", { alpha: false });
		this.screen = screen;
		this.theme = {
			...DEFAULT_THEME,
			...theme
		};
		this.dpr = window.devicePixelRatio || 1;
		this.scrollOffset = 0;
		this.cursorOn = true;
		this._measure();
	}
	_measure() {
		const ctx = this.ctx;
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.font = `${this.theme.fontSize}px ${this.theme.fontFamily}`;
		const width = ctx.measureText("MMMMMMMMMM").width / 10;
		this.cellW = Math.max(1, Math.round(width * 100) / 100);
		this.cellW = Math.max(1, Math.ceil(this.cellW));
		this.cellH = Math.ceil(this.theme.fontSize * this.theme.lineHeight);
		this.baseline = Math.round(this.fontSizeBaseline());
	}
	fontSizeBaseline() {
		return this.theme.fontSize * .8 + (this.cellH - this.theme.fontSize) * .35;
	}
	/** Fit the canvas to a pixel box; returns the resulting {cols, rows}. */
	fit(pixelW, pixelH) {
		const cols = Math.max(1, Math.floor(pixelW / this.cellW));
		const rows = Math.max(1, Math.floor(pixelH / this.cellH));
		this.canvas.width = Math.floor(cols * this.cellW * this.dpr);
		this.canvas.height = Math.floor(rows * this.cellH * this.dpr);
		this.canvas.style.width = cols * this.cellW + "px";
		this.canvas.style.height = rows * this.cellH + "px";
		this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
		this.ctx.textBaseline = "alphabetic";
		return {
			cols,
			rows
		};
	}
	setTheme(patch) {
		this.theme = {
			...this.theme,
			...patch
		};
		this._measure();
	}
	maxScroll() {
		return this.screen.scrollback.length;
	}
	scrollBy(lines) {
		this.scrollOffset = Math.max(0, Math.min(this.maxScroll(), this.scrollOffset + lines));
	}
	scrollToBottom() {
		this.scrollOffset = 0;
	}
	_color(val, fallback) {
		if (val == null) return fallback;
		if (Array.isArray(val)) return rgb(val[0] | 0, val[1] | 0, val[2] | 0);
		if (typeof val === "number") return PALETTE[val] || fallback;
		return fallback;
	}
	_viewportRows() {
		const { screen } = this;
		if (this.scrollOffset <= 0) return screen.grid;
		const sb = screen.scrollback;
		const start = sb.length - this.scrollOffset;
		const fromHistory = sb.slice(start, start + screen.rows);
		if (fromHistory.length >= screen.rows) return fromHistory;
		return fromHistory.concat(screen.grid.slice(0, screen.rows - fromHistory.length));
	}
	render() {
		const ctx = this.ctx;
		const rows = this._viewportRows();
		const showCursor = this.scrollOffset === 0;
		ctx.fillStyle = this.theme.background;
		ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
		ctx.font = `${this.theme.fontSize}px ${this.theme.fontFamily}`;
		ctx.textBaseline = "alphabetic";
		for (let y = 0; y < rows.length; y++) {
			const row = rows[y];
			if (!row) continue;
			const yPix = y * this.cellH;
			for (let x = 0; x < row.length; x++) {
				const cell = row[x];
				if (!cell) continue;
				const xPix = x * this.cellW;
				let fg = this._color(cell.fg, this.theme.foreground);
				let bg = this._color(cell.bg, this.theme.background);
				if (cell.inverse) {
					const t = fg;
					fg = bg;
					bg = t;
				}
				if (cell.dim && !cell.bold) fg = this._dim(fg);
				if (bg !== this.theme.background) {
					ctx.fillStyle = bg;
					ctx.fillRect(xPix, yPix, this.cellW, this.cellH);
				}
				if (cell.hidden || cell.ch === " ") {
					this._maybeDecor(cell, xPix, yPix, fg);
					continue;
				}
				ctx.fillStyle = fg;
				let font = "";
				if (cell.italic) font += "italic ";
				if (cell.bold) font += "bold ";
				ctx.font = `${font}${this.theme.fontSize}px ${this.theme.fontFamily}`;
				ctx.fillText(cell.ch, xPix, yPix + this.baseline);
				this._maybeDecor(cell, xPix, yPix, fg);
			}
		}
		if (showCursor && this.screen.cursor.visible && this.cursorOn) this._drawCursor();
		else if (showCursor && this.screen.cursor.visible) this._drawCursorOutline();
	}
	_maybeDecor(cell, x, y, fg) {
		const ctx = this.ctx;
		if (cell.underline) {
			ctx.strokeStyle = fg;
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(x, y + this.cellH - 1.5);
			ctx.lineTo(x + this.cellW, y + this.cellH - 1.5);
			ctx.stroke();
		}
		if (cell.strike) {
			ctx.strokeStyle = fg;
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(x, y + this.cellH / 2);
			ctx.lineTo(x + this.cellW, y + this.cellH / 2);
			ctx.stroke();
		}
	}
	_drawCursor() {
		const { x, y } = this.screen.cursor;
		const xPix = x * this.cellW, yPix = y * this.cellH;
		const ctx = this.ctx;
		ctx.fillStyle = this.theme.cursor;
		ctx.fillRect(xPix, yPix, this.cellW, this.cellH);
		const cell = this.screen.grid[y] && this.screen.grid[y][x];
		if (cell && cell.ch !== " ") {
			ctx.fillStyle = this.theme.cursorText;
			ctx.font = `${this.theme.fontSize}px ${this.theme.fontFamily}`;
			ctx.fillText(cell.ch, xPix, yPix + this.baseline);
		}
	}
	_drawCursorOutline() {
		const { x, y } = this.screen.cursor;
		const ctx = this.ctx;
		ctx.strokeStyle = this.theme.cursor;
		ctx.lineWidth = 1;
		ctx.strokeRect(x * this.cellW + .5, y * this.cellH + .5, this.cellW - 1, this.cellH - 1);
	}
	_dim(hex) {
		const c = hex.replace("#", "");
		const r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16);
		return rgb(r * .6 | 0, g * .6 | 0, b * .6 | 0);
	}
	/** Translate a pixel coordinate to a grid cell (for selection). */
	cellAt(px, py) {
		return {
			x: Math.floor(px / this.cellW),
			y: Math.floor(py / this.cellH)
		};
	}
};
var MAX_COLS = 400;
var MAX_ROWS = 200;
/** Remote output controls every CSI count: clamp to the only range that can change the result. */
function clampCount(n, max) {
	n = Number(n);
	if (!Number.isFinite(n) || n < 1) n = 1;
	return Math.min(Math.floor(n), max);
}
function blankCell(pen) {
	return {
		ch: " ",
		fg: pen ? pen.fg : null,
		bg: pen ? pen.bg : null,
		bold: pen ? pen.bold : false,
		dim: pen ? pen.dim : false,
		italic: pen ? pen.italic : false,
		underline: pen ? pen.underline : false,
		inverse: pen ? pen.inverse : false,
		strike: pen ? pen.strike : false,
		hidden: pen ? pen.hidden : false
	};
}
var Screen = class {
	constructor(cols, rows) {
		this.cols = Math.min(MAX_COLS, Math.max(1, cols | 0));
		this.rows = Math.min(MAX_ROWS, Math.max(1, rows | 0));
		this.scrollbackCells = 0;
		this.cursor = {
			x: 0,
			y: 0,
			visible: true
		};
		this.saved = null;
		this.pen = this._defaultPen();
		this.scrollTop = 0;
		this.scrollBottom = this.rows - 1;
		this.scrollback = [];
		this.tabs = /* @__PURE__ */ new Set();
		this.dirty = /* @__PURE__ */ new Set();
		this.wrapNext = false;
		this.onTitle = null;
		this.onBell = null;
		this._initGrid();
		this._resetTabs();
		this.markAllDirty();
	}
	_defaultPen() {
		return {
			fg: null,
			bg: null,
			bold: false,
			dim: false,
			italic: false,
			underline: false,
			inverse: false,
			strike: false,
			hidden: false
		};
	}
	_initGrid() {
		this.grid = [];
		for (let y = 0; y < this.rows; y++) this.grid.push(this._blankRow());
	}
	_blankRow() {
		const row = new Array(this.cols);
		for (let x = 0; x < this.cols; x++) row[x] = blankCell(null);
		return row;
	}
	_resetTabs() {
		this.tabs.clear();
		for (let x = 0; x < this.cols; x += 8) this.tabs.add(x);
	}
	markDirty(y) {
		if (y >= 0 && y < this.rows) this.dirty.add(y);
	}
	markAllDirty() {
		for (let y = 0; y < this.rows; y++) this.dirty.add(y);
	}
	print(str) {
		for (const ch of str) this._putChar(ch);
	}
	_putChar(ch) {
		if (this.wrapNext) {
			this.cursor.x = 0;
			this._lineFeedScroll();
			this.wrapNext = false;
		}
		const cell = blankCell(this.pen);
		cell.ch = ch;
		this.grid[this.cursor.y][this.cursor.x] = cell;
		this.markDirty(this.cursor.y);
		if (this.cursor.x + 1 >= this.cols) this.wrapNext = true;
		else this.cursor.x++;
	}
	bell() {
		if (this.onBell) this.onBell();
	}
	carriageReturn() {
		this.cursor.x = 0;
		this.wrapNext = false;
	}
	backspace() {
		if (this.cursor.x > 0) this.cursor.x--;
		this.wrapNext = false;
	}
	tab() {
		let x = this.cursor.x + 1;
		while (x < this.cols && !this.tabs.has(x)) x++;
		this.cursor.x = Math.min(x, this.cols - 1);
		this.wrapNext = false;
	}
	lineFeed() {
		this._lineFeedScroll();
		this.wrapNext = false;
	}
	nextLine() {
		this.carriageReturn();
		this._lineFeedScroll();
	}
	_lineFeedScroll() {
		if (this.cursor.y === this.scrollBottom) this.scrollUp(1);
		else if (this.cursor.y < this.rows - 1) this.cursor.y++;
	}
	cursorUp(n = 1) {
		this.cursor.y = Math.max(this.scrollTop, this.cursor.y - (n || 1));
		this.wrapNext = false;
	}
	cursorDown(n = 1) {
		this.cursor.y = Math.min(this.scrollBottom, this.cursor.y + (n || 1));
		this.wrapNext = false;
	}
	cursorForward(n = 1) {
		this.cursor.x = Math.min(this.cols - 1, this.cursor.x + (n || 1));
		this.wrapNext = false;
	}
	cursorBack(n = 1) {
		this.cursor.x = Math.max(0, this.cursor.x - (n || 1));
		this.wrapNext = false;
	}
	cursorCol(n = 1) {
		this.cursor.x = Math.min(this.cols - 1, Math.max(0, (n || 1) - 1));
		this.wrapNext = false;
	}
	cursorRow(n = 1) {
		this.cursor.y = Math.min(this.rows - 1, Math.max(0, (n || 1) - 1));
		this.wrapNext = false;
	}
	cursorPos(row = 1, col = 1) {
		this.cursor.y = Math.min(this.rows - 1, Math.max(0, (row || 1) - 1));
		this.cursor.x = Math.min(this.cols - 1, Math.max(0, (col || 1) - 1));
		this.wrapNext = false;
	}
	cursorNextLine(n = 1) {
		this.cursorDown(n);
		this.cursor.x = 0;
	}
	cursorPrevLine(n = 1) {
		this.cursorUp(n);
		this.cursor.x = 0;
	}
	saveCursor() {
		this.saved = {
			x: this.cursor.x,
			y: this.cursor.y,
			pen: { ...this.pen }
		};
	}
	restoreCursor() {
		if (this.saved) {
			this.cursor.x = this.saved.x;
			this.cursor.y = this.saved.y;
			this.pen = { ...this.saved.pen };
		}
	}
	setCursorVisible(v) {
		this.cursor.visible = !!v;
	}
	eraseInLine(mode = 0) {
		const row = this.grid[this.cursor.y];
		if (mode === 0) for (let x = this.cursor.x; x < this.cols; x++) row[x] = blankCell(this.pen);
		else if (mode === 1) for (let x = 0; x <= this.cursor.x; x++) row[x] = blankCell(this.pen);
		else for (let x = 0; x < this.cols; x++) row[x] = blankCell(this.pen);
		this.markDirty(this.cursor.y);
	}
	eraseInDisplay(mode = 0) {
		if (mode === 0) {
			this.eraseInLine(0);
			for (let y = this.cursor.y + 1; y < this.rows; y++) {
				this.grid[y] = this._blankRow();
				this.markDirty(y);
			}
		} else if (mode === 1) {
			this.eraseInLine(1);
			for (let y = 0; y < this.cursor.y; y++) {
				this.grid[y] = this._blankRow();
				this.markDirty(y);
			}
		} else {
			if (mode === 3) this.scrollback = [];
			for (let y = 0; y < this.rows; y++) {
				this.grid[y] = this._blankRow();
				this.markDirty(y);
			}
		}
	}
	eraseChars(n = 1) {
		n = clampCount(n, this.cols);
		const row = this.grid[this.cursor.y];
		for (let i = 0; i < n && this.cursor.x + i < this.cols; i++) row[this.cursor.x + i] = blankCell(this.pen);
		this.markDirty(this.cursor.y);
	}
	_pushScrollback(row) {
		this.scrollback.push(row);
		this.scrollbackCells += row.length;
		while (this.scrollback.length > 5e3 || this.scrollbackCells > 2e6) this.scrollbackCells -= this.scrollback.shift().length;
	}
	insertChars(n = 1) {
		n = clampCount(n, this.cols);
		const row = this.grid[this.cursor.y];
		for (let i = 0; i < n; i++) {
			row.splice(this.cursor.x, 0, blankCell(this.pen));
			row.pop();
		}
		this.markDirty(this.cursor.y);
	}
	deleteChars(n = 1) {
		n = clampCount(n, this.cols);
		const row = this.grid[this.cursor.y];
		for (let i = 0; i < n; i++) {
			row.splice(this.cursor.x, 1);
			row.push(blankCell(this.pen));
		}
		this.markDirty(this.cursor.y);
	}
	insertLines(n = 1) {
		if (this.cursor.y < this.scrollTop || this.cursor.y > this.scrollBottom) return;
		n = clampCount(n, this.rows);
		for (let i = 0; i < n; i++) {
			this.grid.splice(this.scrollBottom, 1);
			this.grid.splice(this.cursor.y, 0, this._blankRow());
		}
		this._markRange(this.cursor.y, this.scrollBottom);
	}
	deleteLines(n = 1) {
		if (this.cursor.y < this.scrollTop || this.cursor.y > this.scrollBottom) return;
		n = clampCount(n, this.rows);
		for (let i = 0; i < n; i++) {
			this.grid.splice(this.cursor.y, 1);
			this.grid.splice(this.scrollBottom, 0, this._blankRow());
		}
		this._markRange(this.cursor.y, this.scrollBottom);
	}
	scrollUp(n = 1) {
		n = clampCount(n, this.rows);
		for (let i = 0; i < n; i++) {
			const removed = this.grid.splice(this.scrollTop, 1)[0];
			if (this.scrollTop === 0) this._pushScrollback(removed);
			this.grid.splice(this.scrollBottom, 0, this._blankRow());
		}
		this._markRange(this.scrollTop, this.scrollBottom);
	}
	scrollDown(n = 1) {
		n = clampCount(n, this.rows);
		for (let i = 0; i < n; i++) {
			this.grid.splice(this.scrollBottom, 1);
			this.grid.splice(this.scrollTop, 0, this._blankRow());
		}
		this._markRange(this.scrollTop, this.scrollBottom);
	}
	index() {
		this._lineFeedScroll();
	}
	reverseIndex() {
		if (this.cursor.y === this.scrollTop) this.scrollDown(1);
		else if (this.cursor.y > 0) this.cursor.y--;
	}
	setScrollRegion(top, bottom) {
		top = (top || 1) - 1;
		bottom = (bottom || this.rows) - 1;
		if (top < bottom && bottom < this.rows) {
			this.scrollTop = Math.max(0, top);
			this.scrollBottom = Math.min(this.rows - 1, bottom);
			this.cursor.x = 0;
			this.cursor.y = this.scrollTop;
		}
	}
	_markRange(a, b) {
		for (let y = a; y <= b; y++) this.markDirty(y);
	}
	setSGR(params) {
		if (!params.length) params = [0];
		for (let i = 0; i < params.length; i++) {
			const p = params[i];
			switch (true) {
				case p === 0:
					this.pen = this._defaultPen();
					break;
				case p === 1:
					this.pen.bold = true;
					break;
				case p === 2:
					this.pen.dim = true;
					break;
				case p === 3:
					this.pen.italic = true;
					break;
				case p === 4:
					this.pen.underline = true;
					break;
				case p === 7:
					this.pen.inverse = true;
					break;
				case p === 8:
					this.pen.hidden = true;
					break;
				case p === 9:
					this.pen.strike = true;
					break;
				case p === 22:
					this.pen.bold = false;
					this.pen.dim = false;
					break;
				case p === 23:
					this.pen.italic = false;
					break;
				case p === 24:
					this.pen.underline = false;
					break;
				case p === 27:
					this.pen.inverse = false;
					break;
				case p === 28:
					this.pen.hidden = false;
					break;
				case p === 29:
					this.pen.strike = false;
					break;
				case p >= 30 && p <= 37:
					this.pen.fg = p - 30;
					break;
				case p === 38:
					i = this._extendedColor(params, i, "fg");
					break;
				case p === 39:
					this.pen.fg = null;
					break;
				case p >= 40 && p <= 47:
					this.pen.bg = p - 40;
					break;
				case p === 48:
					i = this._extendedColor(params, i, "bg");
					break;
				case p === 49:
					this.pen.bg = null;
					break;
				case p >= 90 && p <= 97:
					this.pen.fg = p - 90 + 8;
					break;
				case p >= 100 && p <= 107: this.pen.bg = p - 100 + 8;
			}
		}
	}
	_extendedColor(params, i, which) {
		const mode = params[i + 1];
		if (mode === 5) {
			this.pen[which] = params[i + 2];
			return i + 2;
		}
		if (mode === 2) {
			this.pen[which] = [
				params[i + 2] || 0,
				params[i + 3] || 0,
				params[i + 4] || 0
			];
			return i + 4;
		}
		return i;
	}
	setMode(params, priv) {
		for (const p of params) if (priv && p === 25) this.setCursorVisible(true);
	}
	resetMode(params, priv) {
		for (const p of params) if (priv && p === 25) this.setCursorVisible(false);
	}
	reset() {
		this.pen = this._defaultPen();
		this.cursor = {
			x: 0,
			y: 0,
			visible: true
		};
		this.scrollTop = 0;
		this.scrollBottom = this.rows - 1;
		this._initGrid();
		this._resetTabs();
		this.markAllDirty();
	}
	resize(cols, rows) {
		cols = Math.min(MAX_COLS, Math.max(1, cols | 0));
		rows = Math.min(MAX_ROWS, Math.max(1, rows | 0));
		if (rows < this.rows) {
			const remove = this.rows - rows;
			for (let i = 0; i < remove; i++) {
				const top = this.grid.shift();
				this._pushScrollback(top);
			}
		} else if (rows > this.rows) for (let i = 0; i < rows - this.rows; i++) this.grid.push(this._blankRow());
		this.rows = rows;
		for (let y = 0; y < this.rows; y++) {
			const row = this.grid[y];
			if (cols < this.cols) row.length = cols;
			else for (let x = this.cols; x < cols; x++) row[x] = blankCell(null);
		}
		this.cols = cols;
		this.scrollTop = 0;
		this.scrollBottom = this.rows - 1;
		this.cursor.x = Math.min(this.cursor.x, cols - 1);
		this.cursor.y = Math.min(this.cursor.y, rows - 1);
		this._resetTabs();
		this.markAllDirty();
	}
};
function encodeData(kind, seq, payload) {
	const body = payload instanceof Uint8Array ? payload : new Uint8Array(payload);
	const m = new Uint8Array(7 + body.length);
	m[0] = kind;
	let n = seq;
	for (let i = 6; i >= 1; i--) {
		m[i] = n & 255;
		n = Math.floor(n / 256);
	}
	m.set(body, 7);
	return m;
}
function decodeData(buf) {
	const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
	if (u.length < 8) throw new Error("short data frame");
	let seq = 0;
	for (let i = 1; i <= 6; i++) seq = seq * 256 + u[i];
	return {
		kind: u[0],
		seq,
		payload: u.subarray(7)
	};
}
var CREDIT = 262144;
function randomId() {
	const b = /* @__PURE__ */ new Uint8Array(8);
	crypto.getRandomValues(b);
	return [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
}
/**
* One hermit.vws.v2 socket per terminal tab, carried on a MessagePort into
* the guest worker. The filesystem is flushed to the local SSD, so stopping
* the worker does not drop the volume.
*/
var RamLink = class {
	worker = null;
	booted = null;
	generation = 0;
	epoch = "";
	seal = "";
	version = "";
	restored = false;
	device = "nvme0n1";
	sockets = /* @__PURE__ */ new Map();
	statusWait = /* @__PURE__ */ new Map();
	onData = () => {};
	onExit = () => {};
	onState = () => {};
	onBrowser = () => {};
	onHolo = () => {};
	onHalt = () => {};
	boot() {
		if (this.booted) return this.booted;
		this.booted = new Promise((resolve, reject) => {
			if (typeof Worker === "undefined") {
				reject(/* @__PURE__ */ new Error("The server only boots in the browser"));
				return;
			}
			const worker = new Worker(new URL("../vendor/ram-worker.js", import.meta.url), { type: "module" });
			this.worker = worker;
			const timer = window.setTimeout(() => reject(/* @__PURE__ */ new Error("The SSD did not finish mounting")), 8e3);
			worker.onmessage = (ev) => {
				const data = ev.data;
				if (data?.type === "ready") {
					window.clearTimeout(timer);
					this.epoch = data.epoch || "";
					this.seal = data.seal || "";
					this.version = data.version || "";
					this.restored = Boolean(data.restored);
					if (data.device) this.device = data.device;
					resolve();
				} else if (data?.type === "error") {
					window.clearTimeout(timer);
					reject(new Error(data.message || "SSD mount failed"));
				} else if (data?.type === "halt") this.onHalt({ reason: data.reason || "poweroff" });
				else if (data?.type === "browser" && data.payload) this.onBrowser(data.payload);
				else if (data?.type === "holo" && data.payload) this.onHolo(data.payload);
			};
			worker.onerror = (ev) => {
				window.clearTimeout(timer);
				reject(new Error(ev.message || "Server error"));
			};
		});
		return this.booted;
	}
	async reboot(reason = "power cycle") {
		const gen = ++this.generation;
		for (const id of this.sockets.keys()) this.onState({
			sessionId: id,
			state: "reset",
			detail: reason
		});
		this.sockets.clear();
		this.worker?.terminate();
		this.worker = null;
		this.booted = null;
		await this.boot();
		if (gen !== this.generation) return;
	}
	peekHolo() {
		this.worker?.postMessage({ type: "holo-peek" });
	}
	destroy() {
		this.generation += 1;
		this.worker?.terminate();
		this.worker = null;
		this.booted = null;
		this.sockets.clear();
	}
	async open(cols, rows) {
		await this.boot();
		const worker = this.worker;
		if (!worker) throw new Error("Server is down");
		const channel = new MessageChannel();
		const port = channel.port2;
		const sock = {
			port,
			sid: null,
			epoch: null,
			inSeq: 0,
			outSeq: 0,
			consumed: 0,
			opened: false,
			decoder: new TextDecoder("utf-8")
		};
		const rid = randomId();
		return new Promise((resolve, reject) => {
			const timer = window.setTimeout(() => reject(/* @__PURE__ */ new Error("session open timed out")), 5e3);
			port.onmessage = (ev) => {
				if (typeof ev.data !== "string") {
					if (!sock.sid || !sock.opened) return;
					let frame;
					try {
						frame = decodeData(new Uint8Array(ev.data));
					} catch {
						return;
					}
					if (frame.seq !== sock.outSeq + 1) return;
					sock.outSeq = frame.seq;
					sock.consumed += frame.payload.length;
					const text = sock.decoder.decode(frame.payload, { stream: true });
					if (text) this.onData({
						sessionId: sock.sid,
						chunk: text
					});
					this.credit(sock);
					return;
				}
				let msg;
				try {
					msg = JSON.parse(ev.data);
				} catch {
					return;
				}
				if (msg.type === "hello") {
					port.postMessage(JSON.stringify({
						v: 2,
						type: "session.open",
						rid,
						payload: {
							cols,
							rows,
							mode: "virtual",
							creditBytes: CREDIT
						}
					}));
					return;
				}
				if (msg.type === "session.opened" && msg.rid === rid && msg.sid) {
					window.clearTimeout(timer);
					sock.sid = msg.sid;
					sock.epoch = msg.epoch || this.epoch;
					sock.opened = true;
					this.sockets.set(msg.sid, sock);
					this.onState({
						sessionId: msg.sid,
						state: "active"
					});
					resolve({ sessionId: msg.sid });
					return;
				}
				if (msg.type === "session.exit" && msg.sid) {
					const payload = msg.payload || {};
					this.sockets.delete(msg.sid);
					this.onExit({
						sessionId: msg.sid,
						code: Number(payload.code) || 0,
						reason: String(payload.reason || "closed")
					});
					return;
				}
				if (msg.type === "session.status" && msg.rid && this.statusWait.has(msg.rid)) {
					const done = this.statusWait.get(msg.rid);
					this.statusWait.delete(msg.rid);
					done?.(msg.payload);
					return;
				}
				if (msg.type === "error") {
					const payload = msg.payload || {};
					if (!sock.opened) {
						window.clearTimeout(timer);
						reject(new Error(String(payload.message || "open failed")));
					} else if (sock.sid) this.onState({
						sessionId: sock.sid,
						state: "error",
						detail: String(payload.message || payload.code || "error")
					});
				}
			};
			worker.postMessage({ type: "attach" }, [channel.port1]);
		});
	}
	start(sessionId) {
		const sock = this.sockets.get(sessionId);
		if (!sock) return;
		sock.port.postMessage(JSON.stringify({
			v: 2,
			type: "session.start",
			sid: sessionId
		}));
	}
	write(sessionId, text) {
		const sock = this.sockets.get(sessionId);
		if (!sock?.sid) return;
		const bytes = new TextEncoder().encode(text);
		const max = 8192;
		for (let i = 0; i < bytes.length; i += max) {
			const part = bytes.subarray(i, Math.min(bytes.length, i + max));
			sock.inSeq += 1;
			const frame = encodeData(1, sock.inSeq, part);
			sock.port.postMessage(frame, [frame.buffer]);
		}
	}
	resize(sessionId, cols, rows) {
		const sock = this.sockets.get(sessionId);
		if (!sock?.sid) return;
		sock.port.postMessage(JSON.stringify({
			v: 2,
			type: "terminal.resize",
			sid: sock.sid,
			payload: {
				cols,
				rows
			}
		}));
	}
	signal(sessionId, signal = "SIGINT") {
		const sock = this.sockets.get(sessionId);
		if (!sock?.sid) return;
		sock.port.postMessage(JSON.stringify({
			v: 2,
			type: "terminal.signal",
			sid: sock.sid,
			payload: { signal }
		}));
	}
	close(sessionId) {
		const sock = this.sockets.get(sessionId);
		if (!sock?.sid) return;
		sock.port.postMessage(JSON.stringify({
			v: 2,
			type: "session.close",
			sid: sock.sid,
			payload: { reason: "closed" }
		}));
		this.sockets.delete(sessionId);
	}
	status(sessionId) {
		const sock = this.sockets.get(sessionId);
		if (!sock?.sid) return Promise.resolve(null);
		const rid = randomId();
		return new Promise((resolve) => {
			const timer = window.setTimeout(() => {
				this.statusWait.delete(rid);
				resolve(null);
			}, 2e3);
			this.statusWait.set(rid, (st) => {
				window.clearTimeout(timer);
				resolve(st);
			});
			sock.port.postMessage(JSON.stringify({
				v: 2,
				type: "session.status",
				rid,
				sid: sock.sid
			}));
		});
	}
	credit(sock) {
		if (!sock.sid) return;
		sock.port.postMessage(JSON.stringify({
			v: 2,
			type: "flow.credit",
			sid: sock.sid,
			epoch: sock.epoch,
			payload: {
				consumedSeq: sock.outSeq,
				creditBytes: sock.consumed + CREDIT
			}
		}));
	}
};
var LOCAL_ORIGINS = /* @__PURE__ */ new Set(["http://127.0.0.1:8788", "http://127.0.0.1:8791"]);
var TRIALS = [
	"hpu bytes vortex",
	"hpu oam 13",
	"hpu gate xor 1 0",
	"disk",
	"write /tmp/note kept"
];
function fmtBytes(n) {
	if (n == null || !Number.isFinite(n)) return "—";
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KiB`;
	return `${(n / 1048576).toFixed(2)} MiB`;
}
function screenText(screen) {
	return (screen.grid ?? []).map((row) => row.map((cell) => cell?.ch ?? " ").join("").replace(/\s+$/, "")).join("\n");
}
function admit(raw) {
	const url = raw.trim() || "about:blank";
	if (url === "about:blank") return {
		url,
		note: "blank"
	};
	if (url.startsWith("ram://")) return {
		url,
		note: "ram"
	};
	try {
		const origin = new URL(url).origin;
		if (LOCAL_ORIGINS.has(origin)) return {
			url,
			note: "admitted"
		};
	} catch {
		return {
			url,
			note: "rejected"
		};
	}
	return {
		url,
		note: "rejected"
	};
}
function parseHex(raw) {
	const hex = raw.trim().replace("#", "");
	if (hex.length < 6) return [
		12,
		15,
		19
	];
	return [
		parseInt(hex.slice(0, 2), 16),
		parseInt(hex.slice(2, 4), 16),
		parseInt(hex.slice(4, 6), 16)
	];
}
function atto(j) {
	if (j == null || !Number.isFinite(j)) return "—";
	const aj = j * 0xde0b6b3a7640000;
	if (Math.abs(aj) >= .01) return `${aj.toFixed(2)} aJ`;
	return `${(aj * 1e3).toFixed(2)} zJ`;
}
function FieldCanvas({ samples, n, kind }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas || n < 2 || samples.length < n * n) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		canvas.width = n;
		canvas.height = n;
		const img = ctx.createImageData(n, n);
		const style = getComputedStyle(document.documentElement);
		const bg = parseHex(style.getPropertyValue("--color-bg"));
		const fg = parseHex(style.getPropertyValue("--color-fg"));
		const pri = parseHex(style.getPropertyValue("--color-primary"));
		const danger = parseHex(style.getPropertyValue("--color-danger"));
		const data = img.data;
		for (let i = 0; i < n * n; i++) {
			let r;
			let g;
			let b;
			if (kind === "wigner") {
				const u = Math.max(-1, Math.min(1, ((samples[i] ?? 128) - 128) / 127));
				const src = u >= 0 ? pri : danger;
				const t = Math.abs(u);
				r = bg[0] + (src[0] - bg[0]) * t;
				g = bg[1] + (src[1] - bg[1]) * t;
				b = bg[2] + (src[2] - bg[2]) * t;
			} else if (kind === "intensity") {
				const t = Math.max(0, Math.min(1, (samples[i] ?? 0) / 255));
				r = bg[0] + (fg[0] - bg[0]) * t;
				g = bg[1] + (fg[1] - bg[1]) * t;
				b = bg[2] + (fg[2] - bg[2]) * t;
			} else {
				const ang = Math.max(0, Math.min(1, (samples[i] ?? 0) / 255)) * Math.PI * 2;
				const wPri = (1 + Math.cos(ang)) * .5;
				const wFg = (1 + Math.sin(ang)) * .35;
				const wBg = Math.max(.08, 1 - wPri * .85);
				const s = wBg + wPri + wFg;
				r = (bg[0] * wBg + pri[0] * wPri + fg[0] * wFg) / s;
				g = (bg[1] * wBg + pri[1] * wPri + fg[1] * wFg) / s;
				b = (bg[2] * wBg + pri[2] * wPri + fg[2] * wFg) / s;
			}
			const o = i * 4;
			data[o] = r;
			data[o + 1] = g;
			data[o + 2] = b;
			data[o + 3] = 255;
		}
		ctx.putImageData(img, 0, 0);
	}, [
		samples,
		n,
		kind
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "holo-field",
		width: n,
		height: n,
		"aria-hidden": "true"
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "mark",
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				fill: "none",
				stroke: "var(--color-primary)",
				strokeWidth: "3",
				strokeLinecap: "square",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 16 V4 H16" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M48 4 H60 V16" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M60 48 V60 H48" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 60 H4 V48" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				stroke: "var(--color-line)",
				strokeWidth: "1.6",
				strokeDasharray: "2 2.4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "32",
						y1: "32",
						x2: "32",
						y2: "12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "32",
						y1: "32",
						x2: "52",
						y2: "32"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "32",
						y1: "32",
						x2: "32",
						y2: "52"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "32",
						y1: "32",
						x2: "12",
						y2: "32"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				fill: "var(--color-raised)",
				stroke: "var(--color-line)",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "28",
						y: "6",
						width: "8",
						height: "8",
						rx: "1.5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "50",
						y: "28",
						width: "8",
						height: "8",
						rx: "1.5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "28",
						y: "50",
						width: "8",
						height: "8",
						rx: "1.5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "6",
						y: "28",
						width: "8",
						height: "8",
						rx: "1.5"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "32,24 39,28 32,32 25,28",
				fill: "var(--color-primary)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "25,28 32,32 32,40 25,36",
				fill: "var(--color-primary)",
				opacity: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "39,28 32,32 32,40 39,36",
				fill: "var(--color-primary)",
				opacity: "0.5"
			})
		]
	});
}
function Ja21Console() {
	const termRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const imeRef = (0, import_react.useRef)(null);
	const mirrorRef = (0, import_react.useRef)(null);
	const api = (0, import_react.useRef)(null);
	const [tabs, setTabs] = (0, import_react.useState)([]);
	const [active, setActive] = (0, import_react.useState)(null);
	const [conn, setConn] = (0, import_react.useState)("booting");
	const [detail, setDetail] = (0, import_react.useState)("mounting nvme0n1");
	const [status, setStatus] = (0, import_react.useState)(null);
	const [geom, setGeom] = (0, import_react.useState)("80×24");
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [panel, setPanel] = (0, import_react.useState)(false);
	const [surface, setSurface] = (0, import_react.useState)(false);
	const [holoOpen, setHoloOpen] = (0, import_react.useState)(false);
	const [holo, setHolo] = (0, import_react.useState)(null);
	const [browser, setBrowser] = (0, import_react.useState)({
		visible: false,
		url: "about:blank",
		engine: "VB-JA21/9.8.7"
	});
	const [policyNote, setPolicyNote] = (0, import_react.useState)("blank");
	const [urlDraft, setUrlDraft] = (0, import_react.useState)("about:blank");
	const [bootError, setBootError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (window.innerWidth >= 960) setPanel(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const canvasEl = canvasRef.current;
		const termEl = termRef.current;
		const imeEl = imeRef.current;
		if (!canvasEl || !termEl || !imeEl) return;
		const canvas = canvasEl;
		const term = termEl;
		const ime = imeEl;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const fontFamily = "\"IBM Plex Mono\", ui-monospace, monospace";
		const fontSize = window.innerWidth < 640 ? 13 : 15;
		const painter = new CanvasRenderer(canvas, new Screen(80, 24), {
			background: "#0c0f13",
			foreground: "#e9eff4",
			cursor: "#2fd0e4",
			cursorText: "#0c0f13",
			fontFamily,
			fontSize,
			lineHeight: 1.45
		});
		if (reduce) painter.cursorOn = true;
		const link = new RamLink();
		link.onHolo = (payload) => {
			setHolo(payload);
			if (payload.open) setHoloOpen(true);
		};
		const sessions = /* @__PURE__ */ new Map();
		let current = null;
		let seq = 0;
		let cycling = false;
		let dead = false;
		let needs = true;
		const paint = () => {
			needs = true;
		};
		function mirror() {
			const tab = current && sessions.get(current);
			if (tab && mirrorRef.current) mirrorRef.current.textContent = screenText(tab.screen);
		}
		function geometry() {
			const rect = term.getBoundingClientRect();
			const style = getComputedStyle(term);
			const w = rect.width - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
			const h = rect.height - parseFloat(style.paddingTop) - parseFloat(style.paddingBottom);
			const g = painter.fit(Math.max(40, w), Math.max(40, h));
			const cols = Math.max(2, Math.min(400, g.cols));
			const rows = Math.max(1, Math.min(200, g.rows));
			setGeom(`${cols}×${rows}`);
			return {
				cols,
				rows
			};
		}
		function relayout() {
			const { cols, rows } = geometry();
			for (const [id, tab] of sessions) if (tab.screen.cols !== cols || tab.screen.rows !== rows) {
				tab.screen.resize(cols, rows);
				link.resize(id, cols, rows);
			}
			paint();
		}
		function activate(id) {
			const tab = sessions.get(id);
			if (!tab) return;
			current = id;
			setActive(id);
			painter.screen = tab.screen;
			painter.scrollToBottom();
			setScrolled(false);
			paint();
			mirror();
			ime.focus({ preventScroll: true });
		}
		async function openTab() {
			const { cols, rows } = geometry();
			const screen = new Screen(cols, rows);
			const parser = new Parser(screen);
			try {
				const res = await link.open(cols, rows);
				if (dead) return;
				const id = res.sessionId;
				const n = ++seq;
				screen.onTitle = (title) => {
					const tab = sessions.get(id);
					if (tab) tab.title = title || "session";
					setTabs((list) => list.map((t) => t.id === id ? {
						...t,
						title: title || "session"
					} : t));
				};
				sessions.set(id, {
					screen,
					parser,
					title: "session"
				});
				setTabs((list) => [...list, {
					id,
					n,
					title: "session",
					closed: false
				}]);
				activate(id);
				link.start(id);
			} catch (err) {
				painter.screen = screen;
				parser.write(`\x1b[31m[could not open a session: ${err instanceof Error ? err.message : "failed"}]\x1b[0m\r\n`);
				paint();
				setBootError(err instanceof Error ? err.message : "could not open a session");
				setConn("error");
			}
		}
		function closeTab(id) {
			link.close(id);
			sessions.delete(id);
			setTabs((list) => list.filter((t) => t.id !== id));
			if (current === id) {
				const rest = [...sessions.keys()];
				const next = rest[rest.length - 1];
				if (next) activate(next);
				else openTab();
			}
		}
		async function cycle(reason) {
			if (cycling || dead) return;
			cycling = true;
			setConn("reset");
			setDetail(reason);
			sessions.clear();
			setTabs([]);
			current = null;
			setActive(null);
			try {
				await link.reboot(reason);
				if (dead) return;
				setConn("open");
				setDetail(link.restored ? "nvme0n1 remounted" : "nvme0n1 formatted");
				await openTab();
			} catch (err) {
				setBootError(err instanceof Error ? err.message : "reboot failed");
				setConn("error");
			} finally {
				cycling = false;
			}
		}
		link.onData = ({ sessionId, chunk }) => {
			const tab = sessions.get(sessionId);
			if (!tab) return;
			tab.parser.write(chunk);
			if (sessionId === current) {
				painter.scrollToBottom();
				setScrolled(false);
				paint();
				mirror();
			}
		};
		link.onExit = ({ sessionId, code, reason }) => {
			const tab = sessions.get(sessionId);
			if (!tab) return;
			tab.parser.write(`\r\n\x1b[2m[session closed${reason ? " · " + reason : ""}${code ? " · exit " + code : ""}]\x1b[0m\r\n`);
			setTabs((list) => list.map((t) => t.id === sessionId ? {
				...t,
				closed: true
			} : t));
			if (sessionId === current) paint();
		};
		link.onState = ({ sessionId, state, detail: d }) => {
			if (sessionId === current || !current) {
				setConn(state);
				if (d) setDetail(d);
			}
			if (d && (state === "error" || state === "reset")) {
				sessions.get(sessionId)?.parser.write(`\r\n\x1b[33m[${state}: ${d}]\x1b[0m\r\n`);
				if (sessionId === current) paint();
			}
		};
		link.onBrowser = (next) => {
			setBrowser(next);
			setUrlDraft(next.url);
			setPolicyNote(admit(next.url).note);
			if (next.visible) setSurface(true);
		};
		link.onHalt = ({ reason }) => {
			cycle("power cycle — SSD flushed, remounting nvme0n1");
		};
		function send(data) {
			if (!current) return;
			painter.scrollToBottom();
			setScrolled(false);
			link.write(current, data);
		}
		function encodeKey(e) {
			const k = e.key;
			if (e.ctrlKey && !e.altKey && !e.metaKey && k.length === 1) {
				const c = k.toLowerCase().charCodeAt(0);
				if (c >= 97 && c <= 122) return String.fromCharCode(c - 96);
			}
			switch (k) {
				case "Enter": return "\r";
				case "Backspace": return "";
				case "Tab": return "	";
				case "Escape": return "\x1B";
				case "ArrowUp": return "\x1B[A";
				case "ArrowDown": return "\x1B[B";
				case "ArrowRight": return "\x1B[C";
				case "ArrowLeft": return "\x1B[D";
				case "Home": return "\x1B[H";
				case "End":
					painter.scrollToBottom();
					setScrolled(false);
					return "\x1B[F";
				case "Delete": return "\x1B[3~";
				case "PageUp":
					painter.scrollBy(painter.screen.rows - 1);
					setScrolled(painter.scrollOffset !== 0);
					paint();
					return null;
				case "PageDown":
					painter.scrollBy(-(painter.screen.rows - 1));
					setScrolled(painter.scrollOffset !== 0);
					paint();
					return null;
				default:
					if (k.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) return k;
					return null;
			}
		}
		function onKey(e) {
			if (e.target?.tagName === "INPUT") return;
			if (e.isComposing) return;
			if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "t") {
				e.preventDefault();
				openTab();
				return;
			}
			if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "w") {
				e.preventDefault();
				if (current) closeTab(current);
				return;
			}
			const data = encodeKey(e);
			if (data !== null) {
				e.preventDefault();
				send(data);
			}
		}
		function onPaste(e) {
			if (e.target?.tagName === "INPUT") return;
			const text = e.clipboardData?.getData("text") ?? "";
			if (!text) return;
			if (text.length > 262144) return;
			e.preventDefault();
			send(text.replace(/\r?\n/g, "\r"));
		}
		function onWheel(e) {
			painter.scrollBy(e.deltaY > 0 ? -3 : 3);
			setScrolled(painter.scrollOffset !== 0);
			paint();
			e.preventDefault();
		}
		function onInput() {
			if (ime.value) {
				send(ime.value.replace(/\r?\n/g, "\r"));
				ime.value = "";
			}
		}
		api.current = {
			run: (cmd) => {
				ime.focus({ preventScroll: true });
				send(cmd + "\r");
			},
			newTab: () => void openTab(),
			closeTab,
			activate,
			power: () => {
				if (current) send("poweroff\r");
				else cycle("power cycle — SSD flushed, remounting nvme0n1");
			},
			peekHolo: () => link.peekHolo(),
			focus: () => ime.focus({ preventScroll: true })
		};
		const frame = window.requestAnimationFrame(function loop() {
			if (needs) {
				painter.render();
				needs = false;
			}
			if (!dead) window.requestAnimationFrame(loop);
		});
		const blink = window.setInterval(() => {
			if (reduce) return;
			painter.cursorOn = !painter.cursorOn;
			paint();
		}, 530);
		const poll = window.setInterval(() => {
			if (!current) return;
			link.status(current).then((st) => {
				if (st) setStatus(st);
			});
		}, 1e3);
		const observer = new ResizeObserver(() => relayout());
		observer.observe(term);
		document.addEventListener("keydown", onKey);
		document.addEventListener("paste", onPaste);
		term.addEventListener("wheel", onWheel, { passive: false });
		ime.addEventListener("input", onInput);
		(async () => {
			try {
				if (document.fonts) {
					await document.fonts.load(`${fontSize}px ${fontFamily}`);
					await document.fonts.ready;
				}
				painter.setTheme({
					fontFamily,
					fontSize
				});
				relayout();
				await link.boot();
				if (dead) return;
				setConn("open");
				setDetail(link.restored ? "nvme0n1 restored — opening terminal" : "nvme0n1 ready — opening terminal");
				await openTab();
				if (!dead) link.peekHolo();
			} catch (err) {
				setBootError(err instanceof Error ? err.message : "boot failed");
				setConn("error");
			}
		})();
		return () => {
			dead = true;
			window.cancelAnimationFrame(frame);
			window.clearInterval(blink);
			window.clearInterval(poll);
			observer.disconnect();
			document.removeEventListener("keydown", onKey);
			document.removeEventListener("paste", onPaste);
			term.removeEventListener("wheel", onWheel);
			ime.removeEventListener("input", onInput);
			api.current = null;
			link.destroy();
		};
	}, []);
	const ram = status?.ram;
	const usedPct = ram && ram.maxBytes ? Math.min(100, Math.round(100 * ram.bytes / ram.maxBytes)) : 0;
	const dot = conn === "active" || conn === "open" ? "" : conn === "error" ? "bad" : "warn";
	const stageClass = `stage${panel ? " panel" : ""}${surface ? " surface" : ""}${holoOpen ? " holo" : ""}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "console font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "console-bar",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm font-medium tracking-wide text-fg",
							children: "JA21 Console"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate font-mono text-xs text-muted",
							children: "1.4.0 · HERMIT terminal · SSD server"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "tabs",
						"aria-label": "Sessions",
						children: [tabs.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: tab.id === active ? "tab active" : "tab",
							onClick: () => api.current?.activate(tab.id),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: String(tab.n).padStart(2, "0") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-24 truncate",
									children: tab.closed ? "closed" : tab.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "x",
									role: "presentation",
									onClick: (e) => {
										e.stopPropagation();
										api.current?.closeTab(tab.id);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
										className: "size-3",
										"aria-hidden": "true"
									})
								})
							]
						}, tab.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tab",
							onClick: () => api.current?.newTab(),
							"aria-label": "New session",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `inline-flex min-h-11 items-center gap-2 rounded-md border px-3 text-sm ${holoOpen ? "border-primary text-primary" : "border-line text-muted"}`,
								"aria-pressed": holoOpen,
								onClick: () => {
									setHoloOpen((v) => !v);
									api.current?.peekHolo();
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aperture, {
									className: "size-4",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Holo"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `inline-flex min-h-11 items-center gap-2 rounded-md border px-3 text-sm ${surface ? "border-primary text-primary" : "border-line text-muted"}`,
								onClick: () => setSurface((v) => !v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppWindow, {
									className: "size-4",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Surface"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `inline-flex min-h-11 items-center gap-2 rounded-md border px-3 text-sm ${panel ? "border-primary text-primary" : "border-line text-muted"}`,
								onClick: () => setPanel((v) => !v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelRight, {
									className: "size-4",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Ledger"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center gap-2 rounded-md border border-warn px-3 text-sm text-warn",
								onClick: () => api.current?.power(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Power"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "suggestions",
				"aria-label": "Try a command",
				children: TRIALS.map((cmd) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => api.current?.run(cmd),
					children: cmd
				}, cmd))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: stageClass,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						ref: termRef,
						className: "term",
						onMouseDown: (e) => {
							e.preventDefault();
							api.current?.focus();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bracket tl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bracket tr" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bracket bl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "bracket br" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "frame-tag",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `live-dot ${dot}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["SPIRAL // ", conn] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
								ref: canvasRef,
								role: "img",
								"aria-label": "Virtual terminal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								ref: imeRef,
								className: "ime",
								"aria-label": "Terminal input",
								autoCapitalize: "off",
								autoComplete: "off",
								autoCorrect: "off",
								spellCheck: false,
								rows: 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								ref: mirrorRef,
								className: "sr-only",
								"aria-live": "polite"
							}),
							scrolled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "scrollhint",
								children: "scrolled · End returns"
							}) : null,
							bootError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "absolute bottom-3 left-4 right-4 font-mono text-sm text-danger",
								children: bootError
							}) : null
						]
					}),
					surface ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "surface-pane",
						"aria-label": "JA21 blank surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs tracking-wide text-primary",
								children: ["VB-JA21 // ", browser.engine]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-base font-medium text-fg",
								children: "Blank console surface"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: "No tabs, no toolbar. Public web stays closed. Exact local origins and ram:// pages are admitted."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "mt-3 flex gap-2",
								onSubmit: (e) => {
									e.preventDefault();
									const next = admit(urlDraft);
									setPolicyNote(next.note);
									setBrowser((b) => ({
										...b,
										visible: true,
										url: next.url
									}));
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: urlDraft,
									onChange: (e) => setUrlDraft(e.target.value),
									"aria-label": "Surface address",
									spellCheck: false,
									className: "min-h-11 min-w-0 flex-1 rounded-md border border-line bg-bg px-3 font-mono text-sm text-fg"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "min-h-11 rounded-md bg-primary px-3 text-sm font-medium text-bg",
									children: "Open"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "blank mt-3",
								children: policyNote === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-danger",
									children: "Navigation rejected"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs",
									children: "This origin is not in console.json."
								})] }) : policyNote === "admitted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ok",
									children: "Origin admitted"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs",
									children: "No guest is bound to that port in this image."
								})] }) : policyNote === "ram" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-left font-mono text-xs leading-relaxed text-fg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["epoch ", status?.epoch ?? "booting"] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["seal ", (status?.seal ?? "—").slice(0, 24)] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
											"vfs ",
											fmtBytes(ram?.bytes),
											" / ",
											fmtBytes(ram?.maxBytes)
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["drift ", status?.drifted ? "yes" : "no"] })
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-fg",
									children: "about:blank"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs",
									children: "The console is empty until a local guest is loaded. This one is the SSD server."
								})] })
							})
						]
					}) : null,
					holoOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "holo-pane",
						"aria-label": "Holographic processor",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs tracking-wide text-primary",
								children: ["HPU // ", holo ? `${holo.lambdaNm.toFixed(0)} nm` : "532 nm"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-base font-medium text-fg",
								children: "Processable hologram"
							}),
							holo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-sm text-fg",
									children: holo.gate ? `${holo.gate} → bit ${holo.bit}` : holo.op
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: [
										holo.stage && holo.stage !== "idle" ? `${holo.stage} · ` : "",
										"cycle ",
										holo.cycles ?? 0,
										" · z ",
										holo.zMm.toFixed(2),
										" mm · spool ",
										holo.frames
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "holo-fields",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
											className: "mb-1 font-mono text-xs text-muted",
											children: "Phase · TIFF"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {
											samples: holo.phase,
											n: holo.n,
											kind: "phase"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
											className: "mb-1 font-mono text-xs text-muted",
											children: "Intensity · GIF"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {
											samples: holo.intensity,
											n: holo.n,
											kind: "intensity"
										})] }),
										holo.route && holo.route.length >= holo.n * holo.n ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
											className: "mb-1 font-mono text-xs text-muted",
											children: "Processor 7 · route"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {
											samples: holo.route,
											n: holo.n,
											kind: "intensity"
										})] }) : null,
										holo.wigner && holo.wignerN && holo.wigner.length >= holo.wignerN * holo.wignerN ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
											className: "mb-1 font-mono text-xs text-muted",
											children: "Wigner · interaction frame"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {
											samples: holo.wigner,
											n: holo.wignerN,
											kind: "wigner"
										})] }) : null,
										holo.wigner && holo.penteract ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-mono text-xs leading-relaxed text-fg",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-muted",
													children: "non-Gaussian"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [((holo.wNeg ?? 0) * 100).toFixed(1), "% negative"] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													"χ ",
													(holo.gifChi ?? 0).toFixed(2),
													" · n̄ ",
													(holo.gifNbar ?? 0).toFixed(2)
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["order R ", (holo.orderR ?? 0).toFixed(2)] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-2 text-muted",
													children: "penteract"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													"x ",
													holo.penteract.x.toFixed(1),
													" · y ",
													holo.penteract.y.toFixed(1)
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													"z ",
													holo.penteract.z.toFixed(2),
													" mm"
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													"t ",
													holo.penteract.t,
													" · ⟨v₂⟩ ",
													holo.penteract.p.toFixed(2)
												] })
											]
										}) : null
									]
								}),
								holo.stage === "sample" || holo.stage === "relocate" || holo.stage === "reproject" || holo.stage === "diffuse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "carriers"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: "text-fg",
											children: [
												holo.moved ?? 0,
												" moved · ",
												holo.info ?? 0,
												" info"
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "bit / anti-bit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: "text-fg",
											children: [
												(holo.n * holo.n - (holo.logical1 ?? 0)).toLocaleString(),
												" / ",
												holo.logical1 ?? 0
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Landauer"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: atto(holo.landauerJ)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "2-adic ⟨v₂⟩"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: (holo.padic ?? 0).toFixed(2)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted",
												children: "Bloch rx ry rz"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
												className: "text-fg",
												children: [(holo.bloch ?? [
													0,
													0,
													1
												]).map((v) => v.toFixed(2)).join("  "), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [" · purity ", (holo.purity ?? 1).toFixed(2)]
												})]
											})]
										})
									]
								}) : holo.stage === "record" || holo.stage === "replay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "weight"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: "text-fg",
											children: [holo.recorded || "—", " in the array"]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "bus"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: "0 bytes moved"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "MAC"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: "text-fg",
											children: [(holo.macOps ?? 0).toLocaleString(), " in place"]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "fidelity"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: holo.fidelity == null ? "—" : holo.fidelity.toFixed(3)
										})] })
									]
								}) : holo.stage === "oam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "value"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: holo.oamValue ?? "—"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "charge ℓ"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: holo.oamCharge && holo.oamCharge > 0 ? `+${holo.oamCharge}` : holo.oamCharge ?? "—"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "col-span-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted",
												children: "wells MSB → LSB"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "text-fg",
												children: holo.oamBits || "—"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "overflow"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: holo.oamOverflow ? "yes" : "no"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "remainder"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: holo.oamRem ?? 0
										})] })
									]
								}) : holo.stage === "bytes" && holo.byteStages ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs",
									children: holo.byteStages.map((stage) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: stage.id === "processor-7" ? "col-span-2" : void 0,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: stage.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
											className: "text-fg",
											children: [
												stage.equivalent === true ? "CPU≡GPU" : stage.equivalent === false ? "diverged" : "restored",
												stage.cpuCycles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [
														" ",
														"· ",
														stage.cpuCycles.toLocaleString(),
														" cyc · ",
														stage.gpuWarps,
														" warps"
													]
												}) : null,
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [
														" ",
														"· ",
														(stage.owned ?? 0).toLocaleString(),
														" owned · ",
														stage.changed.toLocaleString(),
														" changed"
													]
												}),
												stage.same ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted",
													children: [" · same table as ", stage.same]
												}) : null
											]
										})]
									}, stage.id))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: "Run a cycle to project the field, diffract it, RAM-sample it, and walk the bright pixels along the intensity gradient."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: [
										"hpu bytes vortex",
										"hpu oam 13",
										"hpu shift left"
									].map((cmd) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-h-11 rounded-md border border-line px-3 font-mono text-xs text-fg",
										onClick: () => api.current?.run(cmd),
										children: cmd
									}, cmd))
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "The field is still settling. Run hpu cycle to close the five-stage loop."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs leading-relaxed text-muted",
								children: "16-bit phase leaves as TIFF. The relocated intensity leaves as GIF89a. Both stay on nvme0n1."
							})
						]
					}) : null,
					panel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "side",
						"aria-label": "SSD ledger",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs tracking-wide text-primary",
								children: status?.profile ?? "LOCAL_SSD"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-base font-medium text-fg",
								children: "SSD volume"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: detail
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 space-y-3 font-mono text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "epoch"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "truncate text-fg",
										children: status?.epoch ?? "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "boot seal"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "break-all text-fg",
										children: (status?.seal ?? "measuring").slice(0, 32)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "volume"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: !status ? "text-muted" : status.disk && !status.disk.synced ? "text-warn" : "text-ok",
										children: !status ? "—" : status.disk && !status.disk.synced ? "flushing" : status.drifted ? "on SSD · differs from seal" : "on SSD · matches seal"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "mb-1 text-muted",
										children: "used"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "meter",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${usedPct}%` } })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-fg",
										children: [
											fmtBytes(ram?.bytes),
											" / ",
											fmtBytes(ram?.maxBytes),
											" · ",
											ram ? `${ram.nodes} nodes` : "—"
										]
									})] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "block device"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-fg",
										children: status?.disk ? `${status.disk.device} · ${status.disk.model}` : "nvme0n1"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "protocol"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-fg",
										children: "hermit.vws.v2"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "fabric images"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 flex gap-2",
										children: (status?.nodes?.length ? status.nodes : [
											{
												key: "small",
												node: "N_SMALL",
												present: false,
												built: false
											},
											{
												key: "medium",
												node: "N_MEDIUM",
												present: false,
												built: false
											},
											{
												key: "large",
												node: "N_LARGE",
												present: false,
												built: false
											},
											{
												key: "xlarge",
												node: "N_XLARGE",
												present: false,
												built: false
											}
										]).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											title: n.node,
											className: `inline-block size-3 rounded-sm ${n.built ? "bg-primary" : "bg-line"}`
										}, n.key))
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-xs leading-relaxed text-muted",
								children: "Writes flush to nvme0n1. Power and reload remount the same volume. The seal is only the factory image."
							})
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "statusline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "chip",
						children: ["session ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: active ?? "—" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: status?.cwd ?? "~" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip",
						children: geom
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "chip",
						children: ["link ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: conn })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "chip hidden md:inline",
						children: [status?.disk?.device ?? "nvme0n1", status?.disk ? status.disk.synced ? " · synced" : " · syncing" : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip ml-auto hidden lg:inline",
						children: "Ctrl-C abort · Ctrl-L clear · Ctrl-Shift-T tab"
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ja21Console, {});
}
//#endregion
export { Home as component };
